function _0x2e3c(_0x46c7da, _0xf064) {
    var _0x5271e3 = _0x5271();
    return _0x2e3c = function(_0x2e3cae, _0x221a29) {
        _0x2e3cae = _0x2e3cae - 0x1f4;
        var _0x311ada = _0x5271e3[_0x2e3cae];
        return _0x311ada;
    }, _0x2e3c(_0x46c7da, _0xf064);
}
(function(_0x373aa1, _0x1741d7) {
    var _0x38a22a = _0x2e3c,
        _0x555c09 = _0x373aa1();
    while (!![]) {
        try {
            var _0x78c692 = -parseInt(_0x38a22a(0x1f4)) / 0x1 + -parseInt(_0x38a22a(0x1f5)) / 0x2 + parseInt(_0x38a22a(0x1f6)) / 0x3 * (parseInt(_0x38a22a(0x1f7)) / 0x4) + parseInt(_0x38a22a(0x1f8)) / 0x5 * (parseInt(_0x38a22a(0x1f9)) / 0x6) + -parseInt(_0x38a22a(0x1fa)) / 0x7 + parseInt(_0x38a22a(0x1fb)) / 0x8 * (parseInt(_0x38a22a(0x1fc)) / 0x9) + parseInt(_0x38a22a(0x1fd)) / 0xa;
            if (_0x78c692 === _0x1741d7)
                break;
            else
                _0x555c09['push'](_0x555c09['shift']());
        } catch (_0x54c94a) {
            _0x555c09['push'](_0x555c09['shift']());
        }
    }
}(_0x5271, 0x6ec4b), ! function() {
    var _0x274f5c = _0x2e3c;

    function _0x2a217c(_0x32c7e9) {
        var _0x23a9ca = _0x2e3c;
        return module[_0x23a9ca(0x1fe)] = _0x2a217c = Object['setPrototypeOf'] ? Object[_0x23a9ca(0x1ff)] : function(_0x6d0bab) {
            var _0x315c5a = _0x23a9ca;
            return _0x6d0bab['__proto__'] || Object[_0x315c5a(0x1ff)](_0x6d0bab);
        }, _0x2a217c(_0x32c7e9);
    }
    module[_0x274f5c(0x200)] = _0x2a217c;
}());

function _0x5271() {
    var _0x54459d = [
        '660IWxRSf',
        '2136gDkwhO',
        '2473240PcyrJS',
        '8GBVZCv',
        '172098CGXDVA',
        '11868300OcXDWk',
        'exports',
        'getPrototypeOf',
        '_getPrototypeOf',
        '277875Jolhpg',
        '937600bQXDmj',
        '3aQMGXz',
        '1203032jUZJgp'
    ];
    _0x5271 = function() {
        return _0x54459d;
    };
    return _0x5271();
}