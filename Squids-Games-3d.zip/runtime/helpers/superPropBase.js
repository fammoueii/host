(function(_0x4dcc0d, _0x5f1c88) {
    var _0x452bca = _0x581b,
        _0x42d3b4 = _0x4dcc0d();
    while (!![]) {
        try {
            var _0x47a307 = parseInt(_0x452bca(0xd7)) / 0x1 * (parseInt(_0x452bca(0xd8)) / 0x2) + -parseInt(_0x452bca(0xd9)) / 0x3 + parseInt(_0x452bca(0xda)) / 0x4 * (-parseInt(_0x452bca(0xdb)) / 0x5) + parseInt(_0x452bca(0xdc)) / 0x6 + -parseInt(_0x452bca(0xdd)) / 0x7 + parseInt(_0x452bca(0xde)) / 0x8 + -parseInt(_0x452bca(0xdf)) / 0x9;
            if (_0x47a307 === _0x5f1c88)
                break;
            else
                _0x42d3b4['push'](_0x42d3b4['shift']());
        } catch (_0x1e8600) {
            _0x42d3b4['push'](_0x42d3b4['shift']());
        }
    }
}(_0x1f09, 0x6463e), ! function() {
    var _0x4d460c = _0x581b,
        _0x38aa54 = require(_0x4d460c(0xe0));

    function _0x47baf0(_0x31ba3e, _0x4816be) {
        var _0x634456 = _0x4d460c;
        for (; !Object[_0x634456(0xe1)]['hasOwnProperty'][_0x634456(0xe2)](_0x31ba3e, _0x4816be) && null !== (_0x31ba3e = _0x38aa54(_0x31ba3e)););
        return _0x31ba3e;
    }
    module['_superPropBase'] = _0x47baf0;
}());

function _0x581b(_0x4d48dc, _0x1dcf2e) {
    var _0x1f091e = _0x1f09();
    return _0x581b = function(_0x581b0f, _0x2851c1) {
        _0x581b0f = _0x581b0f - 0xd7;
        var _0x2e27bc = _0x1f091e[_0x581b0f];
        return _0x2e27bc;
    }, _0x581b(_0x4d48dc, _0x1dcf2e);
}

function _0x1f09() {
    var _0x3aec15 = [
        'prototype',
        'call',
        '269058YryDqn',
        '6dmLJcd',
        '1246059VFugUw',
        '916108YsjzRR',
        '5jvejxg',
        '4082616dlyEjW',
        '1981434oCYUSV',
        '3368944IidklH',
        '5130792iGbIma',
        './getPrototypeOf'
    ];
    _0x1f09 = function() {
        return _0x3aec15;
    };
    return _0x1f09();
}