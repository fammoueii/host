function _0x10e6(_0x66330, _0x3e484a) {
    var _0x37c352 = _0x37c3();
    return _0x10e6 = function(_0x10e6d7, _0x330cdb) {
        _0x10e6d7 = _0x10e6d7 - 0xfd;
        var _0x18036c = _0x37c352[_0x10e6d7];
        return _0x18036c;
    }, _0x10e6(_0x66330, _0x3e484a);
}

function _0x37c3() {
    var _0x5a86b3 = [
        '6685FjBZSY',
        '1398lZRtAj',
        '3129JSWSuO',
        '10960pMxyPs',
        '933507AYFVlQ',
        '4264750fOgBkG',
        'undefined',
        'construct',
        'function',
        'prototype',
        'toString',
        'call',
        '_isNativeReflectConstruct',
        '288925JrfSqL',
        '1413628nFglFw',
        '3JlXNbY',
        '2397972SMFVTz'
    ];
    _0x37c3 = function() {
        return _0x5a86b3;
    };
    return _0x37c3();
}
(function(_0x3046f5, _0x18b752) {
    var _0x3411b3 = _0x10e6,
        _0x2b5ab2 = _0x3046f5();
    while (!![]) {
        try {
            var _0x1501a5 = -parseInt(_0x3411b3(0xfd)) / 0x1 + -parseInt(_0x3411b3(0xfe)) / 0x2 + parseInt(_0x3411b3(0xff)) / 0x3 * (parseInt(_0x3411b3(0x100)) / 0x4) + -parseInt(_0x3411b3(0x101)) / 0x5 * (-parseInt(_0x3411b3(0x102)) / 0x6) + parseInt(_0x3411b3(0x103)) / 0x7 * (parseInt(_0x3411b3(0x104)) / 0x8) + -parseInt(_0x3411b3(0x105)) / 0x9 + parseInt(_0x3411b3(0x106)) / 0xa;
            if (_0x1501a5 === _0x18b752)
                break;
            else
                _0x2b5ab2['push'](_0x2b5ab2['shift']());
        } catch (_0x37246b) {
            _0x2b5ab2['push'](_0x2b5ab2['shift']());
        }
    }
}(_0x37c3, 0xcf9f1), ! function() {
    var _0x43d629 = _0x10e6;

    function _0x362807() {
        var _0x5b40e0 = _0x10e6;
        if (_0x5b40e0(0x107) == typeof Reflect || !Reflect['construct'])
            return !0x1;
        if (Reflect[_0x5b40e0(0x108)]['sham'])
            return !0x1;
        if (_0x5b40e0(0x109) == typeof Proxy)
            return !0x0;
        try {
            return Date[_0x5b40e0(0x10a)][_0x5b40e0(0x10b)][_0x5b40e0(0x10c)](Reflect['construct'](Date, [], function() {})), !0x0;
        } catch (_0x5600bc) {
            return !0x1;
        }
    }
    module[_0x43d629(0x10d)] = _0x362807;
}());