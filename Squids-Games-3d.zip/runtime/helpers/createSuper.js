function _0x5ce6(_0x5a6918, _0x19d0fe) {
    var _0x5df720 = _0x5df7();
    return _0x5ce6 = function(_0x5ce66a, _0x34051b) {
        _0x5ce66a = _0x5ce66a - 0x10d;
        var _0x289b4a = _0x5df720[_0x5ce66a];
        return _0x289b4a;
    }, _0x5ce6(_0x5a6918, _0x19d0fe);
}

function _0x5df7() {
    var _0x156594 = [
        './isNativeReflectConstruct',
        'constructor',
        'construct',
        '1YgeVUP',
        '791766LHvTVV',
        '1603209oNxImQ',
        '4ElfXAV',
        '2215635iCGRpf',
        '1568058MaLWfu',
        '773570JwpCZH',
        '32JZkNfl',
        '193797ewypqN',
        '2262510LjgoFS',
        './getPrototypeOf'
    ];
    _0x5df7 = function() {
        return _0x156594;
    };
    return _0x5df7();
}
(function(_0x2d0f47, _0xbf05de) {
    var _0x48a9f0 = _0x5ce6,
        _0x4c1625 = _0x2d0f47();
    while (!![]) {
        try {
            var _0x54d27b = -parseInt(_0x48a9f0(0x10d)) / 0x1 * (-parseInt(_0x48a9f0(0x10e)) / 0x2) + parseInt(_0x48a9f0(0x10f)) / 0x3 * (-parseInt(_0x48a9f0(0x110)) / 0x4) + parseInt(_0x48a9f0(0x111)) / 0x5 + -parseInt(_0x48a9f0(0x112)) / 0x6 + parseInt(_0x48a9f0(0x113)) / 0x7 * (parseInt(_0x48a9f0(0x114)) / 0x8) + parseInt(_0x48a9f0(0x115)) / 0x9 + -parseInt(_0x48a9f0(0x116)) / 0xa;
            if (_0x54d27b === _0xbf05de)
                break;
            else
                _0x4c1625['push'](_0x4c1625['shift']());
        } catch (_0x43981b) {
            _0x4c1625['push'](_0x4c1625['shift']());
        }
    }
}(_0x5df7, 0x4480a), ! function() {
    var _0x19781a = _0x5ce6,
        _0x2c396c = require(_0x19781a(0x117)),
        _0x5883f6 = require(_0x19781a(0x118)),
        _0x549d6d = require('./possibleConstructorReturn');

    function _0x3f33e0(_0x2afa09) {
        var _0x4efeab = _0x5883f6();
        return function() {
            var _0x42824c = _0x5ce6,
                _0x1719b8, _0x18c6d5 = _0x2c396c(_0x2afa09);
            if (_0x4efeab) {
                var _0x22d02e = _0x2c396c(this)[_0x42824c(0x119)];
                _0x1719b8 = Reflect[_0x42824c(0x11a)](_0x18c6d5, arguments, _0x22d02e);
            } else
                _0x1719b8 = _0x18c6d5['apply'](this, arguments);
            return _0x549d6d(this, _0x1719b8);
        };
    }
    module['_createSuper'] = _0x3f33e0;
}());