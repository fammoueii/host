function _0xa6df() {
    var _0x1015e9 = [
        './superPropBase',
        './defineProperty',
        'undefined',
        'set',
        'getOwnPropertyDescriptor',
        'writable',
        'value',
        'defineProperty',
        'failed\x20to\x20set\x20property',
        '_set',
        '794518rpKKGv',
        '3641674AjGyLB',
        '3yZsaPX',
        '5076004VHTrvm',
        '5327150zrdnYQ',
        '6832734sYkYgY',
        '12650281djSNrN',
        '24943512IFwiQE'
    ];
    _0xa6df = function() {
        return _0x1015e9;
    };
    return _0xa6df();
}

function _0x55bc(_0x281cda, _0x255ca4) {
    var _0xa6dfd6 = _0xa6df();
    return _0x55bc = function(_0x55bc79, _0x1c864c) {
        _0x55bc79 = _0x55bc79 - 0x75;
        var _0x3f0ab2 = _0xa6dfd6[_0x55bc79];
        return _0x3f0ab2;
    }, _0x55bc(_0x281cda, _0x255ca4);
}
(function(_0x1aa6e4, _0x19fffb) {
    var _0x59a6b0 = _0x55bc,
        _0x1b00e3 = _0x1aa6e4();
    while (!![]) {
        try {
            var _0x527f29 = -parseInt(_0x59a6b0(0x75)) / 0x1 + -parseInt(_0x59a6b0(0x76)) / 0x2 + parseInt(_0x59a6b0(0x77)) / 0x3 * (-parseInt(_0x59a6b0(0x78)) / 0x4) + parseInt(_0x59a6b0(0x79)) / 0x5 + -parseInt(_0x59a6b0(0x7a)) / 0x6 + parseInt(_0x59a6b0(0x7b)) / 0x7 + parseInt(_0x59a6b0(0x7c)) / 0x8;
            if (_0x527f29 === _0x19fffb)
                break;
            else
                _0x1b00e3['push'](_0x1b00e3['shift']());
        } catch (_0x26de12) {
            _0x1b00e3['push'](_0x1b00e3['shift']());
        }
    }
}(_0xa6df, 0xec2ef), ! function() {
    var _0x101486 = _0x55bc,
        _0x29bbf5 = require(_0x101486(0x7d)),
        _0x117de5 = require(_0x101486(0x7e));

    function _0x431579(_0x538bdd, _0x2fee59, _0x50b82c, _0x2ad8a6) {
        var _0x279bfd = _0x101486;
        return (_0x431579 = _0x279bfd(0x7f) != typeof Reflect && Reflect[_0x279bfd(0x80)] ? Reflect['set'] : function(_0x26c34b, _0x5cc7c2, _0xd293e3, _0x2785ec) {
            var _0x3251d4 = _0x279bfd,
                _0x1c8fda, _0x9f36b3 = _0x29bbf5(_0x26c34b, _0x5cc7c2);
            if (_0x9f36b3) {
                if ((_0x1c8fda = Object[_0x3251d4(0x81)](_0x9f36b3, _0x5cc7c2))['set'])
                    return _0x1c8fda[_0x3251d4(0x80)]['call'](_0x2785ec, _0xd293e3), !0x0;
                if (!_0x1c8fda['writable'])
                    return !0x1;
            }
            if (_0x1c8fda = Object[_0x3251d4(0x81)](_0x2785ec, _0x5cc7c2)) {
                if (!_0x1c8fda[_0x3251d4(0x82)])
                    return !0x1;
                _0x1c8fda[_0x3251d4(0x83)] = _0xd293e3, Object[_0x3251d4(0x84)](_0x2785ec, _0x5cc7c2, _0x1c8fda);
            } else
                _0x117de5(_0x2785ec, _0x5cc7c2, _0xd293e3);
            return !0x0;
        })(_0x538bdd, _0x2fee59, _0x50b82c, _0x2ad8a6);
    }

    function _0x10fca3(_0x7da5b1, _0x11825a, _0x29615e, _0x4aa8c5, _0x91e8b0) {
        var _0x4e1426 = _0x101486;
        if (!_0x431579(_0x7da5b1, _0x11825a, _0x29615e, _0x4aa8c5 || _0x7da5b1) && _0x91e8b0)
            throw new Error(_0x4e1426(0x85));
        return _0x29615e;
    }
    module[_0x101486(0x86)] = _0x10fca3;
}());