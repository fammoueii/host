function _0x2362(_0x5aeff4, _0x3a088b) {
    var _0x5f22a4 = _0x5f22();
    return _0x2362 = function(_0x2362f8, _0x25a7d5) {
        _0x2362f8 = _0x2362f8 - 0x8c;
        var _0x356bff = _0x5f22a4[_0x2362f8];
        return _0x356bff;
    }, _0x2362(_0x5aeff4, _0x3a088b);
}

function _0x5f22() {
    var _0x52a554 = [
        './setPrototypeOf',
        'function',
        'Super\x20expression\x20must\x20either\x20be\x20null\x20or\x20a\x20function',
        'prototype',
        'create',
        '1bXBvcB',
        '468970awjoce',
        '18vYivYn',
        '168944tGUoAA',
        '4185XOlzEQ',
        '1284hsHmkR',
        '3082338FxkeGf',
        '4025424VjwKMu',
        '927747elwKid',
        '40FMhkLe',
        '3902536sFItnC'
    ];
    _0x5f22 = function() {
        return _0x52a554;
    };
    return _0x5f22();
}
(function(_0x4e3dc7, _0xe2c88c) {
    var _0x2f0559 = _0x2362,
        _0x14dd97 = _0x4e3dc7();
    while (!![]) {
        try {
            var _0x20b498 = -parseInt(_0x2f0559(0x8c)) / 0x1 * (-parseInt(_0x2f0559(0x8d)) / 0x2) + -parseInt(_0x2f0559(0x8e)) / 0x3 * (parseInt(_0x2f0559(0x8f)) / 0x4) + parseInt(_0x2f0559(0x90)) / 0x5 * (parseInt(_0x2f0559(0x91)) / 0x6) + -parseInt(_0x2f0559(0x92)) / 0x7 + parseInt(_0x2f0559(0x93)) / 0x8 + -parseInt(_0x2f0559(0x94)) / 0x9 * (-parseInt(_0x2f0559(0x95)) / 0xa) + -parseInt(_0x2f0559(0x96)) / 0xb;
            if (_0x20b498 === _0xe2c88c)
                break;
            else
                _0x14dd97['push'](_0x14dd97['shift']());
        } catch (_0x2bd2b5) {
            _0x14dd97['push'](_0x14dd97['shift']());
        }
    }
}(_0x5f22, 0x4480b), ! function() {
    var _0x5c7b4a = _0x2362,
        _0x408150 = require(_0x5c7b4a(0x97));

    function _0x1f524c(_0x58f459, _0x1bb343) {
        var _0x3c4d3d = _0x5c7b4a;
        if (_0x3c4d3d(0x98) != typeof _0x1bb343 && null !== _0x1bb343)
            throw new TypeError(_0x3c4d3d(0x99));
        _0x58f459[_0x3c4d3d(0x9a)] = Object[_0x3c4d3d(0x9b)](_0x1bb343 && _0x1bb343[_0x3c4d3d(0x9a)], {
            'constructor': {
                'value': _0x58f459,
                'writable': !0x0,
                'configurable': !0x0
            }
        }), _0x1bb343 && _0x408150(_0x58f459, _0x1bb343);
    }
    module['_inherits'] = _0x1f524c;
}());