function _0x3528(_0x56ff92, _0x55dc74) {
    const _0x50504 = _0x5050();
    return _0x3528 = function(_0x3528b0, _0x24a954) {
        _0x3528b0 = _0x3528b0 - 0x143;
        let _0x2196f8 = _0x50504[_0x3528b0];
        return _0x2196f8;
    }, _0x3528(_0x56ff92, _0x55dc74);
}

function _0x5050() {
    const _0x42b804 = [
        'onEnable',
        'owner',
        'top',
        'left',
        'getChildByName',
        'height',
        'pos',
        'closePer',
        'closeNoVideo',
        'noVideoPer',
        'Box,box_clickLayer',
        'box_clickLayer',
        'LOADING\x5cnPLEASE\x20WAIT…',
        'json',
        'loadingPer',
        'addComponent',
        'showLoading',
        'closeLoading',
        'createList',
        'img',
        'thumb',
        'size',
        'List',
        'itemRender',
        '_scrollList',
        'List,scrollAdList',
        'laya/pages/prefab/scrollList.prefab',
        'scrollAdList',
        'Image,img_ListBg',
        'di2.png',
        '30,\x2030,\x2030,\x2030',
        'img_ListBg',
        'Image,thumb',
        'di1.png',
        '30,30,30,30',
        'mask',
        'Image(scrollList)',
        'scaleNum',
        'sizeTran',
        'renderHandler',
        'itemRenderFun',
        'imgArr',
        'clearRes',
        'setSize',
        'scrollBar',
        'mouseWheelEnable',
        'mouseEnabled',
        'listArray',
        'concat',
        'centerX',
        'array',
        'loopList',
        'offAll',
        'MOUSE_OVER',
        'MOUSE_OUT',
        'endAni',
        'MORE',
        'dataSource',
        'value',
        'max',
        'Tween',
        'clearAll',
        'checkPoints',
        'onDisable',
        'getComponent',
        'setSpaceX',
        '_box_adTwo',
        'Box,box_adTwo',
        'Image,img_ad0',
        'laya/pages/prefab/box_adTwo.prefab',
        'img_ad0',
        'Image,img_ad1',
        'img_ad1',
        'Image,img_adImg',
        'img_adImg',
        'spaceNum',
        'img_ad0Ad',
        'img_ad1Ad',
        'img_ad0AdMask',
        'img_ad1AdMask',
        '_box_adTwo0',
        '_inst',
        'inst',
        'anchorX',
        'anchorY',
        'name',
        'leftAdBg',
        'sizeGrid',
        'leftAdMask',
        'leftAd',
        'rightAdMask',
        'rightAd',
        'rightAdBg',
        'spaceXNum',
        'sizeArr',
        'centerY',
        'imgMask',
        'hScrollBarSkin',
        'listAd',
        'touchScrollEnable',
        'frameLoop',
        'refresh',
        'scaleX',
        'scaleY',
        'visibleChangeFun',
        '44138XKLBRk',
        '4lnPGzR',
        '4377iodfVa',
        '524UeNxSW',
        '170795lEXKiq',
        '12zlZEyC',
        '768691gXirld',
        '414784lsJgkT',
        '45KxTFuG',
        '2530980cUFUWq',
        '8844011ffNsgl',
        'beEnabled',
        'tryToResumeIntervalId',
        'isVisibilityMuted',
        'adShowing',
        'init',
        'musicAudio',
        'document',
        'addEventListener',
        'tryToResumeAudioContext',
        'touchstart',
        'visibilitychange',
        'onVisibilitychange',
        'bind',
        'getContext',
        'onMusicStatechange',
        'soundAudio',
        'onSoundStatechange',
        'musicVolume',
        'isFocusOn',
        'Web\x20Audio\x20API',
        'visibilityState',
        'isMuted',
        'timer',
        'stage',
        'renderingEnabled',
        'updateTimer',
        'pause',
        'physicsTimer',
        'visible',
        'muted',
        'resume',
        'onDBInstanceMuted',
        'isSuspend',
        'bePauseMusic',
        'bePauseSound',
        'removeEventListener',
        'mousedown',
        'suspend',
        'pauseMusic',
        'stopAllNoLoop',
        'pauseSound',
        'stopAll',
        'parse',
        'playMusic',
        'stopMusic',
        'stopSound',
        'stop',
        'playSound',
        'play',
        'volume',
        '_audioInstances',
        'AudioContext',
        'context',
        'state',
        'suspended',
        'values',
        'instance',
        'source',
        'loop',
        'currentTime',
        'disconnect',
        'buffer',
        'onended',
        'setup',
        'has',
        'get',
        '_stopSound',
        '_music',
        '_musicVolume',
        'downloadArrayBuffer',
        'gain',
        'WebAudioEngine',
        'playBuffer',
        'error',
        'playBuffer\x20error.\x20Exception:\x20',
        'load',
        'setThreeD',
        'threeD',
        'createSoundInstance',
        'createGain',
        'ended',
        'createBufferSource',
        'setupPanning',
        'connect',
        'panner',
        'rolloffFactor',
        'destination',
        'url',
        'set',
        'decodeAudioData',
        'log',
        'Decode\x20error.',
        'open',
        'GET',
        'responseType',
        'arraybuffer',
        'onload',
        'status',
        'no\x20response',
        'onerror',
        'onabort',
        'send',
        'canNavigateActive_',
        'screen_',
        'prompt_',
        'initialized_',
        'needStartUp',
        'getInstance',
        '_instance',
        'initData',
        'getElementById',
        'mouseup',
        'onNavigate_',
        'touchend',
        'navigate',
        'to_',
        'LocalStorage',
        'getItem',
        'setStorageSync',
        'setItem',
        'stringify',
        'action_',
        'onblur',
        'onfocus',
        'showInterstitial',
        'scale',
        'focus',
        'showReward',
        'No\x20Available\x20Video',
        'Pls\x20watch\x20the\x20ad\x20completely,\x20so\x20that\x20you\x20can\x20claim\x20your\x20reward',
        'initList',
        'prompt',
        'createElement',
        'div',
        'style',
        'cssText',
        'body',
        'appendChild',
        'designWidth',
        'innerWidth',
        'innerHeight',
        'width',
        'innerHTML',
        'display',
        'inline',
        'opacity',
        'webkitTransition',
        '-webkit-transform\x20',
        's\x20ease-in,\x20opacity\x20',
        's\x20ease-in',
        'getForgames',
        'forgames',
        'slice',
        'length',
        'floor',
        'random',
        'createLogo',
        'Image',
        'yad',
        'skin',
        'zOrder',
        'yadstartup',
        'createNoVideo',
        'createLoading',
        'then',
        'SoundManager',
        'loader',
        'cnf.json',
        'Handler',
        'startupByYad',
        'getAdPlatformType',
        'scrollList',
        'box_adTwo',
        'en_GAMEDISTRIBUTION',
        'en_XIAOMI',
        'removeSelf',
        'MOUSE_DOWN',
        'GAME',
        'showBanner',
        'hideBanner',
        'showSplash',
        'hideSplash',
        'cargamesstartup',
        'create',
        'startupByCargames',
        'Event',
        'stopPropagation',
        'LOGO',
        'puzzlegamestartup',
        'startup',
        'addChild',
        'Prefab',
        'Script',
        'Box',
        'laya/pages/Prefab/NoVideo.prefab',
        'Box(NoVideo)',
        'Sprite',
        'Sprite,spr_tip,spr_tip',
        'spr_tip',
        'Rect',
        '#000000',
        'Label',
        'middle',
        '#ffffff',
        'Label(NoVideo)',
        'No\x20Video\x20Available',
        'center',
        'ani1'
    ];
    _0x5050 = function() {
        return _0x42b804;
    };
    return _0x5050();
}
(function(_0x350f44, _0x274053) {
    const _0x160875 = _0x3528,
        _0x50ce8b = _0x350f44();
    while (!![]) {
        try {
            const _0x207467 = -parseInt(_0x160875(0x143)) / 0x1 * (-parseInt(_0x160875(0x144)) / 0x2) + parseInt(_0x160875(0x145)) / 0x3 * (-parseInt(_0x160875(0x146)) / 0x4) + -parseInt(_0x160875(0x147)) / 0x5 * (-parseInt(_0x160875(0x148)) / 0x6) + -parseInt(_0x160875(0x149)) / 0x7 + -parseInt(_0x160875(0x14a)) / 0x8 * (parseInt(_0x160875(0x14b)) / 0x9) + -parseInt(_0x160875(0x14c)) / 0xa + parseInt(_0x160875(0x14d)) / 0xb;
            if (_0x207467 === _0x274053)
                break;
            else
                _0x50ce8b['push'](_0x50ce8b['shift']());
        } catch (_0x26e2ca) {
            _0x50ce8b['push'](_0x50ce8b['shift']());
        }
    }
}(_0x5050, 0x23f73), ! function() {
    const _0x1d5775 = _0x3528;
    class _0x44b52f {
        constructor() {
                const _0x11d7bc = _0x3528;
                this[_0x11d7bc(0x14e)] = ![], this['isMuted'] = ![], this['bePauseSound'] = ![], this['bePauseMusic'] = ![], this[_0x11d7bc(0x14f)] = -0x1, this[_0x11d7bc(0x150)] = ![], this[_0x11d7bc(0x151)] = ![];
            }
            [_0x1d5775(0x152)]() {
                return new Promise((_0x205c4e, _0x47b114) => {
                    const _0x134172 = _0x3528;
                    try {
                        this[_0x134172(0x153)] = new _0x1963f7(), this['soundAudio'] = new _0x1963f7(), window[_0x134172(0x154)][_0x134172(0x155)]('mousedown', () => {
                            setTimeout(() => {
                                const _0x2526b4 = _0x3528;
                                if (this['adShowing']) {} else
                                    this[_0x2526b4(0x156)]();
                            }, 0x64);
                        }, !![]), window[_0x134172(0x154)][_0x134172(0x155)](_0x134172(0x157), () => {
                            setTimeout(() => {
                                const _0x4d7a50 = _0x3528;
                                if (this[_0x4d7a50(0x151)]) {} else
                                    this[_0x4d7a50(0x156)]();
                            }, 0x64);
                        }, !![]), window[_0x134172(0x154)][_0x134172(0x155)](_0x134172(0x158), this[_0x134172(0x159)][_0x134172(0x15a)](this)), this[_0x134172(0x153)][_0x134172(0x15b)]()['onstatechange'] = this[_0x134172(0x15c)][_0x134172(0x15a)](this), this[_0x134172(0x15d)]['getContext']()['onstatechange'] = this[_0x134172(0x15e)][_0x134172(0x15a)](this), this[_0x134172(0x14e)] = !![], this[_0x134172(0x15f)] = 0x3c, this[_0x134172(0x160)] = ![], this[_0x134172(0x156)](), _0x205c4e(!![]);
                    } catch (_0x2fa479) {
                        console['log'](_0x134172(0x161), _0x2fa479), alert('Web\x20Audio\x20API\x20is\x20not\x20supported\x20in\x20this\x20browser'), _0x205c4e(![]);
                    }
                });
            }
            [_0x1d5775(0x159)]() {
                const _0x45ec09 = _0x1d5775;
                if (this[_0x45ec09(0x151)])
                    return;
                if (document[_0x45ec09(0x162)] == 'hidden')
                    !this[_0x45ec09(0x163)] && (this[_0x45ec09(0x150)] = this['muted'] = !![]), Laya[_0x45ec09(0x164)]['scale'] = 0x0, Laya[_0x45ec09(0x165)][_0x45ec09(0x166)] = ![], Laya[_0x45ec09(0x167)] && Laya[_0x45ec09(0x167)][_0x45ec09(0x168)](), Laya[_0x45ec09(0x169)] && Laya[_0x45ec09(0x169)][_0x45ec09(0x168)]();
                else
                    document[_0x45ec09(0x162)] == _0x45ec09(0x16a) && (this['isVisibilityMuted'] && (this['isVisibilityMuted'] = this[_0x45ec09(0x16b)] = ![]), Laya['timer']['scale'] = 0x1, Laya[_0x45ec09(0x165)][_0x45ec09(0x166)] = !![], Laya['updateTimer'] && Laya['updateTimer'][_0x45ec09(0x16c)](), Laya[_0x45ec09(0x169)] && Laya['physicsTimer'][_0x45ec09(0x16c)]());
            }
            [_0x1d5775(0x16d)]() {}
            [_0x1d5775(0x156)]() {
                const _0x17a8ec = _0x1d5775;
                if (this[_0x17a8ec(0x151)])
                    return;
                if (this[_0x17a8ec(0x163)])
                    return;
                this[_0x17a8ec(0x153)][_0x17a8ec(0x16e)]() && !this[_0x17a8ec(0x16f)] && !this[_0x17a8ec(0x163)] && this['musicAudio']['resume'](), this[_0x17a8ec(0x15d)]['isSuspend']() && !this[_0x17a8ec(0x170)] && !this[_0x17a8ec(0x163)] && this[_0x17a8ec(0x15d)][_0x17a8ec(0x16c)](), (!this[_0x17a8ec(0x153)][_0x17a8ec(0x16e)]() || !this['soundAudio'][_0x17a8ec(0x16e)]()) && (window[_0x17a8ec(0x154)][_0x17a8ec(0x171)](_0x17a8ec(0x172), this['tryToResumeAudioContext'][_0x17a8ec(0x15a)](this), !![]), window['document']['removeEventListener']('touchstart', this[_0x17a8ec(0x156)][_0x17a8ec(0x15a)](this), !![]), clearInterval(this['tryToResumeIntervalId']), this[_0x17a8ec(0x14f)] = -0x1);
            }
            [_0x1d5775(0x15c)]() {
                const _0x525c7e = _0x1d5775;
                this[_0x525c7e(0x153)][_0x525c7e(0x16e)]() && !this[_0x525c7e(0x163)] && !this[_0x525c7e(0x16f)] && this['tryToResumeIntervalId'] === -0x1 && (window['document'][_0x525c7e(0x155)](_0x525c7e(0x172), this['tryToResumeAudioContext'][_0x525c7e(0x15a)](this), !![]), window[_0x525c7e(0x154)][_0x525c7e(0x155)](_0x525c7e(0x157), this[_0x525c7e(0x156)]['bind'](this), !![]), this[_0x525c7e(0x14f)] = setInterval(this[_0x525c7e(0x156)][_0x525c7e(0x15a)](this), 0xc8));
            }
            [_0x1d5775(0x15e)]() {
                const _0x3b545a = _0x1d5775;
                this[_0x3b545a(0x15d)]['isSuspend']() && !this[_0x3b545a(0x163)] && !this[_0x3b545a(0x170)] && this['tryToResumeIntervalId'] === -0x1 && (window[_0x3b545a(0x154)][_0x3b545a(0x155)](_0x3b545a(0x172), this['tryToResumeAudioContext'][_0x3b545a(0x15a)](this), !![]), window[_0x3b545a(0x154)][_0x3b545a(0x155)](_0x3b545a(0x157), this[_0x3b545a(0x156)][_0x3b545a(0x15a)](this), !![]), this[_0x3b545a(0x14f)] = setInterval(this[_0x3b545a(0x156)]['bind'](this), 0xc8));
            }
        set[_0x1d5775(0x16b)](_0x13ee53) {
            const _0x48d72c = _0x1d5775;
            this[_0x48d72c(0x163)] = _0x13ee53, this[_0x48d72c(0x163)] ? (this[_0x48d72c(0x153)]['suspend'](), this['soundAudio'][_0x48d72c(0x173)]()) : this[_0x48d72c(0x14f)] == -0x1 && (this['tryToResumeIntervalId'] = setInterval(this[_0x48d72c(0x156)][_0x48d72c(0x15a)](this), 0xc8));
        }
        get[_0x1d5775(0x16b)]() {
            const _0xd2281c = _0x1d5775;
            return this[_0xd2281c(0x163)];
        }
        set['pause'](_0x18fb29) {
            const _0x313247 = _0x1d5775;
            this['pauseSound'] = _0x18fb29, this[_0x313247(0x174)] = _0x18fb29, !_0x18fb29 && this[_0x313247(0x15d)][_0x313247(0x175)]();
        }
        get[_0x1d5775(0x168)]() {
            const _0xb8f33a = _0x1d5775;
            return this['pauseSound'] || this[_0xb8f33a(0x174)];
        }
        set[_0x1d5775(0x176)](_0x27d61c) {
            const _0x10e180 = _0x1d5775;
            this[_0x10e180(0x170)] = _0x27d61c;
            if (this[_0x10e180(0x170)])
                this[_0x10e180(0x15d)][_0x10e180(0x173)]();
            else {
                if (this[_0x10e180(0x163)])
                    return;
                this[_0x10e180(0x15d)][_0x10e180(0x16c)]();
            }
        }
        get[_0x1d5775(0x176)]() {
            const _0x59ef24 = _0x1d5775;
            return this[_0x59ef24(0x170)];
        }
        get[_0x1d5775(0x174)]() {
            const _0x435505 = _0x1d5775;
            return this[_0x435505(0x16f)];
        }
        set[_0x1d5775(0x174)](_0x4e294d) {
                const _0x4d0eb5 = _0x1d5775;
                this[_0x4d0eb5(0x16f)] = _0x4e294d;
                if (this[_0x4d0eb5(0x16f)])
                    this[_0x4d0eb5(0x153)]['suspend']();
                else {
                    if (this['isMuted'])
                        return;
                    this[_0x4d0eb5(0x153)][_0x4d0eb5(0x16c)]();
                }
            }
            [_0x1d5775(0x177)]() {
                const _0x1bd92f = _0x1d5775;
                this['musicAudio']['stopAll'](), this['soundAudio'][_0x1bd92f(0x177)]();
            }
            [_0x1d5775(0x178)](_0x396700, _0x1cecf0, _0x1f6cc9) {
                const _0x46fdca = _0x1d5775;
                this[_0x46fdca(0x15d)][_0x46fdca(0x178)](_0x396700, _0x1cecf0);
            }
            [_0x1d5775(0x179)](_0xdd30b3) {
                const _0x289db5 = _0x1d5775;
                this[_0x289db5(0x153)][_0x289db5(0x177)](), this[_0x289db5(0x153)]['playMusic'](_0xdd30b3);
            }
            [_0x1d5775(0x17a)]() {
                const _0x440dd0 = _0x1d5775;
                this[_0x440dd0(0x153)][_0x440dd0(0x177)]();
            }
            [_0x1d5775(0x17b)](_0x4d07b9) {
                const _0x5d7732 = _0x1d5775;
                this[_0x5d7732(0x15d)][_0x5d7732(0x17c)](_0x4d07b9);
            }
        set[_0x1d5775(0x15f)](_0x2eeea9) {
            const _0x2dafd3 = _0x1d5775;
            this[_0x2dafd3(0x153)][_0x2dafd3(0x15f)] = _0x2eeea9;
        }
        get['musicVolume']() {
                const _0x330d7f = _0x1d5775;
                return this[_0x330d7f(0x153)]['musicVolume'];
            }
            [_0x1d5775(0x17d)](_0x4bd420, _0x31e1ff = ![], _0x500452 = ![]) {
                const _0x349df4 = _0x1d5775;
                if (!this[_0x349df4(0x14e)])
                    return;
                this[_0x349df4(0x15d)][_0x349df4(0x17e)](_0x4bd420, _0x31e1ff, _0x500452);
            }
    }
    class _0x4a4228 {}
    class _0x1963f7 {
        constructor() {
                const _0x10fcb3 = _0x1d5775;
                this[_0x10fcb3(0x17f)] = 0x64, this[_0x10fcb3(0x180)] = new Map(), this['_musicVolume'] = 0x64, window[_0x10fcb3(0x181)] = window[_0x10fcb3(0x181)] || window['webkitAudioContext'], this[_0x10fcb3(0x182)] = new AudioContext();
            }
            ['getContext']() {
                return this['context'];
            }
            [_0x1d5775(0x16e)]() {
                const _0x3f63de = _0x1d5775;
                return this['context'][_0x3f63de(0x183)] === _0x3f63de(0x184);
            }
            ['suspend']() {
                const _0x39f04d = _0x1d5775;
                return this[_0x39f04d(0x182)][_0x39f04d(0x173)]();
            }
            [_0x1d5775(0x16c)]() {
                const _0x343985 = _0x1d5775;
                return this['context'][_0x343985(0x16c)]();
            }
            [_0x1d5775(0x175)]() {
                const _0x3d3a33 = _0x1d5775,
                    _0x5614b5 = this[_0x3d3a33(0x180)][_0x3d3a33(0x185)]();
                for (const _0x3870df of _0x5614b5) {
                    const _0x215978 = _0x3870df[_0x3d3a33(0x186)];
                    if (_0x215978[_0x3d3a33(0x187)]['buffer'] && !_0x215978[_0x3d3a33(0x187)][_0x3d3a33(0x188)]) {
                        try {
                            _0x215978[_0x3d3a33(0x187)]['stop'](this[_0x3d3a33(0x182)][_0x3d3a33(0x189)]);
                        } catch (_0x1dae73) {
                            _0x215978[_0x3d3a33(0x187)][_0x3d3a33(0x18a)]();
                        }
                        _0x215978[_0x3d3a33(0x187)]['onended'] = function() {}, _0x215978['setup']();
                    }
                }
            }
            [_0x1d5775(0x177)]() {
                const _0xcd9f26 = _0x1d5775,
                    _0x96da0f = this[_0xcd9f26(0x180)][_0xcd9f26(0x185)]();
                for (const _0x1e88bc of _0x96da0f) {
                    const _0x3e4acf = _0x1e88bc['instance'];
                    if (_0x3e4acf['source'][_0xcd9f26(0x18b)]) {
                        try {
                            _0x3e4acf[_0xcd9f26(0x187)][_0xcd9f26(0x17c)](this[_0xcd9f26(0x182)][_0xcd9f26(0x189)]);
                        } catch (_0xa99b23) {
                            _0x3e4acf[_0xcd9f26(0x187)][_0xcd9f26(0x18a)]();
                        }
                        _0x3e4acf[_0xcd9f26(0x187)][_0xcd9f26(0x18c)] = function() {}, _0x3e4acf[_0xcd9f26(0x18d)]();
                    }
                }
            }
            ['stop'](_0x5d71ee) {
                const _0x4544a2 = _0x1d5775;
                if (this[_0x4544a2(0x180)][_0x4544a2(0x18e)](_0x5d71ee)) {
                    const _0x195cd0 = this[_0x4544a2(0x180)][_0x4544a2(0x18f)](_0x5d71ee);
                    this[_0x4544a2(0x190)](_0x195cd0);
                }
            }
            [_0x1d5775(0x190)](_0x98434c) {
                const _0x5e87d7 = _0x1d5775,
                    _0x323c40 = _0x98434c[_0x5e87d7(0x186)];
                if (_0x323c40[_0x5e87d7(0x187)][_0x5e87d7(0x18b)]) {
                    try {
                        _0x323c40['source']['stop'](this[_0x5e87d7(0x182)][_0x5e87d7(0x189)]);
                    } catch (_0x155359) {
                        _0x323c40[_0x5e87d7(0x187)][_0x5e87d7(0x18a)]();
                    }
                    _0x323c40[_0x5e87d7(0x187)]['onended'] = function() {}, _0x323c40[_0x5e87d7(0x18d)]();
                }
            }
            ['playMusic'](_0x33fac5) {
                const _0x403499 = _0x1d5775;
                this[_0x403499(0x191)] && this[_0x403499(0x190)](this[_0x403499(0x191)]), this['_audioInstances']['has'](_0x33fac5) ? (this[_0x403499(0x191)] = this[_0x403499(0x180)][_0x403499(0x18f)](_0x33fac5), this['musicVolume'] = this[_0x403499(0x192)], this[_0x403499(0x17e)](_0x33fac5, !![])) : this[_0x403499(0x193)](_0x33fac5, () => {
                    this['playMusic'](_0x33fac5);
                });
            }
            [_0x1d5775(0x17a)]() {
                const _0x5cf171 = _0x1d5775;
                this[_0x5cf171(0x191)] && this['_stopSound'](this[_0x5cf171(0x191)]);
            }
        set[_0x1d5775(0x15f)](_0x9333d2) {
            const _0x99e45c = _0x1d5775;
            this[_0x99e45c(0x192)] = _0x9333d2, this[_0x99e45c(0x191)] && (this[_0x99e45c(0x191)]['instance'][_0x99e45c(0x194)][_0x99e45c(0x194)]['value'] = this[_0x99e45c(0x192)] / 0x64);
        }
        get['musicVolume']() {
                return this['_musicVolume'];
            }
            [_0x1d5775(0x17e)](_0x507629, _0x4a1fbc = ![], _0x4d4e65 = ![]) {
                const _0xbc1198 = _0x1d5775;
                if (this[_0xbc1198(0x180)][_0xbc1198(0x18e)](_0x507629)) {
                    const _0x451c9d = this[_0xbc1198(0x180)][_0xbc1198(0x18f)](_0x507629),
                        _0x4815db = _0x451c9d[_0xbc1198(0x186)];
                    if (_0x4d4e65 && !_0x4815db['ended'])
                        return;
                    this[_0xbc1198(0x17c)](_0x507629);
                    if (_0x451c9d[_0xbc1198(0x18b)])
                        try {
                            if (window[_0xbc1198(0x195)][_0xbc1198(0x168)] && !_0x4a1fbc)
                                return;
                            _0x4815db[_0xbc1198(0x196)](this['context'][_0xbc1198(0x189)], _0x451c9d[_0xbc1198(0x18b)]), _0x4815db[_0xbc1198(0x187)][_0xbc1198(0x188)] = _0x4a1fbc;
                        } catch (_0xd45bf8) {
                            console[_0xbc1198(0x197)](_0xbc1198(0x198) + _0xd45bf8);
                        }
                } else
                    this[_0xbc1198(0x193)](_0x507629, () => {
                        const _0x2c13d6 = _0xbc1198;
                        this[_0x2c13d6(0x17e)](_0x507629, _0x4a1fbc);
                    });
            }
            [_0x1d5775(0x199)](_0x4e66e3, _0x16bf3d) {
                const _0x12e7e0 = _0x1d5775;
                let _0x14fad5 = _0x4e66e3['length'],
                    _0x2f6529 = 0x0;
                for (let _0x49e994 = 0x0; _0x49e994 < _0x4e66e3['length']; _0x49e994++) {
                    const _0x2ef53a = _0x4e66e3[_0x49e994];
                    this[_0x12e7e0(0x193)](_0x2ef53a, () => {
                        _0x2f6529++, _0x2f6529 >= _0x14fad5 && (_0x16bf3d && _0x16bf3d());
                    });
                }
            }
            [_0x1d5775(0x19a)](_0xd09705) {
                const _0x2a9c10 = _0x1d5775;
                if (this[_0x2a9c10(0x180)][_0x2a9c10(0x18e)](_0xd09705)) {
                    const _0x251014 = this[_0x2a9c10(0x180)][_0x2a9c10(0x18f)](_0xd09705);
                    _0x251014['instance'][_0x2a9c10(0x19b)] = !![];
                }
            }
            [_0x1d5775(0x19c)]() {
                const _0x109762 = _0x1d5775;
                let _0x203c8d = this[_0x109762(0x182)];
                const _0x1bf2cf = {
                    'gain': _0x203c8d[_0x109762(0x19d)](),
                    'panner': _0x203c8d['createPanner'](),
                    'threeD': ![],
                    'ended': ![],
                    'playBuffer': function(_0x3114cf, _0x4954d2, _0x402beb) {
                        const _0x3200ea = _0x109762;
                        this['source'][_0x3200ea(0x18b)] = _0x4954d2;
                        var _0x32b686 = this;
                        this[_0x3200ea(0x19e)] = ![], this[_0x3200ea(0x187)][_0x3200ea(0x18c)] = function() {
                            const _0x4c0a0a = _0x3200ea;
                            _0x32b686[_0x4c0a0a(0x18d)](), _0x32b686[_0x4c0a0a(0x19e)] = !![];
                        }, this[_0x3200ea(0x187)]['start'](_0x3114cf, _0x402beb);
                    },
                    'setup': function() {
                        const _0x42c142 = _0x109762;
                        this[_0x42c142(0x187)] = _0x203c8d[_0x42c142(0x19f)](), this[_0x42c142(0x1a0)]();
                    },
                    'setupPanning': function() {
                        const _0x5c2fd2 = _0x109762;
                        this[_0x5c2fd2(0x19b)] ? (this[_0x5c2fd2(0x187)][_0x5c2fd2(0x18a)](), this[_0x5c2fd2(0x187)][_0x5c2fd2(0x1a1)](this['panner']), this[_0x5c2fd2(0x1a2)][_0x5c2fd2(0x1a1)](this[_0x5c2fd2(0x194)])) : (this[_0x5c2fd2(0x1a2)]['disconnect'](), this['source'][_0x5c2fd2(0x1a1)](this[_0x5c2fd2(0x194)]));
                    }
                };
                return _0x1bf2cf[_0x109762(0x1a2)][_0x109762(0x1a3)] = 0x0, _0x1bf2cf['gain'][_0x109762(0x1a1)](this[_0x109762(0x182)][_0x109762(0x1a4)]), _0x1bf2cf[_0x109762(0x18d)](), _0x1bf2cf;
            }
            [_0x1d5775(0x178)](_0x451cfa, _0x46c7ad, _0x11f0e2) {
                const _0x1778a2 = _0x1d5775,
                    _0x1e9532 = new _0x4a4228();
                _0x1e9532[_0x1778a2(0x1a5)] = _0x451cfa, _0x1e9532[_0x1778a2(0x186)] = this[_0x1778a2(0x19c)](), this[_0x1778a2(0x180)][_0x1778a2(0x1a6)](_0x451cfa, _0x1e9532), this['context'][_0x1778a2(0x1a7)](_0x46c7ad, function(_0x511aad) {
                    const _0x25b46a = _0x1778a2;
                    _0x1e9532[_0x25b46a(0x18b)] = _0x511aad, _0x11f0e2 && _0x11f0e2();
                }, function(_0x1b5303) {
                    const _0x9aaeca = _0x1778a2;
                    _0x1e9532[_0x9aaeca(0x197)] = !![], _0x11f0e2 && _0x11f0e2(), console[_0x9aaeca(0x1a8)](_0x9aaeca(0x1a9) + _0x1e9532['url']);
                });
            }
            [_0x1d5775(0x193)](_0x3c74bc, _0x6d66ae) {
                const _0x4c2bb5 = _0x1d5775;
                if (this['_audioInstances'][_0x4c2bb5(0x18e)](_0x3c74bc)) {
                    _0x6d66ae && _0x6d66ae();
                    return;
                }
                const _0x18b0ac = this;
                var _0xb6fbb3 = new XMLHttpRequest();
                _0xb6fbb3[_0x4c2bb5(0x1aa)](_0x4c2bb5(0x1ab), _0x3c74bc, !![]), _0xb6fbb3[_0x4c2bb5(0x1ac)] = _0x4c2bb5(0x1ad), _0xb6fbb3[_0x4c2bb5(0x1ae)] = function() {
                    const _0x3c0800 = _0x4c2bb5;
                    if (_0xb6fbb3[_0x3c0800(0x1af)] === 0xc8 || _0xb6fbb3[_0x3c0800(0x1af)] === 0x0)
                        _0x18b0ac['parse'](_0x3c74bc, _0xb6fbb3['response'], _0x6d66ae);
                    else
                        throw _0x3c0800(0x1b0);
                }, _0xb6fbb3[_0x4c2bb5(0x1b1)] = function() {
                    const _0x387927 = _0x4c2bb5;
                    _0x6d66ae && _0x6d66ae();
                    throw _0x387927(0x1b0);
                }, _0xb6fbb3['ontimeout'] = function() {
                    _0x6d66ae && _0x6d66ae();
                }, _0xb6fbb3[_0x4c2bb5(0x1b2)] = function() {
                    _0x6d66ae && _0x6d66ae();
                }, _0xb6fbb3[_0x4c2bb5(0x1b3)](null);
            }
    }
    const _0x4d5009 = window[_0x1d5775(0x195)] = new _0x44b52f();
    class _0x2ff701 {
        constructor() {
            const _0x1ee9ff = _0x1d5775;
            this[_0x1ee9ff(0x1b4)] = ![], this[_0x1ee9ff(0x1b5)] = '', this['action_'] = '', this['to_'] = '', this[_0x1ee9ff(0x1b6)] = null, this[_0x1ee9ff(0x1b7)] = ![], this[_0x1ee9ff(0x1b8)] = !![], this['initData']();
        }
        static[_0x1d5775(0x1b9)]() {
                const _0x4f6f06 = _0x1d5775;
                return !this[_0x4f6f06(0x1ba)] && (this[_0x4f6f06(0x1ba)] = new _0x2ff701()), this[_0x4f6f06(0x1ba)];
            }
            [_0x1d5775(0x1bb)]() {
                const _0x29776b = _0x1d5775;
                let _0x515527 = document[_0x29776b(0x1bc)]('layaCanvas');
                _0x515527 && (_0x515527[_0x29776b(0x155)](_0x29776b(0x1bd), this[_0x29776b(0x1be)]['bind'](this)), _0x515527[_0x29776b(0x155)](_0x29776b(0x1bf), this[_0x29776b(0x1be)][_0x29776b(0x15a)](this)));
            }
            [_0x1d5775(0x1be)]() {
                const _0x25911f = _0x1d5775;
                this[_0x25911f(0x1b4)] && YYGGames[_0x25911f(0x1c0)](this[_0x25911f(0x1b5)], this['action_'], this[_0x25911f(0x1c1)]), this[_0x25911f(0x1b4)] = ![];
            }
            ['getStorageSync'](_0x57efe8) {
                const _0x444789 = _0x1d5775;
                let _0x1210f3 = null;
                try {
                    let _0x6b61d4 = Laya[_0x444789(0x1c2)][_0x444789(0x1c3)](_0x57efe8);
                    _0x1210f3 = JSON[_0x444789(0x178)](_0x6b61d4);
                } catch (_0xc62e6c) {}
                return _0x1210f3;
            }
            [_0x1d5775(0x1c4)](_0x423a86, _0x11e0e2) {
                const _0x2b9fb1 = _0x1d5775;
                return Laya[_0x2b9fb1(0x1c2)][_0x2b9fb1(0x1c5)](_0x423a86, JSON[_0x2b9fb1(0x1c6)](_0x11e0e2));
            }
            [_0x1d5775(0x1c0)](_0x2443e4, _0x2fc9c9, _0x5c94fe) {
                const _0x58a147 = _0x1d5775;
                this[_0x58a147(0x1b4)] === ![] && (this['screen_'] = _0x2443e4, this[_0x58a147(0x1c7)] = _0x2fc9c9, this[_0x58a147(0x1c1)] = _0x5c94fe, this[_0x58a147(0x1b4)] = !![]);
            }
            [_0x1d5775(0x1c8)]() {
                setTimeout(() => {
                    const _0x357f28 = _0x3528;
                    _0x4d5009[_0x357f28(0x16b)] = !![];
                }, 0x64);
            }
            [_0x1d5775(0x1c9)]() {
                setTimeout(() => {
                    const _0x479a73 = _0x3528;
                    _0x4d5009[_0x479a73(0x16b)] = ![];
                }, 0x64);
            }
            [_0x1d5775(0x1ca)](_0x5e1431) {
                const _0x1508df = _0x1d5775;
                YYGGames[_0x1508df(0x1ca)]({
                    'beforeShowAd': () => {
                        const _0x4a6643 = _0x1508df;
                        window['WebAudioEngine']['adShowing'] = !![], this['onblur'](), Laya[_0x4a6643(0x164)][_0x4a6643(0x1cb)] = 0x0, Laya['stage'][_0x4a6643(0x166)] = ![], Laya['updateTimer'] && Laya[_0x4a6643(0x167)][_0x4a6643(0x168)](), Laya[_0x4a6643(0x169)] && Laya[_0x4a6643(0x169)][_0x4a6643(0x168)]();
                    },
                    'afterShowAd': () => {
                        const _0x4a1807 = _0x1508df;
                        window[_0x4a1807(0x1cc)](), this[_0x4a1807(0x1c9)](), window['WebAudioEngine'][_0x4a1807(0x151)] = ![], Laya[_0x4a1807(0x164)][_0x4a1807(0x1cb)] = 0x1, Laya[_0x4a1807(0x165)][_0x4a1807(0x166)] = !![], Laya[_0x4a1807(0x167)] && Laya[_0x4a1807(0x167)][_0x4a1807(0x16c)](), Laya[_0x4a1807(0x169)] && Laya[_0x4a1807(0x169)][_0x4a1807(0x16c)](), _0x5e1431 && _0x5e1431();
                    }
                });
            }
            [_0x1d5775(0x1cd)](_0x37a633, _0x4fda5a, _0x6c733f) {
                const _0x3c1f82 = _0x1d5775;
                if (!YYGGames['canShowReward']()) {
                    this['prompt'](_0x3c1f82(0x1ce)), _0x6c733f && _0x6c733f();
                    return;
                }
                YYGGames[_0x3c1f82(0x1cd)]({
                    'beforeShowAd': () => {
                        const _0x1a356b = _0x3c1f82;
                        window['WebAudioEngine']['adShowing'] = !![], this[_0x1a356b(0x1c8)](), Laya[_0x1a356b(0x164)]['scale'] = 0x0, Laya[_0x1a356b(0x165)]['renderingEnabled'] = ![], Laya[_0x1a356b(0x167)] && Laya['updateTimer'][_0x1a356b(0x168)](), Laya[_0x1a356b(0x169)] && Laya[_0x1a356b(0x169)][_0x1a356b(0x168)]();
                    },
                    'afterShowAd': () => {
                        const _0xd897e4 = _0x3c1f82;
                        window['focus'](), this[_0xd897e4(0x1c9)](), window['WebAudioEngine'][_0xd897e4(0x151)] = ![], Laya[_0xd897e4(0x164)][_0xd897e4(0x1cb)] = 0x1, Laya[_0xd897e4(0x165)]['renderingEnabled'] = !![], Laya[_0xd897e4(0x167)] && Laya['updateTimer'][_0xd897e4(0x16c)](), Laya['physicsTimer'] && Laya[_0xd897e4(0x169)]['resume']();
                    },
                    'rewardComplete': () => {
                        _0x37a633 && _0x37a633(), _0x6c733f && _0x6c733f(), _0x6c733f = null, _0x37a633 = null;
                    },
                    'rewardDismissed': () => {
                        const _0x1bb459 = _0x3c1f82;
                        _0x4fda5a && (_0x4fda5a(), _0x6c733f && _0x6c733f(), _0x6c733f = null, _0x4fda5a = null), this['prompt'](_0x1bb459(0x1cf));
                    }
                });
            }
            [_0x1d5775(0x1d0)](_0x5a6f7f) {}
            [_0x1d5775(0x1d1)](_0x2e74ce, _0x583be4) {
                const _0x19170c = _0x1d5775;
                !this[_0x19170c(0x1b6)] && (this[_0x19170c(0x1b6)] = document[_0x19170c(0x1d2)](_0x19170c(0x1d3)), this['prompt_'][_0x19170c(0x1d4)][_0x19170c(0x1d5)] = 'overflow:\x20hidden;word-break:\x20break-all;word-wrap:\x20break-word;font-family:siyuan;padding:10px\x2010px\x2010px\x2010px;min-height:40px;color:\x20rgb(255,\x20255,\x20255);line-height:\x2020px;text-align:center;border-radius:\x204px;position:\x20fixed;top:\x2040%;left:\x2050%;transform:\x20translate(-50%,\x20-50%);z-index:\x20999999;background:\x20rgba(0,\x200,\x200,.7);font-size:\x2016px;', document[_0x19170c(0x1d6)][_0x19170c(0x1d7)](this['prompt_']));
                const _0x24678d = Laya[_0x19170c(0x165)][_0x19170c(0x1d8)],
                    _0x6fdd4e = Laya[_0x19170c(0x165)]['designHeight'];
                var _0x50110a = window[_0x19170c(0x1d9)],
                    _0x25c93d = window[_0x19170c(0x1da)],
                    _0x3bae67, _0x4cfe6b;
                _0x50110a / _0x25c93d > _0x24678d / _0x6fdd4e ? (_0x3bae67 = _0x25c93d, _0x4cfe6b = _0x3bae67 * _0x24678d / _0x6fdd4e) : (_0x4cfe6b = _0x50110a, _0x3bae67 = _0x4cfe6b * _0x6fdd4e / _0x24678d), this['prompt_'][_0x19170c(0x1d4)][_0x19170c(0x1db)] = _0x4cfe6b - 0x32 + 'px', this[_0x19170c(0x1b6)][_0x19170c(0x1dc)] = _0x2e74ce, _0x583be4 = isNaN(_0x583be4) ? 0x7d0 : _0x583be4, this['prompt_'][_0x19170c(0x1d4)][_0x19170c(0x1dd)] = _0x19170c(0x1de), this['prompt_'][_0x19170c(0x1d4)][_0x19170c(0x1df)] = '1', setTimeout(function() {
                    const _0x5ecdf2 = _0x19170c;
                    var _0x345244 = 0.5;
                    this['prompt_'][_0x5ecdf2(0x1d4)][_0x5ecdf2(0x1e0)] = _0x5ecdf2(0x1e1) + _0x345244 + _0x5ecdf2(0x1e2) + _0x345244 + _0x5ecdf2(0x1e3), this[_0x5ecdf2(0x1b6)][_0x5ecdf2(0x1d4)][_0x5ecdf2(0x1df)] = '0', this['prompt_'][_0x5ecdf2(0x1d4)][_0x5ecdf2(0x1dd)] = 'none';
                }['bind'](this), _0x583be4);
            }
            [_0x1d5775(0x1e4)]() {
                const _0x2f86be = _0x1d5775;
                let _0x2aae88 = YYGGames[_0x2f86be(0x1e5)] || [],
                    _0x3e01b4 = _0x2aae88[_0x2f86be(0x1e6)]();
                for (let _0x2bb56e = 0x0, _0x1f0bb9 = _0x3e01b4[_0x2f86be(0x1e7)]; _0x2bb56e < _0x1f0bb9; _0x2bb56e++) {
                    const _0x19ed21 = Math[_0x2f86be(0x1e8)](Math[_0x2f86be(0x1e9)]() * (_0x2bb56e + 0x1)),
                        _0x4835a1 = _0x3e01b4[_0x19ed21];
                    _0x3e01b4[_0x19ed21] = _0x3e01b4[_0x2bb56e], _0x3e01b4[_0x2bb56e] = _0x4835a1;
                }
                return _0x3e01b4;
            }
            [_0x1d5775(0x1ea)]() {
                const _0x11c46f = _0x1d5775;
                if (!Laya || !Laya[_0x11c46f(0x1eb)])
                    return null;
                if (!window[_0x11c46f(0x1ec)]) {
                    const _0xa6b1e2 = new Laya[(_0x11c46f(0x1eb))]();
                    _0xa6b1e2[_0x11c46f(0x1ed)] = 'yad.png', _0xa6b1e2[_0x11c46f(0x1ee)] = 0x30d40, window['yad'] = _0xa6b1e2;
                }
                return window[_0x11c46f(0x1ec)];
            }
            [_0x1d5775(0x1ef)](_0x1651d6, _0x58c7f9) {
                const _0x4806b7 = _0x1d5775;
                !this['needStartUp'] && (_0x58c7f9 && _0x58c7f9());
                if (this[_0x4806b7(0x1b7)])
                    return;
                _0x2ff701[_0x4806b7(0x1b9)]()['showSplash'](), _0x2ff701['getInstance']()[_0x4806b7(0x1ea)](), this[_0x4806b7(0x1f0)](), this[_0x4806b7(0x1f1)](), window['WebAudioEngine'][_0x4806b7(0x152)]()[_0x4806b7(0x1f2)](() => {
                    const _0x4c9a07 = _0x4806b7;
                    Laya[_0x4c9a07(0x1f3)][_0x4c9a07(0x179)] = function(_0x1c2013) {
                        const _0x146b8c = _0x4c9a07;
                        window[_0x146b8c(0x195)] && window['WebAudioEngine']['playMusic'](_0x1c2013);
                    }, Laya[_0x4c9a07(0x1f3)][_0x4c9a07(0x17d)] = function(_0x5e4d27, _0x5f392e = ![]) {
                        const _0x4525a2 = _0x4c9a07;
                        window[_0x4525a2(0x195)] && window[_0x4525a2(0x195)][_0x4525a2(0x17d)](_0x5e4d27);
                    }, Laya['SoundManager'][_0x4c9a07(0x17a)] = function() {
                        const _0x3d16aa = _0x4c9a07;
                        window['WebAudioEngine'] && window[_0x3d16aa(0x195)][_0x3d16aa(0x17a)]();
                    }, Laya[_0x4c9a07(0x1f3)]['stopSound'] = function(_0x49321e) {
                        const _0x40a232 = _0x4c9a07;
                        window[_0x40a232(0x195)] && window['WebAudioEngine'][_0x40a232(0x17b)](_0x49321e);
                    };
                }), this[_0x4806b7(0x1b7)] = !![], Laya[_0x4806b7(0x1f4)][_0x4806b7(0x199)](_0x4806b7(0x1f5), Laya[_0x4806b7(0x1f6)]['create'](this, _0x198461 => {
                    const _0x3237df = _0x4806b7;
                    YYGGames[_0x3237df(0x1f7)]({
                        'appName': _0x1651d6,
                        'config': _0x198461,
                        'complete': () => {
                            const _0x354e5f = _0x3237df,
                                _0x2ec519 = YYGGames[_0x354e5f(0x1f8)]();
                            window[_0x354e5f(0x1f9)] = this['scrollList'](), window[_0x354e5f(0x1fa)] = this['box_adTwo']();
                            switch (_0x2ec519) {
                                case AdPlatformType[_0x354e5f(0x1fb)]:
                                case AdPlatformType[_0x354e5f(0x1fc)]:
                                    window[_0x354e5f(0x1ec)] && (window[_0x354e5f(0x1ec)][_0x354e5f(0x1cb)](0x0, 0x0), window[_0x354e5f(0x1ec)][_0x354e5f(0x1fd)]());
                                    break;
                                default:
                                    window[_0x354e5f(0x1ec)] && Laya[_0x354e5f(0x165)]['addChild'](window[_0x354e5f(0x1ec)]), window[_0x354e5f(0x1ec)]['on'](Laya['Event'][_0x354e5f(0x1fe)], window['yad'], _0x10a23d => {
                                        const _0x33ddd7 = _0x354e5f;
                                        _0x10a23d['stopPropagation'](), _0x2ff701['getInstance']()[_0x33ddd7(0x1c0)](_0x33ddd7(0x1ff), 'LOGO');
                                    });
                                    break;
                            }
                            this[_0x354e5f(0x1b8)] = ![], _0x58c7f9 && _0x58c7f9();
                        }
                    });
                }));
            }
            [_0x1d5775(0x200)](_0xda2512) {
                const _0x2057ae = _0x1d5775;
                _0xda2512 ? YYGGames[_0x2057ae(0x200)](_0xda2512) : YYGGames['showBanner']();
            }
            [_0x1d5775(0x201)]() {
                const _0x3f43e1 = _0x1d5775;
                YYGGames[_0x3f43e1(0x201)]();
            }
            ['showSplash'](_0x571b17) {
                const _0x2379ba = _0x1d5775;
                _0x571b17 ? YYGGames['showSplash'](_0x571b17) : YYGGames[_0x2379ba(0x202)]();
            }
            [_0x1d5775(0x203)]() {
                const _0x54c629 = _0x1d5775;
                YYGGames[_0x54c629(0x203)]();
            }
            [_0x1d5775(0x204)](_0x533c67, _0x4f32e5) {
                const _0x318769 = _0x1d5775;
                !this[_0x318769(0x1b8)] && (_0x4f32e5 && _0x4f32e5());
                if (this[_0x318769(0x1b7)])
                    return;
                _0x2ff701[_0x318769(0x1b9)]()[_0x318769(0x202)](), _0x2ff701['getInstance']()['createLogo'](), this[_0x318769(0x1f0)](), this[_0x318769(0x1f1)](), window[_0x318769(0x195)]['init']()[_0x318769(0x1f2)](() => {
                    const _0x34cd49 = _0x318769;
                    Laya[_0x34cd49(0x1f3)][_0x34cd49(0x179)] = function(_0x1e53ce) {
                        window['WebAudioEngine'] && window['WebAudioEngine']['playMusic'](_0x1e53ce);
                    }, Laya[_0x34cd49(0x1f3)]['playSound'] = function(_0x381920, _0x593eb0 = ![]) {
                        const _0x5b0d62 = _0x34cd49;
                        window[_0x5b0d62(0x195)] && window[_0x5b0d62(0x195)][_0x5b0d62(0x17d)](_0x381920);
                    }, Laya['SoundManager'][_0x34cd49(0x17a)] = function() {
                        const _0x290831 = _0x34cd49;
                        window[_0x290831(0x195)] && window[_0x290831(0x195)][_0x290831(0x17a)]();
                    }, Laya[_0x34cd49(0x1f3)][_0x34cd49(0x17b)] = function(_0x3f37ba) {
                        const _0x3aa48b = _0x34cd49;
                        window[_0x3aa48b(0x195)] && window[_0x3aa48b(0x195)][_0x3aa48b(0x17b)](_0x3f37ba);
                    };
                }), this[_0x318769(0x1b7)] = !![], Laya[_0x318769(0x1f4)][_0x318769(0x199)]('cnf.json', Laya[_0x318769(0x1f6)][_0x318769(0x205)](this, _0x487acb => {
                    const _0x46b628 = _0x318769;
                    YYGGames[_0x46b628(0x206)]({
                        'appName': _0x533c67,
                        'config': _0x487acb,
                        'complete': () => {
                            const _0x57c3b8 = _0x46b628,
                                _0x6f2ec3 = YYGGames['getAdPlatformType']();
                            window[_0x57c3b8(0x1f9)] = this['scrollList'](), window[_0x57c3b8(0x1fa)] = this[_0x57c3b8(0x1fa)]();
                            switch (_0x6f2ec3) {
                                case AdPlatformType[_0x57c3b8(0x1fb)]:
                                case AdPlatformType[_0x57c3b8(0x1fc)]:
                                    window[_0x57c3b8(0x1ec)] && (window['yad'][_0x57c3b8(0x1cb)](0x0, 0x0), window[_0x57c3b8(0x1ec)]['removeSelf']());
                                    break;
                                default:
                                    window[_0x57c3b8(0x1ec)] && Laya[_0x57c3b8(0x165)]['addChild'](window[_0x57c3b8(0x1ec)]), window['yad']['on'](Laya[_0x57c3b8(0x207)][_0x57c3b8(0x1fe)], window['yad'], _0x380d63 => {
                                        const _0x471316 = _0x57c3b8;
                                        _0x380d63[_0x471316(0x208)](), _0x2ff701[_0x471316(0x1b9)]()[_0x471316(0x1c0)](_0x471316(0x1ff), _0x471316(0x209));
                                    });
                                    break;
                            }
                            this[_0x57c3b8(0x1b8)] = ![], _0x4f32e5 && _0x4f32e5();
                        }
                    });
                }));
            }
            [_0x1d5775(0x20a)](_0x4a4cba, _0x2bc450) {
                const _0x10991c = _0x1d5775;
                !this['needStartUp'] && (_0x2bc450 && _0x2bc450());
                if (this[_0x10991c(0x1b7)])
                    return;
                _0x2ff701[_0x10991c(0x1b9)]()[_0x10991c(0x202)](), _0x2ff701[_0x10991c(0x1b9)]()[_0x10991c(0x1ea)](), this[_0x10991c(0x1f0)](), this['createLoading'](), window['WebAudioEngine']['init']()[_0x10991c(0x1f2)](() => {
                    const _0x220d0a = _0x10991c;
                    Laya[_0x220d0a(0x1f3)][_0x220d0a(0x179)] = function(_0x97ac6b) {
                        const _0x1324b8 = _0x220d0a;
                        window[_0x1324b8(0x195)] && window[_0x1324b8(0x195)][_0x1324b8(0x179)](_0x97ac6b);
                    }, Laya['SoundManager'][_0x220d0a(0x17d)] = function(_0x3c299c) {
                        const _0x3e800e = _0x220d0a;
                        window[_0x3e800e(0x195)] && window[_0x3e800e(0x195)][_0x3e800e(0x17d)](_0x3c299c);
                    }, Laya['SoundManager'][_0x220d0a(0x17a)] = function(_0xe72846) {
                        const _0x4fef8f = _0x220d0a;
                        window[_0x4fef8f(0x195)] && window[_0x4fef8f(0x195)][_0x4fef8f(0x17a)]();
                    };
                }), this[_0x10991c(0x1b7)] = !![], Laya[_0x10991c(0x1f4)][_0x10991c(0x199)](_0x10991c(0x1f5), Laya[_0x10991c(0x1f6)][_0x10991c(0x205)](this, _0x5ecb55 => {
                    const _0x1f9326 = _0x10991c;
                    YYGGames[_0x1f9326(0x20b)]({
                        'channel': 0x5,
                        'appName': _0x4a4cba,
                        'config': _0x5ecb55,
                        'complete': () => {
                            const _0x547cf8 = _0x1f9326,
                                _0x412783 = YYGGames[_0x547cf8(0x1f8)]();
                            window[_0x547cf8(0x1f9)] = this['scrollList'](), window[_0x547cf8(0x1fa)] = this[_0x547cf8(0x1fa)]();
                            switch (_0x412783) {
                                case AdPlatformType[_0x547cf8(0x1fb)]:
                                case AdPlatformType[_0x547cf8(0x1fc)]:
                                    window['yad'] && (window[_0x547cf8(0x1ec)][_0x547cf8(0x1cb)](0x0, 0x0), window[_0x547cf8(0x1ec)]['removeSelf']());
                                    break;
                                default:
                                    window['yad'] && Laya[_0x547cf8(0x165)][_0x547cf8(0x20c)](window[_0x547cf8(0x1ec)]), window[_0x547cf8(0x1ec)]['on'](Laya[_0x547cf8(0x207)][_0x547cf8(0x1fe)], window['yad'], _0x37c0f1 => {
                                        const _0x5ce310 = _0x547cf8;
                                        _0x37c0f1[_0x5ce310(0x208)](), _0x2ff701['getInstance']()[_0x5ce310(0x1c0)](_0x5ce310(0x1ff), _0x5ce310(0x209));
                                    });
                                    break;
                            }
                            this[_0x547cf8(0x1b8)] = ![], _0x2bc450 && _0x2bc450();
                        }
                    });
                }));
            }
            [_0x1d5775(0x1f0)]() {
                const _0xa9de20 = _0x1d5775;
                if (!Laya[_0xa9de20(0x20d)] || !Laya[_0xa9de20(0x20e)])
                    return;
                let _0x3b64a = {
                    'x': 0x0,
                    'type': _0xa9de20(0x20f),
                    'selectedBox': 0x3,
                    'selecteID': 0x4,
                    'searchKey': _0xa9de20(0x20f),
                    'props': {
                        'y': 0x0,
                        'x': 0x0,
                        'top': 0x0,
                        'right': 0x0,
                        'presetID': 0x1,
                        'preset': _0xa9de20(0x210),
                        'mouseEnabled': !![],
                        'left': 0x0,
                        'isPresetRoot': !![],
                        'bottom': 0x0
                    },
                    'nodeParent': -0x1,
                    'maxID': 0xa,
                    'label': _0xa9de20(0x211),
                    'isOpen': !![],
                    'isDirectory': !![],
                    'isAniNode': !![],
                    'hasChild': !![],
                    'compId': 0x3,
                    'child': [{
                        'x': 0xf,
                        'type': _0xa9de20(0x212),
                        'searchKey': _0xa9de20(0x213),
                        'props': {
                            'y': 0x12c,
                            'x': 0x190,
                            'width': 0x2e4,
                            'var': _0xa9de20(0x214),
                            'presetID': 0x2,
                            'preset': _0xa9de20(0x210),
                            'pivotY': 0x10e,
                            'pivotX': 0x172,
                            'name': 'spr_tip',
                            'height': 0x21c
                        },
                        'nodeParent': 0x3,
                        'label': _0xa9de20(0x214),
                        'isOpen': !![],
                        'isDirectory': !![],
                        'isAniNode': !![],
                        'hasChild': !![],
                        'compId': 0x4,
                        'child': [{
                                'x': 0x1e,
                                'type': _0xa9de20(0x215),
                                'searchKey': _0xa9de20(0x215),
                                'props': {
                                    'y': 0x0,
                                    'x': 0x0,
                                    'width': 0x2e4,
                                    'presetID': 0x3,
                                    'preset': _0xa9de20(0x210),
                                    'height': 0x21c,
                                    'fillColor': _0xa9de20(0x216)
                                },
                                'nodeParent': 0x4,
                                'label': 'Rect(NoVideo)',
                                'isDirectory': ![],
                                'isAniNode': !![],
                                'hasChild': ![],
                                'compId': 0x6,
                                'child': []
                            },
                            {
                                'x': 0x1e,
                                'type': _0xa9de20(0x217),
                                'searchKey': 'Label',
                                'props': {
                                    'y': 0x1e,
                                    'x': 0x0,
                                    'width': 0x2e4,
                                    'valign': _0xa9de20(0x218),
                                    'text': 'VIDEO',
                                    'presetID': 0x4,
                                    'preset': 'laya/pages/Prefab/NoVideo.prefab',
                                    'height': 0x4c,
                                    'fontSize': 0x50,
                                    'color': _0xa9de20(0x219),
                                    'align': 'center'
                                },
                                'nodeParent': 0x4,
                                'label': _0xa9de20(0x21a),
                                'isDirectory': ![],
                                'isAniNode': !![],
                                'hasChild': ![],
                                'compId': 0x7,
                                'child': []
                            },
                            {
                                'x': 0x1e,
                                'type': _0xa9de20(0x217),
                                'searchKey': 'Label',
                                'props': {
                                    'y': 0xa3,
                                    'x': 0x0,
                                    'width': 0x2e4,
                                    'valign': 'middle',
                                    'text': _0xa9de20(0x21b),
                                    'presetID': 0x5,
                                    'preset': _0xa9de20(0x210),
                                    'height': 0xaa,
                                    'fontSize': 0x28,
                                    'color': '#ffffff',
                                    'align': _0xa9de20(0x21c)
                                },
                                'nodeParent': 0x4,
                                'label': _0xa9de20(0x21a),
                                'isDirectory': ![],
                                'isAniNode': !![],
                                'hasChild': ![],
                                'compId': 0x8,
                                'child': []
                            },
                            {
                                'x': 0x1e,
                                'type': _0xa9de20(0x217),
                                'searchKey': _0xa9de20(0x217),
                                'props': {
                                    'y': 0x164,
                                    'x': 0x0,
                                    'width': 0x2e4,
                                    'valign': _0xa9de20(0x218),
                                    'text': 'Click\x20anywhere\x20to\x20close',
                                    'presetID': 0x6,
                                    'preset': 'laya/pages/Prefab/NoVideo.prefab',
                                    'height': 0xaa,
                                    'fontSize': 0x23,
                                    'color': _0xa9de20(0x219),
                                    'align': 'center'
                                },
                                'nodeParent': 0x4,
                                'label': _0xa9de20(0x21a),
                                'isDirectory': ![],
                                'isAniNode': !![],
                                'hasChild': ![],
                                'compId': 0x9,
                                'child': []
                            }
                        ]
                    }],
                    'animations': [{
                        'nodes': [],
                        'name': _0xa9de20(0x21d),
                        'id': 0x1,
                        'frameRate': 0x18,
                        'action': 0x0
                    }]
                };
                class _0x1ab5c8 extends Laya[_0xa9de20(0x20e)] {
                    constructor() {
                            super();
                        }
                        [_0xa9de20(0x21e)]() {
                            const _0x3a0b1b = _0xa9de20;
                            this[_0x3a0b1b(0x21f)][_0x3a0b1b(0x220)] = 0x0, this[_0x3a0b1b(0x21f)]['bottom'] = 0x0, this['owner'][_0x3a0b1b(0x221)] = 0x0, this[_0x3a0b1b(0x21f)]['right'] = 0x0, this[_0x3a0b1b(0x214)] = this[_0x3a0b1b(0x21f)][_0x3a0b1b(0x222)](_0x3a0b1b(0x214)), this[_0x3a0b1b(0x21f)][_0x3a0b1b(0x1db)] > this['owner'][_0x3a0b1b(0x223)] ? this[_0x3a0b1b(0x214)][_0x3a0b1b(0x1cb)](this[_0x3a0b1b(0x21f)][_0x3a0b1b(0x223)] / 0x780, this[_0x3a0b1b(0x21f)][_0x3a0b1b(0x223)] / 0x780) : this[_0x3a0b1b(0x214)][_0x3a0b1b(0x1cb)](this[_0x3a0b1b(0x21f)][_0x3a0b1b(0x1db)] / 0x438, this['owner'][_0x3a0b1b(0x1db)] / 0x438), this[_0x3a0b1b(0x214)][_0x3a0b1b(0x224)](this[_0x3a0b1b(0x21f)][_0x3a0b1b(0x1db)] / 0x2, this['owner'][_0x3a0b1b(0x223)] / 0x2), this[_0x3a0b1b(0x21f)]['on'](Laya[_0x3a0b1b(0x207)]['CLICK'], this, this[_0x3a0b1b(0x225)]);
                        }
                        [_0xa9de20(0x225)]() {
                            const _0x3b7c31 = _0xa9de20;
                            _0x2ff701['getInstance']()[_0x3b7c31(0x226)]();
                        }
                }
                let _0x56272c = new Laya[(_0xa9de20(0x20d))]();
                _0x56272c['json'] = _0x3b64a, this[_0xa9de20(0x227)] = _0x56272c['create'](), this['noVideoPer']['zOrder'] = 0x30d3f, this[_0xa9de20(0x227)]['addComponent'](_0x1ab5c8);
            }
            ['showNoVideo']() {
                const _0x198d71 = _0x1d5775;
                this[_0x198d71(0x227)] && Laya['stage'][_0x198d71(0x20c)](this['noVideoPer']);
            }
            [_0x1d5775(0x226)]() {
                const _0x2bdece = _0x1d5775;
                this['noVideoPer'] && this['noVideoPer'][_0x2bdece(0x1fd)]();
            }
            ['createLoading']() {
                const _0x807b3b = _0x1d5775;
                if (!Laya[_0x807b3b(0x20d)] || !Laya['Script'])
                    return;
                let _0x5e7353 = {
                    'x': 0xf,
                    'type': 'Box',
                    'searchKey': _0x807b3b(0x228),
                    'props': {
                        'var': 'box_clickLayer',
                        'top': 0x0,
                        'right': 0x0,
                        'mouseEnabled': !![],
                        'left': 0x0,
                        'bottom': 0x0
                    },
                    'nodeParent': 0x2,
                    'label': _0x807b3b(0x229),
                    'isOpen': !![],
                    'isDirectory': !![],
                    'isAniNode': !![],
                    'hasChild': !![],
                    'compId': 0x83,
                    'child': [{
                            'x': 0x1e,
                            'type': _0x807b3b(0x20f),
                            'searchKey': _0x807b3b(0x20f),
                            'props': {
                                'top': 0x0,
                                'right': 0x0,
                                'left': 0x0,
                                'bottom': 0x0,
                                'bgColor': _0x807b3b(0x216),
                                'alpha': 0.5
                            },
                            'nodeParent': 0x83,
                            'label': _0x807b3b(0x20f),
                            'isOpen': !![],
                            'isDirectory': ![],
                            'isAniNode': !![],
                            'hasChild': ![],
                            'compId': 0x84,
                            'child': []
                        },
                        {
                            'x': 0x1e,
                            'type': _0x807b3b(0x217),
                            'searchKey': _0x807b3b(0x217),
                            'props': {
                                'y': 0x0,
                                'x': 0x0,
                                'valign': _0x807b3b(0x218),
                                'text': _0x807b3b(0x22a),
                                'right': 0x0,
                                'left': 0x0,
                                'fontSize': 0x32,
                                'color': _0x807b3b(0x219),
                                'centerY': 0x0,
                                'align': 'center'
                            },
                            'nodeParent': 0x83,
                            'label': 'Label',
                            'isDirectory': ![],
                            'isAniNode': !![],
                            'hasChild': ![],
                            'compId': 0x85,
                            'child': []
                        }
                    ]
                };
                class _0x449f26 extends Laya[_0x807b3b(0x20e)] {
                    constructor() {
                            super();
                        }
                        [_0x807b3b(0x21e)]() {}
                        [_0x807b3b(0x225)]() {
                            const _0x921114 = _0x807b3b;
                            _0x2ff701[_0x921114(0x1b9)]()[_0x921114(0x226)]();
                        }
                }
                let _0x4dbb7c = new Laya[(_0x807b3b(0x20d))]();
                _0x4dbb7c[_0x807b3b(0x22b)] = _0x5e7353, this[_0x807b3b(0x22c)] = _0x4dbb7c['create'](), this[_0x807b3b(0x22c)][_0x807b3b(0x1ee)] = 0x30d3e, this[_0x807b3b(0x22c)][_0x807b3b(0x22d)](_0x449f26);
            }
            [_0x1d5775(0x22e)]() {
                const _0xf19028 = _0x1d5775;
                this[_0xf19028(0x22c)] && Laya[_0xf19028(0x165)][_0xf19028(0x20c)](this['loadingPer']);
            }
            [_0x1d5775(0x22f)]() {
                const _0x6c9ce5 = _0x1d5775;
                this[_0x6c9ce5(0x22c)] && this[_0x6c9ce5(0x22c)][_0x6c9ce5(0x1fd)]();
            }
            [_0x1d5775(0x230)]() {
                const _0x31cd9c = _0x1d5775;
                class _0x226a61 extends Laya[_0x31cd9c(0x20f)] {
                    constructor() {
                        const _0x14c99c = _0x31cd9c;
                        super(), this[_0x14c99c(0x231)] = new Laya['Image'](), this[_0x14c99c(0x231)]['name'] = _0x14c99c(0x232), this[_0x14c99c(0x233)](0x190, 0x12c), this[_0x14c99c(0x231)][_0x14c99c(0x233)](0x190, 0x12c), this['addChild'](this[_0x14c99c(0x231)]);
                    }
                }
                let _0x25d78e = new Laya[(_0x31cd9c(0x234))]();
                return _0x25d78e[_0x31cd9c(0x233)](0x320, 0x258), _0x25d78e[_0x31cd9c(0x235)] = _0x226a61, _0x25d78e;
            }
            [_0x1d5775(0x1f9)]() {
                const _0x217322 = _0x1d5775;
                if (!Laya || !Laya[_0x217322(0x165)])
                    return null;
                if (YYGGames[_0x217322(0x1f8)]() == AdPlatformType[_0x217322(0x1fb)] || YYGGames[_0x217322(0x1f8)]() == AdPlatformType[_0x217322(0x1fc)]) {
                    let _0x403917 = new Laya['Box']();
                    return _0x403917['setSize'] = function() {}, _0x403917;
                }
                if (!this[_0x217322(0x236)]) {
                    let _0x35c3d7 = {
                        'x': 0x0,
                        'type': _0x217322(0x234),
                        'selectedBox': 0x90,
                        'selecteID': 0x78,
                        'searchKey': _0x217322(0x237),
                        'props': {
                            'y': 0x0,
                            'x': 0x0,
                            'width': 0x370,
                            'repeatY': 0x1,
                            'presetID': 0x1,
                            'preset': _0x217322(0x238),
                            'name': 'scrollAdList',
                            'isPresetRoot': !![],
                            'height': 0xaa,
                            'hScrollBarSkin': '\x20',
                            'anchorY': 0.5,
                            'anchorX': 0.5
                        },
                        'nodeParent': -0x1,
                        'maxID': 0x91,
                        'label': _0x217322(0x239),
                        'isOpen': !![],
                        'isDirectory': !![],
                        'isAniNode': !![],
                        'hasChild': !![],
                        'compId': 0x90,
                        'child': [{
                                'x': 0xf,
                                'type': _0x217322(0x1eb),
                                'searchKey': _0x217322(0x23a),
                                'props': {
                                    'zOrder': -0xa,
                                    'width': 0x384,
                                    'skin': _0x217322(0x23b),
                                    'sizeGrid': _0x217322(0x23c),
                                    'presetID': 0x2,
                                    'preset': _0x217322(0x238),
                                    'name': _0x217322(0x23d),
                                    'height': 0xbe,
                                    'centerY': 0x0,
                                    'centerX': 0x0
                                },
                                'nodeParent': 0x90,
                                'label': 'img_ListBg',
                                'isDirectory': ![],
                                'isAniNode': ![],
                                'hasChild': ![],
                                'compId': 0x78,
                                'child': []
                            },
                            {
                                'x': 0xf,
                                'type': _0x217322(0x20f),
                                'searchKey': _0x217322(0x20f),
                                'props': {
                                    'x': 0x0,
                                    'width': 0xdc,
                                    'renderType': 'render',
                                    'presetID': 0x3,
                                    'preset': _0x217322(0x238),
                                    'height': 0xaa
                                },
                                'nodeParent': 0x90,
                                'label': 'Box(scrollList)',
                                'isOpen': !![],
                                'isDirectory': !![],
                                'isAniNode': ![],
                                'hasChild': !![],
                                'compId': 0x77,
                                'child': [{
                                    'x': 0x1e,
                                    'type': _0x217322(0x1eb),
                                    'searchKey': _0x217322(0x23e),
                                    'props': {
                                        'width': 0xc8,
                                        'presetID': 0x4,
                                        'preset': 'laya/pages/prefab/scrollList.prefab',
                                        'name': _0x217322(0x232),
                                        'height': 0x96,
                                        'centerY': 0x0,
                                        'centerX': 0x0,
                                        'anchorY': 0.5,
                                        'anchorX': 0.5
                                    },
                                    'nodeParent': 0x77,
                                    'label': 'thumb',
                                    'isOpen': !![],
                                    'isDirectory': !![],
                                    'isAniNode': ![],
                                    'hasChild': !![],
                                    'compId': 0x79,
                                    'child': [{
                                        'x': 0x2d,
                                        'type': _0x217322(0x1eb),
                                        'searchKey': _0x217322(0x1eb),
                                        'props': {
                                            'y': 0x4b,
                                            'x': 0x64,
                                            'width': 0xc8,
                                            'skin': _0x217322(0x23f),
                                            'sizeGrid': _0x217322(0x240),
                                            'renderType': _0x217322(0x241),
                                            'presetID': 0x5,
                                            'preset': _0x217322(0x238),
                                            'height': 0x96,
                                            'anchorY': 0.5,
                                            'anchorX': 0.5
                                        },
                                        'nodeParent': 0x79,
                                        'label': _0x217322(0x242),
                                        'isDirectory': ![],
                                        'isAniNode': ![],
                                        'hasChild': ![],
                                        'compId': 0x7a,
                                        'child': []
                                    }]
                                }]
                            }
                        ],
                        'animations': [{
                            'nodes': [],
                            'name': _0x217322(0x21d),
                            'id': 0x1,
                            'frameRate': 0x18,
                            'action': 0x0
                        }]
                    };
                    class _0x27b0c9 extends Laya['Script'] {
                        constructor() {
                                const _0x5b06e4 = _0x217322;
                                super(), this['imgArr'] = [], this[_0x5b06e4(0x243)] = [
                                    0.83,
                                    0.83
                                ], this[_0x5b06e4(0x244)] = [
                                    0xc8,
                                    0x96, !![]
                                ];
                            }
                            ['onEnable']() {
                                const _0x4fb72b = _0x217322;
                                this[_0x4fb72b(0x23d)] = this['owner'][_0x4fb72b(0x222)](_0x4fb72b(0x23d)), this[_0x4fb72b(0x21f)][_0x4fb72b(0x16a)] = ![], !this[_0x4fb72b(0x21f)][_0x4fb72b(0x245)] && (this[_0x4fb72b(0x21f)]['renderHandler'] = new Laya[(_0x4fb72b(0x1f6))](this, this[_0x4fb72b(0x246)]));
                                if (this[_0x4fb72b(0x247)][_0x4fb72b(0x1e7)]) {
                                    let _0x47be05 = JSON[_0x4fb72b(0x178)](JSON[_0x4fb72b(0x1c6)](this['imgArr']));
                                    Laya[_0x4fb72b(0x1f4)][_0x4fb72b(0x248)](_0x47be05);
                                }
                                this[_0x4fb72b(0x249)](this[_0x4fb72b(0x244)][0x0], this[_0x4fb72b(0x244)][0x1], this[_0x4fb72b(0x244)][0x2]), this[_0x4fb72b(0x21f)][_0x4fb72b(0x24a)][_0x4fb72b(0x24b)] = ![], this[_0x4fb72b(0x21f)][_0x4fb72b(0x24a)][_0x4fb72b(0x24c)] = ![], this[_0x4fb72b(0x21f)][_0x4fb72b(0x24a)]['touchScrollEnable'] = ![];
                                let _0x336fc2 = _0x2ff701[_0x4fb72b(0x1b9)]()[_0x4fb72b(0x1e4)]();
                                if (!_0x336fc2[_0x4fb72b(0x1e7)])
                                    return;
                                this['listArray'] = JSON['parse'](JSON[_0x4fb72b(0x1c6)](_0x336fc2)), this[_0x4fb72b(0x24d)] = this[_0x4fb72b(0x24d)][_0x4fb72b(0x24e)](this[_0x4fb72b(0x24d)][_0x4fb72b(0x1e6)](0x0, 0x4)), this['owner'][_0x4fb72b(0x24f)] = 0x0, this[_0x4fb72b(0x21f)][_0x4fb72b(0x250)] = this[_0x4fb72b(0x24d)], Laya[_0x4fb72b(0x164)]['frameLoop'](0x1, this, this[_0x4fb72b(0x251)]), this[_0x4fb72b(0x21f)][_0x4fb72b(0x16a)] = !![];
                            }
                            [_0x217322(0x246)](_0x1a6869, _0x2093ce) {
                                const _0x1b6edc = _0x217322;
                                let _0x487695 = _0x1a6869[_0x1b6edc(0x222)](_0x1b6edc(0x232));
                                _0x1a6869[_0x1b6edc(0x252)](), _0x487695['offAll'](), _0x1a6869['on'](Laya[_0x1b6edc(0x207)][_0x1b6edc(0x253)], _0x1a6869, () => {
                                    const _0x2692bf = _0x1b6edc;
                                    _0x1a6869[_0x2692bf(0x1ee)] = 0x64;
                                }), _0x1a6869['on'](Laya[_0x1b6edc(0x207)][_0x1b6edc(0x254)], _0x1a6869, () => {
                                    _0x1a6869['zOrder'] = _0x2093ce;
                                }), _0x487695['on'](Laya[_0x1b6edc(0x207)][_0x1b6edc(0x253)], _0x1a6869, () => {
                                    const _0x12a242 = _0x1b6edc;
                                    _0x487695[_0x12a242(0x1cb)](1.1, 1.1), this[_0x12a242(0x255)]();
                                }), _0x487695['on'](Laya['Event'][_0x1b6edc(0x254)], _0x1a6869, () => {
                                    const _0x42de67 = _0x1b6edc;
                                    _0x487695['scale'](0x1, 0x1), Laya[_0x42de67(0x164)]['frameLoop'](0x1, this, this[_0x42de67(0x251)]);
                                }), _0x487695['on'](Laya['Event'][_0x1b6edc(0x1fe)], _0x1a6869, _0x226fb1 => {
                                    const _0x592739 = _0x1b6edc;
                                    _0x226fb1[_0x592739(0x208)](), _0x2ff701[_0x592739(0x1b9)]()[_0x592739(0x1c0)](_0x592739(0x1ff), _0x592739(0x256), _0x1a6869[_0x592739(0x257)]['id']);
                                });
                                let _0x38fef1 = _0x487695[_0x1b6edc(0x241)];
                                _0x1a6869[_0x1b6edc(0x1db)] = this[_0x1b6edc(0x244)][0x0] + 0x14, _0x1a6869[_0x1b6edc(0x223)] = this[_0x1b6edc(0x244)][0x1] + 0x14, _0x1a6869['x'] = (this[_0x1b6edc(0x244)][0x0] + 0x14) * _0x2093ce;
                                if (this[_0x1b6edc(0x244)][0x2])
                                    _0x38fef1[_0x1b6edc(0x1db)] = _0x487695[_0x1b6edc(0x1db)] = this['sizeTran'][0x0], _0x38fef1[_0x1b6edc(0x223)] = _0x487695['height'] = this[_0x1b6edc(0x244)][0x1];
                                else {
                                    let _0x1f8c88 = 0xc8 / this[_0x1b6edc(0x244)][0x0] < 0x96 / this[_0x1b6edc(0x244)][0x1] ? 0xc8 / this[_0x1b6edc(0x244)][0x0] : 0x96 / this['sizeTran'][0x1];
                                    _0x487695[_0x1b6edc(0x1db)] = 0xc8 / _0x1f8c88, _0x487695[_0x1b6edc(0x223)] = 0x96 / _0x1f8c88, _0x38fef1[_0x1b6edc(0x1db)] = this[_0x1b6edc(0x244)][0x0], _0x38fef1[_0x1b6edc(0x223)] = this[_0x1b6edc(0x244)][0x1];
                                }
                                _0x38fef1['x'] = _0x487695[_0x1b6edc(0x1db)] / 0x2, _0x38fef1['y'] = _0x487695[_0x1b6edc(0x223)] / 0x2;
                            }
                            [_0x217322(0x249)](_0x4faad8, _0x5c504d, _0x37c40d = ![]) {
                                const _0x543ce5 = _0x217322;
                                this['sizeTran'] = [
                                    _0x4faad8,
                                    _0x5c504d,
                                    _0x37c40d
                                ], this['img_ListBg'] && (this[_0x543ce5(0x21f)][_0x543ce5(0x1db)] = (_0x4faad8 + 0x14) * 0x4, this[_0x543ce5(0x21f)][_0x543ce5(0x223)] = _0x5c504d + 0x14, this[_0x543ce5(0x23d)][_0x543ce5(0x1db)] = (_0x4faad8 + 0x14) * 0x4 + 0x14, this[_0x543ce5(0x23d)]['height'] = _0x5c504d + 0x28, this[_0x543ce5(0x21f)]['array'] = [], this[_0x543ce5(0x21f)][_0x543ce5(0x250)] = this['listArray']);
                            }
                            [_0x217322(0x251)]() {
                                const _0x3ec0d3 = _0x217322;
                                this[_0x3ec0d3(0x21f)][_0x3ec0d3(0x24a)][_0x3ec0d3(0x258)] += 0x1, this['owner'][_0x3ec0d3(0x24a)][_0x3ec0d3(0x258)] >= this['owner'][_0x3ec0d3(0x24a)][_0x3ec0d3(0x259)] && (this[_0x3ec0d3(0x21f)]['scrollBar'][_0x3ec0d3(0x258)] = 0x0);
                            }
                            [_0x217322(0x255)]() {
                                const _0x9b607f = _0x217322;
                                Laya['timer']['clearAll'](this), Laya[_0x9b607f(0x25a)][_0x9b607f(0x25b)](this[_0x9b607f(0x21f)][_0x9b607f(0x24a)]);
                            }
                            [_0x217322(0x25c)](_0xa0512e) {}
                            [_0x217322(0x25d)]() {
                                const _0x5daf4c = _0x217322;
                                if (this[_0x5daf4c(0x247)][_0x5daf4c(0x1e7)]) {
                                    let _0x4d56c5 = JSON[_0x5daf4c(0x178)](JSON[_0x5daf4c(0x1c6)](this[_0x5daf4c(0x247)]));
                                    Laya[_0x5daf4c(0x1f4)][_0x5daf4c(0x248)](_0x4d56c5);
                                }
                                this[_0x5daf4c(0x247)] = [], this['endAni'](), this[_0x5daf4c(0x21f)][_0x5daf4c(0x250)] = [];
                            }
                    }
                    let _0x159afc = new Laya[(_0x217322(0x20d))]();
                    _0x159afc[_0x217322(0x22b)] = _0x35c3d7, this['_scrollList'] = _0x159afc['create'](), this[_0x217322(0x236)][_0x217322(0x1ee)] = 0x30d3f, this['_scrollList']['addComponent'](_0x27b0c9), this[_0x217322(0x236)]['setSize'] = this[_0x217322(0x236)][_0x217322(0x25e)](_0x27b0c9)[_0x217322(0x249)][_0x217322(0x15a)](this[_0x217322(0x236)][_0x217322(0x25e)](_0x27b0c9));
                }
                return this[_0x217322(0x236)];
            }
            ['box_adTwo']() {
                const _0x483aad = _0x1d5775;
                if (!Laya || !Laya['stage'])
                    return null;
                if (YYGGames[_0x483aad(0x1f8)]() == AdPlatformType[_0x483aad(0x1fb)] || YYGGames[_0x483aad(0x1f8)]() == AdPlatformType[_0x483aad(0x1fc)]) {
                    let _0x579210 = new Laya[(_0x483aad(0x20f))]();
                    return _0x579210[_0x483aad(0x25f)] = _0x579210[_0x483aad(0x249)] = function() {}, _0x579210;
                }
                if (!this[_0x483aad(0x260)]) {
                    let _0x5f2df9 = {
                        'x': 0x0,
                        'type': _0x483aad(0x20f),
                        'selectedBox': 0x96,
                        'selecteID': 0x98,
                        'searchKey': _0x483aad(0x261),
                        'props': {
                            'y': 0x0,
                            'x': 0x0,
                            'width': 0x1,
                            'presetID': 0x1,
                            'preset': 'laya/pages/prefab/box_adTwo.prefab',
                            'name': _0x483aad(0x1fa),
                            'isPresetRoot': !![],
                            'height': 0x1,
                            'centerX': 0x0,
                            'anchorY': 0.5,
                            'anchorX': 0.5
                        },
                        'nodeParent': -0x1,
                        'maxID': 0x99,
                        'label': _0x483aad(0x1fa),
                        'isOpen': !![],
                        'isDirectory': !![],
                        'isAniNode': !![],
                        'hasChild': !![],
                        'compId': 0x92,
                        'child': [{
                                'x': 0xf,
                                'type': _0x483aad(0x1eb),
                                'searchKey': _0x483aad(0x262),
                                'props': {
                                    'y': 0x0,
                                    'x': -0x136,
                                    'width': 0xdc,
                                    'skin': _0x483aad(0x23f),
                                    'sizeGrid': _0x483aad(0x240),
                                    'presetID': 0x2,
                                    'preset': _0x483aad(0x263),
                                    'name': _0x483aad(0x264),
                                    'height': 0xaa
                                },
                                'nodeParent': 0x92,
                                'label': _0x483aad(0x264),
                                'isOpen': !![],
                                'isDirectory': !![],
                                'isAniNode': !![],
                                'hasChild': !![],
                                'compId': 0x93,
                                'child': [{
                                    'x': 0x1e,
                                    'type': _0x483aad(0x1eb),
                                    'searchKey': 'Image,img_adImg',
                                    'props': {
                                        'width': 0xc8,
                                        'presetID': 0x3,
                                        'preset': 'laya/pages/prefab/box_adTwo.prefab',
                                        'name': 'img_adImg',
                                        'height': 0x96,
                                        'centerY': 0x0,
                                        'centerX': 0x0
                                    },
                                    'nodeParent': 0x93,
                                    'label': 'img_adImg',
                                    'isOpen': !![],
                                    'isDirectory': !![],
                                    'isAniNode': !![],
                                    'hasChild': !![],
                                    'compId': 0x95,
                                    'child': [{
                                        'x': 0x2d,
                                        'type': _0x483aad(0x1eb),
                                        'searchKey': 'Image',
                                        'props': {
                                            'width': 0xc8,
                                            'skin': _0x483aad(0x23f),
                                            'sizeGrid': '30,30,30,30',
                                            'renderType': _0x483aad(0x241),
                                            'presetID': 0x4,
                                            'preset': _0x483aad(0x263),
                                            'height': 0x96,
                                            'anchorY': 0.5,
                                            'anchorX': 0.5
                                        },
                                        'nodeParent': 0x95,
                                        'label': 'Image(box_adTwo)',
                                        'isDirectory': ![],
                                        'isAniNode': !![],
                                        'hasChild': ![],
                                        'compId': 0x97,
                                        'child': []
                                    }]
                                }]
                            },
                            {
                                'x': 0xf,
                                'type': 'Image',
                                'searchKey': _0x483aad(0x265),
                                'props': {
                                    'y': 0x0,
                                    'x': 0x5a,
                                    'width': 0xdc,
                                    'skin': 'di1.png',
                                    'sizeGrid': '30,30,30,30',
                                    'presetID': 0x5,
                                    'preset': _0x483aad(0x263),
                                    'name': _0x483aad(0x266),
                                    'height': 0xaa
                                },
                                'nodeParent': 0x92,
                                'label': _0x483aad(0x266),
                                'isOpen': !![],
                                'isDirectory': !![],
                                'isAniNode': !![],
                                'hasChild': !![],
                                'compId': 0x94,
                                'child': [{
                                    'x': 0x1e,
                                    'type': _0x483aad(0x1eb),
                                    'searchKey': _0x483aad(0x267),
                                    'props': {
                                        'width': 0xc8,
                                        'presetID': 0x6,
                                        'preset': _0x483aad(0x263),
                                        'name': _0x483aad(0x268),
                                        'height': 0x96,
                                        'centerY': 0x0,
                                        'centerX': 0x0
                                    },
                                    'nodeParent': 0x94,
                                    'label': 'img_adImg',
                                    'isOpen': !![],
                                    'isDirectory': !![],
                                    'isAniNode': !![],
                                    'hasChild': !![],
                                    'compId': 0x96,
                                    'child': [{
                                        'x': 0x2d,
                                        'type': 'Image',
                                        'searchKey': 'Image',
                                        'props': {
                                            'width': 0xc8,
                                            'skin': _0x483aad(0x23f),
                                            'sizeGrid': _0x483aad(0x240),
                                            'renderType': _0x483aad(0x241),
                                            'presetID': 0x7,
                                            'preset': _0x483aad(0x263),
                                            'height': 0x96,
                                            'anchorY': 0.5,
                                            'anchorX': 0.5
                                        },
                                        'nodeParent': 0x96,
                                        'label': 'Image(box_adTwo)',
                                        'isDirectory': ![],
                                        'isAniNode': !![],
                                        'hasChild': ![],
                                        'compId': 0x98,
                                        'child': []
                                    }]
                                }]
                            }
                        ],
                        'animations': [{
                            'nodes': [],
                            'name': 'ani1',
                            'id': 0x1,
                            'frameRate': 0x18,
                            'action': 0x0
                        }]
                    };
                    class _0x5b2dea extends Laya['Script'] {
                        constructor() {
                                const _0x282918 = _0x483aad;
                                super(), this['imgArr'] = [], this[_0x282918(0x269)] = 0x0, this[_0x282918(0x244)] = [
                                    0xc8,
                                    0x96, !![]
                                ];
                            }
                            [_0x483aad(0x21e)]() {
                                const _0x318aec = _0x483aad;
                                !this[_0x318aec(0x264)] && (this['img_ad0'] = this[_0x318aec(0x21f)][_0x318aec(0x222)](_0x318aec(0x264))), !this[_0x318aec(0x266)] && (this[_0x318aec(0x266)] = this['owner']['getChildByName']('img_ad1')), !this[_0x318aec(0x26a)] && (this['img_ad0Ad'] = this[_0x318aec(0x264)][_0x318aec(0x222)](_0x318aec(0x268))), !this[_0x318aec(0x26b)] && (this['img_ad1Ad'] = this[_0x318aec(0x266)][_0x318aec(0x222)](_0x318aec(0x268))), !this[_0x318aec(0x26c)] && (this[_0x318aec(0x26c)] = this[_0x318aec(0x26a)][_0x318aec(0x241)]), !this[_0x318aec(0x26d)] && (this['img_ad1AdMask'] = this[_0x318aec(0x26b)][_0x318aec(0x241)]), this[_0x318aec(0x21f)]['visible'] = ![];
                                let _0x5bc0ad = _0x2ff701['getInstance']()[_0x318aec(0x1e4)]();
                                if (!_0x5bc0ad['length'])
                                    return;
                                let _0x13eff6 = JSON[_0x318aec(0x178)](JSON[_0x318aec(0x1c6)](_0x5bc0ad));
                                if (this[_0x318aec(0x247)]['length']) {
                                    let _0x42eeb9 = JSON[_0x318aec(0x178)](JSON[_0x318aec(0x1c6)](this[_0x318aec(0x247)]));
                                    Laya[_0x318aec(0x1f4)][_0x318aec(0x248)](_0x42eeb9);
                                }
                                this[_0x318aec(0x25f)](this[_0x318aec(0x269)]), this[_0x318aec(0x249)](this[_0x318aec(0x244)][0x0], this[_0x318aec(0x244)][0x1], this[_0x318aec(0x244)][0x2]), this['img_ad0'][_0x318aec(0x252)](), this[_0x318aec(0x266)][_0x318aec(0x252)](), this[_0x318aec(0x21f)]['visible'] = !![], this[_0x318aec(0x264)][_0x318aec(0x222)](_0x318aec(0x268))[_0x318aec(0x1ed)] = _0x13eff6[0x0][_0x318aec(0x232)], this[_0x318aec(0x266)]['getChildByName'](_0x318aec(0x268))[_0x318aec(0x1ed)] = _0x13eff6[0x1]['thumb'], this[_0x318aec(0x264)]['on'](Laya[_0x318aec(0x207)]['MOUSE_DOWN'], this, _0x1ea48a => {
                                    const _0x2e02aa = _0x318aec;
                                    _0x1ea48a[_0x2e02aa(0x208)](), _0x2ff701[_0x2e02aa(0x1b9)]()[_0x2e02aa(0x1c0)]('GAME', _0x2e02aa(0x256), _0x13eff6[0x0]['id']);
                                }), this[_0x318aec(0x266)]['on'](Laya[_0x318aec(0x207)][_0x318aec(0x1fe)], this, _0x14d974 => {
                                    const _0x1eee24 = _0x318aec;
                                    _0x14d974[_0x1eee24(0x208)](), _0x2ff701[_0x1eee24(0x1b9)]()[_0x1eee24(0x1c0)]('GAME', _0x1eee24(0x256), _0x13eff6[0x1]['id']);
                                });
                            }
                            [_0x483aad(0x25f)](_0x45fd9f) {
                                const _0x1f3d0d = _0x483aad;
                                this[_0x1f3d0d(0x269)] = _0x45fd9f, this[_0x1f3d0d(0x264)] && (this['img_ad0']['x'] = -this[_0x1f3d0d(0x264)][_0x1f3d0d(0x1db)] - this['spaceNum'] / 0x2, this[_0x1f3d0d(0x266)]['x'] = this['spaceNum'] / 0x2);
                            }
                            [_0x483aad(0x25d)]() {
                                const _0x4b6a7e = _0x483aad;
                                if (this['imgArr'][_0x4b6a7e(0x1e7)]) {
                                    let _0x3ad4c9 = JSON[_0x4b6a7e(0x178)](JSON[_0x4b6a7e(0x1c6)](this[_0x4b6a7e(0x247)]));
                                    Laya['loader'][_0x4b6a7e(0x248)](_0x3ad4c9);
                                }
                                this['imgArr'] = [];
                            }
                            [_0x483aad(0x249)](_0x4afafe, _0x5930d5, _0x2191f0 = ![]) {
                                const _0x4d42e8 = _0x483aad;
                                this['sizeTran'] = [
                                    _0x4afafe,
                                    _0x5930d5,
                                    _0x2191f0
                                ];
                                if (this[_0x4d42e8(0x264)]) {
                                    this[_0x4d42e8(0x264)][_0x4d42e8(0x1db)] = this['img_ad1'][_0x4d42e8(0x1db)] = _0x4afafe + 0x14, this[_0x4d42e8(0x264)][_0x4d42e8(0x223)] = this['img_ad1'][_0x4d42e8(0x223)] = _0x5930d5 + 0x14;
                                    if (_0x2191f0)
                                        this[_0x4d42e8(0x26c)]['width'] = this[_0x4d42e8(0x26d)][_0x4d42e8(0x1db)] = this[_0x4d42e8(0x26a)][_0x4d42e8(0x1db)] = this[_0x4d42e8(0x26b)][_0x4d42e8(0x1db)] = _0x4afafe, this[_0x4d42e8(0x26c)]['height'] = this[_0x4d42e8(0x26d)]['height'] = this[_0x4d42e8(0x26a)][_0x4d42e8(0x223)] = this[_0x4d42e8(0x26b)]['height'] = _0x5930d5;
                                    else {
                                        let _0x4b2805 = 0xc8 / _0x4afafe < 0x96 / _0x5930d5 ? 0xc8 / _0x4afafe : 0x96 / _0x5930d5;
                                        this[_0x4d42e8(0x26a)][_0x4d42e8(0x1db)] = this[_0x4d42e8(0x26b)][_0x4d42e8(0x1db)] = 0xc8 / _0x4b2805, this[_0x4d42e8(0x26a)][_0x4d42e8(0x223)] = this[_0x4d42e8(0x26b)][_0x4d42e8(0x223)] = 0x96 / _0x4b2805, this[_0x4d42e8(0x26c)][_0x4d42e8(0x1db)] = this[_0x4d42e8(0x26d)][_0x4d42e8(0x1db)] = _0x4afafe, this[_0x4d42e8(0x26c)][_0x4d42e8(0x223)] = this['img_ad1AdMask'][_0x4d42e8(0x223)] = _0x5930d5;
                                    }
                                    this['img_ad0AdMask']['x'] = this[_0x4d42e8(0x26d)]['x'] = this[_0x4d42e8(0x26a)][_0x4d42e8(0x1db)] / 0x2, this['img_ad0AdMask']['y'] = this['img_ad1AdMask']['y'] = this[_0x4d42e8(0x26a)][_0x4d42e8(0x223)] / 0x2, this[_0x4d42e8(0x25f)](this[_0x4d42e8(0x269)]);
                                }
                            }
                    }
                    let _0x36910e = new Laya[(_0x483aad(0x20d))]();
                    _0x36910e[_0x483aad(0x22b)] = _0x5f2df9, this['_box_adTwo'] = _0x36910e[_0x483aad(0x205)](), this[_0x483aad(0x260)][_0x483aad(0x1ee)] = 0x30d3f, this[_0x483aad(0x260)][_0x483aad(0x22d)](_0x5b2dea), this[_0x483aad(0x260)][_0x483aad(0x25f)] = this['_box_adTwo']['getComponent'](_0x5b2dea)[_0x483aad(0x25f)]['bind'](this[_0x483aad(0x260)][_0x483aad(0x25e)](_0x5b2dea)), this[_0x483aad(0x260)][_0x483aad(0x249)] = this[_0x483aad(0x260)][_0x483aad(0x25e)](_0x5b2dea)['setSize'][_0x483aad(0x15a)](this[_0x483aad(0x260)][_0x483aad(0x25e)](_0x5b2dea));
                }
                return this[_0x483aad(0x260)];
            }
    }
    _0x2ff701['_instance'] = null, window['platform'] = _0x2ff701;
    class _0x369f3d {
        constructor() {
            const _0x3c86f5 = _0x1d5775;
            this[_0x3c86f5(0x26e)] = null, this[_0x3c86f5(0x236)] = null, this[_0x3c86f5(0x26f)] = this;
        }
        static get[_0x1d5775(0x270)]() {
                const _0x1eed20 = _0x1d5775;
                return !this[_0x1eed20(0x26f)] && new _0x369f3d(), this[_0x1eed20(0x26f)];
            }
            [_0x1d5775(0x1fa)]() {
                const _0x5a57ec = _0x1d5775;
                if (!Laya || !Laya[_0x5a57ec(0x165)])
                    return null;
                if (YYGGames[_0x5a57ec(0x1f8)]() == AdPlatformType['en_GAMEDISTRIBUTION'] || YYGGames[_0x5a57ec(0x1f8)]() == AdPlatformType['en_XIAOMI']) {
                    let _0x2f4501 = new Laya['Box']();
                    return _0x2f4501['setSpaceX'] = _0x2f4501[_0x5a57ec(0x249)] = function() {}, _0x2f4501;
                }
                if (!this[_0x5a57ec(0x26e)]) {
                    this[_0x5a57ec(0x26e)] = new Laya[(_0x5a57ec(0x20f))](), this[_0x5a57ec(0x26e)]['name'] = '_box_adTwo0', this[_0x5a57ec(0x26e)][_0x5a57ec(0x271)] = this['_box_adTwo0'][_0x5a57ec(0x272)] = 0.5, this[_0x5a57ec(0x26e)][_0x5a57ec(0x1ee)] = 0x30d3f, this[_0x5a57ec(0x26e)]['spaceXNum'] = 0x0;
                    let _0x397fbb = new Laya[(_0x5a57ec(0x1eb))]();
                    _0x397fbb[_0x5a57ec(0x273)] = _0x5a57ec(0x274), _0x397fbb[_0x5a57ec(0x275)] = _0x5a57ec(0x240), _0x397fbb['size'](0xdc, 0xaa), _0x397fbb[_0x5a57ec(0x1ed)] = _0x5a57ec(0x23f);
                    let _0x2285aa = new Laya['Image']();
                    _0x2285aa['name'] = _0x5a57ec(0x276), _0x2285aa[_0x5a57ec(0x233)](0xc8, 0x96), _0x2285aa[_0x5a57ec(0x275)] = _0x5a57ec(0x240), _0x2285aa[_0x5a57ec(0x271)] = _0x2285aa[_0x5a57ec(0x272)] = 0.5, _0x2285aa['skin'] = _0x5a57ec(0x23f);
                    let _0x4e9455 = new Laya[(_0x5a57ec(0x1eb))]();
                    _0x4e9455[_0x5a57ec(0x273)] = _0x5a57ec(0x277), _0x4e9455[_0x5a57ec(0x233)](0xc8, 0x96), _0x4e9455['anchorX'] = _0x4e9455['anchorY'] = 0.5, _0x4e9455[_0x5a57ec(0x1ed)] = '', _0x4e9455['mask'] = _0x2285aa, _0x397fbb[_0x5a57ec(0x20c)](_0x4e9455), _0x397fbb[_0x5a57ec(0x224)](0x0, 0x0), _0x4e9455[_0x5a57ec(0x224)](_0x397fbb[_0x5a57ec(0x1db)] / 0x2, _0x397fbb[_0x5a57ec(0x223)] / 0x2), _0x2285aa[_0x5a57ec(0x224)](_0x4e9455[_0x5a57ec(0x1db)] / 0x2, _0x4e9455[_0x5a57ec(0x223)] / 0x2);
                    let _0x3624f3 = new Laya[(_0x5a57ec(0x1eb))]();
                    _0x3624f3[_0x5a57ec(0x273)] = 'rightAdBg', _0x3624f3[_0x5a57ec(0x275)] = _0x5a57ec(0x240), _0x3624f3[_0x5a57ec(0x233)](0xdc, 0xaa), _0x3624f3[_0x5a57ec(0x1ed)] = 'di1.png';
                    let _0x127609 = new Laya['Image']();
                    _0x127609[_0x5a57ec(0x273)] = _0x5a57ec(0x278), _0x127609[_0x5a57ec(0x233)](0xc8, 0x96), _0x127609['sizeGrid'] = '30,30,30,30', _0x127609[_0x5a57ec(0x271)] = _0x127609[_0x5a57ec(0x272)] = 0.5, _0x127609[_0x5a57ec(0x1ed)] = 'di1.png';
                    let _0x578843 = new Laya[(_0x5a57ec(0x1eb))]();
                    _0x578843[_0x5a57ec(0x273)] = _0x5a57ec(0x279), _0x578843['size'](0xc8, 0x96), _0x578843[_0x5a57ec(0x271)] = _0x578843[_0x5a57ec(0x272)] = 0.5, _0x578843['skin'] = '', _0x578843[_0x5a57ec(0x241)] = _0x127609, _0x3624f3[_0x5a57ec(0x20c)](_0x578843), _0x3624f3[_0x5a57ec(0x224)](_0x397fbb[_0x5a57ec(0x1db)], 0x0), _0x578843[_0x5a57ec(0x224)](_0x3624f3['width'] / 0x2, _0x3624f3['height'] / 0x2), _0x127609['pos'](_0x578843[_0x5a57ec(0x1db)] / 0x2, _0x578843[_0x5a57ec(0x223)] / 0x2), this[_0x5a57ec(0x26e)][_0x5a57ec(0x24f)] = 0x0, this[_0x5a57ec(0x26e)][_0x5a57ec(0x1db)] = _0x397fbb[_0x5a57ec(0x1db)] + _0x3624f3[_0x5a57ec(0x1db)], this['_box_adTwo0'][_0x5a57ec(0x20c)](_0x397fbb), this[_0x5a57ec(0x26e)][_0x5a57ec(0x20c)](_0x3624f3), this[_0x5a57ec(0x26e)][_0x5a57ec(0x25f)] = this[_0x5a57ec(0x25f)][_0x5a57ec(0x15a)](this['_box_adTwo0']), this[_0x5a57ec(0x26e)]['setSize'] = this['setSize'][_0x5a57ec(0x15a)](this[_0x5a57ec(0x26e)]);
                    let _0x4c8874 = _0x2ff701[_0x5a57ec(0x1b9)]()['getForgames']();
                    if (!_0x4c8874[_0x5a57ec(0x1e7)])
                        return;
                    let _0x14be17 = JSON[_0x5a57ec(0x178)](JSON[_0x5a57ec(0x1c6)](_0x4c8874));
                    _0x4e9455['offAll'](), _0x578843['offAll'](), _0x4e9455[_0x5a57ec(0x1ed)] = _0x14be17[0x0][_0x5a57ec(0x232)], _0x578843['skin'] = _0x14be17[0x1]['thumb'], _0x4e9455['on'](Laya['Event']['MOUSE_DOWN'], this, _0xf4ef6f => {
                        const _0x266bde = _0x5a57ec;
                        _0xf4ef6f[_0x266bde(0x208)](), _0x2ff701[_0x266bde(0x1b9)]()[_0x266bde(0x1c0)](_0x266bde(0x1ff), 'MORE', _0x14be17[0x0]['id']);
                    }), _0x578843['on'](Laya['Event'][_0x5a57ec(0x1fe)], this, _0x246621 => {
                        const _0x1c3c9f = _0x5a57ec;
                        _0x246621[_0x1c3c9f(0x208)](), _0x2ff701[_0x1c3c9f(0x1b9)]()['navigate'](_0x1c3c9f(0x1ff), _0x1c3c9f(0x256), _0x14be17[0x1]['id']);
                    }), this[_0x5a57ec(0x26e)]['visible'] = ![];
                }
                return this[_0x5a57ec(0x26e)];
            }
            [_0x1d5775(0x249)](_0x2e189e = 0xc8, _0x4d27c0 = 0x96, _0x1a77d3 = ![], _0x35c5d5 = !![]) {
                const _0x19d3ef = _0x1d5775;
                let _0xa3731e = 0xc8;
                _0x2e189e / 0xc8 > _0x4d27c0 / 0x96 ? _0xa3731e = _0x2e189e / 0xc8 : _0xa3731e = _0x4d27c0 / 0x96;
                let _0x1b3d87 = 0xc8;
                if (this[_0x19d3ef(0x273)] == _0x19d3ef(0x26e)) {
                    let _0x1a2ecc = this[_0x19d3ef(0x222)](_0x19d3ef(0x274)),
                        _0x1d78cc = this[_0x19d3ef(0x222)](_0x19d3ef(0x27a)),
                        _0x2fd6a0 = _0x1a2ecc['getChildByName'](_0x19d3ef(0x277)),
                        _0x1f98eb = _0x1d78cc[_0x19d3ef(0x222)](_0x19d3ef(0x279));
                    _0x35c5d5 && (_0x1a2ecc[_0x19d3ef(0x233)](0xdc, 0xaa), _0x1d78cc[_0x19d3ef(0x233)](0xdc, 0xaa), _0x2fd6a0['size'](0xc8, 0x96), _0x1f98eb[_0x19d3ef(0x233)](0xc8, 0x96), _0x2fd6a0[_0x19d3ef(0x241)][_0x19d3ef(0x233)](0xc8, 0x96), _0x1f98eb[_0x19d3ef(0x241)]['size'](0xc8, 0x96), _0x1a2ecc[_0x19d3ef(0x1cb)](0x1, 0x1), _0x1d78cc[_0x19d3ef(0x1cb)](0x1, 0x1), _0x2fd6a0['scale'](0x1, 0x1), _0x1f98eb[_0x19d3ef(0x1cb)](0x1, 0x1), _0x2fd6a0[_0x19d3ef(0x241)][_0x19d3ef(0x1cb)](0x1, 0x1), _0x1f98eb[_0x19d3ef(0x241)][_0x19d3ef(0x1cb)](0x1, 0x1));
                    let _0x2ba3d7 = 0xc8 * _0x4d27c0 / _0x2e189e;
                    _0x1a2ecc[_0x19d3ef(0x233)](_0x1b3d87 + 0x14, _0x2ba3d7 + 0x14), _0x1d78cc[_0x19d3ef(0x233)](_0x1b3d87 + 0x14, _0x2ba3d7 + 0x14), _0x2fd6a0['mask']['size'](_0x1b3d87, _0x2ba3d7), _0x1f98eb[_0x19d3ef(0x241)][_0x19d3ef(0x233)](_0x1b3d87, _0x2ba3d7), !_0x1a77d3 ? (_0x2fd6a0[_0x19d3ef(0x233)](_0x1b3d87, _0x2ba3d7), _0x1f98eb[_0x19d3ef(0x233)](_0x1b3d87, _0x2ba3d7)) : (_0x2fd6a0[_0x19d3ef(0x233)](0xc8 * _0xa3731e, 0x96 * _0xa3731e), _0x1f98eb[_0x19d3ef(0x233)](0xc8 * _0xa3731e, 0x96 * _0xa3731e)), _0x2fd6a0[_0x19d3ef(0x224)](_0x1a2ecc[_0x19d3ef(0x1db)] / 0x2, _0x1a2ecc['height'] / 0x2), _0x2fd6a0['mask']['pos'](_0x2fd6a0['width'] / 0x2, _0x2fd6a0[_0x19d3ef(0x223)] / 0x2), _0x1f98eb[_0x19d3ef(0x224)](_0x1d78cc[_0x19d3ef(0x1db)] / 0x2, _0x1d78cc[_0x19d3ef(0x223)] / 0x2), _0x1f98eb[_0x19d3ef(0x241)][_0x19d3ef(0x224)](_0x1f98eb['width'] / 0x2, _0x1f98eb[_0x19d3ef(0x223)] / 0x2), this[_0x19d3ef(0x25f)](this[_0x19d3ef(0x27b)]);
                } else
                    this[_0x19d3ef(0x273)] == _0x19d3ef(0x236) && (this[_0x19d3ef(0x27c)] = [
                        _0x2e189e,
                        _0x4d27c0,
                        _0x1a77d3,
                        _0x35c5d5
                    ]);
            }
            ['scrollList']() {
                const _0x4b2e72 = _0x1d5775;
                if (!Laya || !Laya[_0x4b2e72(0x165)])
                    return null;
                if (YYGGames[_0x4b2e72(0x1f8)]() == AdPlatformType[_0x4b2e72(0x1fb)] || YYGGames[_0x4b2e72(0x1f8)]() == AdPlatformType[_0x4b2e72(0x1fc)]) {
                    let _0x16fd84 = new Laya[(_0x4b2e72(0x20f))]();
                    return _0x16fd84[_0x4b2e72(0x249)] = function() {}, _0x16fd84;
                }
                if (!this['_scrollList']) {
                    this[_0x4b2e72(0x236)] = new Laya[(_0x4b2e72(0x1eb))](), this[_0x4b2e72(0x236)][_0x4b2e72(0x273)] = _0x4b2e72(0x236), this[_0x4b2e72(0x236)]['skin'] = _0x4b2e72(0x23b), this['_scrollList']['sizeGrid'] = _0x4b2e72(0x240), this[_0x4b2e72(0x236)][_0x4b2e72(0x233)](0x384, 0xbe), this['_scrollList'][_0x4b2e72(0x1ee)] = 0x30d3f, this[_0x4b2e72(0x236)]['centerX'] = 0x0, this[_0x4b2e72(0x236)][_0x4b2e72(0x27c)] = [
                        0xc8,
                        0x96, ![], !![]
                    ];
                    class _0x59144c extends Laya[_0x4b2e72(0x20f)] {
                        constructor() {
                            const _0x4062b6 = _0x4b2e72;
                            super(), this[_0x4062b6(0x27d)] = 0x0, this[_0x4062b6(0x231)] = new Laya['Image'](), this[_0x4062b6(0x231)][_0x4062b6(0x273)] = _0x4062b6(0x231), this[_0x4062b6(0x231)][_0x4062b6(0x271)] = this['img'][_0x4062b6(0x272)] = 0.5, this[_0x4062b6(0x233)](0xdc, 0xaa), this[_0x4062b6(0x231)][_0x4062b6(0x233)](0xc8, 0x96), this['addChild'](this[_0x4062b6(0x231)]), this['imgMask'] = new Laya[(_0x4062b6(0x1eb))](), this[_0x4062b6(0x27e)][_0x4062b6(0x275)] = _0x4062b6(0x240), this['imgMask']['name'] = 'imgMask', this[_0x4062b6(0x27e)][_0x4062b6(0x271)] = this[_0x4062b6(0x27e)][_0x4062b6(0x272)] = 0.5, this[_0x4062b6(0x27e)]['skin'] = _0x4062b6(0x23f), this[_0x4062b6(0x27e)][_0x4062b6(0x233)](0xc8, 0x96), this['img'][_0x4062b6(0x241)] = this[_0x4062b6(0x27e)], this['img'][_0x4062b6(0x224)](this[_0x4062b6(0x1db)] / 0x2, this[_0x4062b6(0x223)] / 0x2), this[_0x4062b6(0x27e)][_0x4062b6(0x224)](this[_0x4062b6(0x231)][_0x4062b6(0x1db)] / 0x2, this[_0x4062b6(0x231)][_0x4062b6(0x223)] / 0x2);
                        }
                    }
                    let _0x246076 = new Laya[(_0x4b2e72(0x234))]();
                    _0x246076[_0x4b2e72(0x27f)] = '\x20', _0x246076[_0x4b2e72(0x273)] = _0x4b2e72(0x280), _0x246076[_0x4b2e72(0x271)] = _0x246076[_0x4b2e72(0x272)] = 0.5, _0x246076[_0x4b2e72(0x233)](0x370, 0xaa), _0x246076['scrollBar'][_0x4b2e72(0x24b)] = ![], _0x246076['scrollBar'][_0x4b2e72(0x24c)] = ![], _0x246076[_0x4b2e72(0x24a)][_0x4b2e72(0x281)] = ![], _0x246076[_0x4b2e72(0x235)] = _0x59144c, _0x246076[_0x4b2e72(0x245)] = new Laya[(_0x4b2e72(0x1f6))](this, this['renderADHandler']), this[_0x4b2e72(0x236)][_0x4b2e72(0x20c)](_0x246076), _0x246076[_0x4b2e72(0x224)](this[_0x4b2e72(0x236)][_0x4b2e72(0x1db)] / 0x2, this['_scrollList'][_0x4b2e72(0x223)] / 0x2);
                    let _0x55e41a = _0x2ff701['getInstance']()[_0x4b2e72(0x1e4)]();
                    if (!_0x55e41a['length'])
                        return;
                    let _0x3daa8f = JSON[_0x4b2e72(0x178)](JSON[_0x4b2e72(0x1c6)](_0x55e41a));
                    _0x3daa8f = _0x3daa8f[_0x4b2e72(0x24e)](_0x3daa8f['slice'](0x0, 0x4)), _0x246076[_0x4b2e72(0x250)] = _0x3daa8f, Laya['timer'][_0x4b2e72(0x282)](0x1, this, this[_0x4b2e72(0x251)]), Laya[_0x4b2e72(0x164)]['once'](0x64, this, () => {
                        const _0x97c969 = _0x4b2e72;
                        _0x246076[_0x97c969(0x283)]();
                    }), this[_0x4b2e72(0x236)]['visible'] = ![], this[_0x4b2e72(0x236)]['setSize'] = this[_0x4b2e72(0x249)][_0x4b2e72(0x15a)](this[_0x4b2e72(0x236)]);
                }
                return this['_scrollList'];
            }
            ['renderADHandler'](_0xefc50a, _0x594491) {
                const _0x271ea1 = _0x1d5775;
                let _0x3d53db = _0xefc50a[_0x271ea1(0x257)],
                    _0x54a843 = _0xefc50a[_0x271ea1(0x222)](_0x271ea1(0x231)),
                    _0x15f069 = _0x54a843[_0x271ea1(0x241)];
                _0x54a843['skin'] = _0x3d53db['thumb'];
                this['_scrollList'][_0x271ea1(0x27c)][0x3] && (_0xefc50a['size'](0xdc, 0xaa), _0xefc50a['img'][_0x271ea1(0x233)](0xc8, 0x96), _0x15f069[_0x271ea1(0x233)](0xc8, 0x96), _0xefc50a[_0x271ea1(0x1cb)](0x1, 0x1), _0xefc50a[_0x271ea1(0x1cb)](0x1, 0x1), _0x15f069[_0x271ea1(0x1cb)](0x1, 0x1));
                _0xefc50a[_0x271ea1(0x252)](), _0x54a843[_0x271ea1(0x252)](), _0xefc50a['on'](Laya[_0x271ea1(0x207)]['MOUSE_OVER'], _0xefc50a, () => {
                    _0xefc50a['zOrder'] = 0x64;
                }), _0xefc50a['on'](Laya[_0x271ea1(0x207)][_0x271ea1(0x254)], _0xefc50a, () => {
                    const _0x5b5ac2 = _0x271ea1;
                    _0xefc50a[_0x5b5ac2(0x1ee)] = _0x594491;
                }), _0x54a843['on'](Laya[_0x271ea1(0x207)][_0x271ea1(0x253)], _0xefc50a, () => {
                    const _0x4608d0 = _0x271ea1;
                    _0x54a843['scale'](_0x54a843[_0x4608d0(0x284)] + 0.1, _0x54a843[_0x4608d0(0x285)] + 0.1), this['endAni']();
                }), _0x54a843['on'](Laya[_0x271ea1(0x207)][_0x271ea1(0x254)], _0xefc50a, () => {
                    const _0x132c5f = _0x271ea1;
                    _0x54a843[_0x132c5f(0x1cb)](_0x54a843[_0x132c5f(0x284)] - 0.1, _0x54a843[_0x132c5f(0x285)] - 0.1), Laya['timer'][_0x132c5f(0x282)](0x1, this, this[_0x132c5f(0x251)]);
                }), _0x54a843['on'](Laya[_0x271ea1(0x207)][_0x271ea1(0x1fe)], _0xefc50a, _0x4c9ab3 => {
                    const _0x559520 = _0x271ea1;
                    _0x4c9ab3['stopPropagation'](), _0x2ff701[_0x559520(0x1b9)]()[_0x559520(0x1c0)]('GAME', _0x559520(0x256), _0x3d53db['id']);
                });
                let _0x426f9c = 0xc8;
                this['_scrollList'][_0x271ea1(0x27c)][0x0] / 0xc8 > this[_0x271ea1(0x236)][_0x271ea1(0x27c)][0x1] / 0x96 ? _0x426f9c = this[_0x271ea1(0x236)][_0x271ea1(0x27c)][0x0] / 0xc8 : _0x426f9c = this['_scrollList'][_0x271ea1(0x27c)][0x1] / 0x96;
                let _0x178e31 = 0xc8,
                    _0x4e2936 = 0xc8 * this[_0x271ea1(0x236)][_0x271ea1(0x27c)][0x1] / this['_scrollList'][_0x271ea1(0x27c)][0x0];
                _0xefc50a[_0x271ea1(0x233)](_0x178e31 + 0x14, _0x4e2936 + 0x14), _0x15f069[_0x271ea1(0x233)](_0x178e31, _0x4e2936), !this[_0x271ea1(0x236)][_0x271ea1(0x27c)][0x2] ? _0xefc50a[_0x271ea1(0x231)][_0x271ea1(0x233)](_0x178e31, _0x4e2936) : (leftAd[_0x271ea1(0x233)](0xc8 * _0x426f9c, 0x96 * _0x426f9c), rightAd['size'](0xc8 * _0x426f9c, 0x96 * _0x426f9c)), _0x54a843[_0x271ea1(0x224)](_0xefc50a[_0x271ea1(0x1db)] / 0x2, _0xefc50a[_0x271ea1(0x223)] / 0x2), _0x15f069[_0x271ea1(0x224)](_0x54a843[_0x271ea1(0x1db)] / 0x2, _0x54a843[_0x271ea1(0x223)] / 0x2);
            }
            [_0x1d5775(0x255)]() {
                const _0x3ad96f = _0x1d5775;
                Laya[_0x3ad96f(0x164)][_0x3ad96f(0x25b)](this, this[_0x3ad96f(0x251)]);
            }
            [_0x1d5775(0x251)]() {
                const _0x50337b = _0x1d5775;
                if (!this[_0x50337b(0x236)]) {
                    this['endAni']();
                    return;
                }
                let _0xe6998b = this[_0x50337b(0x236)][_0x50337b(0x222)](_0x50337b(0x280));
                _0xe6998b[_0x50337b(0x24a)][_0x50337b(0x258)] += 0x1, _0xe6998b['scrollBar'][_0x50337b(0x258)] >= _0xe6998b[_0x50337b(0x24a)][_0x50337b(0x259)] && (_0xe6998b['scrollBar'][_0x50337b(0x258)] = 0x0);
            }
            [_0x1d5775(0x286)](_0xf4ee76) {
                const _0x4e31e7 = _0x1d5775;
                if (_0xf4ee76[_0x4e31e7(0x273)] == _0x4e31e7(0x26e)) {
                    let _0x7862ef = _0xf4ee76[_0x4e31e7(0x222)](_0x4e31e7(0x274)),
                        _0x3ec53b = _0xf4ee76[_0x4e31e7(0x222)](_0x4e31e7(0x27a)),
                        _0x5cf67d = _0x2ff701[_0x4e31e7(0x1b9)]()['getForgames']();
                    if (!_0x5cf67d[_0x4e31e7(0x1e7)])
                        return;
                    let _0x6d8f84 = JSON['parse'](JSON[_0x4e31e7(0x1c6)](_0x5cf67d));
                    _0x7862ef[_0x4e31e7(0x252)](), _0x3ec53b[_0x4e31e7(0x252)](), _0x7862ef[_0x4e31e7(0x222)]('leftAd')['skin'] = _0x6d8f84[0x0][_0x4e31e7(0x232)], _0x3ec53b['getChildByName'](_0x4e31e7(0x279))[_0x4e31e7(0x1ed)] = _0x6d8f84[0x1]['thumb'], _0x7862ef['on'](Laya[_0x4e31e7(0x207)][_0x4e31e7(0x1fe)], _0xf4ee76, _0x22a907 => {
                        const _0xc34e68 = _0x4e31e7;
                        _0x22a907[_0xc34e68(0x208)](), _0x2ff701[_0xc34e68(0x1b9)]()[_0xc34e68(0x1c0)](_0xc34e68(0x1ff), _0xc34e68(0x256), _0x6d8f84[0x0]['id']);
                    }), _0x3ec53b['on'](Laya[_0x4e31e7(0x207)][_0x4e31e7(0x1fe)], _0xf4ee76, _0x5aba29 => {
                        const _0x3fb084 = _0x4e31e7;
                        _0x5aba29[_0x3fb084(0x208)](), _0x2ff701[_0x3fb084(0x1b9)]()[_0x3fb084(0x1c0)](_0x3fb084(0x1ff), _0x3fb084(0x256), _0x6d8f84[0x1]['id']);
                    });
                }
            }
            [_0x1d5775(0x25f)](_0x48deec) {
                const _0x201d9d = _0x1d5775;
                if (this[_0x201d9d(0x273)] == _0x201d9d(0x26e)) {
                    let _0x2c93db = this[_0x201d9d(0x222)](_0x201d9d(0x274)),
                        _0x3d57ed = this[_0x201d9d(0x222)](_0x201d9d(0x27a));
                    _0x3d57ed[_0x201d9d(0x224)](_0x2c93db[_0x201d9d(0x1db)] + _0x48deec, 0x0), this[_0x201d9d(0x1db)] = _0x2c93db[_0x201d9d(0x1db)] + _0x3d57ed[_0x201d9d(0x1db)] + _0x48deec, this[_0x201d9d(0x27b)] = _0x48deec;
                }
            }
    }
}());