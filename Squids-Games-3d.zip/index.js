var _0x2eb1f5 = _0x4905;

function _0x4905(_0x4d0c33, _0x52b0cf) {
    var _0x155055 = _0x1550();
    return _0x4905 = function(_0x4905f6, _0x31220e) {
        _0x4905f6 = _0x4905f6 - 0x159;
        var _0x49eab4 = _0x155055[_0x4905f6];
        return _0x49eab4;
    }, _0x4905(_0x4d0c33, _0x52b0cf);
}

function _0x1550() {
    var _0x4dc306 = [
        'libs/min/laya.physics3D.min.js',
        'libs/min/laya.d3.min.js',
        'libs/min/domparserinone.min.js',
        'libs/min/fx.phx.min.js',
        'js/bundle.js',
        '27cYRAqU',
        '21562RiaAzO',
        '4019340oVQeLT',
        '3877216PcWZZU',
        '565rcppNn',
        '11262XUOmxK',
        '6501782cqzYFC',
        '131832EDqiUI',
        '9Vzroxn',
        '25712470neHuuz',
        'overGameStat',
        'screenOrientation',
        'sensor_portrait',
        'runtime/helpers/setPrototypeOf.js',
        'runtime/helpers/getPrototypeOf.js',
        'runtime/helpers/get.js',
        'runtime/helpers/set.js',
        'runtime/helpers/isNativeReflectConstruct.js',
        'runtime/helpers/assertThisInitialized.js',
        'runtime/helpers/possibleConstructorReturn.js',
        'runtime/helpers/arrayLikeToArray.js',
        'runtime/helpers/arrayWithoutHoles.js',
        'runtime/helpers/classCallCheck.js',
        'runtime/helpers/createClass.js',
        'runtime/helpers/createForOfIteratorHelper.js',
        'runtime/helpers/createSuper.js',
        'runtime/helpers/defineProperty.js',
        'runtime/helpers/iterableToArray.js',
        'runtime/helpers/nonIterableSpread.js',
        'runtime/helpers/superPropBase.js',
        'runtime/helpers/toConsumableArray.js',
        'runtime/helpers/unsupportedIterableToArray.js',
        'libs/min/laya.core.min.js',
        'libs/min/laya.ani.min.js',
        'libs/min/laya.html.min.js',
        'libs/min/laya.particle.min.js',
        'libs/min/laya.ui.min.js'
    ];
    _0x1550 = function() {
        return _0x4dc306;
    };
    return _0x1550();
}
(function(_0x3770b8, _0x350797) {
    var _0x3e1584 = _0x4905,
        _0x4534dd = _0x3770b8();
    while (!![]) {
        try {
            var _0x541c7f = parseInt(_0x3e1584(0x159)) / 0x1 * (-parseInt(_0x3e1584(0x15a)) / 0x2) + -parseInt(_0x3e1584(0x15b)) / 0x3 + -parseInt(_0x3e1584(0x15c)) / 0x4 + -parseInt(_0x3e1584(0x15d)) / 0x5 * (parseInt(_0x3e1584(0x15e)) / 0x6) + parseInt(_0x3e1584(0x15f)) / 0x7 + -parseInt(_0x3e1584(0x160)) / 0x8 * (parseInt(_0x3e1584(0x161)) / 0x9) + parseInt(_0x3e1584(0x162)) / 0xa;
            if (_0x541c7f === _0x350797)
                break;
            else
                _0x4534dd['push'](_0x4534dd['shift']());
        } catch (_0x21ad87) {
            _0x4534dd['push'](_0x4534dd['shift']());
        }
    }
}(_0x1550, 0xa3e5a), window[_0x2eb1f5(0x163)] = 0x0, (window[_0x2eb1f5(0x164)] = _0x2eb1f5(0x165), loadLib(_0x2eb1f5(0x166)), loadLib(_0x2eb1f5(0x167)), loadLib(_0x2eb1f5(0x168)), loadLib(_0x2eb1f5(0x169)), loadLib('runtime/helpers/typeof.js'), loadLib(_0x2eb1f5(0x16a)), loadLib(_0x2eb1f5(0x16b)), loadLib(_0x2eb1f5(0x16c)), loadLib('runtime/helpers/Arrayincludes.js'), loadLib(_0x2eb1f5(0x16d)), loadLib(_0x2eb1f5(0x16e)), loadLib(_0x2eb1f5(0x16f)), loadLib(_0x2eb1f5(0x170)), loadLib(_0x2eb1f5(0x171)), loadLib(_0x2eb1f5(0x172)), loadLib(_0x2eb1f5(0x173)), loadLib('runtime/helpers/inherits.js'), loadLib(_0x2eb1f5(0x174)), loadLib(_0x2eb1f5(0x175)), loadLib(_0x2eb1f5(0x176)), loadLib(_0x2eb1f5(0x177)), loadLib(_0x2eb1f5(0x178)), loadLib(_0x2eb1f5(0x179)), loadLib(_0x2eb1f5(0x17a)), loadLib(_0x2eb1f5(0x17b)), loadLib(_0x2eb1f5(0x17c)), loadLib(_0x2eb1f5(0x17d)), loadLib(_0x2eb1f5(0x17e)), loadLib(_0x2eb1f5(0x17f)), loadLib(_0x2eb1f5(0x180)), loadLib(_0x2eb1f5(0x181)), loadLib(_0x2eb1f5(0x182))));