function _0x372d(_0x4597fd, _0x378058) {
    var _0x3c3a55 = _0x3c3a();
    return _0x372d = function(_0x372d35, _0x26ea34) {
        _0x372d35 = _0x372d35 - 0x1b2;
        var _0x1d299f = _0x3c3a55[_0x372d35];
        return _0x1d299f;
    }, _0x372d(_0x4597fd, _0x378058);
}

function _0x3c3a() {
    var _0x2e192b = [
        'E_GLASS_BREAK',
        'onGlassBreak',
        'delta',
        'getEndPos',
        'checkFrontWay',
        'waitTime',
        'doJump',
        'canAdvance',
        'ray',
        'origin',
        'direction',
        'goToTarPos',
        'isArriveTarPos',
        'addTargetPosArr',
        'getSameChoiceGroupOtherTarPos',
        'curTarPos',
        'TargetPos',
        'getTarPos',
        'equals',
        'EndPos',
        'random',
        'findIndex',
        'addGlassArr',
        'getGlassArr',
        'choiceGroup',
        'RobotsCnt',
        'Robots',
        'robots',
        'endPos',
        'ChoiceGroup',
        'addTargetPos',
        'deleteTargetPos',
        'numChildren',
        'whole',
        'killAllPlayer',
        'host',
        'glassArr',
        'glass',
        'fullIdx',
        'initGlass',
        'parent',
        'part',
        'playSoundById',
        'playMusicById',
        'stopMusicById',
        'You\x20need\x20to\x20pass\x20the\x20glass\x0a\x20\x20\x20bridge\x20within\x202\x20minutes',
        'Good\x20luck',
        'playerNum',
        'levName',
        'lvl',
        'startPlat',
        'plat',
        'deathArea',
        'GameScene123',
        'WirewalkingScene',
        'GlassBridgeScene',
        'maxHeadTipsCnt',
        'init3d',
        'box_adTwo',
        'btn_music',
        'btn_help',
        'showHelp',
        'WebAudioEngine',
        'pause',
        'game/btn_sound_off.png',
        'game/btn_sound_on.png',
        'btn_ready',
        'readyStart',
        'setItem',
        'musicState',
        'showHeadTips',
        'createPrefab',
        'ui_view',
        'HtmlText',
        'richTxt',
        'img_head',
        'img_icon',
        'skin',
        'defaultStyle',
        'setText',
        '<span\x20style=\x27color:',
        'color',
        ';font:32px\x20Arial;stroke:3\x27>',
        '</span>&nbsp;&nbsp;\x20join\x20the\x20game',
        'delay',
        'parallel',
        'fadeOut',
        'exec',
        'checkPower',
        'isCostPower',
        'initAI',
        'Round\x20',
        'b_countdown',
        'txt_time',
        'robotPrefab',
        'rotationEuler',
        'Ground',
        'RobotArea',
        'get3dModelBounds',
        'worldToLocal',
        'genRobot',
        'randomPointInBounds',
        'sceneName',
        'LS_MAINSCENE',
        'PFB_RICKTEXT_TIPS',
        'MainSceneUI',
        'count',
        'packages',
        'pb_progress',
        'loginServer',
        'loadNext',
        'onLoadSuccess',
        'yadstartup',
        'Squids-Games-3d',
        'bottom',
        'E_SDK_INIT_OK',
        'complete',
        'res/sound/ghost1.mp3',
        'res/sound/ghost2.mp3',
        'res/sound/ghost3.mp3',
        'res/sound/ghost4.mp3',
        'res/sound/ghost5.mp3',
        'res/sound/ghost6.mp3',
        'res/sound/ghost7.mp3',
        'res/sound/ghost8.mp3',
        '切换游戏场景！',
        'LoadingScript',
        'hideSplash',
        'showBanner',
        'label_cnt',
        'img_video',
        'onClickItem',
        'gameId',
        'GameCnt',
        'UNKNOWN',
        'unknown',
        'LOADRES',
        'loadres',
        'SETRANK',
        'setrank',
        'changepage',
        'UNDISPLAY',
        'undisplay',
        'TOUCH_EVENT',
        'PASS_EVENT',
        'pass_event',
        'compareVersion',
        'getSystemInfo',
        'SDKVersion',
        '2.9.0',
        'headList',
        'changeBtn',
        'changeList',
        'dataSource',
        'openRank',
        'cellUpdata',
        'isOnWeiXin',
        'res/atlas/res/popularizeRes.atlas',
        'MiniAdpter',
        'type',
        'ShareFriendUI',
        'wx_open_data_viewerTouchEvent',
        'window',
        'passData',
        'Point',
        'localToGlobal',
        'adunit-ab87dacba2f45583',
        'screenWidth',
        'customId',
        'hideBlockAd',
        'Ease',
        'backOut',
        'backIn',
        'label_value',
        'img_infinity',
        'onClickAdd',
        'recoverCd',
        'CoinsChange',
        'E_PROP_CHANGED',
        'getCurDialogRegName',
        'designHeight',
        'top',
        'KEY_UP',
        'onKeyUp',
        'onKeyDown',
        'initList',
        'updateItem',
        'keyCode',
        'KeyBoardManager',
        'hasKeyDown',
        'moveForward',
        'moveRight',
        'lookForward',
        'getDefault3dScene',
        'lookRight',
        '_record_time',
        'maxRecordTime',
        'record_time',
        '_maxRecordTime',
        'giveRewardEvent',
        '分享成功，获得300金币~',
        'SHARE_FAILED',
        'NOT_RECORD',
        'START_RECORD',
        'SUCCESS_RECORD',
        'res/record_3.png',
        'res/record_1.png',
        '$GAME_RECORD',
        'E_RECORD_READY',
        'E_RECORD_START',
        'E_RECORD_FAILED',
        'E_RECORD_REVIVE',
        'E_RECORD_FINISH',
        'E_RECORD_VIDEO_END',
        'E_RECORD_VIDEO_PAUSE',
        'E_RECORD_VIDEO_RESUME',
        'E_GAME_RECORD',
        'end_video',
        'pause_video',
        'resume_video',
        'share_success',
        'onGameRecordEvent',
        'shareImg',
        '_owner',
        'shareTime',
        'playStage',
        'start_video',
        '请耐心录制3秒以上~',
        'stopRecord',
        'funcName',
        'end_record',
        'source',
        'toString',
        'resumeBtnStage',
        'V1934A',
        'model',
        'devtools',
        '游戏准备~',
        'start_record',
        '游戏开始~',
        'pause_record',
        '游戏失败~',
        'resume_record',
        '游戏复活~',
        '游戏结束~',
        'startRecord',
        'record_pause',
        'record_resume',
        'actionLock',
        'boxBgScaleMin',
        'boxBgScaleMax',
        'settingBox',
        'settingBoxBg',
        'setting_box_bg',
        'settingBtnIcon',
        'setting_btn_icon',
        'sound_btn',
        'shakeBtn',
        'shake_btn',
        'soundBtn',
        'setting_box_listener',
        'sound_btn_listener',
        'refreshSelf',
        'SettingBtnScript组件初始化失败！',
        'shake_btn_listener',
        'setActionLockTimer',
        'actionLockTimer',
        'setAtionLock',
        'trigger',
        'settingBoxSwitch',
        'toggleAll',
        'soundFx:',
        'vibrateEnable:',
        'UI_SHAKE_ON_IMG',
        'UI_SHAKE_OFF_IMG',
        'UI_SOUND_OFF_IMG',
        'script/ScaleEffectBtn.ts',
        'script/AliveCntScript.ts',
        'script/GameCountdown.ts',
        'script/PlayerInputScript.ts',
        'script/LoadingScript.ts',
        'script/GameUITimer.ts',
        'script/GameItemScript.ts',
        'script/ShareFriendScript.ts',
        'modules/WXExportAd/CustomAd.ts',
        'script/GuessMarbleScript.ts',
        'script/PulseEffectBtn.ts',
        'modules/Power/PowerScript.ts',
        'script/BoxCoinScript.ts',
        'script/SettingBtnScript.ts',
        'showall',
        'none',
        'alignV',
        'alignH',
        'center',
        'startScene',
        'scenes/LoadingScene.scene',
        'debug',
        'exportSceneToJson',
        'enableLog',
        '#C0C0C0',
        'warn',
        'error',
        'showStat',
        'Stat',
        'show',
        'hideStat',
        'disableGPUTips',
        'sDisableGpu',
        'killRobot',
        'finishGame',
        'fly',
        'fast',
        'openGlassBridge',
        'sInit',
        'isOnMiniGame',
        'URL',
        'basePath',
        'AutoCacheDownFile',
        'remotefiles',
        'MouseManager',
        'onLoaded',
        'loadJson',
        'Config\x20Load\x20Completed\x20!',
        'launch',
        'initGraphicsSetting',
        'AppBase',
        '1091696aqlyXi',
        '56MtGbIP',
        '25527EBmIlh',
        '3588476bAtPqX',
        '5rDYHgt',
        '2970918SZhWcO',
        '7765373FMGNuW',
        '6897832jvIPvE',
        '9SlSWdV',
        '10930ISnsZz',
        '18293lzhzXP',
        '../runtime/helpers/possibleConstructorReturn',
        '../runtime/helpers/toConsumableArray',
        '../runtime/helpers/get',
        '../runtime/helpers/getPrototypeOf',
        '../runtime/helpers/classCallCheck',
        '../runtime/helpers/inherits',
        '../runtime/helpers/createSuper',
        'Vector2',
        'Vector3',
        'Sprite3D',
        'MeshSprite3D',
        'res/head.png',
        'res/img_tips.png',
        'res/img_coins.png',
        'res/img_diamond.png',
        'res/img_video.png',
        'res/img_share.png',
        'json/gameCfg.json',
        'res/sound/click_ui.mp3',
        'res/turntable/wheel_start.mp3',
        'res/turntable/wheel_end.mp3',
        'res/sound/Diamond_Collect.mp3',
        'res3d/Textures/shadow.png',
        'res3d/Textures/water.png',
        'res3d/Textures/waves_n.png',
        'scenes/prefab/boxGameCD.json',
        'scenes/prefab/RichTextTips.json',
        'res3d/Character.lh',
        '$GAME_STATE_CHANGE',
        'COLLISION_EXIT',
        'TRIGGER_ENTER',
        'TRIGGER_EXIT',
        '$E_CLOSE_ALL_PANEL',
        '$E_GAME_TIME_IS_UP',
        '$E_CHARACTER_CNT_CHANGED',
        '$E_GAME_CNT_CHANGED',
        'E_COLLIDE_ENTER',
        'E_COLLIDE_EXIT',
        'E_GAME_READY',
        'E_GAME_START',
        'E_GAME_PAUSE',
        'E_GAME_FINISH',
        'E_GAME_FAILED',
        'E_GAME_OVER',
        'NONE',
        'DEFAULT',
        'Physics3DUtils',
        'ALL',
        'COLLISIONFILTERGROUP_ALLFILTER',
        'COLLISIONFILTERGROUP_STATICFILTER',
        'STATIC',
        'PLAYER',
        'FINISH_BOX',
        'COLLISIONFILTERGROUP_CUSTOMFILTER2',
        'DEATH_AREA',
        'apply',
        'BaseData',
        'cnt',
        'call',
        'anchorCenter',
        'scaleY',
        'onAwake',
        'Utils',
        'resetAnchor',
        'Effect',
        'owner',
        'scaleX',
        'onClicked',
        'res',
        'SoundManager',
        'instance',
        'playSound',
        'SOUND_CLICK',
        'Script',
        'ownerUI',
        'labelCd',
        'getChildByName',
        'label_cd',
        'visible',
        'onDestroy',
        'stopSoundFx',
        'res/sound/countdown1.mp3',
        'res/sound/countdown2.mp3',
        'text',
        'onCD',
        'Start',
        'clearTimer',
        'timerOnce',
        'run',
        'vibrateEnable',
        'coins',
        'guideSteps',
        'gameInfos',
        'ugcShareSkinId',
        'stageSkinInfo',
        'stageSkins',
        'isBreakingIce',
        'signInDays',
        'turntableFreetime',
        'turntableCnt',
        'trySkinNum',
        'keyNum',
        'isFirstSuper',
        'stageId',
        'dirty',
        'addCoins',
        'save',
        '_interstitialIndex',
        'onInitOnce',
        'UserLogic',
        'onInit',
        'player',
        'getPlayerInfo',
        'getUserInfo',
        'coinsEnough',
        'showInterstitial',
        'Sdk',
        'showInterstitialMain',
        '_instance',
        'BaseLogic',
        'lastDeadSoundTime',
        'isSpecial',
        'getItem',
        'youyuIsSpecialGame',
        'playDeadSound',
        'res/sound/die.mp3',
        'randomHat',
        'getChildBySubName',
        'Character',
        'hat',
        'randomByRate',
        'active',
        'SkinnedMeshSprite3D',
        'skinnedMeshRenderer',
        'material',
        'emissionTexture',
        'getNumberRandom',
        'emissionColor',
        'SimpleSkinnedMeshSprite3D',
        'albedoTexture',
        'formatScenePath',
        'replace',
        '.ls',
        '_bytedance.ls',
        'formatSoundPath',
        '.mp3',
        '_bytedance.mp3',
        'headArr',
        'timer3d',
        'constantCfg',
        'get',
        'JSON_GAME_CFG',
        'gameCfg',
        'BaseDataModel',
        'miniGameCfg',
        'recurisRaw',
        'maxMiniGameId',
        'PREFAB_CHARACTER',
        '.lh',
        '_bytedance.lh',
        'gameState',
        '_deadIndex',
        'characters',
        'getGameConstants',
        'event',
        'E_GAME_STATE_CHANGED',
        'offAll',
        'getGameState',
        'goMain',
        'ClassUtils',
        'getRegClass',
        'MainScene',
        'changeScene',
        'getStageCfg',
        'specMiniGameId',
        'goNextStage',
        'curMiniGameInfo',
        'stageIncreasing',
        'turnIndex',
        'init',
        'E_GO_NEXT_STAGE',
        'setCurStage',
        'setCurStageInfo',
        'postMessage',
        'getOpenDataContext',
        'revive',
        'setGameState',
        'clear',
        'getIntRandom',
        'addCharacter',
        'E_CHARACTER_CNT_CHANGED',
        'length',
        'removeCharacter',
        'indexOf',
        'splice',
        'getCharacterCnt',
        'getCharacters',
        'getTurnIndex',
        'getGameDuration',
        'duration',
        'deadIndex',
        'robotsCnt',
        '_robotsCnt',
        'done',
        'value',
        'getGameCnt',
        'getGameInfo',
        'max',
        'E_GAME_CNT_CHANGED',
        'addGameCnt',
        'getRandomHeadCfg',
        'push',
        'randomArray',
        'label_aliveCnt',
        'updateUI',
        'EventCenter',
        'offAllCaller',
        'concat',
        'labelCD',
        'onGameStateChange',
        'isStart',
        'updateLabel',
        'start',
        'onUpdate',
        'timestampToMS',
        '_downEnable',
        'downEnable',
        'joystickNode',
        'showHandle',
        'background',
        'handle',
        'input',
        'lastPos',
        'moveY',
        'originPos',
        'height',
        'img_jump',
        'Browser',
        'onPC',
        'Event',
        'MOUSE_DOWN',
        'stopPropagation',
        'onDown',
        'mouseDown',
        'stageX',
        'pos',
        'drag',
        'setValue',
        'stageY',
        'onMove',
        'moveX',
        'onUp',
        'updateHandle',
        'width',
        'scale',
        'scalarLength',
        'centerY',
        'onLateUpdate',
        'getLookInputsHorizontal',
        '_moveEnable',
        'moveEnable',
        'joysticks',
        'moveInput',
        'getComponent',
        'rotInput',
        'stage',
        'MOUSE_OUT',
        'onStageMouseDown',
        'getJoystickByPosition',
        'touchId',
        'getJoystickByTouchId',
        'hideBanner',
        '1.0.1',
        'GameMsgEvent',
        'MsgUrlDefine',
        'version',
        'manifestFile',
        'version.json',
        'test_user_1312527',
        'platform',
        'PlatformType',
        'server_cfg_url',
        'res_server_url',
        'local_share_image',
        'ald_share_enable',
        'wx56a95af91d2ada07',
        'stat',
        'saveDurSec',
        'showBQ',
        'adunit-166e12f7ff099c66',
        'adunit-6eccbcce80e6be32',
        'adunit-fc98346e27720721',
        'BaseScene',
        'BaseDialog',
        'regClass',
        'createChildren',
        'prototype',
        'loadScene',
        'ui.scenes.GameFailedDialogUI',
        'scenes/GameGlassBridge',
        'GameGlassBridgeUI',
        'ui.scenes.GameGlassBridgeUI',
        'scenes/GameScene123',
        'GameScene123UI',
        'ui.scenes.GameScene123UI',
        'GameSuccessDialogUI',
        'ui.scenes.GameSuccessDialogUI',
        'scenes/MainScene',
        'ui.scenes.MainSceneUI',
        'scenes',
        'GuessMarbleSceneUI',
        'ui.scenes.marble.GuessMarbleSceneUI',
        'marble',
        'scenes/power/PowerDialog',
        'PowerDialogUI',
        'ui.scenes.power.PowerDialogUI',
        'power',
        'scenes/shareGuide/ShareGuide',
        'ui.scenes.shareGuide.ShareGuideUI',
        'shareGuide',
        'disableSimulation',
        'World',
        'Physics',
        'physicWorld',
        'PhysicsSimulation',
        'physicsSimulation',
        'rayCast',
        'bind',
        'SLEEP_LINEAR_VELOCITY',
        'SLEEP_ANGULAR_VELOCITY',
        'SLEEP_DELTA_TIME',
        'FIX_PENETRATE_SQ',
        'Directional\x20Light',
        'getAllCameras',
        'forEach',
        'enableHDR',
        'GraphicsCfg',
        'enableFog',
        'fogColor',
        'color4Fto3F',
        'clearColor',
        'water',
        'sWaterMat',
        'genWaterMaterial',
        'TEX_WATER',
        'getSpRenderer',
        'light',
        'step',
        'loader',
        'getRes',
        'destroyed',
        'bitmap',
        'wrapModeU',
        'wrapModeV',
        'lock',
        'mainTexture',
        'normalTexture',
        '_addReference',
        'load',
        'Handler',
        'create',
        'Script3D',
        'hitPos',
        'camera',
        'from',
        'transform',
        'bindPlayer',
        'distance',
        'position',
        'clone',
        'subtract',
        'normalize',
        'rayCastByDir',
        'target',
        'name',
        'includes',
        'Wall',
        'add',
        'locateCameraSp',
        'temp2',
        'impulse',
        'bodyEnableRadius',
        'safeArea',
        'enabled',
        'enableBodyByRadius',
        'origSp',
        'bodyEnableOnce',
        'isStatic',
        'isSyncShape',
        'distanceSquared',
        'obstacle',
        'onEnable',
        'sleeping',
        'boxContainsPoint',
        'onOutSide',
        'onDisable',
        'applyImpulse',
        'scalarLengthSquared',
        'body',
        'getImpulse',
        'setVelocity',
        'linearVelocity',
        'temp',
        'setSpeed',
        'linearSpeed',
        'getSpeed',
        'getInvMass',
        'awake',
        'sleep',
        'overrideGravity',
        'getBodyName',
        'positionConstraint',
        'setLinearVelocityConstraint',
        'linearVelocityConstraint',
        'linearVelocityMax',
        'setAngularVelocityConstraint',
        'angularVelocityMax',
        'ZERO',
        'getBoundBox',
        'min',
        'boundBox',
        'PhysicsScript',
        'crashSprite3D',
        'clearCrashBox',
        'clearCrashBoxGravity',
        'createMeshColliderShape',
        'addComponent',
        'PhysicsCollider',
        'MeshColliderShape',
        'sharedMesh',
        'colliderShape',
        'collisionGroup',
        'createBoxColliderShape',
        'BoxColliderShape',
        'canCollideWith',
        'setRigidBodyCollideWith',
        'Rigidbody3D',
        'meshFilter',
        '__smoothprocmeshcollider',
        'mesh',
        'setColliderShapeGroup',
        'off',
        '_nativeTriangleMesh',
        'Mesh',
        '_physics3D',
        'btTriangleMesh',
        '_nativeTempVector32',
        '_tempVector31',
        '_tempVector32',
        '_getPositionElement',
        'getData',
        'vertexDeclaration',
        'vertexStride',
        'offset',
        '_indexBuffer',
        'Utils3D',
        '_convertToBulletVec3',
        'frameLoop',
        'timer',
        'playBombEff',
        'playMagEff',
        'playChainEff',
        '__involveNodes',
        'playHoleEff',
        'playRollUpEff',
        'playTornadoEff',
        'playThunderLightEff',
        'effColorSplash',
        '__color_splash_anim',
        'meshRenderer',
        'shininess',
        'specularColor',
        'tween',
        'Tween',
        'stopColorSplashAnim',
        'REMOVED',
        '__scale_anim',
        'getWorldLossyScale',
        'setWorldLossyScale',
        'stopScaleAnim',
        'once',
        'enableMeshRender',
        'filterAffectObstacles',
        'PHYSICS_DEBUG_SHOW',
        'disableShadow',
        'showTips',
        '#ffffff',
        'Label',
        'fontSize',
        'centerX',
        'strokeColor',
        '#000000',
        'Box',
        'zOrder',
        'Image',
        'res/img_bg.png',
        '12,11,12,11',
        'alpha',
        'addChild',
        'caller',
        'getFormatCD',
        'number',
        'floor',
        'Helper',
        'currentStateID',
        'currentState',
        '_currentState',
        'update',
        'addState',
        'states',
        '_currentStateID',
        'log',
        'FSM\x20ERROR:\x20Impossible\x20to\x20add\x20state\x20',
        '\x20because\x20state\x20has\x20already\x20been\x20added',
        'deleteState',
        'performTransition',
        'getOutputState',
        'onExit',
        'handleMessage',
        'onMessage',
        'getCurrentStateID',
        'stateId',
        'addTransition',
        'map',
        'deleteTransition',
        'delete',
        'has',
        'onEnter',
        'NoInput',
        'Input',
        'Jump',
        'Idle',
        'Move',
        'blackBorad',
        'playAnim',
        'jump',
        'setTransition',
        'isZero',
        'groundDt',
        'sound',
        'res/sound/step.mp3',
        'grounded',
        'walk',
        'Run',
        'hitResult',
        'HitResult',
        'ownerSp',
        'character',
        'animator',
        'Animator',
        'onAnimEvent',
        'moveSpeed',
        'MoveSpeed',
        'jumpSpeed',
        'makeFSM',
        'changeShadow',
        'initRigidbody',
        'rigidbody',
        'BaseEvent',
        'E_PHYSICS_COLLISION',
        'onCollision',
        'StepEvent',
        'eventName',
        'playStepSound',
        'isDead',
        'fsm',
        'checkGround',
        'Ray',
        'succeeded',
        'move',
        'getVelocity',
        'Quaternion',
        'slerp',
        'rotation',
        'stopMove',
        'curAnim',
        'playAnimator3d',
        'isMoving',
        'kill',
        'onDead',
        'Die',
        'tempRot',
        'horizontalAngle',
        'rotationSpeed',
        'cameraPivot',
        'CameraPivot',
        'tempV3',
        'label_timer',
        'onStart',
        'timerLoop',
        'onInterval',
        'res/sound/tik.mp3',
        'destroy',
        'gameTurn',
        'gameTime',
        'boxGaming',
        'BoundBox',
        'boxEnd',
        'isFinish',
        'WM_GameTime',
        'initTurn',
        'finishPos',
        'goNextTurn',
        'killMoving',
        'isArrived',
        'delayKill',
        'checkArrived',
        'onArriveFinishLine',
        'getGamingCnt',
        'getAliveCnt',
        'tempV10',
        'setMoveBox',
        'localPosition',
        'moveAnim',
        'velocity',
        'clamp',
        'moveBox',
        'gravity',
        'isMoved',
        'changeFace',
        'getChildAt',
        'createFromAxisAngle',
        'transformQuat',
        'res/sound/right.mp3',
        '$GHOST_BACK',
        'rotDir',
        'timestamp',
        'delayKillTime',
        'head',
        'constants',
        'curSoundUrl',
        'turnToBack',
        'headSp',
        'localRotationEulerY',
        'rotTo',
        'turnToFront',
        'startKill',
        'killing',
        'WM_GhostKillTime',
        'GHOST_FRONT',
        'res/sound/head.mp3',
        'rotValue',
        'checkTime',
        'WM_GhostChoose',
        'changeDirRate',
        'moveInKillRate',
        'free',
        'GHOST_BACK',
        'onGhostFront',
        'startMove',
        'onGhostBack',
        'moveRange',
        'stayRate',
        'jumpRate',
        'canInput',
        'setCountdown',
        'countdownRange',
        'onAdd',
        'btn_retry',
        'CLICK',
        'getInstance',
        'SceneManager',
        'closePanel',
        'share',
        'stopMusic',
        'res/sound/fail.mp3',
        'scrollList',
        'showLoading',
        'clearTextureRes',
        'res/atlas/res/gameEnd.atlas',
        'GameFailedDialogUI',
        'img_closeBtn',
        'onClickClose',
        'btn_share',
        'onClickShare',
        'img_playBtn',
        'img_playBg',
        'img_root',
        'callLater',
        'scaleAction',
        'E_CLOSE_ALL_PANEL',
        'SdkEvent',
        'code',
        'SdkCode',
        'shared',
        'onShareSuccess',
        'screenTexture',
        'shareVideo',
        'showBtn',
        'screenShot',
        'texture',
        'img_screen',
        'box_screen',
        'img_mask',
        'mask',
        'box_border',
        'ShareGuideUI',
        'res/sound/win.mp3',
        'countdown',
        'takeRes',
        'scenePath',
        'scene3d',
        'size',
        'addChildAt',
        'initLevel',
        'boxReady',
        'finishBox',
        'closeLoading',
        'initUI',
        'startCDScript',
        'box_cd',
        'box_nextTurnTips',
        'gameCDScript',
        'box_countdown',
        'setDuration',
        'spr_guide',
        'getJSON',
        'setJSON',
        '_firstGame',
        'startCD',
        'btn_home',
        'goMainScene0',
        'initPlayer',
        'Player',
        'characterPrefab',
        'playerController',
        'startBox',
        'Ghost',
        'ghostController',
        'Hole',
        'initRobots',
        'ceil',
        'MAP_WIDTH',
        'positiveRate',
        'box_guide',
        'startGame',
        'onTimeIsUp',
        'killNotArrived',
        'finished',
        'onFailed',
        'onMouseDown',
        'onMouseMove',
        'onMouseUp',
        'openPanel',
        'goMainScene',
        'gameOver',
        'res3d/Game123.ls',
        'PREFABE_GAME_CD',
        'startPos',
        'collidesWith',
        'other',
        'checkRunAndWalk',
        'isOnWire',
        'Walk',
        'targetPoint',
        'changeBehaviorDelta',
        'stayDuration',
        'backRate',
        'freeRateBeforeOnWay',
        'stayTime',
        'points',
        'updateArrivedBehavior',
        'isChangedDir',
        'targetPos',
        'abs',
        'currTimer',
        'nextchangeTime',
        'goPrePoint',
        'goNextPoint',
        'moveToPoint',
        'isOnWay',
        'changeBehavior',
        'LocalStorage',
        'Level',
        'Map',
        'recurisNode',
        'initStaticCollider',
        'getChildren',
        'seekChildrenBySubName',
        'point',
        'CfgMgr',
        'wirewalkingAI',
        'slice',
        'res3d/steel.ls',
        'isRobot',
        '_marbleNum',
        'scene',
        'jumpTime',
        'rate',
        'jumpInterval',
        'randomMarble',
        'marbleNum',
        'curGuessIsOdd',
        'resetTime',
        'guessCnt',
        'winRate',
        'label_odd',
        'guess',
        'box_countDown',
        'label_time',
        'box_mid',
        'box_btn',
        'label_even',
        'label_guess',
        'label_null',
        'box_wager',
        'box_own',
        'label_own',
        'startTime',
        'You\x20have\x2010\x20seconds\x20to\x20guess',
        'updateMarble',
        'onUpdateCd',
        'curWager',
        'takeOneByWeight',
        'cloneArray',
        'judge',
        'Even\x20number',
        'Your\x20answer\x20is:',
        'Odd\x20number',
        'ownerMarble',
        'gameSuccess',
        'Starting\x20round\x20',
        'You\x20won\x20',
        'res/sound/wrong.mp3',
        'You\x20lost\x20',
        '\x20marbles',
        'The\x20number\x20of\x20marbles\x20is\x20',
        'gameFail',
        'onRemove',
        'clearAll',
        'round',
        'updateCd',
        'gms',
        'goMain0',
        'box_game',
        'GuessMarbleScene',
        'onStopInput',
        'key',
        'loadData',
        'hasOwnProperty',
        'parse',
        'CallLater',
        '_save',
        'saveToLocal',
        '$PowerChange',
        'PowerData',
        'powerStartTime',
        'videoNum',
        'warpObjectGetterSetter',
        'data',
        'now',
        'recoverTime',
        'recoverPower',
        'loop',
        'videoPower',
        'maxVideo',
        'isFull',
        'isInfinity',
        'maxPower',
        'PowerChange',
        'usePower',
        'tryUsePower',
        '_power',
        'Power',
        '_videobindCtrlGId',
        '_videoStrategyInst',
        'createVideoStrategy',
        'E_REWARD_GAIN',
        'onRewardGain',
        'E_SHARE_RESULT',
        'onShareComplete',
        'getRewardStrategyInst',
        'setCurStrategy',
        'GetRewardSDKWay',
        'VIDEO',
        '_videoGainWayParams',
        'way',
        'gid',
        'playVideo',
        'showReward',
        'onVideoComplete',
        '_videoCallBack',
        'REWARD_GAIN_SUCCESS',
        '_videoCbParam',
        '_videoCaller',
        '_shareCaller',
        'isOnPC',
        'SHARE_SUCCESS',
        '_shareCbParam',
        '_shareCallBack',
        'clipboardData',
        'closeSelf',
        'img_cancel',
        'img_get',
        'onClickVideo',
        'PowerDilog',
        'addPowerByVideo',
        'label_power',
        'label_video',
        'runWith',
        'GB_MoveSpeed',
        'GB_JumpSpeed',
        'setGravity',
        'GB_Gravity',
        'rayH',
        'rayDir',
        'getNextTargetPos',
        'getWaitTime'
    ];
    _0x3c3a = function() {
        return _0x2e192b;
    };
    return _0x3c3a();
}
(function(_0xb85831, _0x25a1ae) {
    var _0x3635ff = _0x372d,
        _0x48ae10 = _0xb85831();
    while (!![]) {
        try {
            var _0x46216 = parseInt(_0x3635ff(0x1b2)) / 0x1 + -parseInt(_0x3635ff(0x1b3)) / 0x2 * (-parseInt(_0x3635ff(0x1b4)) / 0x3) + -parseInt(_0x3635ff(0x1b5)) / 0x4 * (parseInt(_0x3635ff(0x1b6)) / 0x5) + parseInt(_0x3635ff(0x1b7)) / 0x6 + -parseInt(_0x3635ff(0x1b8)) / 0x7 + parseInt(_0x3635ff(0x1b9)) / 0x8 * (-parseInt(_0x3635ff(0x1ba)) / 0x9) + parseInt(_0x3635ff(0x1bb)) / 0xa * (parseInt(_0x3635ff(0x1bc)) / 0xb);
            if (_0x46216 === _0x25a1ae)
                break;
            else
                _0x48ae10['push'](_0x48ae10['shift']());
        } catch (_0xfcb708) {
            _0x48ae10['push'](_0x48ae10['shift']());
        }
    }
}(_0x3c3a, 0xbcfb9), ! function() {
    var _0x7d969b = _0x372d,
        _0x141ce5 = require(_0x7d969b(0x1bd)),
        _0x40b1ff = require(_0x7d969b(0x1be)),
        _0x58adf2 = require(_0x7d969b(0x1bf)),
        _0x5a6184 = require(_0x7d969b(0x1c0)),
        _0x523788 = require('../runtime/helpers/createForOfIteratorHelper'),
        _0x142038 = require('../runtime/helpers/assertThisInitialized'),
        _0x3f3356 = require('../runtime/helpers/createClass'),
        _0xaf4c50 = require(_0x7d969b(0x1c1)),
        _0x10ff6e = require(_0x7d969b(0x1c2)),
        _0x30529b = require(_0x7d969b(0x1c3));
    ! function() {
        'use strict';
        var _0x28eca3 = _0x7d969b;
        var _0xdb1a4f = Laya[_0x28eca3(0x1c4)],
            _0x31f777 = Laya[_0x28eca3(0x1c5)],
            _0x59fc95 = Laya['Vector4'],
            _0x4ffd78 = (Laya[_0x28eca3(0x1c6)], Laya[_0x28eca3(0x1c7)]),
            _0xf611c3 = {
                'UI_HEAD': _0x28eca3(0x1c8),
                'UI_TIPS': _0x28eca3(0x1c9),
                'UI_COINS_IMG': _0x28eca3(0x1ca),
                'UI_DIAMOND_IMG': _0x28eca3(0x1cb),
                'UI_VIDEO_IMG': _0x28eca3(0x1cc),
                'UI_SHARE_IMG': _0x28eca3(0x1cd),
                'UI_SOUND_ON_IMG': '',
                'UI_SOUND_OFF_IMG': '',
                'UI_SHAKE_ON_IMG': '',
                'UI_SHAKE_OFF_IMG': '',
                'JSON_GAME_CFG': _0x28eca3(0x1ce),
                'SOUND_CLICK': _0x28eca3(0x1cf),
                'SOUND_TURNTABLE_START': _0x28eca3(0x1d0),
                'SOUND_TURNTABLE_END': _0x28eca3(0x1d1),
                'SOUND_XIANGJI': 'res/sound/xiangji.mp3',
                'SOUND_COLLIDE_DIAMOND': _0x28eca3(0x1d2),
                'SOUND_COLLIDE_KEY': 'res/sound/Key_Collect.mp3',
                'TEX_SHADOW': _0x28eca3(0x1d3),
                'TEX_WATER': _0x28eca3(0x1d4),
                'TEX_WAVEN': _0x28eca3(0x1d5),
                'PREFABE_GAME_CD': _0x28eca3(0x1d6),
                'PFB_RICKTEXT_TIPS': _0x28eca3(0x1d7),
                'LS_MAINSCENE': 'res3d/MainScene.ls',
                'PREFAB_CHARACTER': _0x28eca3(0x1d8)
            },
            _0x4b339f = {
                'PHYSICS_DEBUG_SHOW': !0x1
            },
            _0x561c5d = {
                'E_GAME_STATE_CHANGED': _0x28eca3(0x1d9),
                'E_GO_NEXT_STAGE': '$GO_NEXT_STAGE',
                'E_COLLISION_ENTER': 'COLLISION_ENTER',
                'E_COLLISION_EXIT': _0x28eca3(0x1da),
                'E_TRIGGER_ENTER': _0x28eca3(0x1db),
                'E_TRIGGER_EXIT': _0x28eca3(0x1dc),
                'E_CLOSE_ALL_PANEL': _0x28eca3(0x1dd),
                'E_GAME_TIME_IS_UP': _0x28eca3(0x1de),
                'E_CHARACTER_CNT_CHANGED': _0x28eca3(0x1df),
                'E_GAME_CNT_CHANGED': _0x28eca3(0x1e0),
                'E_GLASS_BREAK': '$E_GLASS_BREAK'
            },
            _0xa0898e, _0x4d7387, _0x134368, _0x41211b;
        ! function(_0x355a45) {
            var _0x1a2bb9 = _0x28eca3;
            _0x355a45[_0x355a45[_0x1a2bb9(0x1e1)] = 0x0] = _0x1a2bb9(0x1e1), _0x355a45[_0x355a45['E_COLLIDE_EXIT'] = 0x1] = _0x1a2bb9(0x1e2);
        }(_0xa0898e || (_0xa0898e = {})),
        function(_0x304e76) {
            var _0x35034b = _0x28eca3;
            _0x304e76[_0x304e76['E_GAME_READY'] = 0x1] = _0x35034b(0x1e3), _0x304e76[_0x304e76[_0x35034b(0x1e4)] = 0x2] = _0x35034b(0x1e4), _0x304e76[_0x304e76[_0x35034b(0x1e5)] = 0x3] = _0x35034b(0x1e5), _0x304e76[_0x304e76[_0x35034b(0x1e6)] = 0x4] = 'E_GAME_FINISH', _0x304e76[_0x304e76[_0x35034b(0x1e7)] = 0x5] = _0x35034b(0x1e7), _0x304e76[_0x304e76[_0x35034b(0x1e8)] = 0x6] = 'E_GAME_OVER';
        }(_0x4d7387 || (_0x4d7387 = {})), ! function(_0x186ed8) {
            var _0x3c84f2 = _0x28eca3;
            _0x186ed8[_0x186ed8[_0x3c84f2(0x1e9)] = 0x0] = _0x3c84f2(0x1e9), _0x186ed8[_0x186ed8[_0x3c84f2(0x1ea)] = Laya[_0x3c84f2(0x1eb)]['COLLISIONFILTERGROUP_DEFAULTFILTER']] = _0x3c84f2(0x1ea), _0x186ed8[_0x186ed8[_0x3c84f2(0x1ec)] = Laya['Physics3DUtils'][_0x3c84f2(0x1ed)]] = _0x3c84f2(0x1ec), _0x186ed8[_0x186ed8['STATIC'] = Laya[_0x3c84f2(0x1eb)][_0x3c84f2(0x1ee)]] = _0x3c84f2(0x1ef), _0x186ed8[_0x186ed8[_0x3c84f2(0x1f0)] = Laya[_0x3c84f2(0x1eb)]['COLLISIONFILTERGROUP_CHARACTERFILTER']] = 'PLAYER', _0x186ed8[_0x186ed8[_0x3c84f2(0x1f1)] = Laya[_0x3c84f2(0x1eb)]['COLLISIONFILTERGROUP_CUSTOMFILTER1']] = 'FINISH_BOX', _0x186ed8[_0x186ed8['DEATH_AREA'] = Laya['Physics3DUtils'][_0x3c84f2(0x1f2)]] = _0x3c84f2(0x1f3);
        }(_0x134368 || (_0x134368 = {}));
        var _0xcdc5eb = function(_0x439394) {
                _0x10ff6e(_0x148de7, _0x439394);
                var _0x492731 = _0x30529b(_0x148de7);

                function _0x148de7() {
                    var _0x2c2f6a = _0x372d;
                    return _0xaf4c50(this, _0x148de7), _0x492731[_0x2c2f6a(0x1f4)](this, arguments);
                }
                return _0x148de7;
            }(fx[_0x28eca3(0x1f5)]),
            _0x3ee5fd = function _0x133c0a() {
                var _0x172ff2 = _0x28eca3;
                _0xaf4c50(this, _0x133c0a), this[_0x172ff2(0x1f6)] = 0x0;
            },
            _0x42de24 = function(_0x870d7d) {
                _0x10ff6e(_0x57db27, _0x870d7d);
                var _0x508ab3 = _0x30529b(_0x57db27);

                function _0x57db27() {
                    return _0xaf4c50(this, _0x57db27), _0x508ab3['apply'](this, arguments);
                }
                return _0x57db27;
            }(fx[_0x28eca3(0x1f5)]),
            _0x136e40 = function(_0x5d6874) {
                var _0x4c07d4 = _0x28eca3;
                _0x10ff6e(_0x5794e0, _0x5d6874);
                var _0x22b119 = _0x30529b(_0x5794e0);

                function _0x5794e0() {
                    var _0x50a59e = _0x372d,
                        _0x31bf4a;
                    return _0xaf4c50(this, _0x5794e0), (_0x31bf4a = _0x22b119[_0x50a59e(0x1f7)](this), _0x31bf4a['res'] = '', _0x31bf4a[_0x50a59e(0x1f8)] = !0x0, _0x31bf4a['scaleX'] = 0.88, _0x31bf4a[_0x50a59e(0x1f9)] = 0.88), _0x31bf4a;
                }
                return _0x3f3356(_0x5794e0, [{
                        'key': _0x4c07d4(0x1fa),
                        'value': function _0x32729d() {
                            var _0x337729 = _0x4c07d4,
                                _0x346eee = this['owner'];
                            this[_0x337729(0x1f8)] && fx[_0x337729(0x1fb)][_0x337729(0x1fc)](_0x346eee, 0.5, 0.5), fx[_0x337729(0x1fd)]['btnScaleEff'](this[_0x337729(0x1fe)], {
                                'x': this[_0x337729(0x1ff)],
                                'y': this[_0x337729(0x1f9)]
                            }), _0x346eee['on'](Laya['Event']['MOUSE_DOWN'], this, this[_0x337729(0x200)]);
                        }
                    },
                    {
                        'key': _0x4c07d4(0x200),
                        'value': function _0x32e31c() {
                            var _0x5afd18 = _0x4c07d4,
                                _0x5cf862 = this['res'] && _0xf611c3[this[_0x5afd18(0x201)]];
                            _0x5cf862 ? fx[_0x5afd18(0x202)][_0x5afd18(0x203)][_0x5afd18(0x204)](_0x5cf862) : fx[_0x5afd18(0x202)]['instance'][_0x5afd18(0x204)](_0xf611c3[_0x5afd18(0x205)]);
                        }
                    }
                ]), _0x5794e0;
            }(Laya[_0x28eca3(0x206)]),
            _0xc00205 = function(_0x30a8d2) {
                var _0x58459f = _0x28eca3;
                _0x10ff6e(_0x335702, _0x30a8d2);
                var _0x39df06 = _0x30529b(_0x335702);

                function _0x335702() {
                    var _0x272acb = _0x372d;
                    return _0xaf4c50(this, _0x335702), _0x39df06[_0x272acb(0x1f4)](this, arguments);
                }
                return _0x3f3356(_0x335702, [{
                        'key': _0x58459f(0x1fa),
                        'value': function _0x357236() {
                            var _0x21fd69 = _0x58459f;
                            this[_0x21fd69(0x207)] = this[_0x21fd69(0x1fe)], this[_0x21fd69(0x208)] = this[_0x21fd69(0x1fe)][_0x21fd69(0x209)](_0x21fd69(0x20a)), this[_0x21fd69(0x207)][_0x21fd69(0x20b)] = !0x1;
                        }
                    },
                    {
                        'key': _0x58459f(0x20c),
                        'value': function _0x4c53ae() {
                            var _0xca5b0a = _0x58459f;
                            fx[_0xca5b0a(0x202)]['instance'][_0xca5b0a(0x20d)](_0xca5b0a(0x20e)), fx[_0xca5b0a(0x202)][_0xca5b0a(0x203)][_0xca5b0a(0x20d)](_0xca5b0a(0x20f));
                        }
                    },
                    {
                        'key': 'start',
                        'value': function _0x6a00df(_0x53277f, _0x2f1abe) {
                            var _0xe28b58 = _0x58459f;
                            this['cd'] = _0x53277f, this['cb'] = _0x2f1abe, this[_0xe28b58(0x207)][_0xe28b58(0x20b)] = !0x0, this[_0xe28b58(0x208)][_0xe28b58(0x210)] = this['cd'] + '', this['owner']['timerLoop'](0x3e8, this, this[_0xe28b58(0x211)]), fx[_0xe28b58(0x202)][_0xe28b58(0x203)]['playSound']('res/sound/countdown1.mp3');
                        }
                    },
                    {
                        'key': _0x58459f(0x211),
                        'value': function _0x5b1a47() {
                            var _0x5d0ab1 = _0x58459f,
                                _0x170157 = this;
                            this['cd']--, 0x0 == this['cd'] ? (this[_0x5d0ab1(0x208)][_0x5d0ab1(0x210)] = _0x5d0ab1(0x212), fx[_0x5d0ab1(0x202)][_0x5d0ab1(0x203)][_0x5d0ab1(0x204)](_0x5d0ab1(0x20f)), this['owner'][_0x5d0ab1(0x213)](this, this[_0x5d0ab1(0x211)]), this[_0x5d0ab1(0x1fe)][_0x5d0ab1(0x214)](0x3e8, this, function() {
                                var _0x1e61e7 = _0x5d0ab1;
                                _0x170157[_0x1e61e7(0x207)][_0x1e61e7(0x20b)] = !0x1;
                            }), this['cb'][_0x5d0ab1(0x215)]()) : (this[_0x5d0ab1(0x208)]['text'] = this['cd'] + '', fx[_0x5d0ab1(0x202)][_0x5d0ab1(0x203)][_0x5d0ab1(0x204)](_0x5d0ab1(0x20e)));
                        }
                    }
                ]), _0x335702;
            }(Laya[_0x28eca3(0x206)]),
            _0x28ea2d = function(_0x354563) {
                var _0xf2e45a = _0x28eca3;
                _0x10ff6e(_0x9d0e92, _0x354563);
                var _0x194cba = _0x30529b(_0x9d0e92);

                function _0x9d0e92() {
                    var _0x5ddb56 = _0x372d,
                        _0x268fa9;
                    return _0xaf4c50(this, _0x9d0e92), (_0x268fa9 = _0x194cba['call'](this, !0x1), _0x268fa9['stageId'] = void 0x0, _0x268fa9[_0x5ddb56(0x216)] = void 0x0, _0x268fa9[_0x5ddb56(0x217)] = void 0x0, _0x268fa9[_0x5ddb56(0x218)] = void 0x0, _0x268fa9[_0x5ddb56(0x219)] = void 0x0, _0x268fa9[_0x5ddb56(0x21a)] = void 0x0, _0x268fa9['ugcShareSkins'] = [], _0x268fa9[_0x5ddb56(0x21b)] = [], _0x268fa9[_0x5ddb56(0x21c)] = [], _0x268fa9[_0x5ddb56(0x21d)] = !0x0, _0x268fa9['signInToday'] = void 0x0, _0x268fa9[_0x5ddb56(0x21e)] = void 0x0, _0x268fa9[_0x5ddb56(0x21f)] = void 0x0, _0x268fa9[_0x5ddb56(0x220)] = void 0x0, _0x268fa9['turntableHasTakeIds'] = void 0x0, _0x268fa9[_0x5ddb56(0x221)] = void 0x0, _0x268fa9['closeTryNum'] = void 0x0, _0x268fa9[_0x5ddb56(0x222)] = void 0x0, _0x268fa9['departureTime'] = void 0x0, _0x268fa9[_0x5ddb56(0x223)] = void 0x0, _0x268fa9['openMagnetAbility'] = void 0x0, _0x268fa9['isFirstTouch'] = void 0x0, _0x268fa9[_0x5ddb56(0x224)] = 0x1, _0x268fa9['coins'] = 0x0, _0x268fa9[_0x5ddb56(0x216)] = !0x1, _0x268fa9['guideSteps'] = [], _0x268fa9[_0x5ddb56(0x219)] = [], fx[_0x5ddb56(0x1fb)]['warpObjectGetterSetter'](_0x142038(_0x268fa9), _0x268fa9[_0x5ddb56(0x225)])), _0x268fa9;
                }
                return _0x3f3356(_0x9d0e92, [{
                        'key': _0xf2e45a(0x226),
                        'value': function _0x211f86(_0x128ebf) {
                            var _0x8a340e = _0xf2e45a;
                            _0x128ebf && (this[_0x8a340e(0x217)] += _0x128ebf);
                        }
                    },
                    {
                        'key': 'useCoins',
                        'value': function _0x4360b9(_0x29e29f) {
                            var _0x30baff = _0xf2e45a;
                            _0x29e29f && (this[_0x30baff(0x217)] < _0x29e29f || (this[_0x30baff(0x217)] -= _0x29e29f));
                        }
                    },
                    {
                        'key': _0xf2e45a(0x227),
                        'value': function _0x55b17b(_0x5618d2) {
                            var _0x2f5bd8 = _0xf2e45a;
                            this[_0x2f5bd8(0x225)](_0x5618d2);
                        }
                    }
                ]), _0x9d0e92;
            }(fx['UserInfoEntity']),
            _0x5e5c9b = function(_0x35a83e) {
                var _0x28c347 = _0x28eca3;
                _0x10ff6e(_0x35920c, _0x35a83e);
                var _0x524137 = _0x30529b(_0x35920c);

                function _0x35920c() {
                    var _0x53dbec = _0x372d,
                        _0x4356a1;
                    return _0xaf4c50(this, _0x35920c), (_0x4356a1 = _0x524137[_0x53dbec(0x1f7)](this), _0x4356a1[_0x53dbec(0x228)] = 0x0), _0x4356a1;
                }
                return _0x3f3356(_0x35920c, [{
                        'key': _0x28c347(0x229),
                        'value': function _0xebea53() {
                            var _0xde1557 = _0x28c347;
                            fx[_0xde1557(0x22a)][_0xde1557(0x203)]['init'](_0x28ea2d);
                        }
                    },
                    {
                        'key': _0x28c347(0x22b),
                        'value': function _0x36318a() {
                            var _0x46f25f = _0x28c347;
                            this[_0x46f25f(0x22c)] = this[_0x46f25f(0x22d)]();
                        }
                    },
                    {
                        'key': _0x28c347(0x22d),
                        'value': function _0x2e53ee() {
                            var _0x12e4ed = _0x28c347;
                            return fx[_0x12e4ed(0x22a)]['instance'][_0x12e4ed(0x22e)]();
                        }
                    },
                    {
                        'key': _0x28c347(0x226),
                        'value': function _0x591bf2(_0x57bb54) {
                            var _0x1c8ee2 = _0x28c347;
                            return !(!_0x57bb54 || _0x57bb54 < 0x0) && (this[_0x1c8ee2(0x22c)][_0x1c8ee2(0x217)] += _0x57bb54, !0x0);
                        }
                    },
                    {
                        'key': _0x28c347(0x22f),
                        'value': function _0x48f658(_0x4df3ae) {
                            var _0x3efd50 = _0x28c347;
                            return null != _0x4df3ae && this[_0x3efd50(0x22c)][_0x3efd50(0x217)] >= _0x4df3ae;
                        }
                    },
                    {
                        'key': 'useCoins',
                        'value': function _0x440b9d(_0x5f550b) {
                            var _0x23a5ee = _0x28c347;
                            return !(null == _0x5f550b || _0x5f550b < 0x0 || !this[_0x23a5ee(0x22f)](_0x5f550b)) && (this[_0x23a5ee(0x22c)]['coins'] -= _0x5f550b, !0x0);
                        }
                    },
                    {
                        'key': _0x28c347(0x230),
                        'value': function _0x557c54() {
                            var _0x59eb1d = _0x28c347;
                            this[_0x59eb1d(0x228)] += 0x1, this[_0x59eb1d(0x228)] % 0x2 == 0x0 && fx[_0x59eb1d(0x231)][_0x59eb1d(0x203)][_0x59eb1d(0x230)](null, !0x1);
                        }
                    },
                    {
                        'key': _0x28c347(0x232),
                        'value': function _0x32135b() {
                            var _0x2dd355 = _0x28c347;
                            this['_interstitialIndex'] % 0x2 == 0x1 && fx[_0x2dd355(0x231)][_0x2dd355(0x203)][_0x2dd355(0x230)](null, !0x1);
                        }
                    }
                ], [{
                    'key': 'instance',
                    'get': function _0x42b09e() {
                        var _0xd5d94b = _0x28c347;
                        return this[_0xd5d94b(0x233)] || (this[_0xd5d94b(0x233)] = new _0x35920c()), this[_0xd5d94b(0x233)];
                    }
                }]), _0x35920c;
            }(fx[_0x28eca3(0x234)]),
            _0x457d72 = function() {
                var _0x4f3313 = _0x28eca3;

                function _0x5ee696() {
                    var _0x1314e8 = _0x372d;
                    _0xaf4c50(this, _0x5ee696), (this[_0x1314e8(0x235)] = 0x0, this[_0x1314e8(0x236)] = ![], Laya['LocalStorage'][_0x1314e8(0x237)](_0x1314e8(0x238)) && (this[_0x1314e8(0x236)] = ![]));
                }
                return _0x3f3356(_0x5ee696, [{
                        'key': _0x4f3313(0x239),
                        'value': function _0x3c320a() {
                            var _0x1627f9 = _0x4f3313,
                                _0x74f3c3 = Date['now']();
                            _0x74f3c3 - this['lastDeadSoundTime'] > 0x64 && (this[_0x1627f9(0x235)] = _0x74f3c3, fx['SoundManager'][_0x1627f9(0x203)][_0x1627f9(0x204)](_0x1627f9(0x23a)));
                        }
                    },
                    {
                        'key': _0x4f3313(0x23b),
                        'value': function _0x1c0668(_0x562c8b) {
                            var _0x435885 = _0x4f3313,
                                _0x4839c0 = _0x562c8b[_0x435885(0x23c)](_0x435885(0x23d))['getChildByName'](_0x435885(0x23e));
                            if (fx[_0x435885(0x1fb)][_0x435885(0x23f)](0.1))
                                _0x4839c0[_0x435885(0x240)] = !0x1;
                            else {
                                if (_0x4839c0 instanceof Laya[_0x435885(0x241)]) {
                                    var _0x12b96c = _0x4839c0[_0x435885(0x242)][_0x435885(0x243)];
                                    _0x12b96c['albedoColor'] = null, _0x12b96c[_0x435885(0x244)] = null;
                                    var _0x56580a = fx[_0x435885(0x1fb)][_0x435885(0x245)](0x0, 0x1),
                                        _0x99389d = fx['Utils'][_0x435885(0x245)](0x0, 0x1),
                                        _0x2afcc5 = fx['Utils'][_0x435885(0x245)](0x0, 0x1);
                                    _0x12b96c[_0x435885(0x246)] = new _0x59fc95(_0x56580a, _0x99389d, _0x2afcc5, 0x1);
                                } else {
                                    if (_0x4839c0 instanceof Laya[_0x435885(0x247)]) {
                                        var _0x365621 = _0x4839c0['simpleSkinnedMeshRenderer'][_0x435885(0x243)];
                                        _0x365621[_0x435885(0x248)] = null;
                                        var _0x277023 = fx[_0x435885(0x1fb)][_0x435885(0x245)](0x0, 0x1),
                                            _0x3715be = fx[_0x435885(0x1fb)][_0x435885(0x245)](0x0, 0x1),
                                            _0x31f87c = fx['Utils'][_0x435885(0x245)](0x0, 0x1);
                                        _0x365621['albedoColor'] = new _0x59fc95(_0x277023, _0x3715be, _0x31f87c, 0x1);
                                    }
                                }
                            }
                        }
                    },
                    {
                        'key': _0x4f3313(0x249),
                        'value': function _0x3714cc(_0x57c967) {
                            var _0x43638b = _0x4f3313;
                            return this[_0x43638b(0x236)] ? _0x57c967[_0x43638b(0x24a)](_0x43638b(0x24b), _0x43638b(0x24c)) : _0x57c967;
                        }
                    },
                    {
                        'key': _0x4f3313(0x24d),
                        'value': function _0x5686b0(_0x26aa4b) {
                            var _0x54b5e2 = _0x4f3313;
                            return this[_0x54b5e2(0x236)] ? _0x26aa4b[_0x54b5e2(0x24a)](_0x54b5e2(0x24e), _0x54b5e2(0x24f)) : _0x26aa4b;
                        }
                    }
                ], [{
                    'key': 'I',
                    'get': function _0x4c1bd6() {
                        var _0x652bf8 = _0x4f3313;
                        return this[_0x652bf8(0x233)] || (this[_0x652bf8(0x233)] = new _0x5ee696()), this[_0x652bf8(0x233)];
                    }
                }]), _0x5ee696;
            }(),
            _0x29989c = function(_0xa3d243) {
                var _0x1d874d = _0x28eca3;
                _0x10ff6e(_0x400941, _0xa3d243);
                var _0x2b5dd4 = _0x30529b(_0x400941);

                function _0x400941() {
                    var _0x2edf24 = _0x372d,
                        _0x5d0f69;
                    return _0xaf4c50(this, _0x400941), (_0x5d0f69 = _0x2b5dd4['call'](this), _0x5d0f69[_0x2edf24(0x250)] = []), _0x5d0f69;
                }
                return _0x3f3356(_0x400941, [{
                        'key': _0x1d874d(0x229),
                        'value': function _0x111a34() {
                            var _0x4a53a8 = _0x1d874d,
                                _0x3664ae = this;
                            this[_0x4a53a8(0x251)] = new Laya['Timer'](!0x0);
                            var _0xce1fb0 = fx['CfgMgr'][_0x4a53a8(0x203)];
                            this[_0x4a53a8(0x252)] = _0xce1fb0[_0x4a53a8(0x253)]('constant'), _0xf611c3[_0x4a53a8(0x254)] && (this[_0x4a53a8(0x255)] = _0xce1fb0[_0x4a53a8(0x253)](_0xf611c3[_0x4a53a8(0x254)])), this['headCfg'] = new fx[(_0x4a53a8(0x256))]('playerNames', _0x42de24), this[_0x4a53a8(0x257)] = new fx[(_0x4a53a8(0x256))](_0x4a53a8(0x257), _0xcdc5eb), this[_0x4a53a8(0x257)][_0x4a53a8(0x258)](function(_0x38ad77) {
                                if (void 0x0 === _0x3664ae['maxMiniGameId'] && (_0x3664ae['maxMiniGameId'] = _0x38ad77['id']), _0x3664ae['maxMiniGameId'] != _0x38ad77['id'])
                                    return !0x1;
                                _0x3664ae['maxMiniGameId']++;
                            }), this[_0x4a53a8(0x259)]--, this['clear'](), _0x457d72['I'][_0x4a53a8(0x236)] && (_0xf611c3['PREFAB_CHARACTER'] = _0xf611c3[_0x4a53a8(0x25a)]['replace'](_0x4a53a8(0x25b), _0x4a53a8(0x25c)));
                        }
                    },
                    {
                        'key': _0x1d874d(0x22b),
                        'value': function _0xe210b2() {
                            var _0x4d9982 = _0x1d874d;
                            this[_0x4d9982(0x25d)] = _0x4d7387[_0x4d9982(0x1e3)], this[_0x4d9982(0x25e)] = 0x0, this[_0x4d9982(0x25f)] = [], this['setCurStageInfo']();
                        }
                    },
                    {
                        'key': 'getTimer',
                        'value': function _0x5f403f() {
                            var _0x286993 = _0x1d874d;
                            return this[_0x286993(0x251)];
                        }
                    },
                    {
                        'key': 'getGameCfgJson',
                        'value': function _0x2765f6() {
                            return this['gameCfg'];
                        }
                    },
                    {
                        'key': _0x1d874d(0x260),
                        'value': function _0x875427() {
                            var _0x562610 = _0x1d874d;
                            return this[_0x562610(0x252)];
                        }
                    },
                    {
                        'key': 'setGameState',
                        'value': function _0x1c0e99(_0x1c92f7) {
                            var _0x174265 = _0x1d874d;
                            if (this[_0x174265(0x25d)] != _0x1c92f7 && this[_0x174265(0x25d)] != _0x4d7387[_0x174265(0x1e8)]) {
                                var _0x442f27 = this[_0x174265(0x25d)];
                                this[_0x174265(0x25d)] = _0x1c92f7, this[_0x174265(0x261)](_0x561c5d[_0x174265(0x262)], _0x442f27), _0x1c92f7 != _0x4d7387[_0x174265(0x1e6)] && _0x1c92f7 != _0x4d7387[_0x174265(0x1e8)] || this[_0x174265(0x263)]();
                            }
                        }
                    },
                    {
                        'key': _0x1d874d(0x264),
                        'value': function _0x5e47fd() {
                            var _0x5459aa = _0x1d874d;
                            return this[_0x5459aa(0x25d)];
                        }
                    },
                    {
                        'key': 'getCurStage',
                        'value': function _0x33fee8() {
                            return this['curMiniGameInfo'];
                        }
                    },
                    {
                        'key': _0x1d874d(0x265),
                        'value': function _0x34c0df() {
                            var _0x36aa57 = _0x1d874d,
                                _0x3c1300 = Laya[_0x36aa57(0x266)][_0x36aa57(0x267)](_0x36aa57(0x268));
                            fx['SceneManager'][_0x36aa57(0x269)](_0x3c1300);
                        }
                    },
                    {
                        'key': _0x1d874d(0x26a),
                        'value': function _0x51c230() {
                            var _0x2689a6 = _0x1d874d;
                            return this[_0x2689a6(0x257)];
                        }
                    },
                    {
                        'key': 'setCurStageInfo',
                        'value': function _0x48f27a() {
                            var _0x3eac7e = _0x1d874d;
                            if (this['specMiniGameId'])
                                this['curMiniGameInfo'] = this['miniGameCfg']['get'](this[_0x3eac7e(0x26b)]);
                            else {
                                var _0x2072e3 = _0x5e5c9b[_0x3eac7e(0x203)][_0x3eac7e(0x22d)]();
                                fx[_0x3eac7e(0x1fb)]['isNumber'](_0x2072e3[_0x3eac7e(0x224)]) || (_0x2072e3[_0x3eac7e(0x224)] = 0x1);
                                var _0x1145fc = _0x2072e3[_0x3eac7e(0x224)];
                                this['curMiniGameInfo'] = this[_0x3eac7e(0x257)][_0x3eac7e(0x253)](_0x1145fc);
                            }
                        }
                    },
                    {
                        'key': _0x1d874d(0x26c),
                        'value': function _0x2a980b(_0x118406) {
                            var _0x213dbc = _0x1d874d;
                            _0x118406 && (_0x118406 = Number(_0x118406)), (this[_0x213dbc(0x25d)] != _0x4d7387['E_GAME_READY'] || fx['Utils']['isNumber'](_0x118406) && this[_0x213dbc(0x26d)]['id'] != _0x118406) && (fx[_0x213dbc(0x1fb)]['isNumber'](_0x118406) ? this[_0x213dbc(0x26b)] = _0x118406 : this[_0x213dbc(0x26e)](), this[_0x213dbc(0x26f)]++, this[_0x213dbc(0x270)](), this[_0x213dbc(0x26b)] = null, _0x5e5c9b[_0x213dbc(0x203)][_0x213dbc(0x270)](), this['event'](_0x561c5d[_0x213dbc(0x271)]));
                        }
                    },
                    {
                        'key': _0x1d874d(0x272),
                        'value': function _0xc63bfb(_0x29691d) {
                            var _0x32073b = _0x1d874d;
                            _0x5e5c9b['instance'][_0x32073b(0x22d)]()['stageId'] = _0x29691d, this[_0x32073b(0x273)]();
                        }
                    },
                    {
                        'key': _0x1d874d(0x26e),
                        'value': function _0x5381c0() {
                            var _0x313052 = _0x1d874d,
                                _0x12a49b = this[_0x313052(0x26d)]['id'];
                            _0x12a49b && (++_0x12a49b > this[_0x313052(0x259)] && (_0x12a49b = 0x1), _0x5e5c9b['instance'][_0x313052(0x22d)]()[_0x313052(0x224)] = _0x12a49b);
                        }
                    },
                    {
                        'key': _0x1d874d(0x274),
                        'value': function _0x1b8e0f(_0x475c05) {
                            var _0x20dd63 = _0x1d874d,
                                _0x379bd4 = fx[_0x20dd63(0x231)][_0x20dd63(0x203)][_0x20dd63(0x275)]();
                            _0x379bd4 && _0x379bd4[_0x20dd63(0x274)](_0x475c05);
                        }
                    },
                    {
                        'key': _0x1d874d(0x276),
                        'value': function _0x3350c1() {
                            var _0x2bfa3a = _0x1d874d;
                            this[_0x2bfa3a(0x277)](_0x4d7387[_0x2bfa3a(0x1e4)]);
                        }
                    },
                    {
                        'key': _0x1d874d(0x278),
                        'value': function _0x182d7a() {
                            var _0x40a877 = _0x1d874d;
                            this[_0x40a877(0x25f)] = [], this['_robotsCnt'] = this[_0x40a877(0x252)]['RobotsCnt'] - fx['Utils'][_0x40a877(0x279)](0x1, 0xb), this['turnIndex'] = 0x1, _0x5e5c9b[_0x40a877(0x203)][_0x40a877(0x22d)]()['stageId'] = 0x1;
                        }
                    },
                    {
                        'key': _0x1d874d(0x27a),
                        'value': function _0xac7fd1(_0x4e1c87) {
                            var _0x2ece89 = _0x1d874d; -
                            0x1 == this[_0x2ece89(0x25f)]['indexOf'](_0x4e1c87) && (this[_0x2ece89(0x25f)]['push'](_0x4e1c87), this[_0x2ece89(0x261)](_0x561c5d[_0x2ece89(0x27b)], [this['characters'][_0x2ece89(0x27c)]]));
                        }
                    },
                    {
                        'key': _0x1d874d(0x27d),
                        'value': function _0x62ea62(_0x4a603d) {
                            var _0x4eebc1 = _0x1d874d,
                                _0x2c84b2 = this[_0x4eebc1(0x25f)][_0x4eebc1(0x27e)](_0x4a603d); -
                            0x1 != _0x2c84b2 && (this[_0x4eebc1(0x25f)][_0x4eebc1(0x27f)](_0x2c84b2, 0x1), this[_0x4eebc1(0x261)](_0x561c5d[_0x4eebc1(0x27b)], [this[_0x4eebc1(0x25f)]['length']]));
                        }
                    },
                    {
                        'key': _0x1d874d(0x280),
                        'value': function _0x37dc98() {
                            var _0x9d3266 = _0x1d874d;
                            return this[_0x9d3266(0x25f)][_0x9d3266(0x27c)];
                        }
                    },
                    {
                        'key': _0x1d874d(0x281),
                        'value': function _0x4ba149() {
                            var _0x5b0b49 = _0x1d874d;
                            return this[_0x5b0b49(0x25f)];
                        }
                    },
                    {
                        'key': _0x1d874d(0x282),
                        'value': function _0x34dfb2() {
                            var _0x4a23da = _0x1d874d;
                            return this[_0x4a23da(0x26f)];
                        }
                    },
                    {
                        'key': _0x1d874d(0x283),
                        'value': function _0x1140e8() {
                            var _0x8b5b0e = _0x1d874d;
                            return this[_0x8b5b0e(0x26d)][_0x8b5b0e(0x284)];
                        }
                    },
                    {
                        'key': _0x1d874d(0x285),
                        'get': function _0x50944f() {
                            return this['_deadIndex'];
                        },
                        'set': function _0x19918e(_0x3a1e60) {
                            var _0x56afaa = _0x1d874d;
                            this[_0x56afaa(0x25e)] = _0x3a1e60;
                        }
                    },
                    {
                        'key': _0x1d874d(0x286),
                        'get': function _0x446e7a() {
                            var _0x16985e = _0x1d874d;
                            return this[_0x16985e(0x287)];
                        },
                        'set': function _0x2c8d8c(_0x1e332a) {
                            var _0x40ce5b = _0x1d874d;
                            this[_0x40ce5b(0x287)] = _0x1e332a;
                        }
                    },
                    {
                        'key': 'getGameInfo',
                        'value': function _0x2c1567(_0x43eb15) {
                            var _0x4ee8b9 = _0x1d874d,
                                _0x401b6f = _0x5e5c9b[_0x4ee8b9(0x203)][_0x4ee8b9(0x22d)]()[_0x4ee8b9(0x219)],
                                _0x36aad = _0x523788(_0x401b6f),
                                _0x3c663e;
                            try {
                                for (_0x36aad['s'](); !(_0x3c663e = _0x36aad['n']())[_0x4ee8b9(0x288)];) {
                                    var _0x3b836b = _0x3c663e[_0x4ee8b9(0x289)];
                                    if (_0x3b836b['id'] == _0x43eb15)
                                        return _0x3b836b;
                                }
                            } catch (_0x594e7e) {
                                _0x36aad['e'](_0x594e7e);
                            } finally {
                                _0x36aad['f']();
                            }
                        }
                    },
                    {
                        'key': _0x1d874d(0x28a),
                        'value': function _0x37c52e(_0x44e543) {
                            var _0x374a3c = _0x1d874d,
                                _0x8cde83 = this[_0x374a3c(0x28b)](_0x44e543);
                            return _0x8cde83 ? _0x8cde83[_0x374a3c(0x1f6)] : 0x0;
                        }
                    },
                    {
                        'key': 'addGameCnt',
                        'value': function _0x8c22d2(_0x467e26, _0x20b3c7) {
                            var _0x50153b = _0x1d874d,
                                _0x5289f4 = _0x5e5c9b[_0x50153b(0x203)][_0x50153b(0x22d)](),
                                _0x598326 = _0x5289f4[_0x50153b(0x219)],
                                _0x4d9ca9 = this[_0x50153b(0x28b)](_0x467e26);
                            _0x4d9ca9 || ((_0x4d9ca9 = new _0x3ee5fd())['id'] = _0x467e26, _0x598326['push'](_0x4d9ca9)), _0x4d9ca9[_0x50153b(0x1f6)] += _0x20b3c7, _0x4d9ca9[_0x50153b(0x1f6)] = Math[_0x50153b(0x28c)](_0x4d9ca9[_0x50153b(0x1f6)], 0x0), _0x5289f4[_0x50153b(0x227)]('gameInfos'), this[_0x50153b(0x261)](_0x561c5d[_0x50153b(0x28d)]);
                        }
                    },
                    {
                        'key': 'tryUseCnt',
                        'value': function _0x3ce1af(_0xfa1455, _0x53d534) {
                            var _0x936f86 = _0x1d874d;
                            return !(this[_0x936f86(0x28a)](_0xfa1455) < _0x53d534) && (this[_0x936f86(0x28e)](_0xfa1455, -_0x53d534), !0x0);
                        }
                    },
                    {
                        'key': _0x1d874d(0x28f),
                        'value': function _0x5da002() {
                            var _0x29f625 = _0x1d874d,
                                _0x5cd9ab = this;
                            0x0 == this[_0x29f625(0x250)][_0x29f625(0x27c)] && (this['headCfg'][_0x29f625(0x258)](function(_0x2768bb) {
                                var _0x38e511 = _0x29f625;
                                _0x5cd9ab[_0x38e511(0x250)][_0x38e511(0x290)](_0x2768bb);
                            }), fx[_0x29f625(0x1fb)][_0x29f625(0x291)](this[_0x29f625(0x250)]));
                            var _0x285787 = fx[_0x29f625(0x1fb)]['getIntRandom'](0x0, this[_0x29f625(0x250)][_0x29f625(0x27c)] - 0x1);
                            return this[_0x29f625(0x250)][_0x29f625(0x27f)](_0x285787, 0x1)[0x0];
                        }
                    }
                ], [{
                    'key': _0x1d874d(0x203),
                    'get': function _0x3976b1() {
                        return this['_instance'] || (this['_instance'] = new _0x400941()), this['_instance'];
                    }
                }]), _0x400941;
            }(fx[_0x28eca3(0x234)]),
            _0x408f9d = function(_0x487149) {
                var _0x10d87c = _0x28eca3;
                _0x10ff6e(_0x1c0045, _0x487149);
                var _0x34156a = _0x30529b(_0x1c0045);

                function _0x1c0045() {
                    var _0x1e0b3a = _0x372d;
                    return _0xaf4c50(this, _0x1c0045), _0x34156a[_0x1e0b3a(0x1f4)](this, arguments);
                }
                return _0x3f3356(_0x1c0045, [{
                        'key': _0x10d87c(0x1fa),
                        'value': function _0xa3942a() {
                            var _0x4f5452 = _0x10d87c;
                            this['label_aliveCnt'] = this[_0x4f5452(0x1fe)][_0x4f5452(0x209)](_0x4f5452(0x292)), this[_0x4f5452(0x293)](), fx[_0x4f5452(0x294)][_0x4f5452(0x203)]['on'](_0x561c5d[_0x4f5452(0x27b)], this, this[_0x4f5452(0x293)]);
                        }
                    },
                    {
                        'key': 'onDestroy',
                        'value': function _0xacf43d() {
                            var _0x50bb58 = _0x10d87c;
                            fx[_0x50bb58(0x294)][_0x50bb58(0x203)][_0x50bb58(0x295)](this);
                        }
                    },
                    {
                        'key': _0x10d87c(0x293),
                        'value': function _0x14db66() {
                            var _0x395132 = _0x10d87c,
                                _0x46051d = _0x29989c[_0x395132(0x203)][_0x395132(0x280)]();
                            this[_0x395132(0x292)][_0x395132(0x210)] = 'Player:\x20' [_0x395132(0x296)](_0x46051d);
                        }
                    }
                ]), _0x1c0045;
            }(Laya[_0x28eca3(0x206)]),
            _0x107110 = function(_0x31b7a4) {
                var _0x998384 = _0x28eca3;
                _0x10ff6e(_0x16e6ca, _0x31b7a4);
                var _0x4ed4c6 = _0x30529b(_0x16e6ca);

                function _0x16e6ca() {
                    var _0x48c143 = _0x372d,
                        _0x49079e;
                    return _0xaf4c50(this, _0x16e6ca), (_0x49079e = _0x4ed4c6[_0x48c143(0x1f4)](this, arguments), _0x49079e[_0x48c143(0x284)] = 0x0), _0x49079e;
                }
                return _0x3f3356(_0x16e6ca, [{
                        'key': 'onAwake',
                        'value': function _0x1ce019() {
                            var _0xa2b2d2 = _0x372d;
                            this[_0xa2b2d2(0x297)] = this[_0xa2b2d2(0x1fe)][_0xa2b2d2(0x209)](_0xa2b2d2(0x297)), fx[_0xa2b2d2(0x294)][_0xa2b2d2(0x203)]['on'](_0x561c5d[_0xa2b2d2(0x262)], this, this[_0xa2b2d2(0x298)]);
                        }
                    },
                    {
                        'key': _0x998384(0x20c),
                        'value': function _0x32450c() {
                            var _0x228910 = _0x998384;
                            fx[_0x228910(0x294)]['instance']['offAllCaller'](this);
                        }
                    },
                    {
                        'key': _0x998384(0x298),
                        'value': function _0x36160c(_0x2ef07a) {
                            var _0x51085c = _0x998384,
                                _0x2fc576 = _0x29989c[_0x51085c(0x203)][_0x51085c(0x264)]();
                            _0x2fc576 != _0x4d7387[_0x51085c(0x1e7)] && _0x2fc576 != _0x4d7387[_0x51085c(0x1e6)] || (this[_0x51085c(0x299)] = !0x1);
                        }
                    },
                    {
                        'key': 'setDuration',
                        'value': function _0x2383fa(_0x446904) {
                            var _0x7b618f = _0x998384;
                            this[_0x7b618f(0x284)] = _0x446904, this[_0x7b618f(0x29a)]();
                        }
                    },
                    {
                        'key': _0x998384(0x29b),
                        'value': function _0x42162c(_0x18bc52) {
                            var _0x181d8c = _0x998384;
                            this['cb'] = _0x18bc52, this[_0x181d8c(0x299)] = !0x0;
                        }
                    },
                    {
                        'key': _0x998384(0x29c),
                        'value': function _0x5db1f8() {
                            var _0x54e006 = _0x998384;
                            if (!this['isStart'] || this[_0x54e006(0x284)] <= 0x0)
                                return;
                            var _0x344c4e = 0x10 / 0x3e8;
                            this[_0x54e006(0x284)] = Math[_0x54e006(0x28c)](this['duration'] - _0x344c4e, 0x0), this[_0x54e006(0x29a)](), 0x0 == this[_0x54e006(0x284)] && this['cb'] && this['cb'][_0x54e006(0x215)]();
                        }
                    },
                    {
                        'key': 'updateLabel',
                        'value': function _0x4c3046() {
                            var _0x5daea0 = _0x998384,
                                _0x332a42 = this[_0x5daea0(0x297)][_0x5daea0(0x210)];
                            this['labelCD'][_0x5daea0(0x210)] = fx['Utils'][_0x5daea0(0x29d)](0x3e8 * this[_0x5daea0(0x284)], {
                                'separator': [
                                    ':',
                                    ''
                                ],
                                'isAlign': !0x0
                            }), _0x332a42 != this[_0x5daea0(0x297)][_0x5daea0(0x210)] && fx[_0x5daea0(0x202)][_0x5daea0(0x203)][_0x5daea0(0x204)]('res/sound/tik.mp3');
                        }
                    }
                ]), _0x16e6ca;
            }(Laya[_0x28eca3(0x206)]),
            _0x303818 = function(_0x3a4eb4) {
                var _0x313795 = _0x28eca3;
                _0x10ff6e(_0x104efd, _0x3a4eb4);
                var _0x51786f = _0x30529b(_0x104efd);

                function _0x104efd() {
                    var _0x23f25c = _0x372d,
                        _0x329146;
                    return _0xaf4c50(this, _0x104efd), (_0x329146 = _0x51786f[_0x23f25c(0x1f4)](this, arguments), _0x329146[_0x23f25c(0x29e)] = !0x0), _0x329146;
                }
                return _0x3f3356(_0x104efd, [{
                        'key': _0x313795(0x29f),
                        'set': function _0xe8be54(_0x35e14d) {
                            var _0x30d0b0 = _0x313795;
                            this[_0x30d0b0(0x29e)] = _0x35e14d;
                        }
                    },
                    {
                        'key': _0x313795(0x1fa),
                        'value': function _0x347a54() {
                            var _0x550fae = _0x313795,
                                _0xc57f97 = this;
                            this[_0x550fae(0x207)] = this[_0x550fae(0x1fe)], this[_0x550fae(0x2a0)] = this['owner'][_0x550fae(0x209)](_0x550fae(0x2a0)), this[_0x550fae(0x2a0)][_0x550fae(0x20b)] = this[_0x550fae(0x2a1)], this['background'] = this[_0x550fae(0x2a0)][_0x550fae(0x209)](_0x550fae(0x2a2)), this[_0x550fae(0x2a3)] = this[_0x550fae(0x2a0)][_0x550fae(0x209)](_0x550fae(0x2a3)), this[_0x550fae(0x2a4)] = new _0xdb1a4f(), this[_0x550fae(0x2a5)] = new _0xdb1a4f(), this['moveX'] = 0x0, this[_0x550fae(0x2a6)] = 0x0, this['originPos'] = new _0xdb1a4f(), this[_0x550fae(0x2a7)]['x'] = 0x8e, this[_0x550fae(0x2a7)]['y'] = Laya['stage'][_0x550fae(0x2a8)] - 0x14a, this[_0x550fae(0x2a0)]['pos'](this[_0x550fae(0x2a7)]['x'], this[_0x550fae(0x2a7)]['y']);
                            var _0x1a5c6e = this['owner']['getChildByName'](_0x550fae(0x2a9));
                            !Laya[_0x550fae(0x2aa)][_0x550fae(0x2ab)] && _0x1a5c6e['on'](Laya[_0x550fae(0x2ac)][_0x550fae(0x2ad)], this, function(_0x3d6804) {
                                var _0x4c5742 = _0x550fae;
                                _0x3d6804[_0x4c5742(0x2ae)](), _0xc57f97['jump'] = !0x0;
                            });
                        }
                    },
                    {
                        'key': _0x313795(0x2af),
                        'value': function _0x3baece(_0x50e50e) {
                            var _0x4820fe = _0x313795;
                            if (!this['_downEnable'])
                                return;
                            this[_0x4820fe(0x2b0)] = !0x0;
                            var _0x34469f = _0x50e50e[_0x4820fe(0x2b1)],
                                _0x1b2c04 = _0x50e50e['stageY'];
                            this[_0x4820fe(0x2a0)][_0x4820fe(0x2b2)](_0x34469f, _0x1b2c04), this[_0x4820fe(0x2b3)](_0x34469f, _0x1b2c04), this[_0x4820fe(0x2a5)][_0x4820fe(0x2b4)](_0x50e50e['stageX'], _0x50e50e[_0x4820fe(0x2b5)]);
                        }
                    },
                    {
                        'key': _0x313795(0x2b6),
                        'value': function _0x5ec7b4(_0x39dbdc) {
                            var _0x2e74e5 = _0x313795;
                            if (!this[_0x2e74e5(0x2b0)])
                                return;
                            var _0x4452aa = _0x39dbdc[_0x2e74e5(0x2b1)],
                                _0x11a800 = _0x39dbdc[_0x2e74e5(0x2b5)];
                            this[_0x2e74e5(0x2b3)](_0x4452aa, _0x11a800), this[_0x2e74e5(0x2b7)] = this[_0x2e74e5(0x2a5)]['x'] - _0x39dbdc[_0x2e74e5(0x2b1)], this['lastPos'][_0x2e74e5(0x2b4)](_0x39dbdc[_0x2e74e5(0x2b1)], _0x39dbdc[_0x2e74e5(0x2b5)]);
                        }
                    },
                    {
                        'key': _0x313795(0x2b8),
                        'value': function _0x8fb2c0(_0x48fe53) {
                            var _0x275431 = _0x313795;
                            this[_0x275431(0x2b0)] && (this[_0x275431(0x2b0)] = !0x1, this[_0x275431(0x2a4)][_0x275431(0x2b4)](0x0, 0x0), this[_0x275431(0x2b9)](), this[_0x275431(0x2a0)][_0x275431(0x2b2)](this['originPos']['x'], this['originPos']['y']));
                        }
                    },
                    {
                        'key': 'drag',
                        'value': function _0x1f3ad7(_0x3a3b23, _0x4c67c1) {
                            var _0x3bbafa = _0x313795;
                            this[_0x3bbafa(0x2a4)]['x'] = _0x3a3b23 - this[_0x3bbafa(0x2a0)]['x'], this[_0x3bbafa(0x2a4)]['y'] = _0x4c67c1 - this[_0x3bbafa(0x2a0)]['y'];
                            var _0x44a46a = (this[_0x3bbafa(0x2a0)]['width'] - this[_0x3bbafa(0x2a3)][_0x3bbafa(0x2ba)]) / 0x2;
                            _0xdb1a4f[_0x3bbafa(0x2bb)](this[_0x3bbafa(0x2a4)], 0x1 / _0x44a46a, this['input']), _0xdb1a4f[_0x3bbafa(0x2bc)](this[_0x3bbafa(0x2a4)]) > 0x1 && _0xdb1a4f['normalize'](this[_0x3bbafa(0x2a4)], this[_0x3bbafa(0x2a4)]), this[_0x3bbafa(0x2b9)]();
                        }
                    },
                    {
                        'key': 'updateHandle',
                        'value': function _0x22b3e8() {
                            var _0x53cb29 = _0x313795,
                                _0x12b41d = (this[_0x53cb29(0x2a0)][_0x53cb29(0x2ba)] - this['handle'][_0x53cb29(0x2ba)]) / 0x2;
                            this[_0x53cb29(0x2a3)]['centerX'] = this[_0x53cb29(0x2a4)]['x'] * _0x12b41d, this[_0x53cb29(0x2a3)][_0x53cb29(0x2bd)] = this[_0x53cb29(0x2a4)]['y'] * _0x12b41d;
                        }
                    },
                    {
                        'key': _0x313795(0x2be),
                        'value': function _0x3db9f4() {
                            var _0x582bb0 = _0x313795;
                            this['jump'] = !0x1, this[_0x582bb0(0x2b7)] = 0x0;
                        }
                    },
                    {
                        'key': _0x313795(0x2bf),
                        'value': function _0x47ea06() {
                            var _0x37dcfb = _0x313795;
                            return this[_0x37dcfb(0x2b7)];
                        }
                    }
                ]), _0x104efd;
            }(Laya[_0x28eca3(0x206)]),
            _0x1a62ec = function(_0x5c0b17) {
                var _0x492acd = _0x28eca3;
                _0x10ff6e(_0x5e6809, _0x5c0b17);
                var _0x571721 = _0x30529b(_0x5e6809);

                function _0x5e6809() {
                    var _0x38cf65 = _0x372d,
                        _0x2c375d;
                    return _0xaf4c50(this, _0x5e6809), (_0x2c375d = _0x571721[_0x38cf65(0x1f4)](this, arguments), _0x2c375d[_0x38cf65(0x2c0)] = !0x0, _0x2c375d[_0x38cf65(0x29e)] = !0x0), _0x2c375d;
                }
                return _0x3f3356(_0x5e6809, [{
                        'key': _0x492acd(0x2c1),
                        'set': function _0xdad701(_0x49809c) {
                            var _0x3d96d4 = _0x492acd;
                            this[_0x3d96d4(0x2c0)] = _0x49809c;
                        }
                    },
                    {
                        'key': 'downEnable',
                        'set': function _0x4dcf62(_0x26d490) {
                            this['_downEnable'] = _0x26d490;
                        }
                    },
                    {
                        'key': _0x492acd(0x1fa),
                        'value': function _0x5b8eea() {
                            var _0x208bb0 = _0x492acd;
                            this[_0x208bb0(0x2c2)] = [];
                            var _0x247b24 = this[_0x208bb0(0x1fe)][_0x208bb0(0x209)](_0x208bb0(0x2c3));
                            this['moveInput'] = _0x247b24[_0x208bb0(0x2c4)](_0x303818), this['joysticks'][_0x208bb0(0x290)](this[_0x208bb0(0x2c3)]);
                            var _0x3028da = this[_0x208bb0(0x1fe)][_0x208bb0(0x209)](_0x208bb0(0x2c5));
                            this['rotInput'] = _0x3028da[_0x208bb0(0x2c4)](_0x303818), this[_0x208bb0(0x2c2)][_0x208bb0(0x290)](this['rotInput']), !Laya[_0x208bb0(0x2aa)]['onPC'] ? (_0x3028da[_0x208bb0(0x20b)] = _0x247b24[_0x208bb0(0x20b)] = !![], Laya[_0x208bb0(0x2c6)]['on'](Laya['Event'][_0x208bb0(0x2c7)], this, this['onStageMouseUp'])) : _0x3028da[_0x208bb0(0x20b)] = _0x247b24['visible'] = ![];
                        }
                    },
                    {
                        'key': 'onDestroy',
                        'value': function _0x39b890() {
                            var _0x449e4c = _0x492acd;
                            Laya[_0x449e4c(0x2c6)][_0x449e4c(0x295)](this);
                        }
                    },
                    {
                        'key': _0x492acd(0x2c8),
                        'value': function _0x3eb36a(_0x498146) {
                            var _0xcaba5d = _0x492acd;
                            if (!this['_downEnable'])
                                return;
                            var _0x4a31c9 = this[_0xcaba5d(0x2c9)](_0x498146[_0xcaba5d(0x2b1)], _0x498146['stageY']);
                            _0x4a31c9 && null == _0x4a31c9[_0xcaba5d(0x2ca)] && (_0x4a31c9[_0xcaba5d(0x2ca)] = _0x498146['touchId'], _0x4a31c9[_0xcaba5d(0x2af)](_0x498146));
                        }
                    },
                    {
                        'key': 'onStageMouseMove',
                        'value': function _0x2deca5(_0x5bbb89) {
                            var _0x4a13df = _0x492acd;
                            if (!this[_0x4a13df(0x2c0)])
                                return;
                            var _0x47d6cb = this[_0x4a13df(0x2cb)](_0x5bbb89['touchId']);
                            _0x47d6cb && _0x47d6cb[_0x4a13df(0x2b6)](_0x5bbb89);
                        }
                    },
                    {
                        'key': 'onStageMouseUp',
                        'value': function _0xfd3e74(_0x38b693) {
                            var _0x1d8ef6 = _0x492acd,
                                _0x2b585f = this['getJoystickByTouchId'](_0x38b693[_0x1d8ef6(0x2ca)]);
                            _0x2b585f && (_0x2b585f['touchId'] = null, _0x2b585f[_0x1d8ef6(0x2b8)](_0x38b693));
                        }
                    },
                    {
                        'key': _0x492acd(0x2cb),
                        'value': function _0x34bc4f(_0x1937cc) {
                            var _0xb6cb69 = _0x492acd,
                                _0x16a8e8 = _0x523788(this[_0xb6cb69(0x2c2)]),
                                _0x1d96fa;
                            try {
                                for (_0x16a8e8['s'](); !(_0x1d96fa = _0x16a8e8['n']())[_0xb6cb69(0x288)];) {
                                    var _0x443917 = _0x1d96fa[_0xb6cb69(0x289)];
                                    if (_0x443917[_0xb6cb69(0x2ca)] == _0x1937cc)
                                        return _0x443917;
                                }
                            } catch (_0xb4cdd2) {
                                _0x16a8e8['e'](_0xb4cdd2);
                            } finally {
                                _0x16a8e8['f']();
                            }
                        }
                    },
                    {
                        'key': _0x492acd(0x2c9),
                        'value': function _0x405cab(_0x2d80f6, _0x470048) {
                            var _0x31e1ed = _0x492acd;
                            return _0x2d80f6 < 0.5 * Laya[_0x31e1ed(0x2c6)]['width'] && _0x470048 > 0.5 * Laya['stage'][_0x31e1ed(0x2a8)] && !Laya[_0x31e1ed(0x2aa)][_0x31e1ed(0x2ab)] ? this[_0x31e1ed(0x2c2)][0x0] : this[_0x31e1ed(0x2c2)][0x1];
                        }
                    },
                    {
                        'key': 'getJoysticks',
                        'value': function _0x6ff92e() {
                            var _0xc97a45 = _0x492acd;
                            return this[_0xc97a45(0x2c2)];
                        }
                    }
                ]), _0x5e6809;
            }(Laya['Script']),
            _0x337c61 = function(_0x1a5599) {
                var _0x1ad6bd = _0x28eca3;
                _0x10ff6e(_0x596492, _0x1a5599);
                var _0x167ab1 = _0x30529b(_0x596492);

                function _0x596492() {
                    var _0x105da2 = _0x372d;
                    return _0xaf4c50(this, _0x596492), _0x167ab1[_0x105da2(0x1f7)](this);
                }
                return _0x3f3356(_0x596492, [{
                        'key': 'onEnable',
                        'value': function _0x15fc76() {
                            fx['Sdk']['instance']['showBanner']();
                        }
                    },
                    {
                        'key': _0x1ad6bd(0x20c),
                        'value': function _0xbfaf54() {
                            var _0x36df68 = _0x1ad6bd;
                            fx[_0x36df68(0x231)]['instance'][_0x36df68(0x2cc)]();
                        }
                    }
                ]), _0x596492;
            }(Laya['Script']);
        ! function(_0x11779b) {
            var _0x1e4d3c = _0x28eca3;
            _0x11779b['version'] = _0x1e4d3c(0x2cd), (_0x11779b[_0x1e4d3c(0x2ce)] = function() {
                function _0x3b7510() {
                    _0xaf4c50(this, _0x3b7510);
                }
                return _0x3b7510;
            }(), _0x11779b[_0x1e4d3c(0x2cf)] = {});
        }(_0x41211b || (_0x41211b = {}));
        var _0x498384 = _0x41211b,
            _0x13db4b = function _0x43cd34() {
                _0xaf4c50(this, _0x43cd34);
            };
        _0x13db4b[_0x28eca3(0x2d0)] = _0x498384[_0x28eca3(0x2d0)], _0x13db4b[_0x28eca3(0x2d1)] = _0x28eca3(0x2d2), _0x13db4b['user_unique_id'] = _0x28eca3(0x2d3), _0x13db4b[_0x28eca3(0x2d4)] = fx[_0x28eca3(0x2d5)]['WEIXIN'], _0x13db4b['server_url'] = '', _0x13db4b['server_url_common'] = '', _0x13db4b[_0x28eca3(0x2d6)] = '', _0x13db4b[_0x28eca3(0x2d7)] = '', _0x13db4b['local_share_title'] = '', _0x13db4b[_0x28eca3(0x2d8)] = '', _0x13db4b[_0x28eca3(0x2d9)] = !0x1, _0x13db4b['appSid'] = '', _0x13db4b['appId'] = _0x28eca3(0x2da), _0x13db4b[_0x28eca3(0x2db)] = '', _0x13db4b[_0x28eca3(0x2dc)] = 0x3, _0x13db4b[_0x28eca3(0x2dd)] = !0x1, _0x13db4b['channel_AdIds'] = {
            'videoId': _0x28eca3(0x2de),
            'nativeAdId': [
                '',
                ''
            ],
            'bannerId': _0x28eca3(0x2df),
            'interstitialId': _0x28eca3(0x2e0),
            'appBoxId': '',
            'blockId': 'adunit-ab87dacba2f45583'
        };
        var _0x118985, _0x492b8f = fx[_0x28eca3(0x2e1)],
            _0x1c588d = fx[_0x28eca3(0x2e2)],
            _0x4722fb = Laya[_0x28eca3(0x266)][_0x28eca3(0x2e3)];
        ! function(_0x5ed00a) {
            var _0x1f70df = _0x28eca3;
            ! function(_0x3bcf78) {
                var _0x53f033 = _0x372d,
                    _0x596ee1 = function(_0x293d0) {
                        var _0x37f0c5 = _0x372d;
                        _0x10ff6e(_0x5141c9, _0x293d0);
                        var _0x2fadb4 = _0x30529b(_0x5141c9);

                        function _0x5141c9() {
                            var _0x5b420f = _0x372d;
                            return _0xaf4c50(this, _0x5141c9), _0x2fadb4[_0x5b420f(0x1f7)](this);
                        }
                        return _0x3f3356(_0x5141c9, [{
                            'key': _0x37f0c5(0x2e4),
                            'value': function _0x30b9ab() {
                                var _0x8c7136 = _0x37f0c5;
                                _0x58adf2(_0x5a6184(_0x5141c9[_0x8c7136(0x2e5)]), _0x8c7136(0x2e4), this)['call'](this), this[_0x8c7136(0x2e6)]('scenes/GameFailedDialog');
                            }
                        }]), _0x5141c9;
                    }(_0x1c588d);
                _0x3bcf78['GameFailedDialogUI'] = _0x596ee1, _0x4722fb(_0x53f033(0x2e7), _0x596ee1);
                var _0x4867bc = function(_0x53dd16) {
                    _0x10ff6e(_0x2f8100, _0x53dd16);
                    var _0x2ea4bc = _0x30529b(_0x2f8100);

                    function _0x2f8100() {
                        var _0x3c4481 = _0x372d;
                        return _0xaf4c50(this, _0x2f8100), _0x2ea4bc[_0x3c4481(0x1f7)](this);
                    }
                    return _0x3f3356(_0x2f8100, [{
                        'key': 'createChildren',
                        'value': function _0x218909() {
                            var _0x27a8a9 = _0x372d;
                            _0x58adf2(_0x5a6184(_0x2f8100[_0x27a8a9(0x2e5)]), _0x27a8a9(0x2e4), this)['call'](this), this[_0x27a8a9(0x2e6)](_0x27a8a9(0x2e8));
                        }
                    }]), _0x2f8100;
                }(_0x492b8f);
                _0x3bcf78[_0x53f033(0x2e9)] = _0x4867bc, _0x4722fb(_0x53f033(0x2ea), _0x4867bc);
                var _0x553200 = function(_0x179862) {
                    _0x10ff6e(_0x20ab8b, _0x179862);
                    var _0x315dbc = _0x30529b(_0x20ab8b);

                    function _0x20ab8b() {
                        return _0xaf4c50(this, _0x20ab8b), _0x315dbc['call'](this);
                    }
                    return _0x3f3356(_0x20ab8b, [{
                        'key': 'createChildren',
                        'value': function _0x55a5e1() {
                            var _0x34f48a = _0x372d;
                            _0x58adf2(_0x5a6184(_0x20ab8b[_0x34f48a(0x2e5)]), 'createChildren', this)['call'](this), this['loadScene'](_0x34f48a(0x2eb));
                        }
                    }]), _0x20ab8b;
                }(_0x492b8f);
                _0x3bcf78[_0x53f033(0x2ec)] = _0x553200, _0x4722fb(_0x53f033(0x2ed), _0x553200);
                var _0xd77266 = function(_0x1d2301) {
                    _0x10ff6e(_0xfef1e4, _0x1d2301);
                    var _0x40bf91 = _0x30529b(_0xfef1e4);

                    function _0xfef1e4() {
                        var _0x4306d7 = _0x372d;
                        return _0xaf4c50(this, _0xfef1e4), _0x40bf91[_0x4306d7(0x1f7)](this);
                    }
                    return _0x3f3356(_0xfef1e4, [{
                        'key': 'createChildren',
                        'value': function _0x367de6() {
                            var _0x5601ec = _0x372d;
                            _0x58adf2(_0x5a6184(_0xfef1e4[_0x5601ec(0x2e5)]), 'createChildren', this)[_0x5601ec(0x1f7)](this), this[_0x5601ec(0x2e6)]('scenes/GameSuccessDialog');
                        }
                    }]), _0xfef1e4;
                }(_0x1c588d);
                _0x3bcf78[_0x53f033(0x2ee)] = _0xd77266, _0x4722fb(_0x53f033(0x2ef), _0xd77266);
                var _0x7df5bb = function(_0x41e5b1) {
                    var _0x15ee2c = _0x53f033;
                    _0x10ff6e(_0x3f69a6, _0x41e5b1);
                    var _0x3ccd31 = _0x30529b(_0x3f69a6);

                    function _0x3f69a6() {
                        var _0x34472 = _0x372d;
                        return _0xaf4c50(this, _0x3f69a6), _0x3ccd31[_0x34472(0x1f7)](this);
                    }
                    return _0x3f3356(_0x3f69a6, [{
                        'key': _0x15ee2c(0x2e4),
                        'value': function _0x4effbd() {
                            var _0x4f6ba9 = _0x15ee2c;
                            _0x58adf2(_0x5a6184(_0x3f69a6['prototype']), 'createChildren', this)[_0x4f6ba9(0x1f7)](this), this[_0x4f6ba9(0x2e6)](_0x4f6ba9(0x2f0));
                        }
                    }]), _0x3f69a6;
                }(_0x492b8f);
                _0x3bcf78['MainSceneUI'] = _0x7df5bb, _0x4722fb(_0x53f033(0x2f1), _0x7df5bb);
            }(_0x5ed00a[_0x1f70df(0x2f2)] || (_0x5ed00a[_0x1f70df(0x2f2)] = {}));
        }(_0x118985 || (_0x118985 = {})),
        function(_0xb97dbe) {
            var _0x4140c5 = _0x28eca3;
            ! function(_0x1e8a44) {
                var _0x5779c2 = _0x372d;
                ! function(_0x1cfe67) {
                    var _0x475a69 = _0x372d,
                        _0x4702a1 = function(_0x11c0c2) {
                            var _0x3a2024 = _0x372d;
                            _0x10ff6e(_0x589199, _0x11c0c2);
                            var _0x59d038 = _0x30529b(_0x589199);

                            function _0x589199() {
                                return _0xaf4c50(this, _0x589199), _0x59d038['call'](this);
                            }
                            return _0x3f3356(_0x589199, [{
                                'key': _0x3a2024(0x2e4),
                                'value': function _0x11ff51() {
                                    var _0x1fe4a4 = _0x3a2024;
                                    _0x58adf2(_0x5a6184(_0x589199['prototype']), _0x1fe4a4(0x2e4), this)['call'](this), this[_0x1fe4a4(0x2e6)]('scenes/marble/GuessMarbleScene');
                                }
                            }]), _0x589199;
                        }(_0x492b8f);
                    _0x1cfe67[_0x475a69(0x2f3)] = _0x4702a1, _0x4722fb(_0x475a69(0x2f4), _0x4702a1);
                }(_0x1e8a44[_0x5779c2(0x2f5)] || (_0x1e8a44[_0x5779c2(0x2f5)] = {}));
            }(_0xb97dbe['scenes'] || (_0xb97dbe[_0x4140c5(0x2f2)] = {}));
        }(_0x118985 || (_0x118985 = {})),
        function(_0x4e4f8f) {
            var _0x491b57 = _0x28eca3;
            ! function(_0x1d58c3) {
                var _0x592764 = _0x372d;
                ! function(_0x49cc43) {
                    var _0x3bb1e6 = _0x372d,
                        _0x47dfd3 = function(_0x16a241) {
                            var _0x13603b = _0x372d;
                            _0x10ff6e(_0x267b51, _0x16a241);
                            var _0x107337 = _0x30529b(_0x267b51);

                            function _0x267b51() {
                                return _0xaf4c50(this, _0x267b51), _0x107337['call'](this);
                            }
                            return _0x3f3356(_0x267b51, [{
                                'key': _0x13603b(0x2e4),
                                'value': function _0x203487() {
                                    var _0x55b18b = _0x13603b;
                                    _0x58adf2(_0x5a6184(_0x267b51[_0x55b18b(0x2e5)]), _0x55b18b(0x2e4), this)[_0x55b18b(0x1f7)](this), this['loadScene'](_0x55b18b(0x2f6));
                                }
                            }]), _0x267b51;
                        }(_0x1c588d);
                    _0x49cc43[_0x3bb1e6(0x2f7)] = _0x47dfd3, _0x4722fb(_0x3bb1e6(0x2f8), _0x47dfd3);
                }(_0x1d58c3[_0x592764(0x2f9)] || (_0x1d58c3[_0x592764(0x2f9)] = {}));
            }(_0x4e4f8f[_0x491b57(0x2f2)] || (_0x4e4f8f['scenes'] = {}));
        }(_0x118985 || (_0x118985 = {})),
        function(_0x334e5e) {
            var _0x31f536 = _0x28eca3;
            ! function(_0x344b9c) {
                var _0x58743b = _0x372d;
                ! function(_0x4b7f18) {
                    var _0x206c9c = _0x372d,
                        _0x3de474 = function(_0xdecb6a) {
                            var _0x2d5dc4 = _0x372d;
                            _0x10ff6e(_0x463a6b, _0xdecb6a);
                            var _0x46dc15 = _0x30529b(_0x463a6b);

                            function _0x463a6b() {
                                var _0x43d92b = _0x372d;
                                return _0xaf4c50(this, _0x463a6b), _0x46dc15[_0x43d92b(0x1f7)](this);
                            }
                            return _0x3f3356(_0x463a6b, [{
                                'key': _0x2d5dc4(0x2e4),
                                'value': function _0x7eda6f() {
                                    var _0x4b667b = _0x2d5dc4;
                                    _0x58adf2(_0x5a6184(_0x463a6b['prototype']), _0x4b667b(0x2e4), this)['call'](this), this[_0x4b667b(0x2e6)](_0x4b667b(0x2fa));
                                }
                            }]), _0x463a6b;
                        }(_0x1c588d);
                    _0x4b7f18['ShareGuideUI'] = _0x3de474, _0x4722fb(_0x206c9c(0x2fb), _0x3de474);
                }(_0x344b9c[_0x58743b(0x2fc)] || (_0x344b9c['shareGuide'] = {}));
            }(_0x334e5e[_0x31f536(0x2f2)] || (_0x334e5e[_0x31f536(0x2f2)] = {}));
        }(_0x118985 || (_0x118985 = {}));
        var _0x39ee6f = function(_0x505bde) {
                var _0x46204d = _0x28eca3;
                _0x10ff6e(_0x4c574c, _0x505bde);
                var _0x43a113 = _0x30529b(_0x4c574c);

                function _0x4c574c() {
                    var _0x4e7ec4 = _0x372d;
                    return _0xaf4c50(this, _0x4c574c), _0x43a113[_0x4e7ec4(0x1f4)](this, arguments);
                }
                return _0x3f3356(_0x4c574c, [{
                        'key': _0x46204d(0x1fa),
                        'value': function _0x361baf() {
                            var _0x2d14b6 = _0x46204d,
                                _0x392a52 = this,
                                _0x30ab90 = this['s3d'] = this[_0x2d14b6(0x1fe)];
                            Laya['PhysicsSimulation'][_0x2d14b6(0x2fd)] = !0x0;
                            var _0x22db65 = new fx['Physics'][(_0x2d14b6(0x2fe))]({
                                'iterations': 0x6,
                                'worldscale': 0x1,
                                'random': !0x1,
                                'gravity': [
                                    0x0, -9.8,
                                    0x0
                                ]
                            });
                            fx[_0x2d14b6(0x2ff)]['World']['instance'] = this[_0x2d14b6(0x300)] = _0x22db65, Laya[_0x2d14b6(0x301)]['disableSimulation'] && (_0x30ab90[_0x2d14b6(0x302)][_0x2d14b6(0x303)] = _0x22db65['rayCast'][_0x2d14b6(0x304)](_0x22db65)), fx[_0x2d14b6(0x2ff)][_0x2d14b6(0x2fe)][_0x2d14b6(0x305)] = 0.1, fx[_0x2d14b6(0x2ff)][_0x2d14b6(0x2fe)][_0x2d14b6(0x306)] = 0.4, fx[_0x2d14b6(0x2ff)][_0x2d14b6(0x2fe)][_0x2d14b6(0x307)] = 0.1, fx['Physics']['World'][_0x2d14b6(0x308)] = 0x4;
                            var _0x5ac3fa = _0x30ab90[_0x2d14b6(0x209)](_0x2d14b6(0x309)),
                                _0x36b0fa = fx[_0x2d14b6(0x1fb)][_0x2d14b6(0x30a)]();
                            if (_0x36b0fa[_0x2d14b6(0x30b)](function(_0x548c13) {
                                    var _0x52c6fc = _0x2d14b6;
                                    _0x548c13[_0x52c6fc(0x30c)] = fx[_0x52c6fc(0x30d)][_0x52c6fc(0x30c)];
                                }), _0x30ab90[_0x2d14b6(0x30e)]) {
                                var _0x49f47f = _0x36b0fa[0x0];
                                _0x30ab90[_0x2d14b6(0x30f)] = fx[_0x2d14b6(0x1fb)][_0x2d14b6(0x310)](_0x49f47f[_0x2d14b6(0x311)]);
                            }
                            var _0x20a4d5 = _0x30ab90[_0x2d14b6(0x209)](_0x2d14b6(0x312));
                            if (_0x20a4d5) {
                                var _0x4d3355 = _0x4c574c[_0x2d14b6(0x313)];
                                _0x4d3355 || (_0x4d3355 = _0x4c574c['sWaterMat'] = this[_0x2d14b6(0x314)]([
                                    _0xf611c3[_0x2d14b6(0x315)],
                                    _0xf611c3['TEX_WAVEN']
                                ], !0x0, function() {
                                    var _0x23f66f = _0x2d14b6;
                                    if (_0x392a52['destroyed'] || _0x20a4d5['destroyed'])
                                        return;
                                    fx[_0x23f66f(0x1fb)][_0x23f66f(0x316)](_0x20a4d5)[_0x23f66f(0x243)] = _0x4d3355;
                                }));
                            }
                        }
                    },
                    {
                        'key': 'getLight',
                        'value': function _0x4cbfa4() {
                            var _0x166109 = _0x46204d;
                            return this[_0x166109(0x317)];
                        }
                    },
                    {
                        'key': 'onUpdate',
                        'value': function _0x3b22b3() {
                            var _0x37815b = _0x46204d;
                            this[_0x37815b(0x300)][_0x37815b(0x318)]();
                        }
                    },
                    {
                        'key': _0x46204d(0x314),
                        'value': function _0x1ac69f(_0x209f20, _0x1f24cb, _0x2128bf) {
                            var _0x2c8964 = _0x46204d,
                                _0x101218 = new fx['WaterMaterial']();

                            function _0x1d322a(_0x1e0dcd, _0x2cc9c4) {
                                var _0xfb9bbc = _0x372d,
                                    _0x139d64 = Laya[_0xfb9bbc(0x319)][_0xfb9bbc(0x31a)](_0x1e0dcd);
                                if (!_0x139d64 || _0x101218[_0xfb9bbc(0x31b)])
                                    return;
                                var _0x4cedd6 = _0x139d64[_0xfb9bbc(0x31c)];
                                _0x4cedd6 ? _0x101218[_0x2cc9c4] = _0x4cedd6 : (_0x4cedd6 = _0x139d64, _0x101218[_0x2cc9c4] = _0x139d64), _0x4cedd6[_0xfb9bbc(0x31d)] = Laya['WarpMode']['Repeat'], _0x4cedd6[_0xfb9bbc(0x31e)] = Laya['WarpMode']['Repeat'];
                            }
                            if (_0x101218[_0x2c8964(0x31f)] = !0x0, Laya[_0x2c8964(0x319)]['getRes'](_0x209f20[0x0])) {
                                if (_0x1d322a(_0x209f20[0x0], _0x2c8964(0x320)), _0x1d322a(_0x209f20[0x1], _0x2c8964(0x321)), _0x1f24cb)
                                    _0x101218[_0x2c8964(0x322)]();
                                else
                                    _0x101218[_0x2c8964(0x31f)] = !0x1;
                                _0x2128bf && _0x2128bf(_0x101218);
                            } else
                                Laya[_0x2c8964(0x319)][_0x2c8964(0x323)](_0x209f20, Laya[_0x2c8964(0x324)][_0x2c8964(0x325)](this, function() {
                                    var _0xea9ac9 = _0x2c8964;
                                    if (_0x1d322a(_0x209f20[0x0], _0xea9ac9(0x320)), _0x1d322a(_0x209f20[0x1], _0xea9ac9(0x321)), _0x1f24cb)
                                        _0x101218[_0xea9ac9(0x322)]();
                                    else
                                        _0x101218['lock'] = !0x1;
                                    _0x2128bf && _0x2128bf(_0x101218);
                                }));
                            return _0x101218;
                        }
                    }
                ]), _0x4c574c;
            }(Laya[_0x28eca3(0x326)]),
            _0x5f1a96 = function(_0x2c53e9) {
                var _0x59277c = _0x28eca3;
                _0x10ff6e(_0x124c91, _0x2c53e9);
                var _0x2ca15e = _0x30529b(_0x124c91);

                function _0x124c91() {
                    var _0x6e80fb = _0x372d,
                        _0x4c4d02;
                    return _0xaf4c50(this, _0x124c91), (_0x4c4d02 = _0x2ca15e[_0x6e80fb(0x1f4)](this, arguments), _0x4c4d02['temp'] = new _0x31f777(), _0x4c4d02['lastPos'] = new _0x31f777(), _0x4c4d02[_0x6e80fb(0x327)] = new _0x31f777()), _0x4c4d02;
                }
                return _0x3f3356(_0x124c91, [{
                        'key': _0x59277c(0x1fa),
                        'value': function _0x179145() {
                            var _0x1bbbc0 = _0x59277c;
                            this[_0x1bbbc0(0x328)] = this[_0x1bbbc0(0x1fe)], this['hitPos'][_0x1bbbc0(0x329)](this[_0x1bbbc0(0x328)][_0x1bbbc0(0x32a)]['position']), this['lastPos']['from'](this['hitPos']);
                        }
                    },
                    {
                        'key': _0x59277c(0x32b),
                        'value': function _0x44fe9f(_0xc54070) {
                            var _0x4b4a49 = _0x59277c;
                            this['player'] = _0xc54070, this['distance'] = _0x31f777[_0x4b4a49(0x32c)](_0xc54070['transform'][_0x4b4a49(0x32d)], this[_0x4b4a49(0x328)][_0x4b4a49(0x32a)]['position']);
                        }
                    },
                    {
                        'key': _0x59277c(0x29c),
                        'value': function _0x48e45b() {
                            var _0xb9a527 = _0x59277c,
                                _0x534d8a = this[_0xb9a527(0x328)][_0xb9a527(0x32a)][_0xb9a527(0x32d)];
                            if (_0x31f777[_0xb9a527(0x32c)](this[_0xb9a527(0x2a5)], _0x534d8a) <= 0.01)
                                return;
                            var _0x53edc0 = this['player']['transform'][_0xb9a527(0x32d)][_0xb9a527(0x32e)]();
                            _0x53edc0['y'] += 0x2;
                            var _0x272335 = !0x1,
                                _0x1d829f = this['temp'];
                            _0x31f777[_0xb9a527(0x32f)](_0x534d8a, _0x53edc0, _0x1d829f), _0x1d829f[_0xb9a527(0x330)]();
                            var _0x15a418 = this[_0xb9a527(0x328)]['scene'],
                                _0x3e625a = this['hitPos'],
                                _0x1909e5 = _0x1d829f[_0xb9a527(0x32e)]();
                            _0x1909e5[_0xb9a527(0x330)](this['distance']), _0x31f777['add'](_0x53edc0, _0x1909e5, _0x3e625a);
                            var _0x39673a = fx['Utils'][_0xb9a527(0x331)](_0x1d829f, _0x53edc0, _0x15a418, this[_0xb9a527(0x32c)], _0x134368[_0xb9a527(0x1ef)]);
                            if (_0x39673a && _0x39673a[_0xb9a527(0x332)] && _0x39673a[_0xb9a527(0x332)]['name'] && _0x39673a['target'][_0xb9a527(0x333)][_0xb9a527(0x334)](_0xb9a527(0x335))) {
                                this['hitPos'][_0xb9a527(0x329)](_0x39673a['cp']);
                                var _0x1fd9e3 = _0x31f777[_0xb9a527(0x32c)](_0x53edc0, this[_0xb9a527(0x327)]),
                                    _0x939df9 = Math['clamp'](_0x1fd9e3 - 0x1, 0x1, this[_0xb9a527(0x32c)]);
                                _0x1909e5[_0xb9a527(0x330)](_0x939df9), _0x31f777[_0xb9a527(0x336)](_0x53edc0, _0x1909e5, this[_0xb9a527(0x327)]), _0x272335 = !0x0;
                            } else
                                this[_0xb9a527(0x327)]['from'](_0x3e625a);
                            this[_0xb9a527(0x337)]();
                        }
                    },
                    {
                        'key': 'locateCameraSp',
                        'value': function _0x2190e7() {
                            var _0x1ba3aa = _0x59277c,
                                _0x12a827 = arguments[_0x1ba3aa(0x27c)] > 0x0 && arguments[0x0] !== undefined ? arguments[0x0] : !0x0;
                            this[_0x1ba3aa(0x2a5)]['from'](this[_0x1ba3aa(0x327)]);
                            var _0xe20648 = this['temp'],
                                _0xc98f = this[_0x1ba3aa(0x328)][_0x1ba3aa(0x32a)];
                            _0xe20648['from'](_0xc98f['position']), _0x12a827 && _0x31f777['lerp'](_0xe20648, this[_0x1ba3aa(0x2a5)], 0.25, _0xe20648), _0xc98f['position'] = _0xe20648;
                        }
                    }
                ]), _0x124c91;
            }(Laya[_0x28eca3(0x326)]),
            _0xdd3063 = function(_0x3beb7b) {
                var _0x792a6c = _0x28eca3;
                _0x10ff6e(_0x206ae3, _0x3beb7b);
                var _0x5e7624 = _0x30529b(_0x206ae3);

                function _0x206ae3() {
                    var _0x205936 = _0x372d,
                        _0x5b760e;
                    return _0xaf4c50(this, _0x206ae3), (_0x5b760e = _0x5e7624['apply'](this, arguments), _0x5b760e['min'] = new _0x31f777(), _0x5b760e[_0x205936(0x28c)] = new _0x31f777(), _0x5b760e[_0x205936(0x338)] = new _0x31f777(), _0x5b760e[_0x205936(0x339)] = new _0x31f777(), _0x5b760e[_0x205936(0x33a)] = 0x0), _0x5b760e;
                }
                return _0x3f3356(_0x206ae3, [{
                        'key': _0x792a6c(0x270),
                        'value': function _0x49adff(_0x202794, _0x48f1be) {
                            var _0x382293 = _0x792a6c;
                            _0x58adf2(_0x5a6184(_0x206ae3[_0x382293(0x2e5)]), _0x382293(0x270), this)[_0x382293(0x1f7)](this, _0x202794), this[_0x382293(0x33b)] = _0x48f1be, this[_0x382293(0x33c)] = !0x0;
                        }
                    },
                    {
                        'key': _0x792a6c(0x33d),
                        'value': function _0x3a0734(_0x57c172, _0x469bf2) {
                            var _0x65fbe4 = _0x792a6c,
                                _0x49e059 = arguments[_0x65fbe4(0x27c)] > 0x2 && arguments[0x2] !== undefined ? arguments[0x2] : !0x0;
                            this[_0x65fbe4(0x33e)] = _0x57c172, this[_0x65fbe4(0x33a)] = _0x469bf2, this[_0x65fbe4(0x33f)] = _0x49e059;
                        }
                    },
                    {
                        'key': _0x792a6c(0x29c),
                        'value': function _0x430984() {
                            var _0x341a56 = _0x792a6c;
                            if (this[_0x341a56(0x340)]() && !this[_0x341a56(0x341)]())
                                return;
                            if (this[_0x341a56(0x33e)] && !this['origSp'][_0x341a56(0x31b)]) {
                                var _0x4f33ed = _0x31f777[_0x341a56(0x342)](this[_0x341a56(0x343)][_0x341a56(0x32a)]['position'], this[_0x341a56(0x33e)]['transform'][_0x341a56(0x32d)]),
                                    _0x2444c0 = this['bodyEnableRadius'];
                                if (!(_0x4f33ed < _0x2444c0 * _0x2444c0))
                                    return void _0x58adf2(_0x5a6184(_0x206ae3[_0x341a56(0x2e5)]), 'onDisable', this)[_0x341a56(0x1f7)](this);
                                _0x58adf2(_0x5a6184(_0x206ae3[_0x341a56(0x2e5)]), _0x341a56(0x344), this)[_0x341a56(0x1f7)](this), this[_0x341a56(0x33f)] && (this[_0x341a56(0x33e)] = null);
                            }
                            var _0x24ddd5 = this['body'];
                            !_0x24ddd5[_0x341a56(0x345)] && _0x24ddd5['parent'] ? (_0x58adf2(_0x5a6184(_0x206ae3['prototype']), _0x341a56(0x29c), this)[_0x341a56(0x1f7)](this), this[_0x341a56(0x33b)] && 0x0 == Laya['CollisionUtils'][_0x341a56(0x346)](this[_0x341a56(0x33b)], this[_0x341a56(0x343)]['transform'][_0x341a56(0x32d)]) && this[_0x341a56(0x347)]()) : this['impulse']['toDefault']();
                        }
                    },
                    {
                        'key': 'onOutSide',
                        'value': function _0x2b2750() {
                            var _0x17dc50 = _0x792a6c;
                            _0x58adf2(_0x5a6184(_0x206ae3[_0x17dc50(0x2e5)]), _0x17dc50(0x348), this)['call'](this);
                        }
                    },
                    {
                        'key': _0x792a6c(0x349),
                        'value': function _0x11c089(_0x2a8f0b, _0x252608) {
                            var _0x84d5b = _0x792a6c;
                            _0x31f777[_0x84d5b(0x34a)](_0x2a8f0b) > 0x0 && (this['impulse'][_0x84d5b(0x329)](_0x2a8f0b), this[_0x84d5b(0x34b)][_0x84d5b(0x349)](_0x2a8f0b, _0x252608));
                        }
                    },
                    {
                        'key': _0x792a6c(0x34c),
                        'value': function _0x58f647() {
                            var _0x24fafb = _0x792a6c;
                            return this[_0x24fafb(0x339)];
                        }
                    },
                    {
                        'key': _0x792a6c(0x34d),
                        'value': function _0x18b904(_0x2958ee, _0x47a73d) {
                            var _0x1c86c6 = _0x792a6c,
                                _0x4518fe = this['body'][_0x1c86c6(0x34e)];
                            _0x4518fe['x'] = _0x2958ee['x'], _0x47a73d || (_0x4518fe['y'] = _0x2958ee['y']), _0x4518fe['z'] = _0x2958ee['z'];
                        }
                    },
                    {
                        'key': 'getVelocity',
                        'value': function _0x5601de() {
                            var _0x30db24 = _0x792a6c,
                                _0x234077 = this[_0x30db24(0x34f)],
                                _0x1de112 = this[_0x30db24(0x34b)]['linearVelocity'];
                            return _0x234077['setValue'](_0x1de112['x'], _0x1de112['y'], _0x1de112['z']), _0x234077;
                        }
                    },
                    {
                        'key': _0x792a6c(0x350),
                        'value': function _0x55f60e(_0x3b82c3) {
                            var _0x82453d = _0x792a6c,
                                _0x207e0d = this[_0x82453d(0x34b)][_0x82453d(0x351)];
                            _0x207e0d['x'] = _0x3b82c3['x'], _0x207e0d['y'] = _0x3b82c3['y'], _0x207e0d['z'] = _0x3b82c3['z'];
                        }
                    },
                    {
                        'key': _0x792a6c(0x352),
                        'value': function _0x539bd1() {
                            var _0x12124c = _0x792a6c,
                                _0xb86d16 = this[_0x12124c(0x34f)],
                                _0x36570f = this['body']['linearSpeed'];
                            return _0xb86d16[_0x12124c(0x2b4)](_0x36570f['x'], _0x36570f['y'], _0x36570f['z']), _0xb86d16;
                        }
                    },
                    {
                        'key': 'getMass',
                        'value': function _0x2a5298() {
                            var _0x3b0216 = _0x792a6c;
                            return this[_0x3b0216(0x34b)]['mass'];
                        }
                    },
                    {
                        'key': _0x792a6c(0x353),
                        'value': function _0x1998fd() {
                            return this['body']['inverseMass'];
                        }
                    },
                    {
                        'key': 'wakeUp',
                        'value': function _0x187a52() {
                            var _0x3c3018 = _0x792a6c;
                            this['body'][_0x3c3018(0x345)] && this[_0x3c3018(0x34b)][_0x3c3018(0x354)]();
                        }
                    },
                    {
                        'key': _0x792a6c(0x355),
                        'value': function _0x11fbd1() {
                            var _0x335b47 = _0x792a6c;
                            this[_0x335b47(0x34b)]['sleep']();
                        }
                    },
                    {
                        'key': 'setGravity',
                        'value': function _0x251e7b(_0x420cbd) {
                            var _0x281d57 = _0x792a6c;
                            this[_0x281d57(0x34b)] && (this[_0x281d57(0x34b)][_0x281d57(0x356)] = _0x420cbd);
                        }
                    },
                    {
                        'key': _0x792a6c(0x357),
                        'value': function _0x534161() {
                            var _0x48ed51 = _0x792a6c;
                            return this[_0x48ed51(0x34b)][_0x48ed51(0x333)];
                        }
                    },
                    {
                        'key': 'setPositionConstraint',
                        'value': function _0x156fc4(_0x2c420e, _0x5c0c64) {
                            var _0x176052 = _0x792a6c;
                            this['body'][_0x176052(0x358)] = [
                                _0x2c420e['x'],
                                _0x5c0c64['x'],
                                _0x2c420e['y'],
                                _0x5c0c64['y'],
                                _0x2c420e['z'],
                                _0x5c0c64['z']
                            ];
                        }
                    },
                    {
                        'key': _0x792a6c(0x359),
                        'value': function _0x3651fe(_0x189acf) {
                            var _0x4466ce = _0x792a6c;
                            this[_0x4466ce(0x34b)][_0x4466ce(0x35a)] = _0x189acf;
                        }
                    },
                    {
                        'key': 'setLinearVelocityMax',
                        'value': function _0x19368d(_0x3b28d7) {
                            var _0x29a74c = _0x792a6c;
                            this['body'][_0x29a74c(0x35b)] = _0x3b28d7;
                        }
                    },
                    {
                        'key': _0x792a6c(0x35c),
                        'value': function _0x5633da(_0x8a18c9) {
                            var _0x5f08ad = _0x792a6c;
                            this[_0x5f08ad(0x34b)]['angularVelocityConstraint'] = _0x8a18c9;
                        }
                    },
                    {
                        'key': 'setAngularVelocityMax',
                        'value': function _0x2c1ff2(_0x3094a3) {
                            var _0x3fa04c = _0x792a6c;
                            this[_0x3fa04c(0x34b)][_0x3fa04c(0x35d)] = _0x3094a3;
                        }
                    },
                    {
                        'key': 'setKinematic',
                        'value': function _0x185024(_0x4af049) {
                            var _0x4f03b3 = _0x792a6c;
                            this[_0x4f03b3(0x34b)]['isKinematic'] = _0x4af049;
                        }
                    },
                    {
                        'key': 'clearForces',
                        'value': function _0x2b1c49() {
                            var _0x4bbbf7 = _0x792a6c;
                            this[_0x4bbbf7(0x350)](_0x31f777['ZERO']), this['setVelocity'](_0x31f777[_0x4bbbf7(0x35e)]);
                        }
                    },
                    {
                        'key': _0x792a6c(0x35f),
                        'value': function _0x58539a() {
                            var _0x4c57ed = _0x792a6c,
                                _0x40e36b = this[_0x4c57ed(0x360)];
                            _0x40e36b['from'](this['boundBox'][_0x4c57ed(0x360)]);
                            var _0x316ebd = this[_0x4c57ed(0x28c)];
                            _0x316ebd[_0x4c57ed(0x329)](this[_0x4c57ed(0x361)][_0x4c57ed(0x28c)]);
                            var _0x550d06 = this[_0x4c57ed(0x343)]['transform'][_0x4c57ed(0x32d)],
                                _0x4da5a6 = this[_0x4c57ed(0x343)]['transform']['rotation'];
                            _0x31f777['transformQuat'](_0x40e36b, _0x4da5a6, _0x40e36b), _0x31f777['transformQuat'](_0x316ebd, _0x4da5a6, _0x316ebd);
                            var _0x509f20 = this[_0x4c57ed(0x34f)],
                                _0x8ce857 = this[_0x4c57ed(0x338)];
                            return _0x31f777['min'](_0x40e36b, _0x316ebd, _0x509f20), _0x31f777[_0x4c57ed(0x336)](_0x550d06, _0x509f20, _0x509f20), _0x31f777[_0x4c57ed(0x28c)](_0x40e36b, _0x316ebd, _0x8ce857), _0x31f777[_0x4c57ed(0x336)](_0x550d06, _0x8ce857, _0x8ce857), new Laya['BoundBox'](_0x509f20, _0x8ce857);
                        }
                    }
                ]), _0x206ae3;
            }(fx[_0x28eca3(0x362)]),
            _0x20256e = function(_0x35c827) {
                var _0x9c9a7d = _0x28eca3;
                _0x10ff6e(_0x332420, _0x35c827);
                var _0x1f59ae = _0x30529b(_0x332420);

                function _0x332420() {
                    return _0xaf4c50(this, _0x332420), _0x1f59ae['apply'](this, arguments);
                }
                return _0x3f3356(_0x332420, null, [{
                        'key': _0x9c9a7d(0x363),
                        'value': function _0x511337(_0x6fe4e7, _0x19ac45, _0xa33e2b) {}
                    },
                    {
                        'key': _0x9c9a7d(0x364),
                        'value': function _0x578c92() {}
                    },
                    {
                        'key': 'crashSprite3dGravity',
                        'value': function _0x3ae63a(_0x4a734e, _0x1776ec, _0x450713) {
                            var _0xb51451 = _0x9c9a7d,
                                _0x3403fb = arguments[_0xb51451(0x27c)] > 0x3 && arguments[0x3] !== undefined ? arguments[0x3] : 0x5a,
                                _0x4f55f8 = arguments[_0xb51451(0x27c)] > 0x4 && arguments[0x4] !== undefined ? arguments[0x4] : !0x0,
                                _0x17e05b = arguments['length'] > 0x5 && arguments[0x5] !== undefined ? arguments[0x5] : !0x1,
                                _0x12d196 = arguments['length'] > 0x6 && arguments[0x6] !== undefined ? arguments[0x6] : 0xe,
                                _0x5aae9e = arguments[_0xb51451(0x27c)] > 0x7 && arguments[0x7] !== undefined ? arguments[0x7] : 0x10,
                                _0x5ebf4c = arguments[_0xb51451(0x27c)] > 0x8 && arguments[0x8] !== undefined ? arguments[0x8] : 0xbb8;
                        }
                    },
                    {
                        'key': _0x9c9a7d(0x365),
                        'value': function _0x9d2c24() {}
                    },
                    {
                        'key': _0x9c9a7d(0x366),
                        'value': function _0x1bf1fd(_0x359758, _0x49b9b0) {
                            var _0x1bda9c = _0x9c9a7d,
                                _0x16725c = _0x359758[_0x1bda9c(0x2c4)](Laya['PhysicsCollider']);
                            if (_0x16725c)
                                return;
                            _0x16725c = _0x359758[_0x1bda9c(0x367)](Laya[_0x1bda9c(0x368)]);
                            var _0x3e6d4b = new Laya[(_0x1bda9c(0x369))]();
                            return _0x3e6d4b['mesh'] = _0x359758['meshFilter'][_0x1bda9c(0x36a)], _0x16725c[_0x1bda9c(0x36b)] = _0x3e6d4b, _0x49b9b0 && (_0x16725c[_0x1bda9c(0x36c)] = _0x49b9b0), _0x16725c;
                        }
                    },
                    {
                        'key': _0x9c9a7d(0x36d),
                        'value': function _0x43bd77(_0x35ed2d, _0x13a0f3, _0x157508) {
                            var _0xf039ac = _0x9c9a7d,
                                _0x49b93d = _0x35ed2d[_0xf039ac(0x2c4)](Laya['PhysicsCollider']);
                            if (_0x49b93d)
                                return;
                            _0x49b93d = _0x35ed2d[_0xf039ac(0x367)](Laya[_0xf039ac(0x368)]);
                            var _0x49d68c = fx[_0xf039ac(0x1fb)]['get3dLocalModelSize'](_0x35ed2d);
                            _0x157508 && (_0x49d68c['x'] *= _0x157508['x'], _0x49d68c['y'] *= _0x157508['y'], _0x49d68c['z'] *= _0x157508['z']);
                            var _0x997958 = new Laya[(_0xf039ac(0x36e))](_0x49d68c['x'], _0x49d68c['y'], _0x49d68c['z']);
                            return _0x49b93d[_0xf039ac(0x36b)] = _0x997958, _0x13a0f3 && (_0x49b93d[_0xf039ac(0x36c)] = _0x13a0f3), _0x49b93d;
                        }
                    },
                    {
                        'key': 'setColliderShapeGroup',
                        'value': function _0x177285(_0x391829, _0xedc9e5, _0x56c222) {
                            var _0x41a914 = _0x9c9a7d,
                                _0x4ce37d = _0x391829[_0x41a914(0x2c4)](Laya['PhysicsCollider']);
                            return _0x4ce37d && (_0x4ce37d[_0x41a914(0x36c)] = _0xedc9e5, _0x56c222 && (_0x4ce37d[_0x41a914(0x36f)] = _0x56c222)), _0x4ce37d;
                        }
                    },
                    {
                        'key': _0x9c9a7d(0x370),
                        'value': function _0x22e104(_0x57baac, _0x2beded, _0x5c0bd7) {
                            var _0x33666c = _0x9c9a7d,
                                _0x23560d = _0x57baac[_0x33666c(0x2c4)](Laya[_0x33666c(0x371)]);
                            return _0x23560d && (_0x5c0bd7 && (_0x23560d[_0x33666c(0x36c)] = _0x5c0bd7), _0x23560d[_0x33666c(0x36f)] = _0x2beded), _0x23560d;
                        }
                    },
                    {
                        'key': 'smoothProcMeshCollider',
                        'value': function _0x16b699(_0x543b11, _0x40b0e6) {
                            var _0x2ffbb7 = _0x9c9a7d,
                                _0x16867d = this,
                                _0x580cdc = _0x543b11[_0x2ffbb7(0x372)][_0x2ffbb7(0x36a)],
                                _0x17e541 = _0x543b11;
                            if (_0x580cdc && !_0x17e541[_0x2ffbb7(0x373)]) {
                                var _0x4bd399;
                                _0x17e541['__smoothprocmeshcollider'] = !0x0;
                                var _0x3bd6d6 = function _0x16a8fa() {
                                        var _0x17589 = _0x2ffbb7,
                                            _0x2b9c35 = _0x543b11['getComponent'](Laya[_0x17589(0x368)]);
                                        if (!_0x2b9c35) {
                                            _0x2b9c35 = _0x543b11[_0x17589(0x367)](Laya['PhysicsCollider']);
                                            var _0x197dad = new Laya['MeshColliderShape']();
                                            _0x197dad[_0x17589(0x374)] = _0x543b11[_0x17589(0x372)][_0x17589(0x36a)], _0x2b9c35[_0x17589(0x36b)] = _0x197dad, _0x332420[_0x17589(0x375)](_0x543b11, _0x40b0e6);
                                        }
                                        _0x17e541['__smoothprocmeshcollider'] = !0x1, _0x543b11[_0x17589(0x376)](Laya['Event']['REMOVED'], _0x16867d, _0x4bd399);
                                    },
                                    _0x46c053 = _0x580cdc;
                                if (_0x46c053[_0x2ffbb7(0x377)])
                                    _0x3bd6d6();
                                else {
                                    var _0x268c32 = Laya[_0x2ffbb7(0x378)],
                                        _0x42ce74 = new Laya3D[(_0x2ffbb7(0x379))][(_0x2ffbb7(0x37a))](),
                                        _0x4487a4 = _0x268c32['_nativeTempVector30'],
                                        _0x330506 = _0x268c32['_nativeTempVector31'],
                                        _0x10548d = _0x268c32[_0x2ffbb7(0x37b)],
                                        _0x10d7f9 = _0x46c053['_tempVector30'],
                                        _0x13aff0 = _0x46c053[_0x2ffbb7(0x37c)],
                                        _0x4a312f = _0x46c053[_0x2ffbb7(0x37d)],
                                        _0x8d95a8 = _0x46c053['_vertexBuffer'],
                                        _0x3b3f77 = _0x46c053[_0x2ffbb7(0x37e)](_0x8d95a8),
                                        _0x5d5a43 = _0x8d95a8[_0x2ffbb7(0x37f)](),
                                        _0x38a258 = _0x8d95a8[_0x2ffbb7(0x380)][_0x2ffbb7(0x381)] / 0x4,
                                        _0x601f5b = _0x3b3f77[_0x2ffbb7(0x382)] / 0x4,
                                        _0x305fa1 = _0x46c053[_0x2ffbb7(0x383)][_0x2ffbb7(0x37f)](),
                                        _0x427ddc = 0x0,
                                        _0x5634dc = function _0x3b6e7d() {
                                            var _0x318ccd = _0x2ffbb7,
                                                _0x440148 = Laya[_0x318ccd(0x384)][_0x318ccd(0x385)];
                                            for (; _0x427ddc < _0x305fa1[_0x318ccd(0x27c)]; _0x427ddc += 0x3) {
                                                if (Laya[_0x318ccd(0x2c6)]['getTimeFromFrameStart']() > 0x1e)
                                                    return;
                                                var _0x1999ea = _0x305fa1[_0x427ddc] * _0x38a258 + _0x601f5b,
                                                    _0xa6c8d9 = _0x305fa1[_0x427ddc + 0x1] * _0x38a258 + _0x601f5b,
                                                    _0x3e8d1b = _0x305fa1[_0x427ddc + 0x2] * _0x38a258 + _0x601f5b;
                                                _0x10d7f9[_0x318ccd(0x2b4)](_0x5d5a43[_0x1999ea], _0x5d5a43[_0x1999ea + 0x1], _0x5d5a43[_0x1999ea + 0x2]), _0x13aff0['setValue'](_0x5d5a43[_0xa6c8d9], _0x5d5a43[_0xa6c8d9 + 0x1], _0x5d5a43[_0xa6c8d9 + 0x2]), _0x4a312f[_0x318ccd(0x2b4)](_0x5d5a43[_0x3e8d1b], _0x5d5a43[_0x3e8d1b + 0x1], _0x5d5a43[_0x3e8d1b + 0x2]), _0x440148(_0x10d7f9, _0x4487a4, !0x0), _0x440148(_0x13aff0, _0x330506, !0x0), _0x440148(_0x4a312f, _0x10548d, !0x0), _0x42ce74['addTriangle'](_0x4487a4, _0x330506, _0x10548d, !0x0);
                                            }
                                            _0x46c053[_0x318ccd(0x377)] = _0x42ce74, Laya['timer']['clear'](_0x16867d, _0x3b6e7d), _0x3bd6d6();
                                        };
                                    Laya['timer'][_0x2ffbb7(0x386)](0x1, this, _0x5634dc), _0x4bd399 = function _0x48c623() {
                                        var _0x1dea00 = _0x2ffbb7;
                                        _0x17e541[_0x1dea00(0x373)] = !0x1, Laya[_0x1dea00(0x387)][_0x1dea00(0x278)](_0x16867d, _0x5634dc);
                                    }, _0x543b11['once'](Laya[_0x2ffbb7(0x2ac)]['REMOVED'], this, _0x4bd399);
                                }
                            }
                        }
                    },
                    {
                        'key': 'changeRigibodyToCollider',
                        'value': function _0x4ff280(_0x26de13) {
                            var _0x1aa056 = _0x9c9a7d,
                                _0xea0f60 = _0x26de13['getComponent'](Laya[_0x1aa056(0x371)]);
                            if (_0xea0f60) {
                                var _0x118022 = _0xea0f60[_0x1aa056(0x36b)][_0x1aa056(0x32e)](),
                                    _0x147227 = _0x26de13[_0x1aa056(0x367)](Laya[_0x1aa056(0x368)]);
                                return _0x147227['colliderShape'] = _0x118022, _0xea0f60[_0x1aa056(0x33c)] = !0x1, _0x147227;
                            }
                        }
                    },
                    {
                        'key': 'changeColliderToRigibody',
                        'value': function _0x1a72cb(_0x255858) {
                            var _0x1f1511 = _0x9c9a7d,
                                _0x473a4d = _0x255858['getComponent'](Laya['PhysicsCollider']);
                            if (_0x473a4d) {
                                var _0x5c0734 = _0x473a4d[_0x1f1511(0x36b)][_0x1f1511(0x32e)](),
                                    _0x3e35c2 = _0x255858[_0x1f1511(0x367)](Laya['Rigidbody3D']);
                                return _0x3e35c2[_0x1f1511(0x36b)] = _0x5c0734, _0x473a4d['enabled'] = !0x1, _0x3e35c2;
                            }
                        }
                    },
                    {
                        'key': _0x9c9a7d(0x388),
                        'value': function _0x155527(_0x3d3e59, _0x337a07, _0x30f42e) {
                            var _0x18275a = _0x9c9a7d,
                                _0x1b43d1 = arguments[_0x18275a(0x27c)] > 0x3 && arguments[0x3] !== undefined ? arguments[0x3] : !0x0;
                        }
                    },
                    {
                        'key': _0x9c9a7d(0x389),
                        'value': function _0x154d73(_0x1f0e07, _0x25369c, _0x68a6ba) {}
                    },
                    {
                        'key': _0x9c9a7d(0x38a),
                        'value': function _0x8d775a(_0x349a98, _0x20d3c3, _0x52e58e) {}
                    },
                    {
                        'key': 'playInvolveEff',
                        'value': function _0x2e89c9(_0x5d6b4f, _0x1f1227, _0x1e748e) {
                            var _0x3cab85 = _0x9c9a7d,
                                _0x4503ec = arguments[_0x3cab85(0x27c)] > 0x3 && arguments[0x3] !== undefined ? arguments[0x3] : 0x1,
                                _0x621ed6 = arguments[_0x3cab85(0x27c)] > 0x4 && arguments[0x4] !== undefined ? arguments[0x4] : 0x1,
                                _0x539df3 = arguments[_0x3cab85(0x27c)] > 0x5 ? arguments[0x5] : undefined,
                                _0x51fdd3 = arguments[_0x3cab85(0x27c)] > 0x6 ? arguments[0x6] : undefined;
                            return _0x5d6b4f[_0x3cab85(0x38b)];
                        }
                    },
                    {
                        'key': _0x9c9a7d(0x38c),
                        'value': function _0x5b7e91(_0x3029bf, _0x4445b3, _0x4ff81a, _0x3a883a, _0x15e6ca, _0x2cbee1, _0x5f5474, _0x309282) {}
                    },
                    {
                        'key': _0x9c9a7d(0x38d),
                        'value': function _0x374049(_0x1a34d1, _0x19588c) {
                            var _0x18ae66 = _0x9c9a7d,
                                _0x23ec23 = arguments[_0x18ae66(0x27c)] > 0x2 && arguments[0x2] !== undefined ? arguments[0x2] : 0x1,
                                _0x47d3ab = arguments['length'] > 0x3 ? arguments[0x3] : undefined;
                        }
                    },
                    {
                        'key': _0x9c9a7d(0x38e),
                        'value': function _0xec3da7(_0x1131dd, _0x5802df, _0x27db14, _0x1d4a29, _0x1705e7, _0xfd876f) {}
                    },
                    {
                        'key': _0x9c9a7d(0x38f),
                        'value': function _0x5dcf8a(_0x51f351, _0x148517, _0x5f3034, _0x40e448) {}
                    },
                    {
                        'key': _0x9c9a7d(0x390),
                        'value': function _0x103511(_0x1d3867, _0x2f7ec6, _0x382611) {
                            var _0x1d026e = _0x9c9a7d,
                                _0x4ad5a2, _0x4a493c = _0x1d3867;
                            if (_0x4a493c[_0x1d026e(0x391)])
                                return;
                            var _0x294aac = (_0x4ad5a2 = _0x1d3867 instanceof Laya[_0x1d026e(0x241)] ? _0x1d3867['skinnedMeshRenderer'][_0x1d026e(0x243)] : _0x1d3867[_0x1d026e(0x392)][_0x1d026e(0x243)])[_0x1d026e(0x393)];
                            _0x4a493c['__color_splash_anim'] = {
                                'tween': null,
                                'shininess': _0x294aac
                            }, _0x4ad5a2[_0x1d026e(0x393)] = 0x0;
                            var _0x4c1c3d = _0x2f7ec6[_0x1d026e(0x32e)](),
                                _0x35d75f = new Laya[(_0x1d026e(0x324))](this, function() {
                                    var _0x4f1a9f = _0x1d026e;
                                    _0x4ad5a2[_0x4f1a9f(0x394)] = _0x4c1c3d;
                                });
                            _0x1d3867['once'](Laya[_0x1d026e(0x2ac)]['REMOVED'], this, this['stopColorSplashAnim'], [_0x1d3867]),
                                function() {
                                    var _0x45226c = _0x1d026e;
                                    _0x4a493c[_0x45226c(0x391)][_0x45226c(0x395)] = Laya[_0x45226c(0x396)]['to'](_0x4c1c3d, {
                                        'x': 0x0,
                                        'y': 0x0,
                                        'z': 0x0,
                                        'update': _0x35d75f
                                    }, _0x382611, null, Laya['Handler'][_0x45226c(0x325)](this, function() {
                                        var _0x55736d = _0x45226c;
                                        _0x332420[_0x55736d(0x397)](_0x1d3867);
                                    }));
                                }();
                        }
                    },
                    {
                        'key': _0x9c9a7d(0x397),
                        'value': function _0x431308(_0x292560) {
                            var _0x528d3c = _0x9c9a7d,
                                _0x310fa1 = _0x292560;
                            if (_0x310fa1[_0x528d3c(0x391)]) {
                                var _0x262881;
                                _0x292560[_0x528d3c(0x376)](Laya['Event'][_0x528d3c(0x398)], this, this[_0x528d3c(0x397)]), (_0x262881 = _0x292560 instanceof Laya[_0x528d3c(0x241)] ? _0x292560[_0x528d3c(0x242)][_0x528d3c(0x243)] : _0x292560['meshRenderer'][_0x528d3c(0x243)])[_0x528d3c(0x393)] = _0x310fa1[_0x528d3c(0x391)][_0x528d3c(0x393)], Laya[_0x528d3c(0x396)][_0x528d3c(0x278)](_0x310fa1['__color_splash_anim'][_0x528d3c(0x395)]), _0x310fa1[_0x528d3c(0x391)] = null;
                            }
                        }
                    },
                    {
                        'key': 'scaleAnim',
                        'value': function _0x3dc46c(_0xa51de1, _0x2b0309, _0x5257e0) {
                            var _0x4bc95a = _0x9c9a7d,
                                _0x52024c = arguments['length'] > 0x3 && arguments[0x3] !== undefined ? arguments[0x3] : 0x0,
                                _0x4c0236 = arguments[_0x4bc95a(0x27c)] > 0x4 ? arguments[0x4] : undefined,
                                _0x119343 = _0xa51de1;
                            if (!_0x119343 || _0x119343[_0x4bc95a(0x399)])
                                return;
                            _0x5257e0 *= 0x3e8, _0x52024c *= 0x3e8;
                            var _0x485a4c = new _0x31f777(),
                                _0x5b3232 = _0xa51de1['transform'][_0x4bc95a(0x39a)]();
                            _0x485a4c[_0x4bc95a(0x329)](_0x5b3232);
                            var _0x5bd7e2 = new Laya[(_0x4bc95a(0x324))](this, function() {
                                var _0xff9b65 = _0x4bc95a;
                                _0xa51de1[_0xff9b65(0x32a)][_0xff9b65(0x39b)](_0x485a4c);
                            });
                            _0x119343['__scale_anim'] = Laya[_0x4bc95a(0x396)]['to'](_0x485a4c, {
                                'x': _0x2b0309['x'],
                                'y': _0x2b0309['y'],
                                'z': _0x2b0309['z'],
                                'update': _0x5bd7e2
                            }, _0x5257e0, null, Laya[_0x4bc95a(0x324)][_0x4bc95a(0x325)](this, function() {
                                var _0x54de7a = _0x4bc95a;
                                _0x332420[_0x54de7a(0x39c)](_0xa51de1), _0x4c0236 && _0x4c0236[_0x54de7a(0x215)]();
                            }), _0x52024c), _0xa51de1[_0x4bc95a(0x39d)](Laya[_0x4bc95a(0x2ac)][_0x4bc95a(0x398)], this, this[_0x4bc95a(0x39c)], [_0xa51de1]);
                        }
                    },
                    {
                        'key': 'stopScaleAnim',
                        'value': function _0x519782(_0x14f539) {
                            var _0x5a336a = _0x9c9a7d,
                                _0x648638 = _0x14f539,
                                _0x349321 = _0x648638[_0x5a336a(0x399)];
                            _0x349321 && (Laya[_0x5a336a(0x396)][_0x5a336a(0x278)](_0x349321), _0x14f539['off'](Laya[_0x5a336a(0x2ac)]['REMOVED'], this, this[_0x5a336a(0x39c)]), _0x648638['__scale_anim'] = null);
                        }
                    },
                    {
                        'key': _0x9c9a7d(0x39e),
                        'value': function _0x3ce226(_0x17ebf9, _0x2e6dfd) {
                            var _0x3b7a25 = function _0x2fe77b(_0x13ba1f) {
                                var _0x5d04ec = _0x372d;
                                _0x13ba1f instanceof _0x4ffd78 && (_0x13ba1f[_0x5d04ec(0x392)]['enable'] = _0x2e6dfd);
                                var _0x20658d = _0x13ba1f['getChildren'](),
                                    _0x4ee62a = _0x523788(_0x20658d),
                                    _0x1b5dfa;
                                try {
                                    for (_0x4ee62a['s'](); !(_0x1b5dfa = _0x4ee62a['n']())[_0x5d04ec(0x288)];) {
                                        var _0x315fbc = _0x1b5dfa[_0x5d04ec(0x289)];
                                        _0x2fe77b(_0x315fbc);
                                    }
                                } catch (_0x278254) {
                                    _0x4ee62a['e'](_0x278254);
                                } finally {
                                    _0x4ee62a['f']();
                                }
                            };
                            _0x3b7a25(_0x17ebf9);
                        }
                    },
                    {
                        'key': _0x9c9a7d(0x39f),
                        'value': function _0x2a022d(_0xf32975, _0x2c2ee7, _0x2df0fb) {
                            var _0xf7f63f = _0x9c9a7d,
                                _0x4f188a = arguments[_0xf7f63f(0x27c)] > 0x3 && arguments[0x3] !== undefined ? arguments[0x3] : !0x0,
                                _0x3424cb = arguments[_0xf7f63f(0x27c)] > 0x4 ? arguments[0x4] : undefined,
                                _0x5d11c8 = arguments[_0xf7f63f(0x27c)] > 0x5 ? arguments[0x5] : undefined,
                                _0x8ecf4d = arguments[_0xf7f63f(0x27c)] > 0x6 ? arguments[0x6] : undefined;
                            return [];
                        }
                    },
                    {
                        'key': 'initStaticCollider',
                        'value': function _0x17b308(_0x56a20e, _0x4a1106, _0x493de6, _0x22559c) {
                            var _0x4a96b5 = _0x9c9a7d,
                                _0x385298 = _0x56a20e['getComponent'](Laya[_0x4a96b5(0x368)]);
                            if (!_0x385298)
                                return;
                            var _0x5bbe29 = _0x56a20e[_0x4a96b5(0x367)](_0xdd3063);
                            return _0x5bbe29[_0x4a96b5(0x270)]({
                                'static': !0x0,
                                'kinematic': !0x1,
                                'trigger': _0x22559c,
                                'event': !0x0,
                                'eventOnce': !0x0,
                                'belongsTo': _0x4a1106,
                                'collidesWith': _0x493de6,
                                'shape': _0x385298[_0x4a96b5(0x36b)],
                                'debug': _0x4b339f[_0x4a96b5(0x3a0)],
                                'neverSleep': !0x0
                            }), _0x385298['destroy'](), _0x5bbe29;
                        }
                    },
                    {
                        'key': _0x9c9a7d(0x3a1),
                        'value': function _0x37b861(_0xeacbaa) {}
                    },
                    {
                        'key': _0x9c9a7d(0x3a2),
                        'value': function _0xf9d6ef(_0x4a2cb9, _0x5eb391) {
                            var _0x4d0d09 = _0x9c9a7d,
                                _0x446738 = arguments[_0x4d0d09(0x27c)] > 0x2 && arguments[0x2] !== undefined ? arguments[0x2] : 0x2,
                                _0x2e59cf = arguments['length'] > 0x3 && arguments[0x3] !== undefined ? arguments[0x3] : _0x4d0d09(0x3a3),
                                _0x5ebd38 = new Laya[(_0x4d0d09(0x3a4))]();
                            _0x5ebd38[_0x4d0d09(0x3a5)] = 0x1e, _0x5ebd38['color'] = _0x2e59cf, _0x5ebd38[_0x4d0d09(0x3a6)] = 0x0, _0x5ebd38[_0x4d0d09(0x2bd)] = 0x0, _0x5ebd38['bold'] = !0x0, _0x5ebd38['stroke'] = 0x5, _0x5ebd38[_0x4d0d09(0x3a7)] = _0x4d0d09(0x3a8), _0x5ebd38['text'] = _0x4a2cb9;
                            var _0x3f87d5 = _0x5ebd38[_0x4d0d09(0x2ba)] + 0x64,
                                _0x45735a = _0x5ebd38[_0x4d0d09(0x2a8)] + 0x28,
                                _0x214903 = new Laya[(_0x4d0d09(0x3a9))]();
                            _0x214903[_0x4d0d09(0x3aa)] = 0x2710, _0x214903[_0x4d0d09(0x2ba)] = _0x3f87d5, _0x214903[_0x4d0d09(0x2a8)] = _0x45735a, _0x214903[_0x4d0d09(0x3a6)] = 0x0, _0x214903['y'] = Laya[_0x4d0d09(0x2c6)][_0x4d0d09(0x2a8)] - 0x12c, Laya['stage']['addChild'](_0x214903);
                            var _0x5c0093 = new Laya[(_0x4d0d09(0x3ab))](_0x4d0d09(0x3ac));
                            _0x5c0093['sizeGrid'] = _0x4d0d09(0x3ad), _0x5c0093[_0x4d0d09(0x2ba)] = _0x3f87d5, _0x5c0093['height'] = _0x45735a, _0x5c0093[_0x4d0d09(0x3ae)] = 0.5, _0x214903['addChild'](_0x5c0093), _0x214903[_0x4d0d09(0x3af)](_0x5ebd38), Laya[_0x4d0d09(0x396)]['to'](_0x214903, {
                                'y': _0x214903['y'] + 0xc8,
                                'alpha': 0x0
                            }, 0xc8, null, Laya[_0x4d0d09(0x324)][_0x4d0d09(0x325)](this, function() {
                                var _0x50ca58 = _0x4d0d09;
                                (_0x214903['destroy'](), _0x5eb391) && (_0x5eb391[_0x50ca58(0x3b0)][_0x50ca58(0x31b)] || _0x5eb391[_0x50ca58(0x215)]());
                            }), 0x3e8 * _0x446738, !0x0, !0x0);
                        }
                    },
                    {
                        'key': _0x9c9a7d(0x3b1),
                        'value': function _0x2855b5(_0x16f688) {
                            var _0x594f37 = _0x9c9a7d,
                                _0x218748 = '';
                            if (_0x594f37(0x3b2) != typeof _0x16f688 || isNaN(_0x16f688) || _0x16f688 < 0x0)
                                return _0x218748;
                            var _0x5f4183 = Math[_0x594f37(0x3b3)](_0x16f688 / 0x36ee80),
                                _0x59cb3b = Math['floor'](_0x16f688 % 0x36ee80 / 0xea60),
                                _0x4b9aa4 = Math[_0x594f37(0x3b3)](_0x16f688 % 0xea60 / 0x3e8);
                            return _0x218748 = '' [_0x594f37(0x296)](_0x5f4183 < 0xa ? '0' + _0x5f4183 : _0x5f4183, ':')[_0x594f37(0x296)](_0x59cb3b < 0xa ? '0' + _0x59cb3b : _0x59cb3b, ':')[_0x594f37(0x296)](_0x4b9aa4 < 0xa ? '0' + _0x4b9aa4 : _0x4b9aa4);
                        }
                    }
                ]), _0x332420;
            }(fx[_0x28eca3(0x3b4)]),
            _0x247c83 = function _0x524590() {
                _0xaf4c50(this, _0x524590);
            },
            _0x25b706 = function() {
                var _0xd21360 = _0x28eca3;

                function _0x4a7511() {
                    _0xaf4c50(this, _0x4a7511), this['states'] = [];
                }
                return _0x3f3356(_0x4a7511, [{
                        'key': _0xd21360(0x3b5),
                        'get': function _0x5e9c77() {
                            return this['_currentStateID'];
                        }
                    },
                    {
                        'key': _0xd21360(0x3b6),
                        'get': function _0x2717bf() {
                            var _0x50e3ec = _0xd21360;
                            return this[_0x50e3ec(0x3b7)];
                        }
                    },
                    {
                        'key': _0xd21360(0x3b8),
                        'value': function _0x11d04a() {
                            this['_currentState']['onUpdate']();
                        }
                    },
                    {
                        'key': _0xd21360(0x3b9),
                        'value': function _0x4a5382(_0x3caa2a) {
                            var _0x44775a = _0xd21360;
                            if (0x0 == this['states'][_0x44775a(0x27c)])
                                return this[_0x44775a(0x3ba)][_0x44775a(0x290)](_0x3caa2a), this['_currentState'] = _0x3caa2a, void(this[_0x44775a(0x3bb)] = _0x3caa2a['ID']);
                            var _0xabed32 = _0x523788(this[_0x44775a(0x3ba)]),
                                _0x36df6b;
                            try {
                                for (_0xabed32['s'](); !(_0x36df6b = _0xabed32['n']())['done'];) {
                                    var _0x205407 = _0x36df6b[_0x44775a(0x289)];
                                    if (_0x205407['ID'] == _0x3caa2a['ID'])
                                        return void console[_0x44775a(0x3bc)](_0x44775a(0x3bd)[_0x44775a(0x296)](_0x3caa2a['ID'], _0x44775a(0x3be)));
                                }
                            } catch (_0x10f5d8) {
                                _0xabed32['e'](_0x10f5d8);
                            } finally {
                                _0xabed32['f']();
                            }
                            this[_0x44775a(0x3ba)][_0x44775a(0x290)](_0x3caa2a);
                        }
                    },
                    {
                        'key': _0xd21360(0x3bf),
                        'value': function _0x1efd2b(_0x476ce9) {
                            var _0x444fb5 = _0xd21360;
                            for (var _0xd7651e = 0x0; _0xd7651e < this[_0x444fb5(0x3ba)][_0x444fb5(0x27c)]; ++_0xd7651e) {
                                this[_0x444fb5(0x3ba)][_0xd7651e]['ID'] == _0x476ce9 && this[_0x444fb5(0x3ba)][_0x444fb5(0x27f)](_0xd7651e, 0x1);
                            }
                        }
                    },
                    {
                        'key': _0xd21360(0x3c0),
                        'value': function _0x2e2693(_0x3fb4dc) {
                            var _0x530552 = _0xd21360,
                                _0x22b4c6 = this['_currentState'][_0x530552(0x3c1)](_0x3fb4dc);
                            if (null != _0x22b4c6) {
                                this[_0x530552(0x3bb)] = _0x22b4c6;
                                var _0x48719e = _0x523788(this['states']),
                                    _0x509b97;
                                try {
                                    for (_0x48719e['s'](); !(_0x509b97 = _0x48719e['n']())[_0x530552(0x288)];) {
                                        var _0x193646 = _0x509b97[_0x530552(0x289)];
                                        _0x193646['ID'] == this[_0x530552(0x3bb)] && (this['_currentState'][_0x530552(0x3c2)](), this['_currentState'] = _0x193646, this[_0x530552(0x3b7)]['onEnter']());
                                    }
                                } catch (_0x2bc890) {
                                    _0x48719e['e'](_0x2bc890);
                                } finally {
                                    _0x48719e['f']();
                                }
                            }
                        }
                    },
                    {
                        'key': _0xd21360(0x3c3),
                        'value': function _0x5eee7c(_0x5a9d7a) {
                            var _0x2a29f9 = _0xd21360;
                            this[_0x2a29f9(0x3b7)][_0x2a29f9(0x3c4)](_0x5a9d7a);
                        }
                    },
                    {
                        'key': _0xd21360(0x3c5),
                        'value': function _0x493848() {
                            return this['_currentStateID'];
                        }
                    }
                ]), _0x4a7511;
            }(),
            _0x4afe8e = function() {
                var _0x3188f6 = _0x28eca3;

                function _0x5bb72a() {
                    _0xaf4c50(this, _0x5bb72a), this['map'] = new Map();
                }
                return _0x3f3356(_0x5bb72a, [{
                        'key': 'ID',
                        'get': function _0x1bb08e() {
                            var _0x3dd0e4 = _0x372d;
                            return this[_0x3dd0e4(0x3c6)];
                        }
                    },
                    {
                        'key': _0x3188f6(0x3c7),
                        'value': function _0xa7cf82(_0x40d9db, _0x238581) {
                            var _0x559fdc = _0x3188f6;
                            this[_0x559fdc(0x3c8)]['has'](_0x40d9db) || this[_0x559fdc(0x3c8)]['set'](_0x40d9db, _0x238581);
                        }
                    },
                    {
                        'key': _0x3188f6(0x3c9),
                        'value': function _0xb7d89d(_0x2f3b16) {
                            var _0x5eea2 = _0x3188f6;
                            this[_0x5eea2(0x3c8)]['has'](_0x2f3b16) && this[_0x5eea2(0x3c8)][_0x5eea2(0x3ca)](_0x2f3b16);
                        }
                    },
                    {
                        'key': _0x3188f6(0x3c1),
                        'value': function _0x101219(_0x4be1c1) {
                            var _0x4d825f = _0x3188f6;
                            return this[_0x4d825f(0x3c8)][_0x4d825f(0x3cb)](_0x4be1c1) ? this[_0x4d825f(0x3c8)][_0x4d825f(0x253)](_0x4be1c1) : null;
                        }
                    },
                    {
                        'key': _0x3188f6(0x3cc),
                        'value': function _0x2d0881() {}
                    },
                    {
                        'key': _0x3188f6(0x3c2),
                        'value': function _0x4a4f5c() {}
                    },
                    {
                        'key': 'onMessage',
                        'value': function _0x466cd0(_0x323b3f) {}
                    }
                ]), _0x5bb72a;
            }(),
            _0x468e80, _0x25410a;
        ! function(_0x317a35) {
            var _0x2d5a36 = _0x28eca3;
            _0x317a35[_0x317a35['NoInput'] = 0x0] = _0x2d5a36(0x3cd), _0x317a35[_0x317a35[_0x2d5a36(0x3ce)] = 0x1] = _0x2d5a36(0x3ce), _0x317a35[_0x317a35[_0x2d5a36(0x3cf)] = 0x2] = _0x2d5a36(0x3cf);
        }(_0x468e80 || (_0x468e80 = {})),
        function(_0x1f913d) {
            var _0x5e4de5 = _0x28eca3;
            _0x1f913d[_0x1f913d[_0x5e4de5(0x3d0)] = 0x0] = _0x5e4de5(0x3d0), _0x1f913d[_0x1f913d[_0x5e4de5(0x3d1)] = 0x1] = _0x5e4de5(0x3d1), _0x1f913d[_0x1f913d['Jump'] = 0x2] = 'Jump';
        }(_0x25410a || (_0x25410a = {}));
        var _0x163661 = function(_0x418c48) {
                var _0x34ad76 = _0x28eca3;
                _0x10ff6e(_0x1a323e, _0x418c48);
                var _0x318aa0 = _0x30529b(_0x1a323e);

                function _0x1a323e() {
                    var _0x3f7234 = _0x372d,
                        _0x257261;
                    return _0xaf4c50(this, _0x1a323e), (_0x257261 = _0x318aa0[_0x3f7234(0x1f7)](this), _0x257261[_0x3f7234(0x3c6)] = _0x25410a[_0x3f7234(0x3d0)]), _0x257261;
                }
                return _0x3f3356(_0x1a323e, [{
                        'key': _0x34ad76(0x3cc),
                        'value': function _0xea73e8() {
                            var _0x505201 = _0x34ad76,
                                _0x5e381f = this[_0x505201(0x3d2)]['pc'];
                            _0x5e381f[_0x505201(0x3d3)]('Idle'), _0x5e381f['stopMove']();
                        }
                    },
                    {
                        'key': _0x34ad76(0x29c),
                        'value': function _0x12df30() {
                            var _0x2da6d9 = _0x34ad76,
                                _0x4abca0 = this[_0x2da6d9(0x3d2)]['pc'],
                                _0x336fae = this[_0x2da6d9(0x3d2)][_0x2da6d9(0x2a4)];
                            this['blackBorad'][_0x2da6d9(0x3d4)] ? _0x4abca0[_0x2da6d9(0x3d5)](_0x468e80[_0x2da6d9(0x3cf)]) : _0x336fae[_0x2da6d9(0x3d6)]() || _0x4abca0[_0x2da6d9(0x3d5)](_0x468e80['Input']);
                        }
                    }
                ]), _0x1a323e;
            }(_0x4afe8e),
            _0x405772 = function(_0xbfe106) {
                var _0x2290e0 = _0x28eca3;
                _0x10ff6e(_0x4d62be, _0xbfe106);
                var _0x2c29aa = _0x30529b(_0x4d62be);

                function _0x4d62be() {
                    var _0x1ced34 = _0x372d,
                        _0x4e64b0;
                    return _0xaf4c50(this, _0x4d62be), (_0x4e64b0 = _0x2c29aa[_0x1ced34(0x1f7)](this), _0x4e64b0[_0x1ced34(0x34f)] = new _0x31f777(), _0x4e64b0['stateId'] = _0x25410a['Jump']), _0x4e64b0;
                }
                return _0x3f3356(_0x4d62be, [{
                        'key': _0x2290e0(0x3cc),
                        'value': function _0x127fa8() {
                            var _0x3cd917 = _0x2290e0,
                                _0x215412 = this['blackBorad']['pc'],
                                _0x24f8f8 = this[_0x3cd917(0x3d2)][_0x3cd917(0x2a4)];
                            _0x24f8f8[_0x3cd917(0x3d6)]() ? _0x215412[_0x3cd917(0x3d4)]() : (this[_0x3cd917(0x34f)][_0x3cd917(0x2b4)](-_0x24f8f8['x'], 0x0, -_0x24f8f8['y']), _0x215412['jump'](this[_0x3cd917(0x34f)])), _0x215412[_0x3cd917(0x3d3)](_0x3cd917(0x3cf), 0x1, !0x1, !0x0), this[_0x3cd917(0x3d7)] = 0.1, this[_0x3cd917(0x3d2)][_0x3cd917(0x3d8)] && fx[_0x3cd917(0x202)][_0x3cd917(0x203)][_0x3cd917(0x204)](_0x3cd917(0x3d9));
                        }
                    },
                    {
                        'key': _0x2290e0(0x29c),
                        'value': function _0x2469e4() {
                            var _0x5e9ba8 = _0x2290e0,
                                _0x26d871 = this[_0x5e9ba8(0x3d2)]['pc'],
                                _0x34049b = this['blackBorad'][_0x5e9ba8(0x2a4)];
                            _0x34049b[_0x5e9ba8(0x3d6)]() || (this[_0x5e9ba8(0x34f)]['setValue'](-_0x34049b['x'], 0x0, -_0x34049b['y']), _0x26d871['move'](this[_0x5e9ba8(0x34f)])), this['groundDt'] -= 0x10 / 0x3e8, this[_0x5e9ba8(0x3d7)] <= 0x0 && _0x26d871[_0x5e9ba8(0x3da)] && _0x26d871[_0x5e9ba8(0x3d5)](_0x468e80[_0x5e9ba8(0x3cd)]);
                        }
                    }
                ]), _0x4d62be;
            }(_0x4afe8e),
            _0x8d7c23 = function(_0xeaa67a) {
                var _0x400417 = _0x28eca3;
                _0x10ff6e(_0x3fa525, _0xeaa67a);
                var _0xf53149 = _0x30529b(_0x3fa525);

                function _0x3fa525() {
                    var _0x36ddce = _0x372d,
                        _0x2c2605;
                    return _0xaf4c50(this, _0x3fa525), (_0x2c2605 = _0xf53149[_0x36ddce(0x1f7)](this), _0x2c2605[_0x36ddce(0x34f)] = new _0x31f777(), _0x2c2605[_0x36ddce(0x3c6)] = _0x25410a['Move']), _0x2c2605;
                }
                return _0x3f3356(_0x3fa525, [{
                        'key': _0x400417(0x3cc),
                        'value': function _0x5d322f() {
                            var _0x35586f = _0x400417,
                                _0x235d2e = this[_0x35586f(0x3d2)]['pc'];
                            this[_0x35586f(0x3d2)][_0x35586f(0x3db)] ? _0x235d2e['playAnim']('Walk') : _0x235d2e[_0x35586f(0x3d3)](_0x35586f(0x3dc)), this[_0x35586f(0x3d2)][_0x35586f(0x3d8)] && fx[_0x35586f(0x202)][_0x35586f(0x203)][_0x35586f(0x204)](_0x35586f(0x3d9));
                        }
                    },
                    {
                        'key': 'onUpdate',
                        'value': function _0x1d3ff4() {
                            var _0xdf6f09 = _0x400417,
                                _0x5b8481 = this['blackBorad']['pc'],
                                _0x4f1dc2 = this['blackBorad']['input'];
                            _0x4f1dc2[_0xdf6f09(0x3d6)]() || (this[_0xdf6f09(0x34f)][_0xdf6f09(0x2b4)](-_0x4f1dc2['x'], 0x0, -_0x4f1dc2['y']), _0x5b8481['move'](this[_0xdf6f09(0x34f)])), this['blackBorad'][_0xdf6f09(0x3d4)] ? _0x5b8481[_0xdf6f09(0x3d5)](_0x468e80['Jump']) : _0x4f1dc2[_0xdf6f09(0x3d6)]() && _0x5b8481['setTransition'](_0x468e80['NoInput']);
                        }
                    }
                ]), _0x3fa525;
            }(_0x4afe8e),
            _0x500c49 = function(_0x2009bb) {
                var _0x563048 = _0x28eca3;
                _0x10ff6e(_0x8577b3, _0x2009bb);
                var _0x2a92bd = _0x30529b(_0x8577b3);

                function _0x8577b3() {
                    var _0x2df3dc = _0x372d,
                        _0x119bdd;
                    return _0xaf4c50(this, _0x8577b3), (_0x119bdd = _0x2a92bd['apply'](this, arguments), _0x119bdd['temp'] = new _0x31f777(), _0x119bdd[_0x2df3dc(0x3dd)] = new Laya[(_0x2df3dc(0x3de))]()), _0x119bdd;
                }
                return _0x3f3356(_0x8577b3, [{
                        'key': 'onAwake',
                        'value': function _0x104571() {
                            var _0x4a9cc7 = _0x372d;
                            this[_0x4a9cc7(0x3df)] = this[_0x4a9cc7(0x1fe)], this[_0x4a9cc7(0x32a)] = this['ownerSp'][_0x4a9cc7(0x32a)], this[_0x4a9cc7(0x3e0)] = this['owner'][_0x4a9cc7(0x23c)](_0x4a9cc7(0x23d)), this[_0x4a9cc7(0x3e1)] = this['character'][_0x4a9cc7(0x2c4)](Laya[_0x4a9cc7(0x3e2)]), _0x20256e['addAnimatorEventScript'](this['character'], this['ownerSp'], Laya['Handler'][_0x4a9cc7(0x325)](this, this[_0x4a9cc7(0x3e3)]));
                            var _0x432b57 = _0x29989c[_0x4a9cc7(0x203)][_0x4a9cc7(0x260)]();
                            this[_0x4a9cc7(0x3e4)] = _0x432b57[_0x4a9cc7(0x3e5)], this[_0x4a9cc7(0x3e6)] = _0x432b57['JumpSpeed'], this['initRigidbody'](), this[_0x4a9cc7(0x3e7)](), this[_0x4a9cc7(0x3e8)](!0x1, !0x1), _0x29989c[_0x4a9cc7(0x203)][_0x4a9cc7(0x27a)](this[_0x4a9cc7(0x3df)]);
                        }
                    },
                    {
                        'key': _0x563048(0x3e8),
                        'value': function _0x33107b(_0x258185, _0x887841) {}
                    },
                    {
                        'key': _0x563048(0x3e9),
                        'value': function _0x5e7714() {
                            var _0x2be8d9 = _0x563048,
                                _0x46026c = this[_0x2be8d9(0x3df)][_0x2be8d9(0x2c4)](Laya['PhysicsCollider']);
                            this[_0x2be8d9(0x3ea)] = this[_0x2be8d9(0x3df)][_0x2be8d9(0x367)](_0xdd3063);
                            var _0x1be74f = {
                                'static': !0x1,
                                'kinematic': !0x1,
                                'event': !0x0,
                                'eventOnce': !0x1,
                                'canRotation': !0x1,
                                'shape': _0x46026c[_0x2be8d9(0x36b)],
                                'belongsTo': _0x134368[_0x2be8d9(0x1f0)],
                                'collidesWith': _0x134368[_0x2be8d9(0x1ec)] & ~(_0x134368[_0x2be8d9(0x1f0)] | _0x134368[_0x2be8d9(0x1f1)]),
                                'neverSleep': !0x0,
                                'debug': _0x4b339f['PHYSICS_DEBUG_SHOW']
                            };
                            this[_0x2be8d9(0x3ea)][_0x2be8d9(0x270)](_0x1be74f), this[_0x2be8d9(0x3df)]['on'](fx[_0x2be8d9(0x3eb)][_0x2be8d9(0x3ec)], this, this['onCollision']);
                        }
                    },
                    {
                        'key': _0x563048(0x3ed),
                        'value': function _0x2f4804(_0xd5a2c2) {}
                    },
                    {
                        'key': _0x563048(0x3e3),
                        'value': function _0x5c003c(_0x4bc300) {
                            var _0x56204c = _0x563048;
                            _0x56204c(0x3ee) == _0x4bc300[_0x56204c(0x3ef)] && this[_0x56204c(0x3f0)]();
                        }
                    },
                    {
                        'key': _0x563048(0x3f0),
                        'value': function _0x3929c8() {
                            var _0x2f920e = _0x563048;
                            this['fsm'] && this['fsm'][_0x2f920e(0x3d2)][_0x2f920e(0x3d8)] && fx[_0x2f920e(0x202)][_0x2f920e(0x203)][_0x2f920e(0x204)]('res/sound/step.mp3');
                        }
                    },
                    {
                        'key': _0x563048(0x29c),
                        'value': function _0x10a0df() {
                            var _0x5b873f = _0x563048;
                            this[_0x5b873f(0x3f1)] || this[_0x5b873f(0x3f2)][_0x5b873f(0x3b8)]();
                        }
                    },
                    {
                        'key': _0x563048(0x3f3),
                        'value': function _0x157b25() {
                            var _0x5edbe6 = _0x563048;
                            this[_0x5edbe6(0x3da)] = !0x1;
                            var _0x3f09c8 = this[_0x5edbe6(0x32a)][_0x5edbe6(0x32d)];
                            this[_0x5edbe6(0x34f)][_0x5edbe6(0x329)](_0x3f09c8), this[_0x5edbe6(0x34f)]['y'] += 0.1;
                            var _0x256cd2 = new _0x31f777(0x0, -0x1, 0x0),
                                _0x4d4275 = new Laya[(_0x5edbe6(0x3f4))](this[_0x5edbe6(0x34f)], _0x256cd2),
                                _0x3a6441 = this[_0x5edbe6(0x1fe)]['scene'];
                            this[_0x5edbe6(0x3dd)][_0x5edbe6(0x3f5)] = !0x1, _0x3a6441[_0x5edbe6(0x302)][_0x5edbe6(0x303)](_0x4d4275, this[_0x5edbe6(0x3dd)], 0.12, _0x134368['PLAYER'], _0x134368[_0x5edbe6(0x1ef)]), this[_0x5edbe6(0x3dd)][_0x5edbe6(0x3f5)] && (this['grounded'] = !0x0);
                        }
                    },
                    {
                        'key': _0x563048(0x3e7),
                        'value': function _0x5e49f9() {
                            var _0x4004fd = _0x563048,
                                _0x4073c7 = new _0x247c83();
                            _0x4073c7['pc'] = this, _0x4073c7[_0x4004fd(0x2a4)] = new _0xdb1a4f(), _0x4073c7['jump'] = !0x1;
                            var _0x33ceae = new _0x163661();
                            _0x33ceae[_0x4004fd(0x3d2)] = _0x4073c7, _0x33ceae[_0x4004fd(0x3c7)](_0x468e80[_0x4004fd(0x3ce)], _0x25410a['Move']), _0x33ceae[_0x4004fd(0x3c7)](_0x468e80[_0x4004fd(0x3cf)], _0x25410a[_0x4004fd(0x3cf)]);
                            var _0x5751d1 = new _0x8d7c23();
                            _0x5751d1[_0x4004fd(0x3d2)] = _0x4073c7, _0x5751d1[_0x4004fd(0x3c7)](_0x468e80[_0x4004fd(0x3cd)], _0x25410a['Idle']), _0x5751d1[_0x4004fd(0x3c7)](_0x468e80[_0x4004fd(0x3cf)], _0x25410a[_0x4004fd(0x3cf)]);
                            var _0x4624a8 = new _0x405772();
                            _0x4624a8[_0x4004fd(0x3d2)] = _0x4073c7, _0x4624a8[_0x4004fd(0x3c7)](_0x468e80[_0x4004fd(0x3cd)], _0x25410a[_0x4004fd(0x3d0)]), this['fsm'] = new _0x25b706(), this[_0x4004fd(0x3f2)][_0x4004fd(0x3d2)] = _0x4073c7, this[_0x4004fd(0x3f2)][_0x4004fd(0x3b9)](_0x33ceae), this[_0x4004fd(0x3f2)][_0x4004fd(0x3b9)](_0x5751d1), this[_0x4004fd(0x3f2)]['addState'](_0x4624a8);
                        }
                    },
                    {
                        'key': _0x563048(0x3d5),
                        'value': function _0x254b1e(_0x29689a) {
                            var _0x32ae8e = _0x563048;
                            this[_0x32ae8e(0x3f1)] || this[_0x32ae8e(0x3f2)]['performTransition'](_0x29689a);
                        }
                    },
                    {
                        'key': _0x563048(0x3f6),
                        'value': function _0x5ded3c(_0x58c9eb) {
                            var _0x280b24 = _0x563048;
                            this[_0x280b24(0x34f)][_0x280b24(0x329)](_0x58c9eb), this[_0x280b24(0x34f)]['normalize'](this[_0x280b24(0x3e4)]);
                            var _0x519451 = this[_0x280b24(0x3ea)][_0x280b24(0x3f7)]();
                            this[_0x280b24(0x34f)]['y'] = _0x519451['y'], this[_0x280b24(0x3ea)][_0x280b24(0x34d)](this[_0x280b24(0x34f)]), this['changeFace'](_0x58c9eb['x'], _0x58c9eb['z'], 0.8);
                        }
                    },
                    {
                        'key': 'changeFace',
                        'value': function _0x11417e(_0x351193, _0x78a6f6, _0x25dcd7) {
                            var _0x381b19 = _0x563048;
                            if (this[_0x381b19(0x34f)]['setValue'](_0x351193, 0x0, -_0x78a6f6), this['temp'][_0x381b19(0x330)](), _0x31f777[_0x381b19(0x34a)](this[_0x381b19(0x34f)]) > 0.01) {
                                var _0x3e587b = this['character'][_0x381b19(0x32a)]['rotation']['clone']();
                                Laya[_0x381b19(0x3f8)]['rotationLookAt'](this['temp'], _0x31f777['Up'], _0x3e587b), Laya[_0x381b19(0x3f8)][_0x381b19(0x3f9)](this[_0x381b19(0x3e0)]['transform'][_0x381b19(0x3fa)], _0x3e587b, _0x25dcd7, _0x3e587b), this[_0x381b19(0x3e0)][_0x381b19(0x32a)][_0x381b19(0x3fa)] = _0x3e587b;
                            }
                        }
                    },
                    {
                        'key': _0x563048(0x3fb),
                        'value': function _0x22b4cc(_0x34d4f5) {
                            var _0x519974 = _0x563048;
                            if (!this[_0x519974(0x3ea)])
                                return;
                            var _0x519140 = this[_0x519974(0x3ea)]['getVelocity']();
                            _0x519140['x'] = 0x0, _0x519140['z'] = 0x0, _0x34d4f5 && (_0x519140['y'] = 0x0), this['rigidbody'][_0x519974(0x34d)](_0x519140);
                        }
                    },
                    {
                        'key': _0x563048(0x3d4),
                        'value': function _0x342a28(_0x245433) {
                            var _0x4d4d1f = _0x563048,
                                _0x1ef28f = this['rigidbody'][_0x4d4d1f(0x3f7)]();
                            _0x1ef28f['y'] = this['jumpSpeed'], _0x245433 && (_0x245433[_0x4d4d1f(0x330)](this[_0x4d4d1f(0x3e4)]), _0x1ef28f['x'] = _0x245433['x'], _0x1ef28f['z'] = _0x245433['z']), this[_0x4d4d1f(0x3ea)][_0x4d4d1f(0x34d)](_0x1ef28f);
                        }
                    },
                    {
                        'key': _0x563048(0x3d3),
                        'value': function _0x384303(_0x3bdf89) {
                            var _0x479079 = _0x563048,
                                _0x61f5d9 = arguments[_0x479079(0x27c)] > 0x1 && arguments[0x1] !== undefined ? arguments[0x1] : 0x1,
                                _0x3bdeb2 = arguments[_0x479079(0x27c)] > 0x2 && arguments[0x2] !== undefined ? arguments[0x2] : !0x0,
                                _0x1d8c56 = arguments[_0x479079(0x27c)] > 0x3 && arguments[0x3] !== undefined ? arguments[0x3] : !0x1;
                            this[_0x479079(0x3e1)] && (this[_0x479079(0x3fc)] != _0x3bdf89 || _0x1d8c56) && (this[_0x479079(0x3fc)] = _0x3bdf89, fx[_0x479079(0x1fb)][_0x479079(0x3fd)](this[_0x479079(0x3e1)], _0x3bdf89, _0x61f5d9, _0x3bdeb2));
                        }
                    },
                    {
                        'key': _0x563048(0x3fe),
                        'value': function _0x406ef9() {
                            var _0x6c77a1 = _0x563048;
                            if (!this[_0x6c77a1(0x3ea)])
                                return !0x1;
                            if (this[_0x6c77a1(0x3f2)][_0x6c77a1(0x3c5)]() == _0x25410a['Idle'])
                                return !0x1;
                            var _0x32131b = this[_0x6c77a1(0x3ea)][_0x6c77a1(0x3f7)]();
                            return !(_0x31f777[_0x6c77a1(0x34a)](_0x32131b) < 0.1);
                        }
                    },
                    {
                        'key': _0x563048(0x3ff),
                        'value': function _0x45844d() {
                            var _0x1ceac1 = _0x563048;
                            this['onDead'](), this[_0x1ceac1(0x3fb)](!0x0);
                        }
                    },
                    {
                        'key': _0x563048(0x400),
                        'value': function _0x4ed7dd() {
                            var _0x442c96 = _0x563048;
                            this['isDead'] || (this[_0x442c96(0x3f1)] = !0x0, this[_0x442c96(0x3d3)](_0x442c96(0x401), 0x1, !0x1, !0x0), _0x457d72['I'][_0x442c96(0x239)](), _0x29989c[_0x442c96(0x203)][_0x442c96(0x27d)](this[_0x442c96(0x3df)]));
                        }
                    }
                ]), _0x8577b3;
            }(Laya[_0x28eca3(0x326)]),
            _0x5bf357 = function(_0x1f9e9b) {
                var _0x1550d5 = _0x28eca3;
                _0x10ff6e(_0x37afdd, _0x1f9e9b);
                var _0x5f1ea8 = _0x30529b(_0x37afdd);

                function _0x37afdd() {
                    var _0x14a193 = _0x372d,
                        _0x3d6a7d;
                    return _0xaf4c50(this, _0x37afdd), (_0x3d6a7d = _0x5f1ea8[_0x14a193(0x1f4)](this, arguments), _0x3d6a7d['tempV3'] = new _0x31f777(), _0x3d6a7d[_0x14a193(0x402)] = new Laya['Quaternion'](), _0x3d6a7d[_0x14a193(0x403)] = 0x0, _0x3d6a7d[_0x14a193(0x404)] = 0.15), _0x3d6a7d;
                }
                return _0x3f3356(_0x37afdd, [{
                        'key': _0x1550d5(0x1fa),
                        'value': function _0x5e2983() {
                            var _0x3b74f5 = _0x1550d5;
                            _0x58adf2(_0x5a6184(_0x37afdd[_0x3b74f5(0x2e5)]), _0x3b74f5(0x1fa), this)[_0x3b74f5(0x1f7)](this), this[_0x3b74f5(0x405)] = this['owner'][_0x3b74f5(0x209)](_0x3b74f5(0x406)), this['cameraPivot']['getChildAt'](0x0)['addComponent'](_0x5f1a96)[_0x3b74f5(0x32b)](this[_0x3b74f5(0x1fe)]);
                        }
                    },
                    {
                        'key': 'init',
                        'value': function _0x34b762(_0x1d23d8) {
                            var _0x27a8e3 = _0x1550d5;
                            this['input'] = _0x1d23d8, this[_0x27a8e3(0x3f2)][_0x27a8e3(0x3d2)]['sound'] = !0x0;
                        }
                    },
                    {
                        'key': _0x1550d5(0x29c),
                        'value': function _0x5ed100() {
                            var _0x498140 = _0x1550d5;
                            this[_0x498140(0x403)] += this[_0x498140(0x2a4)][_0x498140(0x2c5)][_0x498140(0x2bf)]() * this['rotationSpeed'], this[_0x498140(0x405)]['transform']['localRotationEulerY'] = this['horizontalAngle'], Laya['Quaternion']['createFromAxisAngle'](_0x31f777['Up'], Math['PI'] * this['horizontalAngle'] / 0xb4, this[_0x498140(0x402)]), this[_0x498140(0x407)]['setValue'](this[_0x498140(0x2a4)][_0x498140(0x2c3)][_0x498140(0x2a4)]['x'], 0x0, this[_0x498140(0x2a4)][_0x498140(0x2c3)]['input']['y']), _0x31f777['transformQuat'](this[_0x498140(0x407)], this['tempRot'], this[_0x498140(0x407)]), this['fsm']['blackBorad'][_0x498140(0x2a4)][_0x498140(0x2b4)](this[_0x498140(0x407)]['x'], this['tempV3']['z']), this['checkGround'](), this[_0x498140(0x3da)] && this[_0x498140(0x2a4)][_0x498140(0x2c3)][_0x498140(0x3d4)] ? this[_0x498140(0x3f2)][_0x498140(0x3d2)]['jump'] = !0x0 : this[_0x498140(0x3f2)]['blackBorad'][_0x498140(0x3d4)] = !0x1, _0x58adf2(_0x5a6184(_0x37afdd[_0x498140(0x2e5)]), _0x498140(0x29c), this)[_0x498140(0x1f7)](this);
                        }
                    },
                    {
                        'key': _0x1550d5(0x400),
                        'value': function _0x39929c() {
                            var _0x3bf6eb = _0x1550d5;
                            _0x58adf2(_0x5a6184(_0x37afdd['prototype']), 'onDead', this)[_0x3bf6eb(0x1f7)](this), _0x29989c[_0x3bf6eb(0x203)][_0x3bf6eb(0x277)](_0x4d7387[_0x3bf6eb(0x1e7)]);
                        }
                    }
                ]), _0x37afdd;
            }(_0x500c49),
            _0x5edaf4 = function(_0xca0674) {
                var _0xd77387 = _0x28eca3;
                _0x10ff6e(_0x28c427, _0xca0674);
                var _0x2c0819 = _0x30529b(_0x28c427);

                function _0x28c427() {
                    var _0x3cc07f = _0x372d,
                        _0x54fd48;
                    return _0xaf4c50(this, _0x28c427), (_0x54fd48 = _0x2c0819[_0x3cc07f(0x1f4)](this, arguments), _0x54fd48[_0x3cc07f(0x284)] = 0x0), _0x54fd48;
                }
                return _0x3f3356(_0x28c427, [{
                        'key': _0xd77387(0x1fa),
                        'value': function _0x4f01e9() {
                            var _0x345de8 = _0xd77387;
                            this[_0x345de8(0x408)] = this['owner'];
                        }
                    },
                    {
                        'key': _0xd77387(0x409),
                        'value': function _0x4a6a75() {
                            var _0x533173 = _0xd77387;
                            this[_0x533173(0x284)] > 0x0 && (this[_0x533173(0x408)][_0x533173(0x210)] = fx[_0x533173(0x1fb)][_0x533173(0x29d)](0x3e8 * this[_0x533173(0x284)], {
                                'separator': [
                                    ':',
                                    ''
                                ],
                                'isAlign': !0x0
                            }), this[_0x533173(0x408)][_0x533173(0x40a)](0x3e8, this, this[_0x533173(0x40b)]));
                        }
                    },
                    {
                        'key': 'onInterval',
                        'value': function _0x3be925() {
                            var _0x44f5ff = _0xd77387,
                                _0x539146 = _0x29989c[_0x44f5ff(0x203)]['getGameState']();
                            if (_0x539146 == _0x4d7387['E_GAME_READY'])
                                return this[_0x44f5ff(0x284)]--, this[_0x44f5ff(0x408)]['text'] = fx['Utils'][_0x44f5ff(0x29d)](0x3e8 * this[_0x44f5ff(0x284)], {
                                    'separator': [
                                        ':',
                                        ''
                                    ],
                                    'isAlign': !0x0
                                }), fx[_0x44f5ff(0x202)][_0x44f5ff(0x203)][_0x44f5ff(0x204)](_0x44f5ff(0x40c)), void(this['duration'] <= 0x0 && _0x29989c[_0x44f5ff(0x203)]['setGameState'](_0x4d7387['E_GAME_START'])); -
                            0x1 != [
                                _0x4d7387[_0x44f5ff(0x1e7)],
                                _0x4d7387[_0x44f5ff(0x1e6)],
                                _0x4d7387['E_GAME_OVER']
                            ]['indexOf'](_0x539146) && (this[_0x44f5ff(0x408)]['clearTimer'](this, this[_0x44f5ff(0x40b)]), this[_0x44f5ff(0x40d)]());
                        }
                    }
                ]), _0x28c427;
            }(Laya['Script']),
            _0x57eff4 = function() {
                var _0x41e0a5 = _0x28eca3;

                function _0x5aea59() {
                    var _0xdaf93e = _0x372d;
                    _0xaf4c50(this, _0x5aea59), (this[_0xdaf93e(0x25f)] = [], this[_0xdaf93e(0x40e)] = 0x0, this[_0xdaf93e(0x40f)] = 0x0, this['boxReady'] = new Laya['BoundBox'](new _0x31f777(-28.77, 0x0, -17.25), new _0x31f777(27.77, 0x0, 4.1)), this[_0xdaf93e(0x410)] = new Laya[(_0xdaf93e(0x411))](new _0x31f777(-28.77, 0x0, -17.25), new _0x31f777(27.77, 0x0, 284.8)), this[_0xdaf93e(0x412)] = new Laya[(_0xdaf93e(0x411))](new _0x31f777(-28.77, 0x0, 264.82), new _0x31f777(27.77, 0x0, 284.8)));
                }
                return _0x3f3356(_0x5aea59, [{
                        'key': 'init',
                        'value': function _0x7143d() {
                            var _0x1e6bac = _0x372d;
                            this['gameTurn'] = 0x0, this[_0x1e6bac(0x25f)] = [], this[_0x1e6bac(0x286)] = _0x29989c[_0x1e6bac(0x203)][_0x1e6bac(0x286)], this[_0x1e6bac(0x413)] = !0x1;
                            var _0x3fa4ce = _0x29989c[_0x1e6bac(0x203)][_0x1e6bac(0x260)]()[_0x1e6bac(0x414)];
                            this[_0x1e6bac(0x40f)] = _0x3fa4ce[0x0] - _0x5aea59['I']['gameTurn'] * _0x3fa4ce[0x2], this[_0x1e6bac(0x40f)] = Math['max'](this[_0x1e6bac(0x40f)], _0x3fa4ce[0x1]);
                        }
                    },
                    {
                        'key': _0x41e0a5(0x415),
                        'value': function _0x1abfed(_0x100b51) {
                            var _0x365019 = _0x41e0a5;
                            this[_0x365019(0x416)] = _0x100b51;
                        }
                    },
                    {
                        'key': _0x41e0a5(0x417),
                        'value': function _0x5438f6() {
                            var _0x3a8483 = _0x41e0a5;
                            this[_0x3a8483(0x40e)]++;
                            var _0x412bb7 = _0x29989c['instance'][_0x3a8483(0x260)]()['WM_GameTime'];
                            this[_0x3a8483(0x40f)] = _0x412bb7[0x0] - _0x5aea59['I'][_0x3a8483(0x40e)] * _0x412bb7[0x2], this[_0x3a8483(0x40f)] = Math[_0x3a8483(0x28c)](this[_0x3a8483(0x40f)], _0x412bb7[0x1]), this[_0x3a8483(0x25f)] = [];
                        }
                    },
                    {
                        'key': _0x41e0a5(0x27a),
                        'value': function _0x2f37c6(_0xbcd548) {
                            var _0xd0abea = _0x41e0a5;
                            this[_0xd0abea(0x25f)][_0xd0abea(0x290)](_0xbcd548);
                        }
                    },
                    {
                        'key': _0x41e0a5(0x281),
                        'value': function _0x18ca6d() {
                            var _0x4f3792 = _0x41e0a5;
                            return this[_0x4f3792(0x25f)];
                        }
                    },
                    {
                        'key': _0x41e0a5(0x418),
                        'value': function _0x422a72() {
                            var _0x107157 = _0x41e0a5;
                            for (var _0x213112 = this['characters'][_0x107157(0x27c)] - 0x1; _0x213112 >= 0x0; --_0x213112) {
                                var _0x1f374c = this[_0x107157(0x25f)][_0x213112];
                                _0x1f374c['isDead'] || _0x1f374c[_0x107157(0x419)] || _0x1f374c[_0x107157(0x3fe)]() && _0x1f374c[_0x107157(0x41a)]();
                            }
                        }
                    },
                    {
                        'key': 'killNotArrived',
                        'value': function _0x35e8b5() {
                            var _0x4e8f8c = _0x41e0a5;
                            for (var _0x1f8c3e = this[_0x4e8f8c(0x25f)][_0x4e8f8c(0x27c)] - 0x1; _0x1f8c3e >= 0x0; --_0x1f8c3e) {
                                var _0x10798e = this[_0x4e8f8c(0x25f)][_0x1f8c3e];
                                _0x10798e['isDead'] || _0x10798e[_0x4e8f8c(0x419)] || _0x10798e[_0x4e8f8c(0x41a)]();
                            }
                        }
                    },
                    {
                        'key': _0x41e0a5(0x41b),
                        'value': function _0x113f5c() {
                            var _0xcdf8ab = _0x41e0a5;
                            for (var _0x2baba0 = this['characters'][_0xcdf8ab(0x27c)] - 0x1; _0x2baba0 >= 0x0; --_0x2baba0) {
                                var _0x445030 = this[_0xcdf8ab(0x25f)][_0x2baba0];
                                _0x445030[_0xcdf8ab(0x3f1)] || _0x445030[_0xcdf8ab(0x419)] || _0x445030[_0xcdf8ab(0x32a)][_0xcdf8ab(0x32d)]['z'] >= this[_0xcdf8ab(0x416)]['z'] && _0x445030[_0xcdf8ab(0x41c)]();
                            }
                        }
                    },
                    {
                        'key': _0x41e0a5(0x41d),
                        'value': function _0x38d6ed() {
                            var _0x16c2a4 = _0x41e0a5,
                                _0x35d44d = 0x0;
                            for (var _0x724abc = this[_0x16c2a4(0x25f)][_0x16c2a4(0x27c)] - 0x1; _0x724abc >= 0x0; --_0x724abc) {
                                var _0x43e171 = this['characters'][_0x724abc];
                                _0x43e171[_0x16c2a4(0x3f1)] || _0x43e171[_0x16c2a4(0x419)] || _0x35d44d++;
                            }
                            return _0x35d44d;
                        }
                    },
                    {
                        'key': _0x41e0a5(0x41e),
                        'value': function _0x4e3eb2() {
                            var _0x38f2fe = _0x41e0a5,
                                _0xee485e = 0x0;
                            for (var _0x2e7be8 = this['characters']['length'] - 0x1; _0x2e7be8 >= 0x0; --_0x2e7be8) {
                                var _0x244475 = this[_0x38f2fe(0x25f)][_0x2e7be8];
                                !_0x244475[_0x38f2fe(0x3f1)] && _0x244475['isArrived'] && _0xee485e++;
                            }
                            return _0xee485e;
                        }
                    }
                ], [{
                    'key': 'I',
                    'get': function _0x253260() {
                        var _0x371854 = _0x41e0a5;
                        return this[_0x371854(0x233)] || (this[_0x371854(0x233)] = new _0x5aea59()), this[_0x371854(0x233)];
                    }
                }]), _0x5aea59;
            }(),
            _0x3a0178 = function(_0x48191c) {
                var _0x1b1cde = _0x28eca3;
                _0x10ff6e(_0xdeb21e, _0x48191c);
                var _0x1e6663 = _0x30529b(_0xdeb21e);

                function _0xdeb21e() {
                    var _0x172630 = _0x372d,
                        _0x3604ef;
                    return _0xaf4c50(this, _0xdeb21e), (_0x3604ef = _0x1e6663[_0x172630(0x1f7)](this), _0x3604ef[_0x172630(0x41f)] = new _0x31f777(), _0x3604ef['velocity'] = new _0x31f777(), _0x3604ef['gravity'] = -9.8), _0x3604ef;
                }
                return _0x3f3356(_0xdeb21e, [{
                        'key': _0x1b1cde(0x41c),
                        'value': function _0x15e9ba() {
                            var _0x14ff07 = _0x1b1cde;
                            this['isArrived'] = !0x0, this[_0x14ff07(0x420)](_0x57eff4['I'][_0x14ff07(0x412)]);
                        }
                    },
                    {
                        'key': _0x1b1cde(0x41a),
                        'value': function _0x41a70a() {
                            var _0x1441c9 = _0x1b1cde;
                            this[_0x1441c9(0x3ff)]();
                        }
                    },
                    {
                        'key': _0x1b1cde(0x400),
                        'value': function _0x15274f() {
                            var _0x3541fb = _0x1b1cde,
                                _0x119479 = this,
                                _0x2d8220 = this[_0x3541fb(0x3e0)]['transform'][_0x3541fb(0x421)],
                                _0x16449b = _0x2d8220['clone']();
                            _0x16449b['z'] += 0x5, fx['Helper'][_0x3541fb(0x422)](this[_0x3541fb(0x3e0)], _0x2d8220, _0x16449b, 0x1, 0x0, !0x1, !0x0, Laya['Handler']['create'](this, function() {
                                var _0x442ab4 = _0x3541fb;
                                _0x119479[_0x442ab4(0x3e0)][_0x442ab4(0x240)] = !0x1;
                            })), _0x58adf2(_0x5a6184(_0xdeb21e['prototype']), _0x3541fb(0x400), this)['call'](this);
                        }
                    },
                    {
                        'key': _0x1b1cde(0x29c),
                        'value': function _0x29113d() {
                            var _0x3959eb = _0x1b1cde;
                            _0x58adf2(_0x5a6184(_0xdeb21e[_0x3959eb(0x2e5)]), _0x3959eb(0x29c), this)[_0x3959eb(0x1f7)](this);
                            var _0x593b41 = 0x10 / 0x3e8;
                            _0x593b41 = Math[_0x3959eb(0x360)](_0x593b41, 0.1);
                            var _0x232310 = this[_0x3959eb(0x41f)];
                            _0x232310['from'](this['transform'][_0x3959eb(0x32d)]), _0x232310['x'] += _0x593b41 * this[_0x3959eb(0x423)]['x'], _0x232310['x'] = Math[_0x3959eb(0x424)](_0x232310['x'], this[_0x3959eb(0x425)][_0x3959eb(0x360)]['x'], this[_0x3959eb(0x425)][_0x3959eb(0x28c)]['x']), _0x232310['z'] += _0x593b41 * this[_0x3959eb(0x423)]['z'], _0x232310['z'] = Math[_0x3959eb(0x424)](_0x232310['z'], this[_0x3959eb(0x425)][_0x3959eb(0x360)]['z'], this[_0x3959eb(0x425)][_0x3959eb(0x28c)]['z']), this[_0x3959eb(0x423)]['y'] += _0x593b41 * this[_0x3959eb(0x426)], _0x232310['y'] += _0x593b41 * this['velocity']['y'], _0x232310['y'] = Math['max'](_0x232310['y'], 0x0), 0x0 == _0x232310['y'] && (this[_0x3959eb(0x423)]['y'] = 0x0), _0x31f777[_0x3959eb(0x342)](_0x232310, this[_0x3959eb(0x32a)]['position']) > 0.01 ? this['isMoved'] = !0x0 : this[_0x3959eb(0x427)] = !0x1, this['transform']['position'] = _0x232310;
                        }
                    },
                    {
                        'key': _0x1b1cde(0x3e9),
                        'value': function _0x554c10() {}
                    },
                    {
                        'key': 'getVelocity',
                        'value': function _0x2ad964() {
                            return this['velocity'];
                        }
                    },
                    {
                        'key': _0x1b1cde(0x34d),
                        'value': function _0x1f9b57(_0x4e9391) {
                            var _0x12efe7 = _0x1b1cde;
                            this[_0x12efe7(0x423)][_0x12efe7(0x329)](_0x4e9391);
                        }
                    },
                    {
                        'key': _0x1b1cde(0x420),
                        'value': function _0x4175fe(_0x6235e3) {
                            var _0x210dd7 = _0x1b1cde;
                            this[_0x210dd7(0x425)] = _0x6235e3['clone']();
                        }
                    },
                    {
                        'key': 'move',
                        'value': function _0x46e711(_0x2393c4) {
                            var _0x431469 = _0x1b1cde;
                            this[_0x431469(0x34f)][_0x431469(0x329)](_0x2393c4), this[_0x431469(0x34f)][_0x431469(0x330)](this['moveSpeed']);
                            var _0x2240e3 = this['getVelocity']();
                            this[_0x431469(0x34f)]['y'] = _0x2240e3['y'], this[_0x431469(0x34d)](this['temp']), this[_0x431469(0x428)](_0x2393c4['x'], _0x2393c4['z'], 0.8);
                        }
                    },
                    {
                        'key': _0x1b1cde(0x3fb),
                        'value': function _0x494a56(_0x3936eb) {
                            var _0xc107ec = _0x1b1cde,
                                _0x57cea0 = this[_0xc107ec(0x3f7)]();
                            _0x57cea0['x'] = 0x0, _0x57cea0['z'] = 0x0, _0x3936eb && (_0x57cea0['y'] = 0x0), this[_0xc107ec(0x34d)](_0x57cea0);
                        }
                    },
                    {
                        'key': _0x1b1cde(0x3d4),
                        'value': function _0x1b01d3(_0x3fa689) {
                            var _0x46d651 = _0x1b1cde,
                                _0x4652e3 = this[_0x46d651(0x3f7)]();
                            _0x4652e3['y'] = this[_0x46d651(0x3e6)], _0x3fa689 && (_0x3fa689[_0x46d651(0x330)](this[_0x46d651(0x3e4)]), _0x4652e3['x'] = _0x3fa689['x'], _0x4652e3['z'] = _0x3fa689['z']), this[_0x46d651(0x34d)](_0x4652e3);
                        }
                    },
                    {
                        'key': _0x1b1cde(0x3fe),
                        'value': function _0x221b2a() {
                            var _0x492a63 = _0x1b1cde;
                            return this[_0x492a63(0x3f2)][_0x492a63(0x3c5)]() != _0x25410a[_0x492a63(0x3d0)];
                        }
                    },
                    {
                        'key': _0x1b1cde(0x3f3),
                        'value': function _0x474326() {
                            var _0xa884f0 = _0x1b1cde;
                            this[_0xa884f0(0x3da)] = this[_0xa884f0(0x32a)][_0xa884f0(0x32d)]['y'] <= 0.01;
                        }
                    }
                ]), _0xdeb21e;
            }(_0x500c49),
            _0x4f421e = function(_0x440987) {
                var _0x47195d = _0x28eca3;
                _0x10ff6e(_0x573365, _0x440987);
                var _0x2c572f = _0x30529b(_0x573365);

                function _0x573365() {
                    var _0x11eee4 = _0x372d,
                        _0x452b37;
                    return _0xaf4c50(this, _0x573365), (_0x452b37 = _0x2c572f[_0x11eee4(0x1f4)](this, arguments), _0x452b37[_0x11eee4(0x407)] = new _0x31f777(), _0x452b37['tempRot'] = new Laya['Quaternion'](), _0x452b37[_0x11eee4(0x403)] = 0x0, _0x452b37[_0x11eee4(0x404)] = 0.15), _0x452b37;
                }
                return _0x3f3356(_0x573365, [{
                        'key': 'onAwake',
                        'value': function _0x116234() {
                            var _0x205aa8 = _0x372d;
                            _0x58adf2(_0x5a6184(_0x573365[_0x205aa8(0x2e5)]), 'onAwake', this)['call'](this), this[_0x205aa8(0x405)] = this[_0x205aa8(0x1fe)][_0x205aa8(0x209)](_0x205aa8(0x406)), this[_0x205aa8(0x405)][_0x205aa8(0x429)](0x0)[_0x205aa8(0x367)](_0x5f1a96)[_0x205aa8(0x32b)](this[_0x205aa8(0x1fe)]);
                        }
                    },
                    {
                        'key': _0x47195d(0x270),
                        'value': function _0x1e1ccd(_0x16c645) {
                            var _0x56db31 = _0x47195d;
                            this[_0x56db31(0x2a4)] = _0x16c645, this[_0x56db31(0x3f2)][_0x56db31(0x3d2)]['sound'] = !0x0;
                        }
                    },
                    {
                        'key': _0x47195d(0x29c),
                        'value': function _0x21fda3() {
                            var _0x1ec0f7 = _0x47195d;
                            this[_0x1ec0f7(0x403)] += this[_0x1ec0f7(0x2a4)][_0x1ec0f7(0x2c5)][_0x1ec0f7(0x2bf)]() * this['rotationSpeed'], this[_0x1ec0f7(0x405)][_0x1ec0f7(0x32a)]['localRotationEulerY'] = this[_0x1ec0f7(0x403)], Laya[_0x1ec0f7(0x3f8)][_0x1ec0f7(0x42a)](_0x31f777['Up'], Math['PI'] * this['horizontalAngle'] / 0xb4, this[_0x1ec0f7(0x402)]), this[_0x1ec0f7(0x407)][_0x1ec0f7(0x2b4)](this['input'][_0x1ec0f7(0x2c3)]['input']['x'], 0x0, this[_0x1ec0f7(0x2a4)][_0x1ec0f7(0x2c3)][_0x1ec0f7(0x2a4)]['y']), _0x31f777[_0x1ec0f7(0x42b)](this[_0x1ec0f7(0x407)], this[_0x1ec0f7(0x402)], this[_0x1ec0f7(0x407)]), this[_0x1ec0f7(0x3f2)][_0x1ec0f7(0x3d2)][_0x1ec0f7(0x2a4)][_0x1ec0f7(0x2b4)](this['tempV3']['x'], this[_0x1ec0f7(0x407)]['z']), this['checkGround'](), this[_0x1ec0f7(0x3da)] && this[_0x1ec0f7(0x2a4)]['moveInput'][_0x1ec0f7(0x3d4)] ? this['fsm']['blackBorad'][_0x1ec0f7(0x3d4)] = !0x0 : this[_0x1ec0f7(0x3f2)]['blackBorad'][_0x1ec0f7(0x3d4)] = !0x1, _0x58adf2(_0x5a6184(_0x573365[_0x1ec0f7(0x2e5)]), 'onUpdate', this)[_0x1ec0f7(0x1f7)](this);
                        }
                    },
                    {
                        'key': _0x47195d(0x400),
                        'value': function _0xd5ce54() {
                            var _0x1629ed = _0x47195d;
                            _0x58adf2(_0x5a6184(_0x573365[_0x1629ed(0x2e5)]), _0x1629ed(0x400), this)['call'](this), _0x29989c[_0x1629ed(0x203)][_0x1629ed(0x277)](_0x4d7387[_0x1629ed(0x1e7)]);
                        }
                    },
                    {
                        'key': _0x47195d(0x41c),
                        'value': function _0x37cae3() {
                            var _0x1ae54c = _0x47195d;
                            _0x58adf2(_0x5a6184(_0x573365[_0x1ae54c(0x2e5)]), 'onArriveFinishLine', this)[_0x1ae54c(0x1f7)](this), fx[_0x1ae54c(0x202)][_0x1ae54c(0x203)][_0x1ae54c(0x204)](_0x1ae54c(0x42c));
                        }
                    }
                ]), _0x573365;
            }(_0x3a0178),
            _0xb09820 = {
                'MAP_WIDTH': 0x38
            },
            _0x1eeab8 = {
                'GHOST_FRONT': '$GHOST_FRONT',
                'GHOST_BACK': _0x28eca3(0x42d)
            },
            _0x36939e = function(_0x4cb70b) {
                var _0x542a90 = _0x28eca3;
                _0x10ff6e(_0x423f79, _0x4cb70b);
                var _0x1c3fb5 = _0x30529b(_0x423f79);

                function _0x423f79() {
                    var _0x454069 = _0x372d,
                        _0x412c04;
                    return _0xaf4c50(this, _0x423f79), (_0x412c04 = _0x1c3fb5[_0x454069(0x1f4)](this, arguments), _0x412c04['rotValue'] = void 0x0, _0x412c04[_0x454069(0x42e)] = 0x1, _0x412c04[_0x454069(0x42f)] = 0x0, _0x412c04[_0x454069(0x430)] = 0.225), _0x412c04;
                }
                return _0x3f3356(_0x423f79, [{
                        'key': _0x542a90(0x1fa),
                        'value': function _0x2319e5() {
                            var _0x46e6d5 = _0x542a90;
                            this[_0x46e6d5(0x3df)] = this['owner'], this['headSp'] = this[_0x46e6d5(0x1fe)][_0x46e6d5(0x209)](_0x46e6d5(0x431)), this[_0x46e6d5(0x432)] = _0x29989c[_0x46e6d5(0x203)]['getGameConstants']();
                        }
                    },
                    {
                        'key': _0x542a90(0x20c),
                        'value': function _0x1f05fd() {
                            var _0x22d9aa = _0x542a90;
                            this[_0x22d9aa(0x433)] && fx['SoundManager'][_0x22d9aa(0x203)][_0x22d9aa(0x20d)](this['curSoundUrl']);
                        }
                    },
                    {
                        'key': _0x542a90(0x29b),
                        'value': function _0x20136b() {
                            this['timestamp'] = 0x0, this['turnToBack']();
                        }
                    },
                    {
                        'key': _0x542a90(0x434),
                        'value': function _0xbea98() {
                            var _0x33a555 = _0x542a90;
                            if (_0x57eff4['I'][_0x33a555(0x413)])
                                return;
                            this[_0x33a555(0x435)][_0x33a555(0x32a)][_0x33a555(0x436)] = 0x0, this[_0x33a555(0x437)](0xb4);
                            var _0x2e233e = this['checkTime'](),
                                _0x3440c8 = this[_0x33a555(0x432)]['WM_GhostBackTime'][_0x2e233e];
                            this[_0x33a555(0x1fe)][_0x33a555(0x214)](0x3e8 * _0x3440c8, this, this[_0x33a555(0x438)]), this[_0x33a555(0x1fe)]['timerOnce'](0x3e8 * (_0x3440c8 + this[_0x33a555(0x430)]), this, this['startKill']);
                            var _0x276d82 = Math[_0x33a555(0x424)](_0x2e233e + 0x1, 0x1, 0x8);
                            this[_0x33a555(0x433)] = 'res/sound/ghost' [_0x33a555(0x296)](_0x276d82, _0x33a555(0x24e)), this['curSoundUrl'] = _0x457d72['I'][_0x33a555(0x24d)](this['curSoundUrl']), console[_0x33a555(0x3bc)]('' [_0x33a555(0x296)](_0x3440c8, '\x20\x20')[_0x33a555(0x296)](this[_0x33a555(0x433)])), fx['SoundManager']['instance'][_0x33a555(0x204)](this['curSoundUrl']), fx[_0x33a555(0x294)][_0x33a555(0x203)][_0x33a555(0x261)](_0x1eeab8['GHOST_BACK'], [_0x3440c8 + this[_0x33a555(0x430)]]);
                        }
                    },
                    {
                        'key': 'turnToFront',
                        'value': function _0x50436c() {
                            var _0x501e05 = _0x542a90;
                            _0x57eff4['I'][_0x501e05(0x413)] || (this[_0x501e05(0x435)][_0x501e05(0x32a)]['localRotationEulerY'] = 0xb4, this[_0x501e05(0x437)](0x0));
                        }
                    },
                    {
                        'key': _0x542a90(0x439),
                        'value': function _0x264338() {
                            var _0x2bad8e = _0x542a90,
                                _0x16fb0b = this;
                            if (_0x57eff4['I']['isFinish'])
                                return;
                            this[_0x2bad8e(0x43a)] = !0x0;
                            var _0x51cb07 = _0x29989c[_0x2bad8e(0x203)][_0x2bad8e(0x260)]()[_0x2bad8e(0x43b)];
                            fx[_0x2bad8e(0x294)][_0x2bad8e(0x203)][_0x2bad8e(0x261)](_0x1eeab8[_0x2bad8e(0x43c)], [_0x51cb07]), this[_0x2bad8e(0x1fe)][_0x2bad8e(0x214)](0x3e8 * _0x51cb07, this, function() {
                                var _0x169dfc = _0x2bad8e;
                                _0x16fb0b['killing'] = !0x1, _0x16fb0b[_0x169dfc(0x434)]();
                            });
                        }
                    },
                    {
                        'key': _0x542a90(0x437),
                        'value': function _0x40997c(_0x4ad5ba) {
                            var _0x5639b4 = _0x542a90;
                            fx[_0x5639b4(0x202)][_0x5639b4(0x203)][_0x5639b4(0x204)](_0x5639b4(0x43d)), this[_0x5639b4(0x43e)] = _0x4ad5ba, _0x4ad5ba > this[_0x5639b4(0x435)]['transform']['localRotationEulerY'] ? this[_0x5639b4(0x42e)] = 0x1 : this[_0x5639b4(0x42e)] = -0x1;
                        }
                    },
                    {
                        'key': _0x542a90(0x29c),
                        'value': function _0x15d323() {
                            var _0x2b6aa4 = _0x542a90;
                            if (_0x57eff4['I'][_0x2b6aa4(0x413)])
                                return;
                            var _0x130908 = 0x10 / 0x3e8;
                            if (this['timestamp'] += _0x130908, null != this[_0x2b6aa4(0x43e)]) {
                                var _0x435c56 = 0x10 / 0x3e8,
                                    _0x48d2eb = this[_0x2b6aa4(0x435)][_0x2b6aa4(0x32a)][_0x2b6aa4(0x436)] + 0x320 * _0x435c56 * this['rotDir'];
                                (_0x48d2eb = 0x1 == this[_0x2b6aa4(0x42e)] ? Math[_0x2b6aa4(0x360)](_0x48d2eb, this[_0x2b6aa4(0x43e)]) : Math[_0x2b6aa4(0x28c)](_0x48d2eb, this[_0x2b6aa4(0x43e)])) == this[_0x2b6aa4(0x43e)] && (this[_0x2b6aa4(0x43e)] = void 0x0), this[_0x2b6aa4(0x435)]['transform'][_0x2b6aa4(0x436)] = _0x48d2eb;
                            }
                            this[_0x2b6aa4(0x43a)] && _0x57eff4['I'][_0x2b6aa4(0x418)]();
                        }
                    },
                    {
                        'key': _0x542a90(0x43f),
                        'value': function _0x13543b() {
                            var _0x438846 = _0x542a90,
                                _0x1b8245 = _0x57eff4['I'][_0x438846(0x40f)] / 0x3,
                                _0x680a03 = Math['floor'](this[_0x438846(0x42f)] / _0x1b8245);
                            _0x680a03 = Math[_0x438846(0x360)](_0x680a03, this[_0x438846(0x432)][_0x438846(0x440)]['length'] - 0x1);
                            var _0x1cee3b = this[_0x438846(0x432)][_0x438846(0x440)][_0x680a03];
                            return _0x1cee3b[fx['Utils'][_0x438846(0x279)](0x0, _0x1cee3b['length'] - 0x1)] - 0x1;
                        }
                    }
                ]), _0x423f79;
            }(Laya[_0x28eca3(0x326)]),
            _0x50846c = function(_0x41f9ed) {
                var _0x4415cb = _0x28eca3;
                _0x10ff6e(_0x43d212, _0x41f9ed);
                var _0x494941 = _0x30529b(_0x43d212);

                function _0x43d212() {
                    var _0x43b22a = _0x372d,
                        _0x289f94;
                    return _0xaf4c50(this, _0x43d212), (_0x289f94 = _0x494941[_0x43b22a(0x1f4)](this, arguments), _0x289f94['input'] = new _0xdb1a4f(), _0x289f94[_0x43b22a(0x441)] = 0x0, _0x289f94[_0x43b22a(0x442)] = 0x0, _0x289f94['stayRate'] = 0x0, _0x289f94['jumpRate'] = 0x0, _0x289f94[_0x43b22a(0x443)] = !0x0, _0x289f94[_0x43b22a(0x42f)] = 0x0), _0x289f94;
                }
                return _0x3f3356(_0x43d212, [{
                        'key': _0x4415cb(0x1fa),
                        'value': function _0x181767() {
                            var _0x20d980 = _0x4415cb;
                            _0x58adf2(_0x5a6184(_0x43d212['prototype']), _0x20d980(0x1fa), this)[_0x20d980(0x1f7)](this), _0x457d72['I'][_0x20d980(0x23b)](this[_0x20d980(0x3df)]), fx[_0x20d980(0x294)]['instance']['on'](_0x1eeab8[_0x20d980(0x43c)], this, this['onGhostFront']), fx[_0x20d980(0x294)][_0x20d980(0x203)]['on'](_0x1eeab8[_0x20d980(0x444)], this, this['onGhostBack']);
                        }
                    },
                    {
                        'key': _0x4415cb(0x20c),
                        'value': function _0x16e386() {
                            var _0x4a7e87 = _0x4415cb;
                            fx[_0x4a7e87(0x294)][_0x4a7e87(0x203)][_0x4a7e87(0x295)](this);
                        }
                    },
                    {
                        'key': 'onUpdate',
                        'value': function _0x599102() {
                            var _0x75a7df = _0x4415cb,
                                _0x29fc20 = 0x10 / 0x3e8;
                            if (this['checkGround'](), this['free'] && (this[_0x75a7df(0x42f)] -= _0x29fc20, this[_0x75a7df(0x42f)] <= 0x0)) {
                                var _0x18cfa5 = fx[_0x75a7df(0x1fb)][_0x75a7df(0x245)](-0x1, 0x1),
                                    _0x41955f = fx[_0x75a7df(0x1fb)][_0x75a7df(0x245)](-0x1, 0x1);
                                this[_0x75a7df(0x2a4)][_0x75a7df(0x2b4)](_0x18cfa5, _0x41955f), this['timestamp'] = fx[_0x75a7df(0x1fb)][_0x75a7df(0x245)](0.5, 0x2), fx[_0x75a7df(0x1fb)]['randomByRate'](0.25) && (this['fsm'][_0x75a7df(0x3d2)][_0x75a7df(0x3d4)] = !0x0);
                            }
                            this[_0x75a7df(0x3f2)][_0x75a7df(0x3d2)]['input'][_0x75a7df(0x329)](this[_0x75a7df(0x2a4)]), _0x58adf2(_0x5a6184(_0x43d212[_0x75a7df(0x2e5)]), _0x75a7df(0x29c), this)[_0x75a7df(0x1f7)](this);
                        }
                    },
                    {
                        'key': 'onLateUpdate',
                        'value': function _0x130a77() {
                            var _0x174818 = _0x4415cb;
                            _0x58adf2(_0x5a6184(_0x43d212[_0x174818(0x2e5)]), _0x174818(0x2be), this)[_0x174818(0x1f7)](this), this[_0x174818(0x3f2)]['blackBorad']['jump'] = !0x1;
                        }
                    },
                    {
                        'key': _0x4415cb(0x445),
                        'value': function _0x550841(_0x1bd690) {
                            var _0xf8e28a = _0x4415cb;
                            if (!this['isArrived'] && !this[_0xf8e28a(0x3f1)] && fx[_0xf8e28a(0x1fb)][_0xf8e28a(0x23f)](this[_0xf8e28a(0x442)])) {
                                this[_0xf8e28a(0x1fe)]['clearTimer'](this, this[_0xf8e28a(0x446)]);
                                var _0x171b6c = _0x1bd690 * fx[_0xf8e28a(0x1fb)]['getNumberRandom'](0.1, 0x1);
                                this[_0xf8e28a(0x1fe)][_0xf8e28a(0x214)](0x3e8 * _0x171b6c, this, this[_0xf8e28a(0x446)]);
                            }
                        }
                    },
                    {
                        'key': _0x4415cb(0x447),
                        'value': function _0x88726b(_0x14819d) {
                            var _0x103e08 = _0x4415cb;
                            if (this['isArrived'] || this[_0x103e08(0x3f1)])
                                return;
                            this['owner'][_0x103e08(0x213)](this, this[_0x103e08(0x446)]), this[_0x103e08(0x1fe)]['clearTimer'](this, this['onStopInput']);
                            var _0x2f7f22 = _0x14819d,
                                _0x2af5bf = _0x14819d - (_0x2f7f22 = fx['Utils'][_0x103e08(0x23f)](this['positiveRate']) ? _0x14819d - fx[_0x103e08(0x1fb)][_0x103e08(0x245)](_0x14819d * this[_0x103e08(0x448)][0x0], _0x14819d * this[_0x103e08(0x448)][0x1]) : _0x14819d + fx['Utils'][_0x103e08(0x245)](0.1 * _0x14819d, 0.2 * _0x14819d));
                            if (_0x2af5bf > 0.1) {
                                var _0x3a0998 = _0x2af5bf * fx[_0x103e08(0x1fb)]['getNumberRandom'](0x0, 0x1);
                                this[_0x103e08(0x1fe)]['timerOnce'](0x3e8 * _0x3a0998, this, this[_0x103e08(0x446)]);
                            } else
                                this[_0x103e08(0x446)]();
                            this[_0x103e08(0x1fe)][_0x103e08(0x214)](0x3e8 * _0x2f7f22, this, this['onStopInput']);
                        }
                    },
                    {
                        'key': _0x4415cb(0x446),
                        'value': function _0x1acb53() {
                            var _0x42fecc = _0x4415cb;
                            if (!this[_0x42fecc(0x419)] && !this[_0x42fecc(0x3f1)]) {
                                if (this['canInput'] = !0x0, this['stayRate'] && fx[_0x42fecc(0x1fb)][_0x42fecc(0x23f)](this[_0x42fecc(0x449)]))
                                    this[_0x42fecc(0x2a4)][_0x42fecc(0x2b4)](0x0, 0x0);
                                else {
                                    if (this[_0x42fecc(0x441)] && fx['Utils'][_0x42fecc(0x23f)](this[_0x42fecc(0x441)])) {
                                        var _0xfe84b0 = fx[_0x42fecc(0x1fb)][_0x42fecc(0x245)](-0.5, 0.5);
                                        this['input'][_0x42fecc(0x2b4)](_0xfe84b0, -0x1);
                                    } else
                                        this[_0x42fecc(0x2a4)][_0x42fecc(0x2b4)](0x0, -0x1);
                                    this[_0x42fecc(0x44a)] && fx[_0x42fecc(0x1fb)][_0x42fecc(0x23f)](this[_0x42fecc(0x44a)]) && (this[_0x42fecc(0x3f2)]['blackBorad'][_0x42fecc(0x3d4)] = !0x0);
                                }
                            }
                        }
                    },
                    {
                        'key': 'onStopInput',
                        'value': function _0x520d39() {
                            var _0x144398 = _0x4415cb;
                            this[_0x144398(0x44b)] = !0x1, this[_0x144398(0x2a4)][_0x144398(0x2b4)](0x0, 0x0), this[_0x144398(0x3fb)]();
                        }
                    },
                    {
                        'key': 'onArriveFinishLine',
                        'value': function _0x5154e5() {
                            var _0x4cc15b = _0x4415cb;
                            _0x58adf2(_0x5a6184(_0x43d212[_0x4cc15b(0x2e5)]), _0x4cc15b(0x41c), this)[_0x4cc15b(0x1f7)](this), this['timestamp'] = fx[_0x4cc15b(0x1fb)][_0x4cc15b(0x245)](0x0, 0x1), this[_0x4cc15b(0x443)] = !0x0;
                        }
                    },
                    {
                        'key': _0x4415cb(0x44c),
                        'value': function _0x5485f8(_0x429359) {
                            var _0x558cdf = _0x4415cb,
                                _0x40ef5e = this,
                                _0x40a9e7 = fx[_0x558cdf(0x1fb)][_0x558cdf(0x245)](this['countdownRange'][0x0], this[_0x558cdf(0x44d)][0x1]);
                            this[_0x558cdf(0x1fe)]['timerOnce'](_0x429359 * _0x40a9e7 * 0x3e8, this, function() {
                                var _0x46f346 = _0x558cdf;
                                _0x40ef5e[_0x46f346(0x443)] = !0x1, _0x40ef5e['input'][_0x46f346(0x2b4)](0x0, -0x1);
                            });
                        }
                    }
                ]), _0x43d212;
            }(_0x3a0178),
            _0x46859c = function(_0x52e519) {
                var _0x187ffe = _0x28eca3;
                _0x10ff6e(_0x3d342c, _0x52e519);
                var _0x3ef13e = _0x30529b(_0x3d342c);

                function _0x3d342c(_0x1f29d3, _0x271d02) {
                    var _0x94bb30 = _0x372d,
                        _0x12c3da;
                    return _0xaf4c50(this, _0x3d342c), (_0x12c3da = _0x3ef13e[_0x94bb30(0x1f7)](this), _0x12c3da['cb'] = _0x271d02), _0x12c3da;
                }
                return _0x3f3356(_0x3d342c, [{
                        'key': _0x187ffe(0x44e),
                        'value': function _0x232240() {
                            var _0x5f39af = _0x187ffe,
                                _0xa40924 = this;
                            this[_0x5f39af(0x44f)]['on'](Laya['Event'][_0x5f39af(0x450)], this, function() {
                                var _0x8216f = _0x5f39af;
                                platform[_0x8216f(0x451)]()[_0x8216f(0x230)](() => {
                                    var _0x41a8e0 = _0x8216f;
                                    fx[_0x41a8e0(0x452)][_0x41a8e0(0x453)](_0xa40924);
                                });
                            }), this['btn_share']['on'](Laya[_0x5f39af(0x2ac)][_0x5f39af(0x450)], this, function() {
                                var _0x24f72f = _0x5f39af;
                                fx['Sdk'][_0x24f72f(0x203)][_0x24f72f(0x454)]();
                            }), _0x5e5c9b[_0x5f39af(0x203)][_0x5f39af(0x230)](), Laya['SoundManager'][_0x5f39af(0x455)](), Laya['SoundManager']['playSound'](_0x5f39af(0x456)), window[_0x5f39af(0x457)][_0x5f39af(0x20b)] = !![], platform[_0x5f39af(0x451)]()['closeLoading']();
                        }
                    },
                    {
                        'key': _0x187ffe(0x20c),
                        'value': function _0x5cfea4() {
                            var _0x51aee0 = _0x187ffe;
                            platform[_0x51aee0(0x451)]()[_0x51aee0(0x458)](), window[_0x51aee0(0x457)][_0x51aee0(0x20b)] = ![], (Laya[_0x51aee0(0x319)][_0x51aee0(0x459)](_0x51aee0(0x45a)), this['cb'] && this['cb']['run']());
                        }
                    }
                ]), _0x3d342c;
            }(_0x118985['scenes'][_0x28eca3(0x45b)]);
        Laya[_0x28eca3(0x266)][_0x28eca3(0x2e3)]('GameFailedDialog', _0x46859c);
        var _0x1270fb = function(_0x269856) {
                var _0x57f967 = _0x28eca3;
                _0x10ff6e(_0x58ad28, _0x269856);
                var _0x4240ea = _0x30529b(_0x58ad28);

                function _0x58ad28(_0x12e38a, _0x4907d7) {
                    var _0x3c155d = _0x372d,
                        _0x26fd52;
                    return _0xaf4c50(this, _0x58ad28), (_0x26fd52 = _0x4240ea[_0x3c155d(0x1f7)](this), _0x26fd52['shared'] = !0x1, _0x26fd52['cb'] = _0x4907d7), _0x26fd52;
                }
                return _0x3f3356(_0x58ad28, [{
                        'key': _0x57f967(0x44e),
                        'value': function _0x51b852() {
                            var _0x16ebfe = _0x57f967,
                                _0x2d1917 = this;
                            this[_0x16ebfe(0x45c)]['on'](Laya[_0x16ebfe(0x2ac)][_0x16ebfe(0x450)], this, this[_0x16ebfe(0x45d)]), this[_0x16ebfe(0x45e)]['on'](Laya[_0x16ebfe(0x2ac)]['CLICK'], this, this[_0x16ebfe(0x45f)]), this[_0x16ebfe(0x460)]['on'](Laya[_0x16ebfe(0x2ac)][_0x16ebfe(0x450)], this, this['onClickShare']), this[_0x16ebfe(0x461)]['on'](Laya[_0x16ebfe(0x2ac)][_0x16ebfe(0x450)], this, this[_0x16ebfe(0x45f)]), this[_0x16ebfe(0x45c)][_0x16ebfe(0x20b)] = !0x1, this['timer'][_0x16ebfe(0x39d)](0x7d0, this, this['showBtn']), this[_0x16ebfe(0x293)](), this[_0x16ebfe(0x462)][_0x16ebfe(0x20b)] = !0x1, this[_0x16ebfe(0x387)][_0x16ebfe(0x463)](this, function() {
                                var _0x1f3ff0 = _0x16ebfe;
                                _0x2d1917['img_root'][_0x1f3ff0(0x20b)] = !0x0, _0x2d1917[_0x1f3ff0(0x464)]();
                            }), fx['EventCenter'][_0x16ebfe(0x203)]['on'](_0x561c5d[_0x16ebfe(0x465)], this, this[_0x16ebfe(0x45d)]);
                        }
                    },
                    {
                        'key': _0x57f967(0x3cc),
                        'value': function _0x439a73() {
                            var _0x322300 = _0x57f967,
                                _0x158ed6 = this;
                            this['on'](fx[_0x322300(0x466)]['E_SHARE_RESULT'], this, function(_0x2c5d81) {
                                var _0x3d56e5 = _0x322300;
                                _0x2c5d81[_0x3d56e5(0x467)] == fx[_0x3d56e5(0x468)]['SHARE_SUCCESS'] ? (_0x158ed6[_0x3d56e5(0x469)] = !0x0, _0x158ed6[_0x3d56e5(0x46a)]()) : _0x2c5d81[_0x3d56e5(0x467)] == fx[_0x3d56e5(0x468)]['SHARE_FAILED'] && (_0x158ed6[_0x3d56e5(0x469)] = !0x1);
                            });
                        }
                    },
                    {
                        'key': 'onDestroy',
                        'value': function _0x15b2fd() {
                            var _0x32338c = _0x57f967;
                            fx[_0x32338c(0x294)][_0x32338c(0x203)]['offAllCaller'](this), this['screenTexture'] && this[_0x32338c(0x46b)]['destroy'](), this['cb'] && this['cb'][_0x32338c(0x215)]();
                        }
                    },
                    {
                        'key': _0x57f967(0x45d),
                        'value': function _0x4cf6ca() {
                            var _0x13b76d = _0x57f967;
                            fx[_0x13b76d(0x452)][_0x13b76d(0x453)](this);
                        }
                    },
                    {
                        'key': 'onClickShare',
                        'value': function _0x286346() {
                            var _0x5b29c1 = _0x57f967;
                            fx[_0x5b29c1(0x231)]['isOnPC']() ? this[_0x5b29c1(0x46a)]() : fx['Sdk'][_0x5b29c1(0x203)][_0x5b29c1(0x46c)]();
                        }
                    },
                    {
                        'key': _0x57f967(0x46d),
                        'value': function _0x17745d() {
                            var _0x1be8d6 = _0x57f967;
                            this['img_closeBtn'][_0x1be8d6(0x20b)] = !0x0;
                        }
                    },
                    {
                        'key': 'updateUI',
                        'value': function _0x4200ab() {
                            var _0x3b356c = _0x57f967;
                            this[_0x3b356c(0x46b)] = fx[_0x3b356c(0x3b4)][_0x3b356c(0x46e)](), this['img_screen'][_0x3b356c(0x46f)] = this[_0x3b356c(0x46b)];
                            var _0x5d6687 = Laya[_0x3b356c(0x2c6)][_0x3b356c(0x2ba)] / this[_0x3b356c(0x470)][_0x3b356c(0x2ba)];
                            this[_0x3b356c(0x470)][_0x3b356c(0x2a8)] = Laya[_0x3b356c(0x2c6)][_0x3b356c(0x2a8)] / _0x5d6687, this[_0x3b356c(0x470)]['height'] < this[_0x3b356c(0x471)]['height'] && (this['box_screen'][_0x3b356c(0x2a8)] = this['img_screen'][_0x3b356c(0x2a8)]), this[_0x3b356c(0x472)]['width'] = this['box_screen']['width'], this[_0x3b356c(0x472)][_0x3b356c(0x2a8)] = this[_0x3b356c(0x471)][_0x3b356c(0x2a8)], this[_0x3b356c(0x472)][_0x3b356c(0x20b)] = !0x1, this[_0x3b356c(0x471)][_0x3b356c(0x473)] = null, this[_0x3b356c(0x474)][_0x3b356c(0x2a8)] = this[_0x3b356c(0x471)][_0x3b356c(0x2a8)];
                        }
                    },
                    {
                        'key': _0x57f967(0x464),
                        'value': function _0xfa0226() {
                            var _0x61a497 = _0x57f967,
                                _0xb86609 = this,
                                _0x3b9f14 = Laya[_0x61a497(0x2c6)][_0x61a497(0x2ba)] / this[_0x61a497(0x470)]['width'];
                            this['img_screen'][_0x61a497(0x2bb)](_0x3b9f14, _0x3b9f14), (this[_0x61a497(0x471)][_0x61a497(0x2a8)], this[_0x61a497(0x470)][_0x61a497(0x2a8)]), (Laya['Tween']['to'](this['img_screen'], {
                                'scaleX': 0x1,
                                'scaleY': 0x1
                            }, 0x1f4, null, Laya[_0x61a497(0x324)][_0x61a497(0x325)](this, function() {
                                var _0x19b06b = _0x61a497;
                                _0xb86609[_0x19b06b(0x460)][_0x19b06b(0x20b)] = !0x0, _0xb86609[_0x19b06b(0x461)]['visible'] = !0x0, _0xb86609[_0x19b06b(0x472)][_0x19b06b(0x20b)] = !0x0, _0xb86609[_0x19b06b(0x471)]['mask'] = _0xb86609[_0x19b06b(0x472)];
                            })), fx['SoundManager'][_0x61a497(0x203)]['playSound'](_0xf611c3['SOUND_XIANGJI']));
                        }
                    },
                    {
                        'key': _0x57f967(0x46a),
                        'value': function _0x281016() {
                            this['onClickClose']();
                        }
                    }
                ]), _0x58ad28;
            }(_0x118985[_0x28eca3(0x2f2)]['shareGuide'][_0x28eca3(0x475)]),
            _0x3dffbb = function(_0x1ed03f) {
                var _0x511768 = _0x28eca3;
                _0x10ff6e(_0x222a1a, _0x1ed03f);
                var _0xcff84e = _0x30529b(_0x222a1a);

                function _0x222a1a(_0xd88ee, _0x41f6f4) {
                    var _0x5a71f2 = _0x372d,
                        _0x37e2d9;
                    return _0xaf4c50(this, _0x222a1a), (_0x37e2d9 = _0xcff84e[_0x5a71f2(0x1f7)](this), _0x37e2d9['cb'] = _0x41f6f4), _0x37e2d9;
                }
                return _0x3f3356(_0x222a1a, [{
                        'key': _0x511768(0x44e),
                        'value': function _0x133985() {
                            var _0x2f3efc = _0x511768,
                                _0x2ddf24 = this;
                            this[_0x2f3efc(0x44f)]['on'](Laya['Event'][_0x2f3efc(0x450)], this, function() {
                                var _0xb8c95a = _0x2f3efc;
                                platform[_0xb8c95a(0x451)]()[_0xb8c95a(0x230)](() => {
                                    var _0x3970df = _0xb8c95a;
                                    fx['SceneManager'][_0x3970df(0x453)](_0x2ddf24);
                                });
                            }), this[_0x2f3efc(0x45e)]['on'](Laya['Event'][_0x2f3efc(0x450)], this, function() {
                                var _0x14bd3a = _0x2f3efc;
                                fx['Sdk']['instance'][_0x14bd3a(0x454)]();
                            }), _0x5e5c9b['instance'][_0x2f3efc(0x230)](), Laya['SoundManager']['stopMusic'](), Laya[_0x2f3efc(0x202)][_0x2f3efc(0x204)](_0x2f3efc(0x476)), window[_0x2f3efc(0x457)]['visible'] = !![], platform[_0x2f3efc(0x451)]()['closeLoading']();
                        }
                    },
                    {
                        'key': _0x511768(0x20c),
                        'value': function _0x7261a4() {
                            var _0x1ff810 = _0x511768;
                            platform[_0x1ff810(0x451)]()[_0x1ff810(0x458)](), window[_0x1ff810(0x457)][_0x1ff810(0x20b)] = ![], (Laya['loader'][_0x1ff810(0x459)]('res/atlas/res/gameEnd.atlas'), this['cb'] && this['cb'][_0x1ff810(0x215)]());
                        }
                    }
                ]), _0x222a1a;
            }(_0x118985[_0x28eca3(0x2f2)][_0x28eca3(0x2ee)]),
            _0xb653ba = function(_0x3df460) {
                var _0x5d6882 = _0x28eca3;
                _0x10ff6e(_0x53b56a, _0x3df460);
                var _0x3c6cdf = _0x30529b(_0x53b56a);

                function _0x53b56a() {
                    var _0x1fcd9b = _0x372d,
                        _0x25aa63;
                    return _0xaf4c50(this, _0x53b56a), (_0x25aa63 = _0x3c6cdf[_0x1fcd9b(0x1f7)](this), _0x25aa63[_0x1fcd9b(0x477)] = 0x3), _0x25aa63;
                }
                return _0x3f3356(_0x53b56a, [{
                        'key': _0x5d6882(0x44e),
                        'value': function _0x4946da() {
                            var _0x4c14e1 = _0x5d6882;
                            _0x29989c[_0x4c14e1(0x203)][_0x4c14e1(0x270)](), _0x57eff4['I'][_0x4c14e1(0x270)]();
                            var _0x3a2c02 = Laya[_0x4c14e1(0x319)][_0x4c14e1(0x478)](_0x53b56a[_0x4c14e1(0x479)]);
                            this[_0x4c14e1(0x47a)] = _0x3a2c02, _0x3a2c02[_0x4c14e1(0x47b)](this['width'], this[_0x4c14e1(0x2a8)]), this[_0x4c14e1(0x47c)](_0x3a2c02, 0x0), _0x3a2c02[_0x4c14e1(0x367)](_0x39ee6f), (this['initUI'](), this['initPlayer'](), this[_0x4c14e1(0x47d)](), this['initRobots']());
                            var _0x4309dc = _0x57eff4['I'][_0x4c14e1(0x281)](),
                                _0x5dfbd0 = _0x523788(_0x4309dc),
                                _0x310c91;
                            try {
                                for (_0x5dfbd0['s'](); !(_0x310c91 = _0x5dfbd0['n']())[_0x4c14e1(0x288)];) {
                                    var _0x59ae28 = _0x310c91['value'];
                                    _0x59ae28[_0x4c14e1(0x420)](_0x57eff4['I'][_0x4c14e1(0x47e)]);
                                }
                            } catch (_0x1718e3) {
                                _0x5dfbd0['e'](_0x1718e3);
                            } finally {
                                _0x5dfbd0['f']();
                            }
                            _0x57eff4['I']['initTurn'](this[_0x4c14e1(0x47f)][_0x4c14e1(0x32a)][_0x4c14e1(0x32d)][_0x4c14e1(0x32e)]()), platform['getInstance']()[_0x4c14e1(0x480)]();
                        }
                    },
                    {
                        'key': _0x5d6882(0x20c),
                        'value': function _0x57acb4() {
                            var _0x1c686e = _0x5d6882;
                            fx[_0x1c686e(0x294)][_0x1c686e(0x203)][_0x1c686e(0x261)](_0x561c5d['E_CLOSE_ALL_PANEL']);
                        }
                    },
                    {
                        'key': _0x5d6882(0x481),
                        'value': function _0x770a1() {
                            var _0x3b201c = _0x5d6882;
                            this[_0x3b201c(0x482)] = this[_0x3b201c(0x483)][_0x3b201c(0x2c4)](_0xc00205), this[_0x3b201c(0x484)][_0x3b201c(0x20b)] = !0x1, this[_0x3b201c(0x485)] = this[_0x3b201c(0x486)][_0x3b201c(0x2c4)](_0x107110), this['gameCDScript'][_0x3b201c(0x487)](_0x29989c[_0x3b201c(0x203)]['getGameDuration']()), this['box_guide'][_0x3b201c(0x20b)] = this[_0x3b201c(0x488)]['visible'] = ![], !Laya['LocalStorage'][_0x3b201c(0x489)]('_firstGame') && Laya[_0x3b201c(0x2aa)][_0x3b201c(0x2ab)] ? (this['box_guide']['visible'] = this[_0x3b201c(0x488)]['visible'] = !![], Laya['LocalStorage'][_0x3b201c(0x48a)](_0x3b201c(0x48b), !![]), Laya[_0x3b201c(0x387)][_0x3b201c(0x39d)](0x1388, this, this[_0x3b201c(0x48c)])) : Laya['timer'][_0x3b201c(0x39d)](0x3e8, this, this[_0x3b201c(0x48c)]), this[_0x3b201c(0x48d)]['on'](Laya['Event'][_0x3b201c(0x450)], this, this[_0x3b201c(0x48e)]), console[_0x3b201c(0x3bc)](0x5be8b167172ab000000000);
                        }
                    },
                    {
                        'key': _0x5d6882(0x48e),
                        'value': function _0x30128e() {
                            var _0xf9b545 = _0x5d6882;
                            platform['getInstance']()[_0xf9b545(0x230)](() => {
                                var _0x552f79 = _0xf9b545;
                                fx[_0x552f79(0x452)][_0x552f79(0x40d)](this), platform['getInstance']()[_0x552f79(0x458)](), _0x29989c['instance']['goMain']();
                            });
                        }
                    },
                    {
                        'key': _0x5d6882(0x48f),
                        'value': function _0x33775d() {
                            var _0x45665b = _0x5d6882,
                                _0x4b4145 = this[_0x45665b(0x2a4)][_0x45665b(0x2c4)](_0x1a62ec),
                                _0x463386 = this[_0x45665b(0x47a)][_0x45665b(0x209)](_0x45665b(0x490)),
                                _0x504c58 = Laya['loader'][_0x45665b(0x31a)](_0xf611c3[_0x45665b(0x25a)])[_0x45665b(0x32e)]();
                            _0x463386[_0x45665b(0x3af)](_0x504c58), this[_0x45665b(0x491)] = _0x463386[_0x45665b(0x32e)]();
                            var _0x5eec6c = _0x463386[_0x45665b(0x367)](_0x4f421e);
                            _0x5eec6c[_0x45665b(0x270)](_0x4b4145), this[_0x45665b(0x492)] = _0x5eec6c, _0x57eff4['I'][_0x45665b(0x27a)](_0x5eec6c), this[_0x45665b(0x491)][_0x45665b(0x209)](_0x45665b(0x406))[_0x45665b(0x40d)]();
                        }
                    },
                    {
                        'key': _0x5d6882(0x47d),
                        'value': function _0x279da9() {
                            var _0x5ee55d = _0x5d6882,
                                _0xcb659a = this[_0x5ee55d(0x47a)][_0x5ee55d(0x209)]('Level');
                            this[_0x5ee55d(0x493)] = _0xcb659a[_0x5ee55d(0x209)]('StartBox'), this[_0x5ee55d(0x47f)] = _0xcb659a[_0x5ee55d(0x209)]('FinishBox');
                            var _0x39a475 = _0xcb659a[_0x5ee55d(0x209)](_0x5ee55d(0x494));
                            this[_0x5ee55d(0x495)] = _0x39a475[_0x5ee55d(0x367)](_0x36939e), this[_0x5ee55d(0x47a)][_0x5ee55d(0x209)](_0x5ee55d(0x496))[_0x5ee55d(0x240)] = !0x1;
                        }
                    },
                    {
                        'key': _0x5d6882(0x497),
                        'value': function _0x5dad03() {
                            var _0x150417 = _0x5d6882,
                                _0x33b252 = this[_0x150417(0x493)]['transform'][_0x150417(0x32d)],
                                _0x52b242 = _0x57eff4['I'][_0x150417(0x286)],
                                _0x1b5840 = Math[_0x150417(0x498)](0.1 * _0x52b242),
                                _0x3ff24e = _0x52b242 * fx[_0x150417(0x1fb)][_0x150417(0x245)](0.3, 0.4);
                            _0x3ff24e = Math['ceil'](_0x3ff24e);
                            for (var _0x55ec17 = 0x0; _0x55ec17 < _0x52b242; ++_0x55ec17) {
                                var _0x54c33d = this[_0x150417(0x491)]['clone']();
                                this[_0x150417(0x47a)]['addChild'](_0x54c33d);
                                var _0x2b9108 = fx[_0x150417(0x1fb)][_0x150417(0x245)](-_0xb09820[_0x150417(0x499)] / 0x2, _0xb09820[_0x150417(0x499)] / 0x2),
                                    _0x45740e = fx[_0x150417(0x1fb)][_0x150417(0x245)](_0x33b252['z'] - 0xa, _0x33b252['z'] - 0x3);
                                _0x54c33d[_0x150417(0x32a)][_0x150417(0x32d)] = new _0x31f777(_0x2b9108, 0x0, _0x45740e);
                                var _0x2b1caf = _0x54c33d['addComponent'](_0x50846c);
                                if (_0x55ec17 < _0x1b5840) {
                                    _0x2b1caf[_0x150417(0x49a)] = 0x1;
                                    var _0x2919d7 = fx[_0x150417(0x1fb)][_0x150417(0x245)](0.01, 0.1),
                                        _0x52d89e = fx['Utils']['getNumberRandom'](0.01, 0.1);
                                    _0x2b1caf[_0x150417(0x448)] = [
                                        Math['min'](_0x2919d7, _0x52d89e),
                                        Math[_0x150417(0x28c)](_0x2919d7, _0x52d89e)
                                    ], _0x2b1caf[_0x150417(0x441)] = 0x0, _0x2b1caf['countdownRange'] = [
                                        0x0,
                                        0x0
                                    ];
                                } else {
                                    if (_0x55ec17 < _0x3ff24e) {
                                        _0x2b1caf[_0x150417(0x49a)] = 0x1;
                                        var _0x2166c1 = fx['Utils'][_0x150417(0x245)](0.1, 0.2),
                                            _0x6b59f4 = fx['Utils'][_0x150417(0x245)](0.1, 0.2);
                                        _0x2b1caf[_0x150417(0x448)] = [
                                            Math['min'](_0x2166c1, _0x6b59f4),
                                            Math[_0x150417(0x28c)](_0x2166c1, _0x6b59f4)
                                        ], _0x2b1caf['changeDirRate'] = 0x0, _0x2b1caf[_0x150417(0x44d)] = [
                                            0.2,
                                            0.5
                                        ];
                                    } else {
                                        _0x2b1caf['positiveRate'] = fx['Utils'][_0x150417(0x245)](0.5, 0x1);
                                        var _0x3641a3 = fx['Utils'][_0x150417(0x245)](0.01, 0.2),
                                            _0x476114 = fx['Utils'][_0x150417(0x245)](0.01, 0.2);
                                        _0x2b1caf[_0x150417(0x448)] = [
                                            Math['min'](_0x3641a3, _0x476114),
                                            Math[_0x150417(0x28c)](_0x3641a3, _0x476114)
                                        ], _0x2b1caf[_0x150417(0x441)] = fx['Utils'][_0x150417(0x245)](0.5, 0x1), _0x2b1caf[_0x150417(0x442)] = fx[_0x150417(0x1fb)]['getNumberRandom'](0.1, 0.3), _0x2b1caf[_0x150417(0x449)] = fx['Utils'][_0x150417(0x245)](0.1, 0.3), _0x2b1caf[_0x150417(0x44a)] = fx[_0x150417(0x1fb)][_0x150417(0x245)](0.1, 0.3), _0x2b1caf[_0x150417(0x44d)] = [
                                            0.5,
                                            0.8
                                        ];
                                    }
                                }
                                _0x57eff4['I'][_0x150417(0x27a)](_0x2b1caf);
                            }
                        }
                    },
                    {
                        'key': _0x5d6882(0x3cc),
                        'value': function _0x200ffb() {
                            var _0x37f23a = _0x5d6882;
                            this['on'](_0x561c5d['E_GAME_STATE_CHANGED'], this, this[_0x37f23a(0x298)]), this[_0x37f23a(0x386)](0x1, this, this[_0x37f23a(0x3b8)]);
                        }
                    },
                    {
                        'key': 'onExit',
                        'value': function _0x70e80b() {
                            var _0x3ec90d = _0x5d6882;
                            this[_0x3ec90d(0x213)](this, this['update']);
                        }
                    },
                    {
                        'key': 'startCD',
                        'value': function _0x1ec1d5() {
                            var _0x17e5d0 = _0x5d6882,
                                _0x37cddd = _0x57eff4['I'][_0x17e5d0(0x281)](),
                                _0x15e260 = _0x523788(_0x37cddd),
                                _0x3f4513;
                            this[_0x17e5d0(0x49b)][_0x17e5d0(0x20b)] = this[_0x17e5d0(0x488)][_0x17e5d0(0x20b)] = ![];
                            try {
                                for (_0x15e260['s'](); !(_0x3f4513 = _0x15e260['n']())[_0x17e5d0(0x288)];) {
                                    var _0x512784 = _0x3f4513[_0x17e5d0(0x289)];
                                    _0x512784 instanceof _0x50846c && _0x512784[_0x17e5d0(0x44c)](this['countdown']);
                                }
                            } catch (_0x2c6c74) {
                                _0x15e260['e'](_0x2c6c74);
                            } finally {
                                _0x15e260['f']();
                            }
                            this[_0x17e5d0(0x482)][_0x17e5d0(0x29b)](this['countdown'], Laya[_0x17e5d0(0x324)][_0x17e5d0(0x325)](this, this['startGame']));
                        }
                    },
                    {
                        'key': _0x5d6882(0x49c),
                        'value': function _0x486d35() {
                            var _0x5519be = _0x5d6882;
                            _0x29989c[_0x5519be(0x203)][_0x5519be(0x277)](_0x4d7387[_0x5519be(0x1e4)]), _0x57eff4['I'][_0x5519be(0x413)] = !0x1, this['startBox']['destroy']();
                            var _0x610ac9 = _0x57eff4['I'][_0x5519be(0x281)](),
                                _0x4d482f = _0x523788(_0x610ac9),
                                _0xbe1b6a;
                            try {
                                for (_0x4d482f['s'](); !(_0xbe1b6a = _0x4d482f['n']())[_0x5519be(0x288)];) {
                                    var _0x43cffb = _0xbe1b6a['value'];
                                    _0x43cffb[_0x5519be(0x420)](_0x57eff4['I']['boxGaming']);
                                }
                            } catch (_0x19aa76) {
                                _0x4d482f['e'](_0x19aa76);
                            } finally {
                                _0x4d482f['f']();
                            }
                            this['ghostController'][_0x5519be(0x29b)](), this[_0x5519be(0x485)][_0x5519be(0x29b)](Laya['Handler'][_0x5519be(0x325)](this, this['onTimeIsUp']));
                        }
                    },
                    {
                        'key': _0x5d6882(0x49d),
                        'value': function _0x26eb87() {
                            var _0x2c9a22 = _0x5d6882;
                            _0x57eff4['I'][_0x2c9a22(0x413)] || (_0x57eff4['I'][_0x2c9a22(0x49e)](), _0x57eff4['I']['isFinish'] = !0x0, this['playerController'][_0x2c9a22(0x419)] && _0x29989c[_0x2c9a22(0x203)]['setGameState'](_0x4d7387['E_GAME_FINISH']));
                        }
                    },
                    {
                        'key': _0x5d6882(0x3b8),
                        'value': function _0x44ed5a() {
                            var _0x3ac433 = _0x5d6882;
                            _0x29989c['instance']['getGameState']() == _0x4d7387[_0x3ac433(0x1e3)] || _0x57eff4['I'][_0x3ac433(0x413)] || (_0x57eff4['I']['checkArrived'](), 0x0 == _0x57eff4['I'][_0x3ac433(0x41d)]() && (_0x57eff4['I'][_0x3ac433(0x413)] = !0x0, !this[_0x3ac433(0x492)][_0x3ac433(0x3f1)] && this[_0x3ac433(0x492)][_0x3ac433(0x419)] && _0x29989c[_0x3ac433(0x203)][_0x3ac433(0x277)](_0x4d7387[_0x3ac433(0x1e6)])));
                        }
                    },
                    {
                        'key': _0x5d6882(0x298),
                        'value': function _0x5d34f7(_0x55907a) {
                            var _0x48144f = _0x5d6882;
                            switch (_0x29989c['instance'][_0x48144f(0x264)]()) {
                                case _0x4d7387[_0x48144f(0x1e6)]:
                                    this[_0x48144f(0x49f)]();
                                    break;
                                case _0x4d7387['E_GAME_FAILED']:
                                    this[_0x48144f(0x4a0)]();
                                    break;
                                case _0x4d7387[_0x48144f(0x1e8)]:
                                    this['gameOver']();
                                    break;
                                case _0x4d7387[_0x48144f(0x1e5)]:
                                    break;
                                case _0x4d7387[_0x48144f(0x1e4)]:
                                    _0x55907a == _0x4d7387['E_GAME_FAILED'] ? this['revive']() : this[_0x48144f(0x29b)]();
                            }
                        }
                    },
                    {
                        'key': _0x5d6882(0x4a1),
                        'value': function _0x5d0acc(_0x5db9a8) {}
                    },
                    {
                        'key': _0x5d6882(0x4a2),
                        'value': function _0x4e9cdf(_0x33781c) {}
                    },
                    {
                        'key': _0x5d6882(0x4a3),
                        'value': function _0x55f613(_0x2a3d2b) {}
                    },
                    {
                        'key': 'start',
                        'value': function _0x1a08f9() {}
                    },
                    {
                        'key': _0x5d6882(0x49f),
                        'value': function _0x3a846e() {
                            var _0x242574 = _0x5d6882;
                            platform[_0x242574(0x451)]()[_0x242574(0x458)]();
                            var _0x3e409e = this,
                                _0x42c689 = _0x29989c[_0x242574(0x203)][_0x242574(0x280)]();
                            0x1 == _0x42c689 ? fx[_0x242574(0x452)][_0x242574(0x4a4)](_0x3dffbb, {
                                'from': '',
                                'userArgs': [Laya['Handler'][_0x242574(0x325)](_0x3e409e, function() {
                                    _0x29989c['instance']['goMain']();
                                })]
                            }) : (_0x29989c[_0x242574(0x203)][_0x242574(0x286)] = Math[_0x242574(0x28c)](_0x42c689 - 0x1, 0x1), _0x29989c['instance']['goNextStage'](), _0x29989c[_0x242574(0x203)][_0x242574(0x265)]()), fx[_0x242574(0x452)]['destroy'](this);
                        }
                    },
                    {
                        'key': _0x5d6882(0x4a0),
                        'value': function _0xb3869d() {
                            var _0xdee6b = _0x5d6882;
                            platform[_0xdee6b(0x451)]()[_0xdee6b(0x458)]();
                            var _0x7be33 = this;
                            _0x29989c[_0xdee6b(0x203)][_0xdee6b(0x278)](), fx[_0xdee6b(0x452)][_0xdee6b(0x4a4)](_0x46859c, {
                                'from': '',
                                'userArgs': [Laya[_0xdee6b(0x324)]['create'](this, function() {
                                    var _0x4b01f2 = _0xdee6b;
                                    _0x29989c[_0x4b01f2(0x203)][_0x4b01f2(0x265)]();
                                })]
                            }), fx['SceneManager']['destroy'](this);
                        }
                    },
                    {
                        'key': _0x5d6882(0x4a5),
                        'value': function _0x2926a5() {
                            var _0x2e00e7 = _0x5d6882;
                            this[_0x2e00e7(0x49b)]['visible'] = this[_0x2e00e7(0x488)][_0x2e00e7(0x20b)] = ![];
                            var _0x59aa4d = Laya[_0x2e00e7(0x266)][_0x2e00e7(0x267)](_0x2e00e7(0x268));
                            fx[_0x2e00e7(0x452)][_0x2e00e7(0x269)](_0x59aa4d);
                        }
                    },
                    {
                        'key': _0x5d6882(0x4a6),
                        'value': function _0x5d0023() {}
                    },
                    {
                        'key': _0x5d6882(0x276),
                        'value': function _0x26ca15() {}
                    },
                    {
                        'key': _0x5d6882(0x278),
                        'value': function _0x12a7e1() {}
                    }
                ], [{
                    'key': 'getRes',
                    'value': function _0x3d90cb() {
                        var _0x52dd7c = _0x5d6882;
                        return this['scenePath'] = _0x457d72['I']['formatScenePath'](_0x52dd7c(0x4a7)), [
                            this['scenePath'],
                            _0xf611c3[_0x52dd7c(0x4a8)],
                            _0xf611c3['PREFAB_CHARACTER']
                        ];
                    }
                }]), _0x53b56a;
            }(_0x118985['scenes'][_0x28eca3(0x2ec)]),
            _0x38bbfa = function() {
                var _0x972758 = _0x28eca3;

                function _0x18aa14() {
                    var _0x5d9039 = _0x372d;
                    _0xaf4c50(this, _0x18aa14), (this[_0x5d9039(0x25f)] = [], this[_0x5d9039(0x40e)] = 0x0, this['gameTime'] = 0x0, this[_0x5d9039(0x4a9)] = new _0x31f777());
                }
                return _0x3f3356(_0x18aa14, [{
                        'key': _0x972758(0x270),
                        'value': function _0x70c471() {
                            var _0x356926 = _0x972758;
                            this['characters'] = [], this['robotsCnt'] = _0x29989c[_0x356926(0x203)][_0x356926(0x286)];
                        }
                    },
                    {
                        'key': 'addCharacter',
                        'value': function _0x5b991b(_0x3cfaca) {
                            var _0x10f506 = _0x972758;
                            this['characters'][_0x10f506(0x290)](_0x3cfaca);
                        }
                    },
                    {
                        'key': _0x972758(0x281),
                        'value': function _0x52f81b() {
                            var _0x2dac5e = _0x972758;
                            return this[_0x2dac5e(0x25f)];
                        }
                    },
                    {
                        'key': _0x972758(0x49e),
                        'value': function _0x1bcd0b() {
                            var _0x3000e1 = _0x972758;
                            for (var _0x1f0f0e = this['characters']['length'] - 0x1; _0x1f0f0e >= 0x0; --_0x1f0f0e) {
                                var _0x54b68f = this[_0x3000e1(0x25f)][_0x1f0f0e];
                                _0x54b68f['isDead'] || _0x54b68f[_0x3000e1(0x419)] || _0x54b68f[_0x3000e1(0x3ff)]();
                            }
                        }
                    },
                    {
                        'key': 'getGamingCnt',
                        'value': function _0x1d59fd() {
                            var _0x436af3 = _0x972758,
                                _0xb9dc0d = 0x0;
                            for (var _0x37a627 = this['characters'][_0x436af3(0x27c)] - 0x1; _0x37a627 >= 0x0; --_0x37a627) {
                                var _0x266195 = this['characters'][_0x37a627];
                                _0x266195[_0x436af3(0x3f1)] || _0x266195['isArrived'] || _0xb9dc0d++;
                            }
                            return _0xb9dc0d;
                        }
                    },
                    {
                        'key': _0x972758(0x41e),
                        'value': function _0x22364f() {
                            var _0x5e7a38 = _0x972758,
                                _0x42e8e1 = 0x0;
                            for (var _0x438917 = this[_0x5e7a38(0x25f)][_0x5e7a38(0x27c)] - 0x1; _0x438917 >= 0x0; --_0x438917) {
                                var _0x4e9223 = this[_0x5e7a38(0x25f)][_0x438917];
                                !_0x4e9223[_0x5e7a38(0x3f1)] && _0x4e9223[_0x5e7a38(0x419)] && _0x42e8e1++;
                            }
                            return _0x42e8e1;
                        }
                    }
                ], [{
                    'key': 'I',
                    'get': function _0x5d6777() {
                        var _0x332bd6 = _0x972758;
                        return this[_0x332bd6(0x233)] || (this[_0x332bd6(0x233)] = new _0x18aa14()), this[_0x332bd6(0x233)];
                    }
                }]), _0x18aa14;
            }(),
            _0x31a692 = function(_0x42f8ca) {
                var _0x278dbe = _0x28eca3;
                _0x10ff6e(_0x15a335, _0x42f8ca);
                var _0x31ce51 = _0x30529b(_0x15a335);

                function _0x15a335() {
                    return _0xaf4c50(this, _0x15a335), _0x31ce51['apply'](this, arguments);
                }
                return _0x3f3356(_0x15a335, [{
                        'key': 'onAwake',
                        'value': function _0x29536f() {
                            var _0x5bb3c1 = _0x372d;
                            _0x58adf2(_0x5a6184(_0x15a335['prototype']), _0x5bb3c1(0x1fa), this)[_0x5bb3c1(0x1f7)](this);
                        }
                    },
                    {
                        'key': _0x278dbe(0x3e9),
                        'value': function _0xa6f44() {
                            var _0x4e5742 = _0x278dbe;
                            _0x58adf2(_0x5a6184(_0x15a335['prototype']), _0x4e5742(0x3e9), this)[_0x4e5742(0x1f7)](this), this['rigidbody'][_0x4e5742(0x4aa)] = _0x134368['ALL'] & ~_0x134368[_0x4e5742(0x1f0)];
                        }
                    },
                    {
                        'key': _0x278dbe(0x3ed),
                        'value': function _0x29c8a6(_0x338c84) {
                            var _0x3fbf84 = _0x278dbe;
                            _0x338c84[_0x3fbf84(0x4ab)][_0x3fbf84(0x2c4)](_0xdd3063)[_0x3fbf84(0x36c)] == _0x134368['FINISH_BOX'] && this[_0x3fbf84(0x41c)](_0x338c84['other']);
                        }
                    },
                    {
                        'key': _0x278dbe(0x41c),
                        'value': function _0x4d6e04(_0x38167c) {}
                    },
                    {
                        'key': _0x278dbe(0x4ac),
                        'value': function _0x232b10() {
                            var _0x37ed23 = _0x278dbe,
                                _0x8f3d25 = this[_0x37ed23(0x32a)]['position']['z'] >= _0x38bbfa['I'][_0x37ed23(0x4a9)]['z'];
                            if (this[_0x37ed23(0x4ad)] != _0x8f3d25) {
                                if (this[_0x37ed23(0x4ad)] = _0x8f3d25, this[_0x37ed23(0x4ad)]) {
                                    this['playAnim'](_0x37ed23(0x4ae), 0x1, !0x0, !0x0), this[_0x37ed23(0x3f2)][_0x37ed23(0x3d2)]['walk'] = !0x0;
                                    var _0x57f5e7 = _0x29989c['instance'][_0x37ed23(0x260)]();
                                    this[_0x37ed23(0x3e4)] = 0.65 * _0x57f5e7['MoveSpeed'];
                                } else {
                                    this['playAnim'](_0x37ed23(0x3dc), 0x1, !0x0, !0x0), this[_0x37ed23(0x3f2)][_0x37ed23(0x3d2)]['walk'] = !0x1;
                                    var _0x2ee480 = _0x29989c['instance'][_0x37ed23(0x260)]();
                                    this[_0x37ed23(0x3e4)] = _0x2ee480[_0x37ed23(0x3e5)];
                                }
                            }
                        }
                    },
                    {
                        'key': 'onUpdate',
                        'value': function _0x235b45() {
                            var _0x52ebfa = _0x278dbe;
                            this[_0x52ebfa(0x4ac)](), _0x58adf2(_0x5a6184(_0x15a335['prototype']), 'onUpdate', this)[_0x52ebfa(0x1f7)](this), this[_0x52ebfa(0x32a)][_0x52ebfa(0x32d)]['y'] < -0x5 && this[_0x52ebfa(0x400)]();
                        }
                    }
                ]), _0x15a335;
            }(_0x500c49),
            _0x16e6f6 = function(_0x153395) {
                var _0x2aea78 = _0x28eca3;
                _0x10ff6e(_0x2f71be, _0x153395);
                var _0x2937f4 = _0x30529b(_0x2f71be);

                function _0x2f71be() {
                    var _0x5a01fd = _0x372d,
                        _0x83ae1f;
                    return _0xaf4c50(this, _0x2f71be), (_0x83ae1f = _0x2937f4[_0x5a01fd(0x1f4)](this, arguments), _0x83ae1f[_0x5a01fd(0x407)] = new _0x31f777(), _0x83ae1f[_0x5a01fd(0x402)] = new Laya['Quaternion'](), _0x83ae1f[_0x5a01fd(0x403)] = 0x0, _0x83ae1f['rotationSpeed'] = 0.15), _0x83ae1f;
                }
                return _0x3f3356(_0x2f71be, [{
                        'key': _0x2aea78(0x1fa),
                        'value': function _0xe22bc6() {
                            var _0x2088db = _0x2aea78;
                            _0x58adf2(_0x5a6184(_0x2f71be['prototype']), _0x2088db(0x1fa), this)[_0x2088db(0x1f7)](this), this[_0x2088db(0x405)] = this[_0x2088db(0x1fe)][_0x2088db(0x209)](_0x2088db(0x406)), this[_0x2088db(0x405)][_0x2088db(0x429)](0x0)[_0x2088db(0x367)](_0x5f1a96)[_0x2088db(0x32b)](this[_0x2088db(0x1fe)]);
                        }
                    },
                    {
                        'key': _0x2aea78(0x270),
                        'value': function _0x33c54a(_0xbc70de) {
                            var _0xbb1c4a = _0x2aea78;
                            this[_0xbb1c4a(0x2a4)] = _0xbc70de, this['fsm'][_0xbb1c4a(0x3d2)][_0xbb1c4a(0x3d8)] = !0x0;
                        }
                    },
                    {
                        'key': _0x2aea78(0x29c),
                        'value': function _0x4b2f6d() {
                            var _0x226aff = _0x2aea78;
                            this[_0x226aff(0x403)] += this[_0x226aff(0x2a4)][_0x226aff(0x2c5)][_0x226aff(0x2bf)]() * this[_0x226aff(0x404)], this[_0x226aff(0x405)]['transform'][_0x226aff(0x436)] = this[_0x226aff(0x403)], Laya[_0x226aff(0x3f8)]['createFromAxisAngle'](_0x31f777['Up'], Math['PI'] * this['horizontalAngle'] / 0xb4, this[_0x226aff(0x402)]), this[_0x226aff(0x407)][_0x226aff(0x2b4)](this[_0x226aff(0x2a4)]['moveInput'][_0x226aff(0x2a4)]['x'], 0x0, this[_0x226aff(0x2a4)]['moveInput']['input']['y']), _0x31f777[_0x226aff(0x42b)](this['tempV3'], this['tempRot'], this['tempV3']), this['fsm'][_0x226aff(0x3d2)][_0x226aff(0x2a4)][_0x226aff(0x2b4)](this[_0x226aff(0x407)]['x'], this['tempV3']['z']), this[_0x226aff(0x3f3)](), this[_0x226aff(0x3da)] && this[_0x226aff(0x2a4)][_0x226aff(0x2c3)][_0x226aff(0x3d4)] ? this[_0x226aff(0x3f2)]['blackBorad']['jump'] = !0x0 : this['fsm'][_0x226aff(0x3d2)][_0x226aff(0x3d4)] = !0x1, _0x58adf2(_0x5a6184(_0x2f71be['prototype']), _0x226aff(0x29c), this)[_0x226aff(0x1f7)](this);
                        }
                    },
                    {
                        'key': _0x2aea78(0x400),
                        'value': function _0x4fab87() {
                            var _0x3d5d05 = _0x2aea78;
                            _0x58adf2(_0x5a6184(_0x2f71be[_0x3d5d05(0x2e5)]), 'onDead', this)[_0x3d5d05(0x1f7)](this), _0x29989c['instance'][_0x3d5d05(0x277)](_0x4d7387[_0x3d5d05(0x1e7)]);
                        }
                    },
                    {
                        'key': 'onArriveFinishLine',
                        'value': function _0x4ba126(_0x4cb7e4) {
                            var _0x22199e = _0x2aea78;
                            this[_0x22199e(0x419)] || (this[_0x22199e(0x419)] = !0x0, fx[_0x22199e(0x202)][_0x22199e(0x203)]['playSound'](_0x22199e(0x42c)));
                        }
                    }
                ]), _0x2f71be;
            }(_0x31a692),
            _0x16a449 = function(_0x7e0992) {
                var _0x1308de = _0x28eca3;
                _0x10ff6e(_0x395bd9, _0x7e0992);
                var _0x576c95 = _0x30529b(_0x395bd9);

                function _0x395bd9() {
                    var _0x2170cb = _0x372d,
                        _0xa350d3;
                    return _0xaf4c50(this, _0x395bd9), (_0xa350d3 = _0x576c95[_0x2170cb(0x1f4)](this, arguments), _0xa350d3[_0x2170cb(0x407)] = new _0x31f777(), _0xa350d3['input'] = new _0xdb1a4f(), _0xa350d3[_0x2170cb(0x4af)] = 0x0, _0xa350d3['nextchangeTime'] = 0x0, _0xa350d3['timestamp'] = 0x0, _0xa350d3[_0x2170cb(0x44d)] = [
                        0x0,
                        0x0
                    ], _0xa350d3[_0x2170cb(0x4b0)] = [
                        0x64,
                        0x64
                    ], _0xa350d3['stayRate'] = 0x0, _0xa350d3[_0x2170cb(0x4b1)] = [
                        0x0,
                        0x0
                    ], _0xa350d3[_0x2170cb(0x4b2)] = 0x0, _0xa350d3['changeDirRate'] = 0x0, _0xa350d3[_0x2170cb(0x4b3)] = 0x0, _0xa350d3[_0x2170cb(0x4b4)] = 0x0, _0xa350d3[_0x2170cb(0x443)] = !0x0), _0xa350d3;
                }
                return _0x3f3356(_0x395bd9, [{
                        'key': 'onAwake',
                        'value': function _0x346411() {
                            var _0x36d0eb = _0x372d;
                            _0x58adf2(_0x5a6184(_0x395bd9[_0x36d0eb(0x2e5)]), _0x36d0eb(0x1fa), this)['call'](this), this[_0x36d0eb(0x4b5)] = _0x38bbfa['I'][_0x36d0eb(0x4b5)], _0x457d72['I'][_0x36d0eb(0x23b)](this[_0x36d0eb(0x3df)]);
                        }
                    },
                    {
                        'key': _0x1308de(0x20c),
                        'value': function _0x12c6cd() {
                            var _0x3b1fa2 = _0x1308de;
                            fx[_0x3b1fa2(0x294)][_0x3b1fa2(0x203)][_0x3b1fa2(0x295)](this);
                        }
                    },
                    {
                        'key': 'onUpdate',
                        'value': function _0x18399d() {
                            var _0x165152 = _0x1308de,
                                _0x52d0e7 = 0x10 / 0x3e8;
                            if (this[_0x165152(0x3f3)](), this[_0x165152(0x419)])
                                this[_0x165152(0x4b6)]();
                            else {
                                if (this[_0x165152(0x443)]) {
                                    if (this[_0x165152(0x42f)] -= _0x52d0e7, this[_0x165152(0x42f)] <= 0x0) {
                                        var _0x57a772 = fx[_0x165152(0x1fb)][_0x165152(0x245)](-0x1, 0x1),
                                            _0x149ff4 = fx[_0x165152(0x1fb)][_0x165152(0x245)](-0x1, 0x1);
                                        this['input'][_0x165152(0x2b4)](_0x57a772, _0x149ff4), this[_0x165152(0x42f)] = fx[_0x165152(0x1fb)][_0x165152(0x245)](0.5, 0x2), fx[_0x165152(0x1fb)][_0x165152(0x23f)](0.25) && (this[_0x165152(0x3f2)][_0x165152(0x3d2)]['jump'] = !0x0);
                                    }
                                } else {
                                    if (this[_0x165152(0x4b4)] > 0x0) {
                                        if (this[_0x165152(0x4b4)] -= _0x52d0e7, this['timestamp'] -= _0x52d0e7, this['timestamp'] <= 0x0) {
                                            var _0x239bf6 = fx['Utils'][_0x165152(0x245)](-0x1, 0x1),
                                                _0x2db24b = fx[_0x165152(0x1fb)][_0x165152(0x245)](-0x1, 0x1);
                                            this[_0x165152(0x428)](_0x239bf6, _0x2db24b, 0x1), this['timestamp'] = fx['Utils']['getNumberRandom'](0.5, 0x2), fx[_0x165152(0x1fb)][_0x165152(0x23f)](0.5) && (this[_0x165152(0x3f2)][_0x165152(0x3d2)][_0x165152(0x3d4)] = !0x0);
                                        }
                                        this[_0x165152(0x2a4)][_0x165152(0x2b4)](0x0, 0x0);
                                    } else
                                        this[_0x165152(0x4b7)] || this['moveToPoint'](this[_0x165152(0x4af)]);
                                }
                            }
                            this[_0x165152(0x3f2)]['blackBorad'][_0x165152(0x2a4)][_0x165152(0x329)](this[_0x165152(0x2a4)]), _0x58adf2(_0x5a6184(_0x395bd9['prototype']), _0x165152(0x29c), this)[_0x165152(0x1f7)](this);
                        }
                    },
                    {
                        'key': 'onLateUpdate',
                        'value': function _0x2c9178() {
                            var _0x22e153 = _0x1308de;
                            _0x58adf2(_0x5a6184(_0x395bd9[_0x22e153(0x2e5)]), _0x22e153(0x2be), this)[_0x22e153(0x1f7)](this), this[_0x22e153(0x3f2)][_0x22e153(0x3d2)][_0x22e153(0x3d4)] = !0x1;
                        }
                    },
                    {
                        'key': _0x1308de(0x4b6),
                        'value': function _0x1fb195() {
                            var _0x24ee37 = _0x1308de;
                            if (this['input'][_0x24ee37(0x2b4)](0x0, 0x0), this[_0x24ee37(0x4b8)]) {
                                var _0x441d8e = this[_0x24ee37(0x32a)]['position'];
                                Math[_0x24ee37(0x4b9)](this[_0x24ee37(0x4b8)]['x'] - _0x441d8e['x']) < 0.2 && Math['abs'](this[_0x24ee37(0x4b8)]['z'] - _0x441d8e['z']) < 0.2 ? (this[_0x24ee37(0x4b8)] = null, this['stopMove']()) : this[_0x24ee37(0x2a4)][_0x24ee37(0x2b4)](_0x441d8e['x'] - this['targetPos']['x'], _0x441d8e['z'] - this[_0x24ee37(0x4b8)]['z']);
                            }
                        }
                    },
                    {
                        'key': 'changeBehavior',
                        'value': function _0x589c96() {
                            var _0x282a50 = _0x1308de,
                                _0x431ac1 = this[_0x282a50(0x1fe)]['timer'][_0x282a50(0x4ba)] / 0x3e8;
                            if (this[_0x282a50(0x4bb)] = _0x431ac1 + fx[_0x282a50(0x1fb)][_0x282a50(0x245)](this[_0x282a50(0x4b0)][0x0], this[_0x282a50(0x4b0)][0x1]), fx[_0x282a50(0x1fb)]['randomByRate'](this[_0x282a50(0x449)]))
                                this['stayTime'] = fx['Utils']['getNumberRandom'](this[_0x282a50(0x4b1)][0x0], this[_0x282a50(0x4b1)][0x1]), this['stopMove']();
                            else {
                                if (fx['Utils'][_0x282a50(0x23f)](this[_0x282a50(0x4b2)]))
                                    this[_0x282a50(0x4bc)]();
                                else {
                                    if (fx['Utils'][_0x282a50(0x23f)](this['changeDirRate'])) {
                                        this['isChangedDir'] = !0x0;
                                        var _0x36768e = fx[_0x282a50(0x1fb)][_0x282a50(0x245)](-0x1, 0x1),
                                            _0xb36f8c = fx[_0x282a50(0x1fb)][_0x282a50(0x245)](-0x1, 0x1);
                                        this['input'][_0x282a50(0x2b4)](_0x36768e, _0xb36f8c);
                                    }
                                }
                            }
                        }
                    },
                    {
                        'key': _0x1308de(0x4bc),
                        'value': function _0x5d06ed() {
                            var _0x23cda0 = _0x1308de;
                            this[_0x23cda0(0x4af)] = Math[_0x23cda0(0x424)](this[_0x23cda0(0x4af)] - 0x1, 0x0, this[_0x23cda0(0x4b5)]['length'] - 0x1);
                        }
                    },
                    {
                        'key': _0x1308de(0x4bd),
                        'value': function _0x139579() {
                            var _0x31b4de = _0x1308de;
                            this['targetPoint'] = Math[_0x31b4de(0x424)](this['targetPoint'] + 0x1, 0x0, this['points']['length'] - 0x1);
                        }
                    },
                    {
                        'key': _0x1308de(0x4be),
                        'value': function _0x86a63e(_0x1bff20) {
                            var _0x5f0760 = _0x1308de,
                                _0x2762fa = this[_0x5f0760(0x1fe)]['timer'][_0x5f0760(0x4ba)] / 0x3e8,
                                _0x2f4b75 = this[_0x5f0760(0x4b5)][_0x1bff20]['transform'][_0x5f0760(0x32d)],
                                _0x40f166 = this[_0x5f0760(0x32a)][_0x5f0760(0x32d)];
                            Math[_0x5f0760(0x4b9)](_0x2f4b75['x'] - _0x40f166['x']) < 0.2 && Math[_0x5f0760(0x4b9)](_0x2f4b75['z'] - _0x40f166['z']) < 0.2 ? (0x0 == this[_0x5f0760(0x4af)] && (this[_0x5f0760(0x4bf)] = !0x0), this['input'][_0x5f0760(0x2b4)](0x0, 0x0), this[_0x5f0760(0x3fb)](), this[_0x5f0760(0x4bd)](), this['changeBehavior']()) : (this[_0x5f0760(0x2a4)]['setValue'](_0x40f166['x'] - _0x2f4b75['x'], _0x40f166['z'] - _0x2f4b75['z']), this[_0x5f0760(0x4bb)] && this[_0x5f0760(0x4bb)] <= _0x2762fa && this[_0x5f0760(0x4c0)]());
                        }
                    },
                    {
                        'key': _0x1308de(0x44c),
                        'value': function _0x11d96a(_0x5e8bf1) {
                            var _0x50dc3a = _0x1308de,
                                _0x32a2bc = this,
                                _0x42620a = fx['Utils'][_0x50dc3a(0x245)](this[_0x50dc3a(0x44d)][0x0], this[_0x50dc3a(0x44d)][0x1]);
                            this[_0x50dc3a(0x1fe)][_0x50dc3a(0x214)](_0x5e8bf1 * _0x42620a * 0x3e8, this, function() {
                                var _0x4245da = _0x50dc3a;
                                if (_0x32a2bc[_0x4245da(0x443)] = !0x1, _0x32a2bc[_0x4245da(0x4af)] = 0x0, fx[_0x4245da(0x1fb)][_0x4245da(0x23f)](_0x32a2bc[_0x4245da(0x4b3)])) {
                                    _0x32a2bc[_0x4245da(0x443)] = !0x0;
                                    var _0xcf094 = 0x3e8 * fx[_0x4245da(0x1fb)][_0x4245da(0x245)](0x3, 0xa);
                                    fx['Utils'][_0x4245da(0x23f)](0.05) && (_0xcf094 *= 0x2), _0x32a2bc[_0x4245da(0x1fe)][_0x4245da(0x214)](_0xcf094, _0x32a2bc, function() {
                                        _0x32a2bc['free'] = !0x1;
                                    });
                                }
                            });
                        }
                    },
                    {
                        'key': 'onDead',
                        'value': function _0x5f495e() {
                            var _0x420ad2 = _0x1308de,
                                _0x5718d2 = this;
                            _0x58adf2(_0x5a6184(_0x395bd9[_0x420ad2(0x2e5)]), _0x420ad2(0x400), this)['call'](this), this[_0x420ad2(0x3df)][_0x420ad2(0x214)](0x7d0, this, function() {
                                var _0x2ea01c = _0x420ad2;
                                _0x5718d2[_0x2ea01c(0x3df)][_0x2ea01c(0x40d)]();
                            }), _0x38bbfa['I'][_0x420ad2(0x286)]--;
                        }
                    },
                    {
                        'key': _0x1308de(0x41c),
                        'value': function _0x5e1a71(_0xc64e0f) {
                            var _0xba7a1d = _0x1308de;
                            if (this[_0xba7a1d(0x419)])
                                return;
                            this[_0xba7a1d(0x419)] = !0x0, this[_0xba7a1d(0x3fb)]();
                            var _0x4c0f5f = _0xc64e0f['transform'][_0xba7a1d(0x32d)][_0xba7a1d(0x32e)]();
                            _0x4c0f5f['x'] += fx[_0xba7a1d(0x1fb)][_0xba7a1d(0x245)](-0x1, 0x1), _0x4c0f5f['y'] += 0.5, _0x4c0f5f['z'] += fx['Utils']['getNumberRandom'](-0x1, 0x1), this[_0xba7a1d(0x4b8)] = _0x4c0f5f;
                        }
                    }
                ]), _0x395bd9;
            }(_0x31a692),
            _0x254a93 = function(_0x4cf321) {
                var _0x5b193a = _0x28eca3;
                _0x10ff6e(_0x48a5c4, _0x4cf321);
                var _0x5557af = _0x30529b(_0x48a5c4);

                function _0x48a5c4() {
                    var _0x54e722 = _0x372d,
                        _0x18755c;
                    return _0xaf4c50(this, _0x48a5c4), (_0x18755c = _0x5557af['call'](this), _0x18755c[_0x54e722(0x477)] = 0x5), _0x18755c;
                }
                return _0x3f3356(_0x48a5c4, [{
                        'key': _0x5b193a(0x44e),
                        'value': function _0x1e95b4() {
                            var _0x717b2d = _0x5b193a;
                            _0x29989c[_0x717b2d(0x203)]['init'](), _0x38bbfa['I'][_0x717b2d(0x270)]();
                            var _0x22599a = Laya[_0x717b2d(0x319)][_0x717b2d(0x478)](_0x48a5c4[_0x717b2d(0x479)]);
                            this[_0x717b2d(0x47a)] = _0x22599a, _0x22599a[_0x717b2d(0x47b)](this[_0x717b2d(0x2ba)], this[_0x717b2d(0x2a8)]), this[_0x717b2d(0x47c)](_0x22599a, 0x0), _0x22599a[_0x717b2d(0x367)](_0x39ee6f), (this[_0x717b2d(0x481)](), this[_0x717b2d(0x48f)](), this[_0x717b2d(0x47d)](), this[_0x717b2d(0x497)]()), this[_0x717b2d(0x49b)][_0x717b2d(0x20b)] = this[_0x717b2d(0x488)][_0x717b2d(0x20b)] = ![], !Laya[_0x717b2d(0x4c1)][_0x717b2d(0x489)]('_firstGame') && Laya[_0x717b2d(0x2aa)][_0x717b2d(0x2ab)] ? (this[_0x717b2d(0x49b)][_0x717b2d(0x20b)] = this['spr_guide']['visible'] = !![], Laya[_0x717b2d(0x4c1)][_0x717b2d(0x48a)](_0x717b2d(0x48b), !![]), Laya['timer'][_0x717b2d(0x39d)](0x1388, this, this[_0x717b2d(0x48c)])) : Laya[_0x717b2d(0x387)]['once'](0x3e8, this, this['startCD']), platform[_0x717b2d(0x451)]()[_0x717b2d(0x480)]();
                        }
                    },
                    {
                        'key': _0x5b193a(0x20c),
                        'value': function _0x3e9aa4() {
                            var _0x2791c2 = _0x5b193a;
                            fx['EventCenter'][_0x2791c2(0x203)][_0x2791c2(0x261)](_0x561c5d['E_CLOSE_ALL_PANEL']);
                        }
                    },
                    {
                        'key': 'initUI',
                        'value': function _0x106831() {
                            var _0x73b8a1 = _0x5b193a;
                            this[_0x73b8a1(0x482)] = this['box_cd']['getComponent'](_0xc00205), this['box_nextTurnTips']['visible'] = !0x1, this[_0x73b8a1(0x485)] = this[_0x73b8a1(0x486)][_0x73b8a1(0x2c4)](_0x107110), this[_0x73b8a1(0x485)][_0x73b8a1(0x487)](_0x29989c['instance'][_0x73b8a1(0x283)]()), this['btn_home']['on'](Laya[_0x73b8a1(0x2ac)]['CLICK'], this, this[_0x73b8a1(0x48e)]), console[_0x73b8a1(0x3bc)](0x5be8b167172ab000000000);
                        }
                    },
                    {
                        'key': _0x5b193a(0x48e),
                        'value': function _0x494605() {
                            var _0x1063b2 = _0x5b193a;
                            platform[_0x1063b2(0x451)]()['showInterstitial'](() => {
                                var _0x2df29f = _0x1063b2;
                                fx[_0x2df29f(0x452)][_0x2df29f(0x40d)](this), platform['getInstance']()[_0x2df29f(0x458)](), _0x29989c[_0x2df29f(0x203)][_0x2df29f(0x265)]();
                            });
                        }
                    },
                    {
                        'key': 'initPlayer',
                        'value': function _0x39d712() {
                            var _0x1fd645 = _0x5b193a,
                                _0x21210b = this[_0x1fd645(0x2a4)]['getComponent'](_0x1a62ec),
                                _0x3c422b = this['scene3d']['getChildByName'](_0x1fd645(0x490)),
                                _0x5e3d29 = Laya[_0x1fd645(0x319)][_0x1fd645(0x31a)](_0xf611c3[_0x1fd645(0x25a)])[_0x1fd645(0x32e)]();
                            _0x3c422b['addChild'](_0x5e3d29), this[_0x1fd645(0x491)] = _0x3c422b[_0x1fd645(0x32e)]();
                            var _0xfb6c0d = _0x3c422b[_0x1fd645(0x367)](_0x16e6f6);
                            _0xfb6c0d['init'](_0x21210b), this[_0x1fd645(0x492)] = _0xfb6c0d, _0x38bbfa['I'][_0x1fd645(0x27a)](_0xfb6c0d), this[_0x1fd645(0x491)][_0x1fd645(0x209)](_0x1fd645(0x406))['destroy']();
                        }
                    },
                    {
                        'key': 'initLevel',
                        'value': function _0x8bd9b6() {
                            var _0x457e79 = _0x5b193a,
                                _0x44bae4 = this[_0x457e79(0x47a)]['getChildByName'](_0x457e79(0x4c2)),
                                _0x21bb4c = _0x44bae4[_0x457e79(0x209)](_0x457e79(0x4c3));
                            fx[_0x457e79(0x1fb)][_0x457e79(0x4c4)](_0x21bb4c, function(_0x22a1f0) {
                                _0x20256e['initStaticCollider'](_0x22a1f0, _0x134368['STATIC']);
                            }), this[_0x457e79(0x493)] = _0x44bae4[_0x457e79(0x209)]('StartBox'), _0x20256e[_0x457e79(0x4c5)](this[_0x457e79(0x493)], _0x134368['STATIC']), _0x38bbfa['I'][_0x457e79(0x4a9)] = this[_0x457e79(0x493)][_0x457e79(0x32a)]['position']['clone']();
                            var _0x4a0d30 = _0x44bae4[_0x457e79(0x209)]('road')[_0x457e79(0x4c6)](),
                                _0x475b38 = fx['Utils'][_0x457e79(0x279)](0x0, _0x4a0d30[_0x457e79(0x27c)] - 0x1);
                            for (var _0x382e29 = 0x0; _0x382e29 < _0x4a0d30[_0x457e79(0x27c)]; ++_0x382e29) {
                                _0x4a0d30[_0x382e29][_0x457e79(0x240)] = _0x382e29 == _0x475b38;
                            }
                            var _0x3cf5e1 = _0x4a0d30[_0x475b38];
                            fx[_0x457e79(0x1fb)][_0x457e79(0x4c4)](_0x3cf5e1, function(_0x5f186f) {
                                var _0x2f2309 = _0x457e79;
                                'end' == _0x5f186f['name'] ? _0x20256e[_0x2f2309(0x4c5)](_0x5f186f, _0x134368['FINISH_BOX']) : _0x20256e[_0x2f2309(0x4c5)](_0x5f186f, _0x134368[_0x2f2309(0x1ef)]);
                            }), _0x38bbfa['I'][_0x457e79(0x4b5)] = _0x3cf5e1[_0x457e79(0x4c7)](_0x457e79(0x4c8));
                        }
                    },
                    {
                        'key': _0x5b193a(0x497),
                        'value': function _0x3fe0a7() {
                            var _0xfa8b94 = _0x5b193a,
                                _0x113b67 = this[_0xfa8b94(0x492)][_0xfa8b94(0x32a)]['position'],
                                _0x4e7d47 = _0x38bbfa['I'][_0xfa8b94(0x286)],
                                _0xe891a5 = fx[_0xfa8b94(0x4c9)][_0xfa8b94(0x203)][_0xfa8b94(0x253)](_0xfa8b94(0x4ca)),
                                _0x2b350f = [];
                            for (var _0x363a63 in _0xe891a5) {
                                _0xe891a5[_0x363a63][_0xfa8b94(0x1f6)] = Math['ceil'](_0xe891a5[_0x363a63]['cntPercent'] * _0x4e7d47), _0x2b350f[_0xfa8b94(0x290)](_0xe891a5[_0x363a63]);
                            }
                            var _0x215658 = function _0x57f6e1(_0x285970) {
                                var _0x53dc52 = _0xfa8b94;
                                for (var _0x2acb83 = 0x0; _0x2acb83 < _0x2b350f['length']; ++_0x2acb83) {
                                    if (_0x285970 < _0x2b350f[_0x2acb83][_0x53dc52(0x1f6)])
                                        return _0x2b350f[_0x2acb83];
                                }
                            };
                            for (var _0x1b6d85 = 0x0; _0x1b6d85 < _0x4e7d47; ++_0x1b6d85) {
                                var _0x1ec9a8 = this[_0xfa8b94(0x491)]['clone']();
                                this[_0xfa8b94(0x47a)][_0xfa8b94(0x3af)](_0x1ec9a8);
                                var _0x2284e7 = _0x113b67['x'] + fx[_0xfa8b94(0x1fb)]['getNumberRandom'](-0xa, 0xa),
                                    _0x25505e = _0x113b67['z'] - fx['Utils'][_0xfa8b94(0x245)](-0xa, 0x14);
                                _0x1ec9a8[_0xfa8b94(0x32a)]['position'] = new _0x31f777(_0x2284e7, 0x0, _0x25505e);
                                var _0x587740 = _0x1ec9a8[_0xfa8b94(0x367)](_0x16a449);
                                _0x38bbfa['I']['addCharacter'](_0x587740);
                                var _0x4cea6d = _0x215658(_0x1b6d85);
                                _0x587740[_0xfa8b94(0x44d)] = _0x4cea6d['countdownRange']['slice'](), _0x587740[_0xfa8b94(0x4b0)] = _0x4cea6d[_0xfa8b94(0x4b0)][_0xfa8b94(0x4cb)](), _0x587740[_0xfa8b94(0x449)] = _0x4cea6d['stayRate'], _0x587740[_0xfa8b94(0x4b1)] = _0x4cea6d[_0xfa8b94(0x4b1)][_0xfa8b94(0x4cb)](), _0x587740[_0xfa8b94(0x4b2)] = _0x4cea6d[_0xfa8b94(0x4b2)], _0x587740[_0xfa8b94(0x441)] = _0x4cea6d['changeDirRate'], _0x587740[_0xfa8b94(0x4b3)] = fx[_0xfa8b94(0x1fb)][_0xfa8b94(0x245)](_0x4cea6d[_0xfa8b94(0x4b3)][0x0], _0x4cea6d[_0xfa8b94(0x4b3)][0x1]);
                            }
                        }
                    },
                    {
                        'key': 'onEnter',
                        'value': function _0x2fac7e() {
                            var _0x31773b = _0x5b193a;
                            this['on'](_0x561c5d['E_GAME_STATE_CHANGED'], this, this[_0x31773b(0x298)]), this['frameLoop'](0x1, this, this['update']);
                        }
                    },
                    {
                        'key': _0x5b193a(0x3c2),
                        'value': function _0x3ada37() {
                            var _0x3c2e52 = _0x5b193a;
                            this[_0x3c2e52(0x213)](this, this[_0x3c2e52(0x3b8)]);
                        }
                    },
                    {
                        'key': _0x5b193a(0x48c),
                        'value': function _0x56ad2e() {
                            var _0x5e0a37 = _0x5b193a;
                            this[_0x5e0a37(0x49b)][_0x5e0a37(0x20b)] = this[_0x5e0a37(0x488)][_0x5e0a37(0x20b)] = ![];
                            var _0x3f4230 = _0x38bbfa['I'][_0x5e0a37(0x281)](),
                                _0x5ed8a5 = _0x523788(_0x3f4230),
                                _0x39c1d9;
                            try {
                                for (_0x5ed8a5['s'](); !(_0x39c1d9 = _0x5ed8a5['n']())[_0x5e0a37(0x288)];) {
                                    var _0x17ee2a = _0x39c1d9[_0x5e0a37(0x289)];
                                    _0x17ee2a instanceof _0x16a449 && _0x17ee2a[_0x5e0a37(0x44c)](this[_0x5e0a37(0x477)]);
                                }
                            } catch (_0xea337f) {
                                _0x5ed8a5['e'](_0xea337f);
                            } finally {
                                _0x5ed8a5['f']();
                            }
                            this[_0x5e0a37(0x482)]['start'](this['countdown'], Laya['Handler'][_0x5e0a37(0x325)](this, this[_0x5e0a37(0x49c)]));
                        }
                    },
                    {
                        'key': _0x5b193a(0x49c),
                        'value': function _0x2dbc5e() {
                            var _0xbd2b75 = _0x5b193a;
                            this[_0xbd2b75(0x49b)]['visible'] = this['spr_guide'][_0xbd2b75(0x20b)] = ![], (_0x29989c[_0xbd2b75(0x203)]['setGameState'](_0x4d7387['E_GAME_START']), _0x38bbfa['I']['isFinish'] = !0x1, this[_0xbd2b75(0x493)][_0xbd2b75(0x40d)](), this['gameCDScript'][_0xbd2b75(0x29b)](Laya['Handler'][_0xbd2b75(0x325)](this, this[_0xbd2b75(0x49d)])));
                        }
                    },
                    {
                        'key': _0x5b193a(0x49d),
                        'value': function _0x5a29b3() {
                            var _0x58d36d = _0x5b193a;
                            _0x38bbfa['I'][_0x58d36d(0x413)] || (_0x38bbfa['I'][_0x58d36d(0x49e)](), _0x38bbfa['I'][_0x58d36d(0x413)] = !0x0, this[_0x58d36d(0x492)][_0x58d36d(0x419)] && _0x29989c['instance'][_0x58d36d(0x277)](_0x4d7387['E_GAME_FINISH']));
                        }
                    },
                    {
                        'key': _0x5b193a(0x3b8),
                        'value': function _0x3a4b6b() {
                            var _0x2b971d = _0x5b193a;
                            _0x29989c[_0x2b971d(0x203)][_0x2b971d(0x264)]() == _0x4d7387[_0x2b971d(0x1e3)] || _0x38bbfa['I'][_0x2b971d(0x413)] || 0x0 == _0x38bbfa['I'][_0x2b971d(0x41d)]() && (_0x38bbfa['I'][_0x2b971d(0x413)] = !0x0, !this[_0x2b971d(0x492)][_0x2b971d(0x3f1)] && this[_0x2b971d(0x492)][_0x2b971d(0x419)] && _0x29989c[_0x2b971d(0x203)][_0x2b971d(0x277)](_0x4d7387[_0x2b971d(0x1e6)]));
                        }
                    },
                    {
                        'key': _0x5b193a(0x298),
                        'value': function _0x3c4cfc(_0x2d003c) {
                            var _0x5821f2 = _0x5b193a;
                            switch (_0x29989c[_0x5821f2(0x203)][_0x5821f2(0x264)]()) {
                                case _0x4d7387[_0x5821f2(0x1e6)]:
                                    this[_0x5821f2(0x49f)]();
                                    break;
                                case _0x4d7387[_0x5821f2(0x1e7)]:
                                    this[_0x5821f2(0x4a0)]();
                                    break;
                                case _0x4d7387['E_GAME_OVER']:
                                    this[_0x5821f2(0x4a6)]();
                                    break;
                                case _0x4d7387['E_GAME_PAUSE']:
                                    break;
                                case _0x4d7387[_0x5821f2(0x1e4)]:
                                    _0x2d003c == _0x4d7387[_0x5821f2(0x1e7)] ? this[_0x5821f2(0x276)]() : this[_0x5821f2(0x29b)]();
                            }
                        }
                    },
                    {
                        'key': 'onMouseDown',
                        'value': function _0x5ef37f(_0x59e930) {}
                    },
                    {
                        'key': 'onMouseMove',
                        'value': function _0x483ede(_0x50cc25) {}
                    },
                    {
                        'key': 'onMouseUp',
                        'value': function _0x5ca713(_0xb75b08) {}
                    },
                    {
                        'key': _0x5b193a(0x29b),
                        'value': function _0x575284() {}
                    },
                    {
                        'key': _0x5b193a(0x49f),
                        'value': function _0x3ceea6() {
                            var _0x1f02f4 = _0x5b193a;
                            platform[_0x1f02f4(0x451)]()[_0x1f02f4(0x458)]();
                            var _0x520571 = this,
                                _0x7546b1 = _0x29989c[_0x1f02f4(0x203)][_0x1f02f4(0x280)]();
                            0x1 == _0x7546b1 ? (_0x29989c[_0x1f02f4(0x203)][_0x1f02f4(0x278)](), fx[_0x1f02f4(0x452)][_0x1f02f4(0x4a4)](_0x3dffbb, {
                                'from': '',
                                'userArgs': [Laya[_0x1f02f4(0x324)][_0x1f02f4(0x325)](_0x520571, function() {
                                    var _0x254465 = _0x1f02f4;
                                    _0x29989c[_0x254465(0x203)]['goMain']();
                                })]
                            })) : (_0x29989c['instance'][_0x1f02f4(0x286)] = Math[_0x1f02f4(0x28c)](_0x7546b1 - 0x1, 0x1), _0x29989c[_0x1f02f4(0x203)][_0x1f02f4(0x26c)](), _0x29989c['instance'][_0x1f02f4(0x265)]()), fx[_0x1f02f4(0x452)][_0x1f02f4(0x40d)](this);
                        }
                    },
                    {
                        'key': _0x5b193a(0x4a0),
                        'value': function _0x1a918e() {
                            var _0x37a0d9 = _0x5b193a;
                            platform['getInstance']()[_0x37a0d9(0x458)]();
                            var _0x505fde = this;
                            _0x29989c[_0x37a0d9(0x203)][_0x37a0d9(0x278)](), fx[_0x37a0d9(0x452)][_0x37a0d9(0x4a4)](_0x46859c, {
                                'from': '',
                                'userArgs': [Laya['Handler'][_0x37a0d9(0x325)](this, function() {
                                    var _0x56bf93 = _0x37a0d9;
                                    _0x505fde[_0x56bf93(0x4a5)]();
                                })]
                            }), fx[_0x37a0d9(0x452)][_0x37a0d9(0x40d)](this);
                        }
                    },
                    {
                        'key': _0x5b193a(0x4a5),
                        'value': function _0x199b79() {
                            var _0x4ee2a8 = _0x5b193a;
                            this[_0x4ee2a8(0x49b)]['visible'] = this[_0x4ee2a8(0x488)][_0x4ee2a8(0x20b)] = ![];
                            var _0x52f497 = Laya[_0x4ee2a8(0x266)][_0x4ee2a8(0x267)](_0x4ee2a8(0x268));
                            fx[_0x4ee2a8(0x452)][_0x4ee2a8(0x269)](_0x52f497);
                        }
                    },
                    {
                        'key': 'gameOver',
                        'value': function _0x1fb8ce() {}
                    },
                    {
                        'key': _0x5b193a(0x276),
                        'value': function _0xc1a3fd() {}
                    },
                    {
                        'key': _0x5b193a(0x278),
                        'value': function _0x34f69c() {}
                    }
                ], [{
                    'key': _0x5b193a(0x31a),
                    'value': function _0x4212e6() {
                        var _0xfbdee7 = _0x5b193a;
                        return this[_0xfbdee7(0x479)] = _0x457d72['I'][_0xfbdee7(0x249)](_0xfbdee7(0x4cc)), [
                            this['scenePath'],
                            _0xf611c3[_0xfbdee7(0x4a8)],
                            _0xf611c3[_0xfbdee7(0x25a)]
                        ];
                    }
                }]), _0x48a5c4;
            }(_0x118985['scenes'][_0x28eca3(0x2ec)]);
        Laya[_0x28eca3(0x266)][_0x28eca3(0x2e3)]('WirewalkingScene', _0x254a93);
        var _0x4d230e = function(_0x374de0) {
                var _0x50bc1d = _0x28eca3;
                _0x10ff6e(_0x230e46, _0x374de0);
                var _0x457a70 = _0x30529b(_0x230e46);

                function _0x230e46() {
                    var _0x5f2997 = _0x372d,
                        _0x207610;
                    return _0xaf4c50(this, _0x230e46), (_0x207610 = _0x457a70[_0x5f2997(0x1f4)](this, arguments), _0x207610[_0x5f2997(0x4cd)] = !0x0, _0x207610['_marbleNum'] = 0xa), _0x207610;
                }
                return _0x3f3356(_0x230e46, [{
                        'key': 'marbleNum',
                        'get': function _0x3e59d0() {
                            var _0x117b0f = _0x372d;
                            return this[_0x117b0f(0x4ce)];
                        },
                        'set': function _0x3016fc(_0x52f464) {
                            var _0x5148fb = _0x372d;
                            this[_0x5148fb(0x4ce)] = _0x52f464;
                        }
                    },
                    {
                        'key': _0x50bc1d(0x20c),
                        'value': function _0x245117() {
                            var _0x1e6f7b = _0x50bc1d;
                            fx[_0x1e6f7b(0x294)][_0x1e6f7b(0x203)][_0x1e6f7b(0x295)](this);
                        }
                    },
                    {
                        'key': 'onUpdate',
                        'value': function _0x5136a2() {
                            var _0x1042bf = _0x50bc1d;
                            _0x58adf2(_0x5a6184(_0x230e46[_0x1042bf(0x2e5)]), _0x1042bf(0x29c), this)[_0x1042bf(0x1f7)](this);
                        }
                    },
                    {
                        'key': _0x50bc1d(0x2be),
                        'value': function _0x141291() {
                            var _0x3148bb = _0x50bc1d;
                            _0x58adf2(_0x5a6184(_0x230e46['prototype']), _0x3148bb(0x2be), this)[_0x3148bb(0x1f7)](this);
                        }
                    }
                ]), _0x230e46;
            }(_0x500c49),
            _0x316784 = function(_0x257183) {
                var _0x3174b5 = _0x28eca3;
                _0x10ff6e(_0x1863f2, _0x257183);
                var _0xea7e8d = _0x30529b(_0x1863f2);

                function _0x1863f2() {
                    var _0x3740fa = _0x372d,
                        _0x40d17e;
                    return _0xaf4c50(this, _0x1863f2), (_0x40d17e = _0xea7e8d[_0x3740fa(0x1f4)](this, arguments), _0x40d17e[_0x3740fa(0x407)] = new _0x31f777(), _0x40d17e['tempRot'] = new Laya[(_0x3740fa(0x3f8))](), _0x40d17e[_0x3740fa(0x403)] = 0x0, _0x40d17e['rotationSpeed'] = 0.15), _0x40d17e;
                }
                return _0x3f3356(_0x1863f2, [{
                        'key': _0x3174b5(0x1fa),
                        'value': function _0x328158() {
                            var _0x50c70e = _0x3174b5;
                            this[_0x50c70e(0x4cd)] = !0x1, _0x58adf2(_0x5a6184(_0x1863f2[_0x50c70e(0x2e5)]), _0x50c70e(0x1fa), this)[_0x50c70e(0x1f7)](this), this[_0x50c70e(0x405)] = this[_0x50c70e(0x1fe)][_0x50c70e(0x209)]('CameraPivot');
                        }
                    },
                    {
                        'key': _0x3174b5(0x270),
                        'value': function _0x36f681(_0x4844d9) {
                            var _0x51a8af = _0x3174b5;
                            this[_0x51a8af(0x2a4)] = _0x4844d9, this['input'][_0x51a8af(0x2c3)][_0x51a8af(0x29f)] = !0x1, this['fsm'][_0x51a8af(0x3d2)][_0x51a8af(0x3d8)] = !0x0;
                        }
                    },
                    {
                        'key': _0x3174b5(0x29c),
                        'value': function _0x2b618c() {
                            var _0x48baeb = _0x3174b5;
                            this[_0x48baeb(0x403)] += this[_0x48baeb(0x2a4)][_0x48baeb(0x2c5)][_0x48baeb(0x2bf)]() * this[_0x48baeb(0x404)], this[_0x48baeb(0x405)]['transform'][_0x48baeb(0x436)] = this[_0x48baeb(0x403)], Laya[_0x48baeb(0x3f8)]['createFromAxisAngle'](_0x31f777['Up'], Math['PI'] * this[_0x48baeb(0x403)] / 0xb4, this['tempRot']), this[_0x48baeb(0x407)][_0x48baeb(0x2b4)](this[_0x48baeb(0x2a4)][_0x48baeb(0x2c3)][_0x48baeb(0x2a4)]['x'], 0x0, this[_0x48baeb(0x2a4)]['moveInput']['input']['y']), _0x31f777[_0x48baeb(0x42b)](this['tempV3'], this[_0x48baeb(0x402)], this[_0x48baeb(0x407)]), this[_0x48baeb(0x3f2)]['blackBorad']['input']['setValue'](this[_0x48baeb(0x407)]['x'], this['tempV3']['z']), this[_0x48baeb(0x3f3)](), this['grounded'] && this['input'][_0x48baeb(0x2c3)]['jump'] ? this['fsm']['blackBorad'][_0x48baeb(0x3d4)] = !0x0 : this[_0x48baeb(0x3f2)][_0x48baeb(0x3d2)][_0x48baeb(0x3d4)] = !0x1, _0x58adf2(_0x5a6184(_0x1863f2['prototype']), 'onUpdate', this)['call'](this);
                        }
                    },
                    {
                        'key': _0x3174b5(0x400),
                        'value': function _0x25a7e9() {
                            var _0xf632ac = _0x3174b5,
                                _0x795e4 = this['owner'][_0xf632ac(0x4cf)][_0xf632ac(0x209)]('Hole');
                            if (_0x795e4) {
                                (_0x795e4 = _0x795e4['clone']())[_0xf632ac(0x240)] = !0x0, this['owner']['scene']['addChild'](_0x795e4);
                                var _0x346690 = this['transform'][_0xf632ac(0x32d)][_0xf632ac(0x32e)]();
                                _0x346690['y'] = -0.76, _0x795e4[_0xf632ac(0x32a)][_0xf632ac(0x32d)] = _0x346690, _0x795e4[_0xf632ac(0x214)](0x7d0, this, function() {
                                    var _0x5b6963 = _0xf632ac;
                                    _0x795e4[_0x5b6963(0x40d)]();
                                });
                                var _0x415a9d = this[_0xf632ac(0x3e0)][_0xf632ac(0x32a)][_0xf632ac(0x421)],
                                    _0x121bcb = _0x415a9d[_0xf632ac(0x32e)]();
                                _0x121bcb['y'] -= 0x1, fx['Helper'][_0xf632ac(0x422)](this[_0xf632ac(0x3e0)], _0x415a9d, _0x121bcb, 0x2, 0x0, !0x1, !0x0);
                            }
                            _0x58adf2(_0x5a6184(_0x1863f2[_0xf632ac(0x2e5)]), _0xf632ac(0x400), this)[_0xf632ac(0x1f7)](this), _0x29989c[_0xf632ac(0x203)][_0xf632ac(0x277)](_0x4d7387['E_GAME_FAILED']);
                        }
                    }
                ]), _0x1863f2;
            }(_0x4d230e),
            _0x286d69 = function(_0xb3c337) {
                var _0x1ceb29 = _0x28eca3;
                _0x10ff6e(_0x327533, _0xb3c337);
                var _0x3e76f0 = _0x30529b(_0x327533);

                function _0x327533() {
                    var _0x23e220 = _0x372d,
                        _0x3b4c05;
                    return _0xaf4c50(this, _0x327533), (_0x3b4c05 = _0x3e76f0['apply'](this, arguments), _0x3b4c05[_0x23e220(0x4d0)] = 0x0, _0x3b4c05[_0x23e220(0x4d1)] = 0.5), _0x3b4c05;
                }
                return _0x3f3356(_0x327533, [{
                        'key': _0x1ceb29(0x1fa),
                        'value': function _0x48112d() {
                            var _0x5cb461 = _0x1ceb29;
                            this[_0x5cb461(0x4d2)] = fx['Utils']['getIntRandom'](0x1, 0x5), _0x58adf2(_0x5a6184(_0x327533[_0x5cb461(0x2e5)]), 'onAwake', this)[_0x5cb461(0x1f7)](this), _0x457d72['I'][_0x5cb461(0x23b)](this[_0x5cb461(0x3df)]);
                        }
                    },
                    {
                        'key': _0x1ceb29(0x20c),
                        'value': function _0x424d2d() {
                            var _0x5c86c = _0x1ceb29;
                            fx[_0x5c86c(0x294)][_0x5c86c(0x203)][_0x5c86c(0x295)](this);
                        }
                    },
                    {
                        'key': 'onUpdate',
                        'value': function _0x107ffa() {
                            var _0x1cc842 = _0x1ceb29;
                            this[_0x1cc842(0x3f3)](), this[_0x1cc842(0x4d0)] += 0x10 / 0x3e8, this[_0x1cc842(0x4d0)] >= this[_0x1cc842(0x4d2)] && (this[_0x1cc842(0x4d0)] -= this[_0x1cc842(0x4d2)], fx[_0x1cc842(0x1fb)][_0x1cc842(0x23f)](this['rate']) ? (this[_0x1cc842(0x4d1)] = 0.8, this[_0x1cc842(0x4d2)] = 1.5, this[_0x1cc842(0x3f2)][_0x1cc842(0x3d2)]['jump'] = !0x0) : (this[_0x1cc842(0x4d2)] = fx[_0x1cc842(0x1fb)][_0x1cc842(0x279)](0x1, 0x5), this['rate'] = 0.2)), _0x58adf2(_0x5a6184(_0x327533[_0x1cc842(0x2e5)]), _0x1cc842(0x29c), this)['call'](this);
                        }
                    },
                    {
                        'key': _0x1ceb29(0x2be),
                        'value': function _0x2f0a69() {
                            var _0x2863a3 = _0x1ceb29;
                            _0x58adf2(_0x5a6184(_0x327533[_0x2863a3(0x2e5)]), _0x2863a3(0x2be), this)[_0x2863a3(0x1f7)](this), this['fsm'][_0x2863a3(0x3d2)][_0x2863a3(0x3d4)] = !0x1;
                        }
                    }
                ]), _0x327533;
            }(_0x4d230e),
            _0x24e7dd = function() {
                var _0x2056b2 = _0x28eca3;

                function _0x297e5f() {
                    var _0x3ec78d = _0x372d;
                    _0xaf4c50(this, _0x297e5f), (this[_0x3ec78d(0x25f)] = [], this[_0x3ec78d(0x4a9)] = new _0x31f777());
                }
                return _0x3f3356(_0x297e5f, [{
                        'key': _0x2056b2(0x270),
                        'value': function _0x663be8() {
                            var _0x460779 = _0x2056b2;
                            this[_0x460779(0x25f)] = [], this['robotsCnt'] = _0x29989c['instance'][_0x460779(0x286)];
                        }
                    },
                    {
                        'key': _0x2056b2(0x27a),
                        'value': function _0xfcbac(_0x1406a7) {
                            var _0x37612d = _0x2056b2;
                            this[_0x37612d(0x25f)]['push'](_0x1406a7);
                        }
                    },
                    {
                        'key': _0x2056b2(0x281),
                        'value': function _0x33c9be() {
                            var _0x3b2952 = _0x2056b2;
                            return this[_0x3b2952(0x25f)];
                        }
                    },
                    {
                        'key': _0x2056b2(0x4d3),
                        'value': function _0x2447ed(_0x4320cd) {
                            var _0x1fe4db = _0x2056b2;
                            for (var _0x23c077 = this[_0x1fe4db(0x25f)][_0x1fe4db(0x27c)] - 0x1; _0x23c077 >= 0x0; --_0x23c077) {
                                var _0x34cb6d = this[_0x1fe4db(0x25f)][_0x23c077];
                                _0x34cb6d[_0x1fe4db(0x4cd)] && (fx[_0x1fe4db(0x1fb)][_0x1fe4db(0x23f)](0.25) ? _0x34cb6d[_0x1fe4db(0x4d4)] += _0x4320cd : _0x34cb6d[_0x1fe4db(0x4d4)] -= _0x4320cd, _0x34cb6d[_0x1fe4db(0x3f1)] || _0x34cb6d[_0x1fe4db(0x4d4)] > 0x0 || _0x34cb6d[_0x1fe4db(0x3ff)]());
                            }
                        }
                    },
                    {
                        'key': _0x2056b2(0x41e),
                        'value': function _0x50b0f7() {
                            var _0x4da8fc = _0x2056b2,
                                _0x340e20 = 0x0;
                            for (var _0x5be1d9 = this[_0x4da8fc(0x25f)]['length'] - 0x1; _0x5be1d9 >= 0x0; --_0x5be1d9) {
                                this[_0x4da8fc(0x25f)][_0x5be1d9][_0x4da8fc(0x3f1)] || _0x340e20++;
                            }
                            return _0x340e20;
                        }
                    }
                ], [{
                    'key': 'I',
                    'get': function _0x17aa26() {
                        var _0xc76557 = _0x2056b2;
                        return this[_0xc76557(0x233)] || (this[_0xc76557(0x233)] = new _0x297e5f()), this['_instance'];
                    }
                }]), _0x297e5f;
            }(),
            _0x4df736 = [{
                    'o': 0x1,
                    'weight': 0x3
                },
                {
                    'o': 0x3,
                    'weight': 0x1
                },
                {
                    'o': 0x5,
                    'weight': 0x3
                }
            ],
            _0x1c1aa9 = [{
                    'o': 0x2,
                    'weight': 0x1
                },
                {
                    'o': 0x4,
                    'weight': 0x2
                }
            ],
            _0x1894a2 = function(_0x4b5c30) {
                var _0xc2400f = _0x28eca3;
                _0x10ff6e(_0x3efcd5, _0x4b5c30);
                var _0x446910 = _0x30529b(_0x3efcd5);

                function _0x3efcd5() {
                    var _0x210256 = _0x372d,
                        _0x24c474;
                    return _0xaf4c50(this, _0x3efcd5), (_0x24c474 = _0x446910['call'](this), _0x24c474[_0x210256(0x4d5)] = !0x0, _0x24c474[_0x210256(0x4d6)] = 0x0, _0x24c474['ownerMarble'] = 0xa, _0x24c474[_0x210256(0x4d7)] = 0x0, _0x24c474[_0x210256(0x4d8)] = 0.5), _0x24c474;
                }
                return _0x3f3356(_0x3efcd5, [{
                        'key': 'onAwake',
                        'value': function _0x2be29d() {
                            var _0x4b7b1b = _0x372d,
                                _0x108237 = this;
                            this['ownerUI'] = this[_0x4b7b1b(0x1fe)], this[_0x4b7b1b(0x481)](), this[_0x4b7b1b(0x4d9)]['on'](Laya[_0x4b7b1b(0x2ac)][_0x4b7b1b(0x450)], this, function(_0xbca3db) {
                                var _0x3549fd = _0x4b7b1b;
                                _0xbca3db['stopPropagation'](), _0x108237[_0x3549fd(0x4da)](0x1);
                            }), this['label_even']['on'](Laya['Event'][_0x4b7b1b(0x450)], this, function(_0x26c347) {
                                var _0x3f2b9a = _0x4b7b1b;
                                _0x26c347[_0x3f2b9a(0x2ae)](), _0x108237['guess'](0x2);
                            });
                        }
                    },
                    {
                        'key': _0xc2400f(0x481),
                        'value': function _0x4cef63() {
                            var _0x410a9e = _0xc2400f;
                            this[_0x410a9e(0x4db)] = this[_0x410a9e(0x207)][_0x410a9e(0x209)](_0x410a9e(0x4db)), this[_0x410a9e(0x4dc)] = this[_0x410a9e(0x4db)][_0x410a9e(0x209)](_0x410a9e(0x4dc)), this[_0x410a9e(0x4dd)] = this['ownerUI'][_0x410a9e(0x209)](_0x410a9e(0x4dd)), this[_0x410a9e(0x4de)] = this['box_mid'][_0x410a9e(0x209)](_0x410a9e(0x4de)), this[_0x410a9e(0x4d9)] = this['box_btn'][_0x410a9e(0x209)](_0x410a9e(0x4d9)), this[_0x410a9e(0x4df)] = this['box_btn']['getChildByName'](_0x410a9e(0x4df)), this['label_guess'] = this[_0x410a9e(0x4dd)][_0x410a9e(0x209)](_0x410a9e(0x4e0)), this[_0x410a9e(0x4e1)] = this[_0x410a9e(0x4dd)][_0x410a9e(0x209)]('label_null'), this[_0x410a9e(0x4e2)] = this[_0x410a9e(0x4dd)][_0x410a9e(0x209)](_0x410a9e(0x4e2));
                            var _0x49b918 = this[_0x410a9e(0x207)][_0x410a9e(0x209)](_0x410a9e(0x4e3));
                            this[_0x410a9e(0x4e4)] = _0x49b918['getChildByName'](_0x410a9e(0x4e4));
                        }
                    },
                    {
                        'key': 'resetGame',
                        'value': function _0x4f54cb() {
                            var _0x579c4b = _0xc2400f;
                            this[_0x579c4b(0x293)](), this[_0x579c4b(0x4e5)](), _0x20256e[_0x579c4b(0x3a2)](_0x579c4b(0x4e6), null, 0xa);
                        }
                    },
                    {
                        'key': 'updateUI',
                        'value': function _0x4b206e() {
                            var _0x15c131 = _0xc2400f;
                            this[_0x15c131(0x4dd)]['visible'] = !0x0, this[_0x15c131(0x4db)]['visible'] = !0x0, this[_0x15c131(0x4de)][_0x15c131(0x20b)] = !0x0, this[_0x15c131(0x4e2)][_0x15c131(0x20b)] = !0x1, this[_0x15c131(0x4e1)][_0x15c131(0x20b)] = !0x0, this[_0x15c131(0x4e0)][_0x15c131(0x20b)] = !0x1;
                        }
                    },
                    {
                        'key': _0xc2400f(0x4e7),
                        'value': function _0x545c19(_0x5dc029) {
                            var _0x3f4a65 = _0xc2400f,
                                _0x248aa6 = this['box_wager']['getChildren']();
                            for (var _0xfaa760 = 0x0; _0xfaa760 < _0x248aa6[_0x3f4a65(0x27c)]; _0xfaa760++) {
                                _0x248aa6[_0xfaa760]['visible'] = _0xfaa760 <= _0x5dc029 - 0x1;
                            }
                            this[_0x3f4a65(0x4e1)][_0x3f4a65(0x20b)] = !0x1, this['box_wager'][_0x3f4a65(0x20b)] = !0x0;
                        }
                    },
                    {
                        'key': 'startTime',
                        'value': function _0x122bb3() {
                            var _0x518909 = _0xc2400f;
                            this[_0x518909(0x4d6)] = Laya['timer'][_0x518909(0x4ba)] + 0x2710, this[_0x518909(0x4e8)](), this['owner']['timerLoop'](0x3e8, this, this[_0x518909(0x4e8)]);
                        }
                    },
                    {
                        'key': 'endTime',
                        'value': function _0xa740fc() {
                            var _0x3ae1b4 = _0xc2400f,
                                _0x4ea261;
                            if (this[_0x3ae1b4(0x1fe)][_0x3ae1b4(0x213)](this, this['onUpdateCd']), _0x4ea261 = fx[_0x3ae1b4(0x1fb)][_0x3ae1b4(0x245)](0x0, 0x1) <= this['winRate'] ? this[_0x3ae1b4(0x4d5)] ? this[_0x3ae1b4(0x4e9)] = fx[_0x3ae1b4(0x1fb)][_0x3ae1b4(0x4ea)](fx[_0x3ae1b4(0x1fb)][_0x3ae1b4(0x4eb)](_0x4df736))[0x1]['o'] : this[_0x3ae1b4(0x4e9)] = fx[_0x3ae1b4(0x1fb)][_0x3ae1b4(0x4ea)](fx[_0x3ae1b4(0x1fb)][_0x3ae1b4(0x4eb)](_0x1c1aa9))[0x1]['o'] : this[_0x3ae1b4(0x4d5)] ? this[_0x3ae1b4(0x4e9)] = fx['Utils']['takeOneByWeight'](fx[_0x3ae1b4(0x1fb)][_0x3ae1b4(0x4eb)](_0x1c1aa9))[0x1]['o'] : this[_0x3ae1b4(0x4e9)] = fx[_0x3ae1b4(0x1fb)][_0x3ae1b4(0x4ea)](fx[_0x3ae1b4(0x1fb)][_0x3ae1b4(0x4eb)](_0x4df736))[0x1]['o'], this['updateMarble'](_0x4ea261), !this['label_guess'][_0x3ae1b4(0x20b)]) {
                                var _0x222f37 = fx[_0x3ae1b4(0x1fb)][_0x3ae1b4(0x279)](0x0, 0x1);
                                this[_0x3ae1b4(0x4da)](0x0);
                            }
                            this['box_countDown'][_0x3ae1b4(0x20b)] = !0x1, this[_0x3ae1b4(0x4ec)]();
                        }
                    },
                    {
                        'key': _0xc2400f(0x4da),
                        'value': function _0x728858() {
                            var _0xc2e82d = _0xc2400f,
                                _0x3b3eda = '',
                                _0x1e1069 = arguments[_0xc2e82d(0x27c)] > 0x0 && arguments[0x0] !== undefined ? arguments[0x0] : !0x0;
                            if (_0x1e1069 == 0x0)
                                _0x3b3eda = '';
                            else {
                                if (_0x1e1069 == 0x1)
                                    _0x3b3eda = 'Odd\x20number';
                                else
                                    _0x1e1069 == 0x2 && (_0x3b3eda = _0xc2e82d(0x4ed));
                            }
                            this['curGuessIsOdd'] = _0x1e1069, this[_0xc2e82d(0x4e0)][_0xc2e82d(0x210)] = _0xc2e82d(0x4ee) + _0x3b3eda, this['label_guess'][_0xc2e82d(0x20b)] = !0x0, this[_0xc2e82d(0x4de)][_0xc2e82d(0x20b)] = !0x1;
                        }
                    },
                    {
                        'key': _0xc2400f(0x4ec),
                        'value': function _0x1ba8a3() {
                            var _0x56b857 = _0xc2400f,
                                _0x174ddd = this,
                                _0x794f4b = 0x1,
                                _0x3a0f95 = _0x56b857(0x4ef);
                            this[_0x56b857(0x4e9)] % 0x2 == 0x0 && (_0x794f4b = 0x2, _0x3a0f95 = _0x56b857(0x4ed)), _0x20256e['showTips']('The\x20correct\x20answer\x20is:' + _0x3a0f95, Laya[_0x56b857(0x324)]['create'](this, function() {
                                var _0x53c5c8 = _0x56b857,
                                    _0x150adc = Laya[_0x53c5c8(0x324)]['create'](_0x174ddd, function() {
                                        var _0x403ef8 = _0x53c5c8,
                                            _0x50bff1 = Laya[_0x403ef8(0x324)][_0x403ef8(0x325)](_0x174ddd, function() {
                                                var _0x133096 = _0x403ef8;
                                                _0x24e7dd['I'][_0x133096(0x4d3)](_0x174ddd[_0x133096(0x4e9)]), _0x174ddd[_0x133096(0x4dd)][_0x133096(0x20b)] = !0x1, 0x0 != _0x174ddd[_0x133096(0x4f0)] ? _0x174ddd[_0x133096(0x4f0)] >= 0x14 ? _0x174ddd[_0x133096(0x4f1)]() : (_0x174ddd[_0x133096(0x4d7)] += 0x1, 0x8 == _0x174ddd[_0x133096(0x4d7)] ? _0x174ddd[_0x133096(0x4f1)]() : (_0x20256e[_0x133096(0x3a2)](_0x133096(0x4f2) + (_0x174ddd[_0x133096(0x4d7)] + 0x1) + '', null, 0x3), Laya[_0x133096(0x387)]['once'](0xbb8, _0x174ddd, _0x174ddd['resetGame']))) : _0x174ddd['gameFail']();
                                            });
                                        _0x174ddd['curGuessIsOdd'] == _0x794f4b ? (_0x174ddd[_0x403ef8(0x4d8)] *= 0.5, _0x174ddd[_0x403ef8(0x4f0)] += _0x174ddd[_0x403ef8(0x4e9)], fx[_0x403ef8(0x202)][_0x403ef8(0x203)]['playSound']('res/sound/right.mp3'), _0x20256e[_0x403ef8(0x3a2)](_0x403ef8(0x4f3) + _0x174ddd[_0x403ef8(0x4e9)] + '\x20marbles', _0x50bff1)) : (_0x174ddd[_0x403ef8(0x4d8)] = 0.5, _0x174ddd[_0x403ef8(0x4f0)] -= _0x174ddd[_0x403ef8(0x4e9)], _0x174ddd[_0x403ef8(0x4f0)] < 0x0 && (_0x174ddd[_0x403ef8(0x4f0)] = 0x0), fx[_0x403ef8(0x202)][_0x403ef8(0x203)][_0x403ef8(0x204)](_0x403ef8(0x4f4)), _0x20256e[_0x403ef8(0x3a2)](_0x403ef8(0x4f5) + _0x174ddd[_0x403ef8(0x4e9)] + _0x403ef8(0x4f6), _0x50bff1)), _0x174ddd[_0x403ef8(0x4e4)]['text'] = 'Number\x20of\x20existing\x20marbles:' + _0x174ddd['ownerMarble'];
                                    });
                                _0x20256e[_0x53c5c8(0x3a2)](_0x53c5c8(0x4f7) + _0x174ddd[_0x53c5c8(0x4e9)], _0x150adc);
                            }));
                        }
                    },
                    {
                        'key': _0xc2400f(0x4f1),
                        'value': function _0x1c28c8() {
                            var _0x3f664b = _0xc2400f,
                                _0x5d2170 = this;
                            _0x5d2170['ownerUI'][_0x3f664b(0x20b)] = !0x1, _0x29989c[_0x3f664b(0x203)][_0x3f664b(0x277)](_0x4d7387[_0x3f664b(0x1e6)]);
                        }
                    },
                    {
                        'key': _0xc2400f(0x4f8),
                        'value': function _0x4ec7c9() {
                            var _0x3640ae = _0xc2400f;
                            this[_0x3640ae(0x492)][_0x3640ae(0x400)](), this[_0x3640ae(0x207)][_0x3640ae(0x20b)] = !0x1, _0x29989c[_0x3640ae(0x203)]['setGameState'](_0x4d7387[_0x3640ae(0x1e7)]);
                        }
                    },
                    {
                        'key': _0xc2400f(0x4f9),
                        'value': function _0x2b24d8() {
                            var _0x43d397 = _0xc2400f;
                            this['owner'][_0x43d397(0x387)][_0x43d397(0x4fa)](this);
                        }
                    },
                    {
                        'key': _0xc2400f(0x4e8),
                        'value': function _0x35f041() {
                            var _0x5ac972 = _0xc2400f;
                            fx[_0x5ac972(0x202)][_0x5ac972(0x203)][_0x5ac972(0x204)](_0x5ac972(0x40c));
                            var _0x34afb1 = Laya[_0x5ac972(0x387)][_0x5ac972(0x4ba)];
                            this[_0x5ac972(0x4d6)] && Math[_0x5ac972(0x4fb)]((_0x34afb1 - this[_0x5ac972(0x4d6)]) / 0x3e8) > 0x0 && this['endTime'](), this[_0x5ac972(0x4fc)]();
                        }
                    },
                    {
                        'key': _0xc2400f(0x4fc),
                        'value': function _0x17f823() {
                            var _0x338496 = _0xc2400f,
                                _0x5e4a43 = Laya['timer'][_0x338496(0x4ba)],
                                _0x5bf05d = this['resetTime'] - _0x5e4a43;
                            _0x5bf05d = Math['max'](_0x5bf05d, 0x0), _0x5bf05d = Math['round'](_0x5bf05d / 0x3e8), _0x5bf05d *= 0x3e8;
                            var _0x5b4b1c = fx[_0x338496(0x1fb)][_0x338496(0x29d)](_0x5bf05d, {
                                'separator': [
                                    ':',
                                    ''
                                ],
                                'isAlign': !0x0
                            });
                            this[_0x338496(0x4dc)]['text'] = _0x5b4b1c;
                        }
                    }
                ]), _0x3efcd5;
            }(Laya[_0x28eca3(0x206)]),
            _0x86f92 = function(_0x181e8f) {
                var _0x2cc3bf = _0x28eca3;
                _0x10ff6e(_0x46de22, _0x181e8f);
                var _0x1696fa = _0x30529b(_0x46de22);

                function _0x46de22() {
                    var _0x544a7c = _0x372d;
                    return _0xaf4c50(this, _0x46de22), _0x1696fa[_0x544a7c(0x1f7)](this);
                }
                return _0x3f3356(_0x46de22, [{
                        'key': _0x2cc3bf(0x44e),
                        'value': function _0x487ae1() {
                            var _0x4ec0c8 = _0x2cc3bf,
                                _0x1c6377 = this;
                            _0x29989c[_0x4ec0c8(0x203)]['init'](), _0x24e7dd['I'][_0x4ec0c8(0x270)]();
                            var _0x36bc9d = Laya[_0x4ec0c8(0x319)][_0x4ec0c8(0x478)](_0x46de22[_0x4ec0c8(0x479)]);
                            this[_0x4ec0c8(0x47a)] = _0x36bc9d, _0x36bc9d['size'](this[_0x4ec0c8(0x2ba)], this[_0x4ec0c8(0x2a8)]), this[_0x4ec0c8(0x47c)](_0x36bc9d, 0x0), _0x36bc9d[_0x4ec0c8(0x367)](_0x39ee6f), (this[_0x4ec0c8(0x481)](), this['initPlayer'](), this[_0x4ec0c8(0x47d)](), this[_0x4ec0c8(0x497)]()), !Laya['LocalStorage'][_0x4ec0c8(0x489)](_0x4ec0c8(0x48b)) && Laya[_0x4ec0c8(0x2aa)][_0x4ec0c8(0x2ab)] ? (this[_0x4ec0c8(0x49b)]['visible'] = this[_0x4ec0c8(0x488)][_0x4ec0c8(0x20b)] = !![], Laya[_0x4ec0c8(0x4c1)][_0x4ec0c8(0x48a)](_0x4ec0c8(0x48b), !![]), Laya[_0x4ec0c8(0x387)]['once'](0x1388, this, () => {
                                var _0x2d6472 = _0x4ec0c8;
                                this[_0x2d6472(0x49b)][_0x2d6472(0x20b)] = this[_0x2d6472(0x488)]['visible'] = ![], this[_0x2d6472(0x482)][_0x2d6472(0x29b)](0x3, Laya[_0x2d6472(0x324)][_0x2d6472(0x325)](this, function() {
                                    var _0x2cabaf = _0x2d6472;
                                    Laya['timer'][_0x2cabaf(0x39d)](0x3e8, _0x1c6377, _0x1c6377[_0x2cabaf(0x49c)]);
                                }));
                            })) : (this[_0x4ec0c8(0x49b)][_0x4ec0c8(0x20b)] = this['spr_guide']['visible'] = ![], this[_0x4ec0c8(0x482)][_0x4ec0c8(0x29b)](0x3, Laya[_0x4ec0c8(0x324)][_0x4ec0c8(0x325)](this, function() {
                                var _0x25d2c8 = _0x4ec0c8;
                                Laya[_0x25d2c8(0x387)][_0x25d2c8(0x39d)](0x3e8, _0x1c6377, _0x1c6377['startGame']);
                            }))), console['log'](0x5be8b167172ab000000000), (this[_0x4ec0c8(0x4fd)] = this['box_game'][_0x4ec0c8(0x2c4)](_0x1894a2), this['gms']['playerController'] = this[_0x4ec0c8(0x492)]), platform[_0x4ec0c8(0x451)]()[_0x4ec0c8(0x480)]();
                        }
                    },
                    {
                        'key': 'onDestroy',
                        'value': function _0x3c6dae() {
                            var _0x26e89e = _0x2cc3bf;
                            fx[_0x26e89e(0x294)][_0x26e89e(0x203)][_0x26e89e(0x261)](_0x561c5d[_0x26e89e(0x465)]);
                        }
                    },
                    {
                        'key': _0x2cc3bf(0x481),
                        'value': function _0x2db1a8() {
                            var _0x599fdf = _0x2cc3bf;
                            this[_0x599fdf(0x482)] = this['box_cd'][_0x599fdf(0x2c4)](_0xc00205), this[_0x599fdf(0x48d)]['on'](Laya[_0x599fdf(0x2ac)]['CLICK'], this, this[_0x599fdf(0x4fe)]);
                        }
                    },
                    {
                        'key': _0x2cc3bf(0x4fe),
                        'value': function _0x123f7e() {
                            var _0x3753b3 = _0x2cc3bf;
                            platform[_0x3753b3(0x451)]()[_0x3753b3(0x230)](() => {
                                var _0x3ded89 = _0x3753b3;
                                fx[_0x3ded89(0x452)]['destroy'](this), platform['getInstance']()[_0x3ded89(0x458)](), _0x29989c[_0x3ded89(0x203)][_0x3ded89(0x265)]();
                            });
                        }
                    },
                    {
                        'key': _0x2cc3bf(0x48f),
                        'value': function _0x2fbf51() {
                            var _0x372eb6 = _0x2cc3bf,
                                _0x218bd1 = this[_0x372eb6(0x2a4)]['getComponent'](_0x1a62ec),
                                _0x3027b4 = this[_0x372eb6(0x47a)][_0x372eb6(0x209)]('Player'),
                                _0x17a37e = Laya[_0x372eb6(0x319)][_0x372eb6(0x31a)](_0xf611c3[_0x372eb6(0x25a)])[_0x372eb6(0x32e)]();
                            _0x3027b4[_0x372eb6(0x3af)](_0x17a37e), this[_0x372eb6(0x491)] = _0x3027b4[_0x372eb6(0x32e)]();
                            var _0x2da25a = _0x3027b4[_0x372eb6(0x367)](_0x316784);
                            _0x2da25a[_0x372eb6(0x270)](_0x218bd1), this[_0x372eb6(0x492)] = _0x2da25a, _0x24e7dd['I'][_0x372eb6(0x27a)](_0x2da25a), this[_0x372eb6(0x491)][_0x372eb6(0x209)](_0x372eb6(0x406))['destroy']();
                        }
                    },
                    {
                        'key': _0x2cc3bf(0x47d),
                        'value': function _0x339b1d() {
                            var _0x42481b = _0x2cc3bf,
                                _0x32e39e = this['scene3d'][_0x42481b(0x209)](_0x42481b(0x4c2))[_0x42481b(0x209)](_0x42481b(0x4c3));
                            fx['Utils'][_0x42481b(0x4c4)](_0x32e39e, function(_0x76e90e) {
                                var _0x1c101c = _0x42481b;
                                _0x20256e[_0x1c101c(0x4c5)](_0x76e90e, _0x134368[_0x1c101c(0x1ef)]);
                            });
                            var _0x51426c = this[_0x42481b(0x47a)][_0x42481b(0x209)]('Hole');
                            _0x51426c && (_0x51426c[_0x42481b(0x240)] = !0x1);
                        }
                    },
                    {
                        'key': 'initRobots',
                        'value': function _0x1836d6() {
                            var _0x31be67 = _0x2cc3bf,
                                _0x2a5fdc = _0x24e7dd['I']['robotsCnt'];
                            for (var _0x23e033 = 0x0; _0x23e033 < _0x2a5fdc; ++_0x23e033) {
                                var _0xf93c05 = this[_0x31be67(0x491)][_0x31be67(0x32e)]();
                                this[_0x31be67(0x47a)]['addChild'](_0xf93c05);
                                var _0x46eac7 = fx[_0x31be67(0x1fb)][_0x31be67(0x245)](-0xa, 0xa),
                                    _0x42bb6e = fx['Utils'][_0x31be67(0x245)](-0xa, 0x14);
                                _0xf93c05[_0x31be67(0x32a)][_0x31be67(0x32d)] = new _0x31f777(_0x46eac7, 0x0, _0x42bb6e);
                                var _0x17d46f = _0xf93c05[_0x31be67(0x367)](_0x286d69);
                                _0x24e7dd['I'][_0x31be67(0x27a)](_0x17d46f);
                            }
                        }
                    },
                    {
                        'key': _0x2cc3bf(0x3cc),
                        'value': function _0x51c64d() {
                            this['on'](_0x561c5d['E_GAME_STATE_CHANGED'], this, this['onGameStateChange']);
                        }
                    },
                    {
                        'key': 'onExit',
                        'value': function _0x3ecdcd() {}
                    },
                    {
                        'key': 'startGame',
                        'value': function _0x298e73() {
                            var _0x404f3e = _0x2cc3bf;
                            _0x29989c[_0x404f3e(0x203)][_0x404f3e(0x277)](_0x4d7387[_0x404f3e(0x1e4)]), this[_0x404f3e(0x4fd)]['resetGame']();
                        }
                    },
                    {
                        'key': _0x2cc3bf(0x265),
                        'value': function _0x5d6c07() {
                            var _0x1ee6b6 = _0x2cc3bf;
                            this[_0x1ee6b6(0x49b)][_0x1ee6b6(0x20b)] = this[_0x1ee6b6(0x488)][_0x1ee6b6(0x20b)] = ![];
                            var _0xdff99a = Laya[_0x1ee6b6(0x266)][_0x1ee6b6(0x267)]('MainScene');
                            fx['SceneManager'][_0x1ee6b6(0x269)](_0xdff99a);
                        }
                    },
                    {
                        'key': _0x2cc3bf(0x298),
                        'value': function _0x25eecd(_0x3a46ca) {
                            var _0x198bb7 = _0x2cc3bf;
                            switch (_0x29989c[_0x198bb7(0x203)][_0x198bb7(0x264)]()) {
                                case _0x4d7387['E_GAME_FINISH']:
                                    this[_0x198bb7(0x49f)]();
                                    break;
                                case _0x4d7387['E_GAME_FAILED']:
                                    this[_0x198bb7(0x4a0)]();
                                    break;
                                case _0x4d7387[_0x198bb7(0x1e8)]:
                                    this[_0x198bb7(0x4a6)]();
                                    break;
                                case _0x4d7387['E_GAME_PAUSE']:
                                    break;
                                case _0x4d7387['E_GAME_START']:
                                    _0x3a46ca == _0x4d7387[_0x198bb7(0x1e7)] ? this['revive']() : this[_0x198bb7(0x29b)]();
                            }
                        }
                    },
                    {
                        'key': _0x2cc3bf(0x4a1),
                        'value': function _0x87b66d(_0x5f2f8a) {}
                    },
                    {
                        'key': _0x2cc3bf(0x4a2),
                        'value': function _0xee8cdd(_0xc470cc) {}
                    },
                    {
                        'key': _0x2cc3bf(0x4a3),
                        'value': function _0x4d96fd(_0x44aefa) {}
                    },
                    {
                        'key': _0x2cc3bf(0x29b),
                        'value': function _0xf88419() {
                            var _0x181c55 = _0x2cc3bf;
                            this[_0x181c55(0x4ff)][_0x181c55(0x20b)] = !0x0;
                        }
                    },
                    {
                        'key': _0x2cc3bf(0x49f),
                        'value': function _0x1018fc() {
                            var _0x29cde9 = _0x2cc3bf,
                                _0x5dd810 = this;
                            platform[_0x29cde9(0x451)]()[_0x29cde9(0x458)]();
                            var _0x3db704 = _0x29989c[_0x29cde9(0x203)]['getCharacterCnt']();
                            0x1 == _0x3db704 ? (_0x29989c[_0x29cde9(0x203)][_0x29cde9(0x278)](), Laya[_0x29cde9(0x324)][_0x29cde9(0x325)](this, function() {
                                var _0x53bda0 = _0x29cde9;
                                fx[_0x53bda0(0x452)][_0x53bda0(0x4a4)](_0x3dffbb, {
                                    'from': '',
                                    'userArgs': [Laya['Handler']['create'](_0x29989c[_0x53bda0(0x203)], function() {
                                        var _0x5eb70c = _0x53bda0;
                                        _0x29989c[_0x5eb70c(0x203)]['goMain']();
                                    })]
                                });
                            })) : (_0x29989c[_0x29cde9(0x203)][_0x29cde9(0x286)] = Math[_0x29cde9(0x28c)](_0x3db704 - 0x1, 0x1), _0x29989c[_0x29cde9(0x203)][_0x29cde9(0x26c)](), _0x29989c['instance'][_0x29cde9(0x265)]()), fx[_0x29cde9(0x452)][_0x29cde9(0x40d)](this);
                        }
                    },
                    {
                        'key': _0x2cc3bf(0x4a0),
                        'value': function _0x244a79() {
                            var _0x3f2855 = _0x2cc3bf;
                            platform[_0x3f2855(0x451)]()[_0x3f2855(0x458)]();
                            var _0x5042cf = this;
                            _0x29989c[_0x3f2855(0x203)]['clear'](), fx['SceneManager'][_0x3f2855(0x4a4)](_0x46859c, {
                                'from': '',
                                'userArgs': [Laya['Handler']['create'](_0x29989c[_0x3f2855(0x203)], function() {
                                    var _0x30e322 = _0x3f2855;
                                    _0x29989c[_0x30e322(0x203)]['goMain']();
                                })]
                            }), fx[_0x3f2855(0x452)][_0x3f2855(0x40d)](this);
                        }
                    },
                    {
                        'key': _0x2cc3bf(0x4a6),
                        'value': function _0x140a03() {}
                    },
                    {
                        'key': 'revive',
                        'value': function _0x2a8dc2() {}
                    },
                    {
                        'key': _0x2cc3bf(0x278),
                        'value': function _0x41105f() {}
                    }
                ], [{
                    'key': _0x2cc3bf(0x31a),
                    'value': function _0x43b4d1() {
                        var _0x530479 = _0x2cc3bf;
                        return this[_0x530479(0x479)] = _0x457d72['I'][_0x530479(0x249)]('res3d/GameMarble.ls'), [
                            this[_0x530479(0x479)],
                            _0xf611c3[_0x530479(0x25a)]
                        ];
                    }
                }]), _0x46de22;
            }(_0x118985['scenes']['marble'][_0x28eca3(0x2f3)]);
        Laya[_0x28eca3(0x266)]['regClass'](_0x28eca3(0x500), _0x86f92);
        var _0x4cb5a1 = function(_0x1aa8d6) {
                var _0x48c8df = _0x28eca3;
                _0x10ff6e(_0x5bc923, _0x1aa8d6);
                var _0x5e364a = _0x30529b(_0x5bc923);

                function _0x5bc923() {
                    var _0x2e695a = _0x372d,
                        _0x5dba17;
                    return _0xaf4c50(this, _0x5bc923), (_0x5dba17 = _0x5e364a['apply'](this, arguments), _0x5dba17[_0x2e695a(0x2a4)] = new _0xdb1a4f(), _0x5dba17[_0x2e695a(0x441)] = 0x0, _0x5dba17['moveInKillRate'] = 0x0, _0x5dba17[_0x2e695a(0x449)] = 0x0, _0x5dba17[_0x2e695a(0x44a)] = 0x0, _0x5dba17[_0x2e695a(0x443)] = !0x0, _0x5dba17[_0x2e695a(0x42f)] = 0x0), _0x5dba17;
                }
                return _0x3f3356(_0x5bc923, [{
                        'key': 'onAwake',
                        'value': function _0x48fb4f() {
                            var _0x3176ea = _0x372d;
                            _0x58adf2(_0x5a6184(_0x5bc923[_0x3176ea(0x2e5)]), 'onAwake', this)[_0x3176ea(0x1f7)](this), _0x457d72['I']['randomHat'](this[_0x3176ea(0x3df)]);
                        }
                    },
                    {
                        'key': _0x48c8df(0x20c),
                        'value': function _0x2a17fa() {
                            var _0x5b2c97 = _0x48c8df;
                            fx[_0x5b2c97(0x294)][_0x5b2c97(0x203)][_0x5b2c97(0x295)](this);
                        }
                    },
                    {
                        'key': _0x48c8df(0x29c),
                        'value': function _0x36a363() {
                            var _0x371c57 = _0x48c8df,
                                _0x15acd2 = 0x10 / 0x3e8;
                            if (this[_0x371c57(0x3f3)](), this[_0x371c57(0x443)] && (this[_0x371c57(0x42f)] -= _0x15acd2, this['timestamp'] <= 0x0)) {
                                var _0x2326ff = fx['Utils'][_0x371c57(0x245)](-0x1, 0x1),
                                    _0x1f37f0 = fx[_0x371c57(0x1fb)][_0x371c57(0x245)](-0x1, 0x1);
                                this[_0x371c57(0x2a4)]['setValue'](_0x2326ff, _0x1f37f0), this[_0x371c57(0x42f)] = fx[_0x371c57(0x1fb)][_0x371c57(0x245)](0.5, 0x2), fx[_0x371c57(0x1fb)][_0x371c57(0x23f)](0.25) && (this['fsm']['blackBorad']['jump'] = !0x0), fx['Utils'][_0x371c57(0x23f)](0.2) && this[_0x371c57(0x2a4)][_0x371c57(0x2b4)](0x0, 0x0);
                            }
                            this[_0x371c57(0x3f2)][_0x371c57(0x3d2)][_0x371c57(0x2a4)]['from'](this['input']), _0x58adf2(_0x5a6184(_0x5bc923[_0x371c57(0x2e5)]), 'onUpdate', this)[_0x371c57(0x1f7)](this);
                        }
                    },
                    {
                        'key': _0x48c8df(0x2be),
                        'value': function _0x1d142a() {
                            var _0x56d12b = _0x48c8df;
                            _0x58adf2(_0x5a6184(_0x5bc923[_0x56d12b(0x2e5)]), _0x56d12b(0x2be), this)['call'](this), this[_0x56d12b(0x3f2)][_0x56d12b(0x3d2)][_0x56d12b(0x3d4)] = !0x1;
                        }
                    },
                    {
                        'key': _0x48c8df(0x445),
                        'value': function _0x41ebdd(_0x456703) {
                            var _0x2bff5a = _0x48c8df;
                            if (!this[_0x2bff5a(0x3f1)] && fx[_0x2bff5a(0x1fb)][_0x2bff5a(0x23f)](this[_0x2bff5a(0x442)])) {
                                this[_0x2bff5a(0x1fe)][_0x2bff5a(0x213)](this, this['startMove']);
                                var _0x4ebdcd = _0x456703 * fx['Utils'][_0x2bff5a(0x245)](0.1, 0x1);
                                this[_0x2bff5a(0x1fe)][_0x2bff5a(0x214)](0x3e8 * _0x4ebdcd, this, this[_0x2bff5a(0x446)]);
                            }
                        }
                    },
                    {
                        'key': 'onGhostBack',
                        'value': function _0xb46743(_0x2aebcd) {
                            var _0x5bc1f1 = _0x48c8df;
                            if (this[_0x5bc1f1(0x3f1)])
                                return;
                            this['owner'][_0x5bc1f1(0x213)](this, this[_0x5bc1f1(0x446)]), this[_0x5bc1f1(0x1fe)][_0x5bc1f1(0x213)](this, this['onStopInput']);
                            var _0x474139 = _0x2aebcd,
                                _0x3714ee = _0x2aebcd - (_0x474139 = fx['Utils'][_0x5bc1f1(0x23f)](this[_0x5bc1f1(0x49a)]) ? _0x2aebcd - fx[_0x5bc1f1(0x1fb)][_0x5bc1f1(0x245)](_0x2aebcd * this[_0x5bc1f1(0x448)][0x0], _0x2aebcd * this[_0x5bc1f1(0x448)][0x1]) : _0x2aebcd + fx['Utils'][_0x5bc1f1(0x245)](0.1 * _0x2aebcd, 0.2 * _0x2aebcd));
                            if (_0x3714ee > 0.1) {
                                var _0x3d5953 = _0x3714ee * fx[_0x5bc1f1(0x1fb)][_0x5bc1f1(0x245)](0x0, 0x1);
                                this[_0x5bc1f1(0x1fe)][_0x5bc1f1(0x214)](0x3e8 * _0x3d5953, this, this['startMove']);
                            } else
                                this[_0x5bc1f1(0x446)]();
                            this[_0x5bc1f1(0x1fe)][_0x5bc1f1(0x214)](0x3e8 * _0x474139, this, this['onStopInput']);
                        }
                    },
                    {
                        'key': _0x48c8df(0x446),
                        'value': function _0x5a45fb() {
                            var _0x206f6f = _0x48c8df;
                            if (!this['isDead']) {
                                if (this[_0x206f6f(0x44b)] = !0x0, this[_0x206f6f(0x449)] && fx[_0x206f6f(0x1fb)][_0x206f6f(0x23f)](this[_0x206f6f(0x449)]))
                                    this[_0x206f6f(0x2a4)][_0x206f6f(0x2b4)](0x0, 0x0);
                                else {
                                    if (this['changeDirRate'] && fx['Utils'][_0x206f6f(0x23f)](this['changeDirRate'])) {
                                        var _0x38b58d = fx[_0x206f6f(0x1fb)]['getNumberRandom'](-0.5, 0.5);
                                        this[_0x206f6f(0x2a4)]['setValue'](_0x38b58d, -0x1);
                                    } else
                                        this[_0x206f6f(0x2a4)][_0x206f6f(0x2b4)](0x0, -0x1);
                                    this[_0x206f6f(0x44a)] && fx['Utils'][_0x206f6f(0x23f)](this['jumpRate']) && (this[_0x206f6f(0x3f2)][_0x206f6f(0x3d2)][_0x206f6f(0x3d4)] = !0x0);
                                }
                            }
                        }
                    },
                    {
                        'key': _0x48c8df(0x501),
                        'value': function _0x2314ea() {
                            var _0x5100e2 = _0x48c8df;
                            this[_0x5100e2(0x44b)] = !0x1, this[_0x5100e2(0x2a4)][_0x5100e2(0x2b4)](0x0, 0x0), this[_0x5100e2(0x3fb)]();
                        }
                    },
                    {
                        'key': 'setCountdown',
                        'value': function _0x5d53d8(_0x525332) {
                            var _0xb9409b = _0x48c8df,
                                _0x104b4f = this,
                                _0x3744d0 = fx[_0xb9409b(0x1fb)][_0xb9409b(0x245)](this['countdownRange'][0x0], this[_0xb9409b(0x44d)][0x1]);
                            this[_0xb9409b(0x1fe)][_0xb9409b(0x214)](_0x525332 * _0x3744d0 * 0x3e8, this, function() {
                                var _0x21f20b = _0xb9409b;
                                _0x104b4f[_0x21f20b(0x443)] = !0x1, _0x104b4f['input'][_0x21f20b(0x2b4)](0x0, -0x1);
                            });
                        }
                    }
                ]), _0x5bc923;
            }(_0x500c49),
            _0x5291cf = function() {
                var _0x3155f4 = _0x28eca3;

                function _0x1e5e19(_0x3d5988) {
                    var _0x48afbc = _0x372d;
                    _0xaf4c50(this, _0x1e5e19), this[_0x48afbc(0x502)] = _0x3d5988;
                }
                return _0x3f3356(_0x1e5e19, [{
                        'key': 'init',
                        'value': function _0x594c21() {
                            var _0x4072ac = _0x372d,
                                _0x159e9f = this[_0x4072ac(0x503)]();
                            if (_0x159e9f)
                                for (var _0x207fa7 in this) {
                                    if (this[_0x4072ac(0x504)](_0x207fa7)) {
                                        var _0x52f794 = _0x159e9f[_0x207fa7];
                                        null != _0x52f794 && '' !== _0x52f794 && (this[_0x207fa7] = _0x52f794);
                                    }
                                }
                        }
                    },
                    {
                        'key': _0x3155f4(0x503),
                        'value': function _0xd44174() {
                            var _0x2a630f = _0x3155f4,
                                _0x569d78 = Laya['LocalStorage'][_0x2a630f(0x237)](this[_0x2a630f(0x502)]);
                            return _0x569d78 ? _0x569d78 instanceof Object ? _0x569d78 : JSON[_0x2a630f(0x505)](_0x569d78) : null;
                        }
                    },
                    {
                        'key': _0x3155f4(0x225),
                        'value': function _0x2d7fa4(_0x387fc6) {
                            var _0xcfa5bd = _0x3155f4;
                            Laya[_0xcfa5bd(0x506)]['I'][_0xcfa5bd(0x463)](this, this[_0xcfa5bd(0x507)]);
                        }
                    },
                    {
                        'key': _0x3155f4(0x227),
                        'value': function _0x53cd56(_0x207a15) {
                            var _0x1594e6 = _0x3155f4;
                            this[_0x1594e6(0x225)](_0x207a15);
                        }
                    },
                    {
                        'key': _0x3155f4(0x507),
                        'value': function _0x105ad2() {
                            this['saveToLocal']();
                        }
                    },
                    {
                        'key': _0x3155f4(0x508),
                        'value': function _0x31ec38() {
                            var _0x545eac = _0x3155f4;
                            Laya[_0x545eac(0x4c1)][_0x545eac(0x48a)](this[_0x545eac(0x502)], this);
                        }
                    }
                ]), _0x1e5e19;
            }(),
            _0x1e6512 = function _0x1476fd() {
                _0xaf4c50(this, _0x1476fd);
            },
            _0x1fba92 = {
                'PowerChange': _0x28eca3(0x509)
            },
            _0x2793d0 = function(_0xb4d996) {
                _0x10ff6e(_0x2e3ceb, _0xb4d996);
                var _0x272520 = _0x30529b(_0x2e3ceb);

                function _0x2e3ceb() {
                    var _0x1d2aac = _0x372d,
                        _0x5c8c35;
                    return _0xaf4c50(this, _0x2e3ceb), (_0x5c8c35 = _0x272520['call'](this, _0x1d2aac(0x50a)), _0x5c8c35[_0x1d2aac(0x2f9)] = 0x5, _0x5c8c35[_0x1d2aac(0x50b)] = 0x0, _0x5c8c35[_0x1d2aac(0x50c)] = 0x0, fx[_0x1d2aac(0x1fb)][_0x1d2aac(0x50d)](_0x142038(_0x5c8c35), _0x5c8c35[_0x1d2aac(0x225)])), _0x5c8c35;
                }
                return _0x2e3ceb;
            }(_0x5291cf),
            _0x1f5896 = function(_0x59ba3a) {
                var _0x5ae865 = _0x28eca3;
                _0x10ff6e(_0xecb9c1, _0x59ba3a);
                var _0x11c773 = _0x30529b(_0xecb9c1);

                function _0xecb9c1() {
                    var _0x312328 = _0x372d,
                        _0x2aa02b;
                    _0xaf4c50(this, _0xecb9c1), (_0x2aa02b = _0x11c773['call'](this), _0x2aa02b[_0x312328(0x50e)] = new _0x2793d0(), _0x2aa02b[_0x312328(0x50e)][_0x312328(0x270)](), fx['UserLogic']['instance']['isNewDay']() && (_0x2aa02b[_0x312328(0x50e)]['videoNum'] = 0x0), _0x2aa02b['isFull']() && (_0x2aa02b['data'][_0x312328(0x50b)] = 0x0));
                    var _0x5b488d = Date[_0x312328(0x50f)]() / 0x3e8;
                    if (_0x2aa02b[_0x312328(0x50e)][_0x312328(0x50b)]) {
                        var _0x22e0db = _0x2aa02b[_0x312328(0x50e)]['powerStartTime'],
                            _0x4925e6 = _0x5b488d - _0x22e0db,
                            _0xb1860d = Math[_0x312328(0x3b3)](_0x4925e6 / _0x2aa02b[_0x312328(0x510)]);
                        _0xb1860d > 0x0 && _0x2aa02b[_0x312328(0x511)](_0xb1860d), _0x2aa02b['isFull']() ? _0x2aa02b[_0x312328(0x50e)][_0x312328(0x50b)] = 0x0 : _0x2aa02b[_0x312328(0x50e)][_0x312328(0x50b)] = _0x22e0db + _0xb1860d * _0x2aa02b['recoverTime'];
                    } else
                        _0x2aa02b[_0x312328(0x50e)]['power'] <= 0x0 && (_0x2aa02b[_0x312328(0x50e)][_0x312328(0x2f9)] = 0x0, _0x2aa02b[_0x312328(0x50e)][_0x312328(0x50b)] = _0x5b488d);
                    return Laya['timer'][_0x312328(0x512)](0x3e8, _0x142038(_0x2aa02b), _0x2aa02b[_0x312328(0x3b8)]), _0x2aa02b;
                }
                return _0x3f3356(_0xecb9c1, [{
                        'key': 'maxPower',
                        'get': function _0x332ab6() {
                            return 0x5;
                        }
                    },
                    {
                        'key': 'maxVideo',
                        'get': function _0x2d8652() {
                            return 0x3;
                        }
                    },
                    {
                        'key': _0x5ae865(0x513),
                        'get': function _0x1241c8() {
                            return 0x5;
                        }
                    },
                    {
                        'key': _0x5ae865(0x510),
                        'get': function _0xce0b0e() {
                            return 0x168;
                        }
                    },
                    {
                        'key': 'isInfinity',
                        'value': function _0x571df() {
                            var _0x8899cd = _0x5ae865;
                            return this[_0x8899cd(0x50e)][_0x8899cd(0x50c)] >= this[_0x8899cd(0x514)];
                        }
                    },
                    {
                        'key': _0x5ae865(0x515),
                        'value': function _0x417de2() {
                            var _0x2d3f1f = _0x5ae865;
                            return !!this[_0x2d3f1f(0x516)]() || this['data'][_0x2d3f1f(0x2f9)] >= this[_0x2d3f1f(0x517)];
                        }
                    },
                    {
                        'key': _0x5ae865(0x511),
                        'value': function _0x1f962e(_0x3a716a) {
                            var _0x36ae87 = _0x5ae865;
                            this[_0x36ae87(0x50e)][_0x36ae87(0x2f9)] >= this[_0x36ae87(0x517)] || (this[_0x36ae87(0x50e)]['power'] += _0x3a716a, this[_0x36ae87(0x50e)][_0x36ae87(0x2f9)] = Math[_0x36ae87(0x360)](this[_0x36ae87(0x50e)]['power'], this['maxPower']), this['isFull']() ? this[_0x36ae87(0x50e)][_0x36ae87(0x50b)] = 0x0 : this[_0x36ae87(0x50e)]['powerStartTime'] = Date[_0x36ae87(0x50f)]() / 0x3e8, fx[_0x36ae87(0x294)][_0x36ae87(0x203)][_0x36ae87(0x261)](_0x1fba92[_0x36ae87(0x518)], [!0x0]));
                        }
                    },
                    {
                        'key': _0x5ae865(0x519),
                        'value': function _0x560bd9(_0x298d8f) {
                            var _0x7f5dd0 = _0x5ae865;
                            return !!this[_0x7f5dd0(0x516)]() || !(this['data'][_0x7f5dd0(0x2f9)] < _0x298d8f) && (this[_0x7f5dd0(0x50e)][_0x7f5dd0(0x2f9)] -= _0x298d8f, this[_0x7f5dd0(0x50e)][_0x7f5dd0(0x2f9)] < this[_0x7f5dd0(0x517)] && (this['data'][_0x7f5dd0(0x50b)] = Date['now']() / 0x3e8), fx[_0x7f5dd0(0x294)][_0x7f5dd0(0x203)][_0x7f5dd0(0x261)](_0x1fba92[_0x7f5dd0(0x518)], [!0x1]), !0x0);
                        }
                    },
                    {
                        'key': _0x5ae865(0x51a),
                        'value': function _0x46bfd3(_0x322127) {
                            var _0x505385 = _0x5ae865;
                            return !!this[_0x505385(0x516)]() || !(this['data'][_0x505385(0x2f9)] < _0x322127);
                        }
                    },
                    {
                        'key': 'addPowerByVideo',
                        'value': function _0x8cfe0f() {
                            var _0x542894 = _0x5ae865;
                            this[_0x542894(0x50e)]['videoNum']++, this[_0x542894(0x50e)]['videoNum'] < this[_0x542894(0x514)] && (this[_0x542894(0x50e)]['power'] += this[_0x542894(0x513)]), this[_0x542894(0x515)]() && (this['data']['powerStartTime'] = 0x0), fx[_0x542894(0x294)]['instance'][_0x542894(0x261)](_0x1fba92[_0x542894(0x518)], [!0x0]);
                        }
                    },
                    {
                        'key': _0x5ae865(0x3b8),
                        'value': function _0x313305() {
                            var _0x36a9ca = _0x5ae865,
                                _0x531313 = Date[_0x36a9ca(0x50f)]() / 0x3e8;
                            !this[_0x36a9ca(0x515)]() && this[_0x36a9ca(0x50e)][_0x36a9ca(0x50b)] && (_0x531313 - this[_0x36a9ca(0x50e)]['powerStartTime'] > this[_0x36a9ca(0x510)] && this[_0x36a9ca(0x511)](0x1));
                        }
                    }
                ]), _0xecb9c1;
            }(_0x1e6512),
            _0x5c9919 = function() {
                var _0x44d344 = _0x28eca3;

                function _0x5bbd12() {
                    var _0x5a3f6c = _0x372d;
                    _0xaf4c50(this, _0x5bbd12), this[_0x5a3f6c(0x51b)] = new _0x1f5896();
                }
                return _0x3f3356(_0x5bbd12, [{
                    'key': _0x44d344(0x51c),
                    'get': function _0x318e1b() {
                        var _0x28f587 = _0x44d344;
                        return this[_0x28f587(0x51b)];
                    }
                }], [{
                    'key': 'I',
                    'get': function _0x536c22() {
                        var _0x2e1efd = _0x44d344;
                        return this[_0x2e1efd(0x233)] || (this[_0x2e1efd(0x233)] = new _0x5bbd12()), this[_0x2e1efd(0x233)];
                    }
                }]), _0x5bbd12;
            }(),
            _0x11e161 = function() {
                var _0xa08a75 = _0x28eca3;

                function _0x1073bf() {
                    var _0x24dd18 = _0x372d;
                    _0xaf4c50(this, _0x1073bf), (this[_0x24dd18(0x51d)] = -0x22b8, this[_0x24dd18(0x51e)] = void 0x0, this[_0x24dd18(0x51f)](), fx['EventCenter']['instance']['on'](fx[_0x24dd18(0x466)][_0x24dd18(0x520)], this, this[_0x24dd18(0x521)]), fx['EventCenter'][_0x24dd18(0x203)]['on'](fx[_0x24dd18(0x466)][_0x24dd18(0x522)], this, this[_0x24dd18(0x523)]));
                }
                return _0x3f3356(_0x1073bf, [{
                        'key': _0xa08a75(0x51f),
                        'value': function _0x4248dd() {
                            var _0x273698 = _0xa08a75;
                            this['_videoStrategyInst'] = fx[_0x273698(0x231)][_0x273698(0x203)][_0x273698(0x524)](), this['_videoGainWayParams'] = new fx['RewardGainWayParams']({
                                'source': '',
                                'bindCtrlGId': this[_0x273698(0x51d)],
                                'id': fx[_0x273698(0x231)][_0x273698(0x203)]['getVideoId'](),
                                'forever': !0x1
                            }), this['_videoStrategyInst'][_0x273698(0x525)](fx[_0x273698(0x526)][_0x273698(0x527)], this[_0x273698(0x528)]);
                        }
                    },
                    {
                        'key': 'onRewardGain',
                        'value': function _0x5463ab(_0x43e4d0) {
                            var _0x359998 = _0xa08a75;
                            _0x43e4d0[_0x359998(0x529)] == fx[_0x359998(0x526)][_0x359998(0x527)] && _0x43e4d0[_0x359998(0x52a)] == this[_0x359998(0x51d)] && this['onVideoComplete'](_0x43e4d0);
                        }
                    },
                    {
                        'key': _0xa08a75(0x52b),
                        'value': function _0x29225d(_0x510a75, _0x43ecb3, _0x43c080, _0x17b08e) {
                            var _0x429d8b = _0xa08a75;
                            platform[_0x429d8b(0x451)]()[_0x429d8b(0x52c)](() => {
                                var _0x4e8759 = _0x429d8b;
                                _0x43c080 && _0x43c080[_0x4e8759(0x304)](_0x43ecb3)(!![]);
                            }, () => {
                                var _0x4c9b51 = _0x429d8b;
                                _0x43c080 && _0x43c080[_0x4c9b51(0x304)](_0x43ecb3)(![]);
                            });
                        }
                    },
                    {
                        'key': _0xa08a75(0x52d),
                        'value': function _0x1c5d7b(_0x5cbf89) {
                            var _0x31a109 = _0xa08a75;
                            if (this['_videoCaller'] && this[_0x31a109(0x52e)]) {
                                var _0x2a8974 = _0x5cbf89[_0x31a109(0x467)] == fx['SdkCode'][_0x31a109(0x52f)];
                                this[_0x31a109(0x530)][_0x31a109(0x290)](_0x2a8974), this[_0x31a109(0x52e)][_0x31a109(0x1f4)](this[_0x31a109(0x531)], this['_videoCbParam']);
                            }
                            this[_0x31a109(0x531)] = null, this[_0x31a109(0x52e)] = nurell, this[_0x31a109(0x530)] = null;
                        }
                    },
                    {
                        'key': 'shareVideo',
                        'value': function _0x197f86(_0x399e50, _0x3833c4, _0x2c2e1c) {
                            var _0x17cd3d = _0xa08a75;
                            this[_0x17cd3d(0x532)] = _0x399e50, this['_shareCallBack'] = _0x3833c4, this['_shareCbParam'] = _0x2c2e1c, fx['Sdk'][_0x17cd3d(0x533)]() ? this['onShareComplete']({
                                'code': fx[_0x17cd3d(0x468)][_0x17cd3d(0x534)]
                            }) : fx['Sdk']['instance'][_0x17cd3d(0x46c)]();
                        }
                    },
                    {
                        'key': _0xa08a75(0x523),
                        'value': function _0x1e4f1e(_0x40679f) {
                            var _0x3ca1b7 = _0xa08a75;
                            if (this[_0x3ca1b7(0x532)] && this['_shareCallBack']) {
                                var _0x964911 = _0x40679f[_0x3ca1b7(0x467)] == fx[_0x3ca1b7(0x468)][_0x3ca1b7(0x534)];
                                this[_0x3ca1b7(0x535)][_0x3ca1b7(0x290)](_0x964911), this[_0x3ca1b7(0x536)][_0x3ca1b7(0x1f4)](this[_0x3ca1b7(0x532)], [this[_0x3ca1b7(0x535)]]);
                            }
                            this[_0x3ca1b7(0x532)] = null, this[_0x3ca1b7(0x536)] = null, this[_0x3ca1b7(0x535)] = null;
                        }
                    },
                    {
                        'key': _0xa08a75(0x537),
                        'value': function _0x45ccd6(_0x3a0a7c) {
                            var _0x35c95e = _0xa08a75;
                            fx['Sdk'][_0x35c95e(0x203)][_0x35c95e(0x537)](_0x3a0a7c);
                        }
                    },
                    {
                        'key': _0xa08a75(0x230),
                        'value': function _0x1c7594() {
                            var _0x41aa11 = _0xa08a75;
                            fx[_0x41aa11(0x231)][_0x41aa11(0x203)][_0x41aa11(0x230)](null, !0x0);
                        }
                    }
                ], [{
                    'key': 'instance',
                    'get': function _0x3fba20() {
                        var _0x596079 = _0xa08a75;
                        return this[_0x596079(0x233)] || (this[_0x596079(0x233)] = new _0x1073bf()), this[_0x596079(0x233)];
                    }
                }]), _0x1073bf;
            }(),
            _0x56a64b = function(_0x86b651) {
                var _0x4289e3 = _0x28eca3;
                _0x10ff6e(_0x1bbe39, _0x86b651);
                var _0x1941ac = _0x30529b(_0x1bbe39);

                function _0x1bbe39(_0x26f2cf, _0x12134f) {
                    var _0x10df4b;
                    return _0xaf4c50(this, _0x1bbe39), (_0x10df4b = _0x1941ac['call'](this), _0x10df4b['cb'] = _0x12134f), _0x10df4b;
                }
                return _0x3f3356(_0x1bbe39, [{
                        'key': _0x4289e3(0x44e),
                        'value': function _0x14e6ef() {
                            var _0x44c3fe = _0x4289e3;
                            this['img_close']['on'](Laya[_0x44c3fe(0x2ac)][_0x44c3fe(0x450)], this, this[_0x44c3fe(0x538)], [!0x1]), this[_0x44c3fe(0x539)]['on'](Laya[_0x44c3fe(0x2ac)][_0x44c3fe(0x450)], this, this[_0x44c3fe(0x538)], [!0x1]), this[_0x44c3fe(0x53a)]['on'](Laya[_0x44c3fe(0x2ac)][_0x44c3fe(0x450)], this, this[_0x44c3fe(0x53b)]), this[_0x44c3fe(0x293)](), fx[_0x44c3fe(0x294)][_0x44c3fe(0x203)]['on'](_0x1fba92[_0x44c3fe(0x518)], this, this[_0x44c3fe(0x293)]);
                        }
                    },
                    {
                        'key': _0x4289e3(0x20c),
                        'value': function _0x3b87c9() {
                            var _0x520866 = _0x4289e3;
                            fx['EventCenter'][_0x520866(0x203)][_0x520866(0x295)](this);
                        }
                    },
                    {
                        'key': _0x4289e3(0x53b),
                        'value': function _0x13a595() {
                            var _0x57da0d = _0x4289e3,
                                _0x16e149 = this;
                            _0x5c9919['I']['Power'][_0x57da0d(0x516)]() ? null : _0x11e161[_0x57da0d(0x203)][_0x57da0d(0x52b)](_0x57da0d(0x53c), this, function(_0x4d3c70) {
                                var _0x3f6c96 = _0x57da0d;
                                _0x4d3c70 && (_0x5c9919['I'][_0x3f6c96(0x51c)][_0x3f6c96(0x53d)](), _0x16e149[_0x3f6c96(0x293)](), _0x16e149['closeSelf'](!0x0));
                            });
                        }
                    },
                    {
                        'key': _0x4289e3(0x293),
                        'value': function _0x9634ab() {
                            var _0x254dfb = _0x4289e3,
                                _0x48bb83 = _0x5c9919['I'][_0x254dfb(0x51c)][_0x254dfb(0x516)](),
                                _0x32df60 = _0x5c9919['I'][_0x254dfb(0x51c)][_0x254dfb(0x50e)][_0x254dfb(0x50c)],
                                _0x876a18 = _0x5c9919['I'][_0x254dfb(0x51c)][_0x254dfb(0x514)];
                            _0x48bb83 || _0x32df60 >= _0x876a18 - 0x1 ? (this[_0x254dfb(0x53e)][_0x254dfb(0x210)] = '无限', this[_0x254dfb(0x53f)][_0x254dfb(0x210)] = '无限') : (this[_0x254dfb(0x53e)][_0x254dfb(0x210)] = 'x' + _0x5c9919['I'][_0x254dfb(0x51c)][_0x254dfb(0x513)], this['label_video']['text'] = '' [_0x254dfb(0x296)](_0x876a18 - _0x32df60, '/')[_0x254dfb(0x296)](_0x876a18));
                        }
                    },
                    {
                        'key': _0x4289e3(0x538),
                        'value': function _0x4901d2() {
                            var _0x10d562 = _0x4289e3,
                                _0x2aedc0 = arguments[_0x10d562(0x27c)] > 0x0 && arguments[0x0] !== undefined ? arguments[0x0] : !0x1,
                                _0x3a9261 = this['cb'];
                            fx['SceneManager'][_0x10d562(0x453)](this), _0x3a9261 && _0x3a9261[_0x10d562(0x540)](_0x2aedc0);
                        }
                    }
                ]), _0x1bbe39;
            }(_0x118985[_0x28eca3(0x2f2)][_0x28eca3(0x2f9)][_0x28eca3(0x2f7)]),
            _0x53f643 = function(_0x572428) {
                var _0x1bb25c = _0x28eca3;
                _0x10ff6e(_0x4d798c, _0x572428);
                var _0x1878b1 = _0x30529b(_0x4d798c);

                function _0x4d798c() {
                    var _0x163d52 = _0x372d,
                        _0x4f40e3;
                    return _0xaf4c50(this, _0x4d798c), (_0x4f40e3 = _0x1878b1[_0x163d52(0x1f4)](this, arguments), _0x4f40e3[_0x163d52(0x407)] = new _0x31f777(), _0x4f40e3[_0x163d52(0x402)] = new Laya['Quaternion'](), _0x4f40e3[_0x163d52(0x403)] = 0x0, _0x4f40e3[_0x163d52(0x404)] = 0.15), _0x4f40e3;
                }
                return _0x3f3356(_0x4d798c, [{
                        'key': 'onAwake',
                        'value': function _0x3bba21() {
                            var _0x56c09d = _0x372d;
                            _0x58adf2(_0x5a6184(_0x4d798c[_0x56c09d(0x2e5)]), 'onAwake', this)[_0x56c09d(0x1f7)](this), this[_0x56c09d(0x405)] = this['owner'][_0x56c09d(0x209)](_0x56c09d(0x406));
                            var _0x583c4f = _0x29989c[_0x56c09d(0x203)]['getGameConstants']();
                            this['moveSpeed'] = _0x583c4f[_0x56c09d(0x541)], this[_0x56c09d(0x3e6)] = _0x583c4f[_0x56c09d(0x542)], this[_0x56c09d(0x3ea)][_0x56c09d(0x543)](new _0x31f777(0x0, _0x583c4f[_0x56c09d(0x544)], 0x0));
                        }
                    },
                    {
                        'key': _0x1bb25c(0x270),
                        'value': function _0x79f582(_0x36fb08) {
                            var _0x49697b = _0x1bb25c;
                            this[_0x49697b(0x2a4)] = _0x36fb08, this[_0x49697b(0x3f2)][_0x49697b(0x3d2)][_0x49697b(0x3d8)] = !0x0;
                        }
                    },
                    {
                        'key': _0x1bb25c(0x29c),
                        'value': function _0x1096ba() {
                            var _0x5c10c9 = _0x1bb25c;
                            this[_0x5c10c9(0x403)] += this[_0x5c10c9(0x2a4)][_0x5c10c9(0x2c5)][_0x5c10c9(0x2bf)]() * this[_0x5c10c9(0x404)], this['cameraPivot'][_0x5c10c9(0x32a)][_0x5c10c9(0x436)] = this[_0x5c10c9(0x403)], Laya[_0x5c10c9(0x3f8)][_0x5c10c9(0x42a)](_0x31f777['Up'], Math['PI'] * this['horizontalAngle'] / 0xb4, this[_0x5c10c9(0x402)]), this['tempV3'][_0x5c10c9(0x2b4)](this[_0x5c10c9(0x2a4)][_0x5c10c9(0x2c3)][_0x5c10c9(0x2a4)]['x'], 0x0, this[_0x5c10c9(0x2a4)][_0x5c10c9(0x2c3)][_0x5c10c9(0x2a4)]['y']), _0x31f777[_0x5c10c9(0x42b)](this[_0x5c10c9(0x407)], this[_0x5c10c9(0x402)], this['tempV3']), this[_0x5c10c9(0x3f2)][_0x5c10c9(0x3d2)]['input'][_0x5c10c9(0x2b4)](this[_0x5c10c9(0x407)]['x'], this['tempV3']['z']), this[_0x5c10c9(0x3f3)](), this[_0x5c10c9(0x3da)] && this[_0x5c10c9(0x2a4)]['moveInput'][_0x5c10c9(0x3d4)] ? this[_0x5c10c9(0x3f2)][_0x5c10c9(0x3d2)][_0x5c10c9(0x3d4)] = !0x0 : this[_0x5c10c9(0x3f2)][_0x5c10c9(0x3d2)][_0x5c10c9(0x3d4)] = !0x1, _0x58adf2(_0x5a6184(_0x4d798c[_0x5c10c9(0x2e5)]), _0x5c10c9(0x29c), this)[_0x5c10c9(0x1f7)](this);
                        }
                    },
                    {
                        'key': 'onDead',
                        'value': function _0x4ac6c6() {
                            var _0x13abbd = _0x1bb25c;
                            _0x58adf2(_0x5a6184(_0x4d798c[_0x13abbd(0x2e5)]), _0x13abbd(0x400), this)[_0x13abbd(0x1f7)](this), _0x29989c['instance']['setGameState'](_0x4d7387[_0x13abbd(0x1e7)]);
                        }
                    }
                ]), _0x4d798c;
            }(_0x500c49),
            _0x6d85d8 = function(_0x29d966) {
                var _0x3eddcc = _0x28eca3;
                _0x10ff6e(_0x4fd22a, _0x29d966);
                var _0x47f29c = _0x30529b(_0x4fd22a);

                function _0x4fd22a() {
                    var _0x525dc9 = _0x372d,
                        _0x5af4a6;
                    return _0xaf4c50(this, _0x4fd22a), (_0x5af4a6 = _0x47f29c[_0x525dc9(0x1f4)](this, arguments), _0x5af4a6[_0x525dc9(0x2a4)] = new _0xdb1a4f(), _0x5af4a6['changeDirRate'] = 0x0, _0x5af4a6[_0x525dc9(0x449)] = 0x0, _0x5af4a6['jumpRate'] = 0x0, _0x5af4a6['free'] = !0x1, _0x5af4a6[_0x525dc9(0x42f)] = 0x0, _0x5af4a6[_0x525dc9(0x545)] = 0x1, _0x5af4a6[_0x525dc9(0x546)] = new _0x31f777(0x0, -0x1, 0x0), _0x5af4a6['canAdvance'] = !0x1, _0x5af4a6['waitTime'] = 0x0), _0x5af4a6;
                }
                return _0x3f3356(_0x4fd22a, [{
                        'key': _0x3eddcc(0x1fa),
                        'value': function _0x4e9cce() {
                            var _0x14a89e = _0x3eddcc;
                            _0x58adf2(_0x5a6184(_0x4fd22a[_0x14a89e(0x2e5)]), _0x14a89e(0x1fa), this)[_0x14a89e(0x1f7)](this), _0x457d72['I'][_0x14a89e(0x23b)](this['ownerSp']), this['getTarPos'] = [], this['getGlassArr'] = [], this[_0x14a89e(0x547)](), this[_0x14a89e(0x548)]();
                            var _0x54973a = _0x29989c[_0x14a89e(0x203)][_0x14a89e(0x260)]();
                            this['moveSpeed'] = _0x54973a['GB_MoveSpeed'], this[_0x14a89e(0x3e6)] = _0x54973a[_0x14a89e(0x542)], this[_0x14a89e(0x3ea)][_0x14a89e(0x543)](new _0x31f777(0x0, _0x54973a[_0x14a89e(0x544)], 0x0)), fx['EventCenter']['instance']['on'](_0x561c5d[_0x14a89e(0x549)], this, this[_0x14a89e(0x54a)]);
                        }
                    },
                    {
                        'key': _0x3eddcc(0x20c),
                        'value': function _0x133ac4() {
                            var _0xeb65d2 = _0x3eddcc;
                            fx['EventCenter'][_0xeb65d2(0x203)]['offAllCaller'](this);
                        }
                    },
                    {
                        'key': _0x3eddcc(0x29c),
                        'value': function _0x4086e0() {
                            var _0x5061a5 = _0x3eddcc;
                            if (this[_0x5061a5(0x3f1)])
                                return;
                            var _0x3f47f3 = this[_0x5061a5(0x1fe)]['timer'][_0x5061a5(0x54b)];
                            this[_0x5061a5(0x3f3)](), this[_0x5061a5(0x54c)]() ? (this['stopMove'](), this['fsm'][_0x5061a5(0x3d2)][_0x5061a5(0x3d4)] = !0x0) : this['free'] && (this[_0x5061a5(0x54d)](), this['waitTime'] > 0x0 ? (this[_0x5061a5(0x54e)] -= _0x3f47f3, this['waitTime'] = Math[_0x5061a5(0x28c)](this[_0x5061a5(0x54e)], 0x0), 0x0 != this[_0x5061a5(0x54e)] || this['canAdvance'] || this[_0x5061a5(0x54f)]()) : this[_0x5061a5(0x550)] ? this['goToTarPos']() : this[_0x5061a5(0x3da)] ? (this[_0x5061a5(0x3fb)](), this[_0x5061a5(0x548)]()) : this['goToTarPos']()), this[_0x5061a5(0x3f2)]['blackBorad'][_0x5061a5(0x2a4)][_0x5061a5(0x329)](this[_0x5061a5(0x2a4)]), _0x58adf2(_0x5a6184(_0x4fd22a[_0x5061a5(0x2e5)]), _0x5061a5(0x29c), this)['call'](this);
                        }
                    },
                    {
                        'key': 'onLateUpdate',
                        'value': function _0x204a8a() {
                            var _0x2fe1ab = _0x3eddcc;
                            _0x58adf2(_0x5a6184(_0x4fd22a[_0x2fe1ab(0x2e5)]), _0x2fe1ab(0x2be), this)[_0x2fe1ab(0x1f7)](this), this[_0x2fe1ab(0x3f2)]['blackBorad'][_0x2fe1ab(0x3d4)] = !0x1;
                        }
                    },
                    {
                        'key': _0x3eddcc(0x54d),
                        'value': function _0x21f756() {
                            var _0x3ab382 = _0x3eddcc,
                                _0x261a78 = this[_0x3ab382(0x3df)]['transform'][_0x3ab382(0x32d)],
                                _0x4884d9 = this[_0x3ab382(0x34f)];
                            _0x4884d9['from'](_0x261a78), _0x4884d9['y'] += this[_0x3ab382(0x545)];
                            var _0x1614e9 = new _0x31f777();
                            this['transform']['getForward'](_0x1614e9), _0x31f777[_0x3ab382(0x2bb)](_0x1614e9, -0.5, _0x1614e9), _0x31f777[_0x3ab382(0x336)](_0x4884d9, _0x1614e9, _0x4884d9);
                            var _0x468c8b = this[_0x3ab382(0x546)];
                            _0x468c8b[_0x3ab382(0x2b4)](0x0, -0x1, 0x0), this[_0x3ab382(0x551)] || (this['ray'] = new Laya[(_0x3ab382(0x3f4))](_0x4884d9, _0x468c8b));
                            var _0x18b9c5 = this[_0x3ab382(0x551)];
                            _0x18b9c5[_0x3ab382(0x552)] = _0x4884d9, _0x18b9c5[_0x3ab382(0x553)] = _0x468c8b;
                            var _0x290181 = this[_0x3ab382(0x1fe)][_0x3ab382(0x4cf)];
                            this[_0x3ab382(0x3dd)]['succeeded'] = !0x1, _0x290181[_0x3ab382(0x302)]['rayCast'](_0x18b9c5, this[_0x3ab382(0x3dd)], 0xa, _0x134368[_0x3ab382(0x1f0)], _0x134368[_0x3ab382(0x1ef)]), this[_0x3ab382(0x550)] = this[_0x3ab382(0x3dd)]['succeeded'];
                        }
                    },
                    {
                        'key': _0x3eddcc(0x554),
                        'value': function _0x112af9() {
                            var _0xe19734 = _0x3eddcc,
                                _0x8c2954 = this['curTarPos'],
                                _0x4a28b5 = this['transform']['position'];
                            if (this[_0xe19734(0x555)]()) {
                                if (this[_0xe19734(0x2a4)][_0xe19734(0x2b4)](0x0, 0x0), this[_0xe19734(0x556)](_0x8c2954[_0xe19734(0x32e)]())) {
                                    var _0xfc93c = _0x178e83['I'][_0xe19734(0x557)](_0x8c2954);
                                    this['addTargetPosArr'](_0xfc93c), this[_0xe19734(0x547)]();
                                }
                            } else
                                this[_0xe19734(0x2a4)]['setValue'](_0x4a28b5['x'] - _0x8c2954['x'], _0x4a28b5['z'] - _0x8c2954['z']);
                        }
                    },
                    {
                        'key': _0x3eddcc(0x54f),
                        'value': function _0x3f995d() {
                            var _0x1f76f4 = _0x3eddcc;
                            this[_0x1f76f4(0x3da)] && (this[_0x1f76f4(0x3f2)][_0x1f76f4(0x3d2)]['jump'] = !0x0);
                        }
                    },
                    {
                        'key': _0x3eddcc(0x555),
                        'value': function _0x3695c7() {
                            var _0x90f281 = _0x3eddcc,
                                _0x23d609 = this[_0x90f281(0x558)],
                                _0x5d81d3 = this[_0x90f281(0x32a)][_0x90f281(0x32d)];
                            return Math[_0x90f281(0x4b9)](_0x23d609['x'] - _0x5d81d3['x']) < 0.2 && Math[_0x90f281(0x4b9)](_0x23d609['z'] - _0x5d81d3['z']) < 0.2;
                        }
                    },
                    {
                        'key': _0x3eddcc(0x547),
                        'value': function _0x5bb552() {
                            var _0xc70fe4 = _0x3eddcc,
                                _0x5ad220 = _0x178e83['I'][_0xc70fe4(0x559)],
                                _0x5a56b5 = this[_0xc70fe4(0x32a)][_0xc70fe4(0x32d)],
                                _0x588677 = 0x1 / 0x0,
                                _0x400fc3 = -0x1;
                            for (var _0x46d434 = 0x0; _0x46d434 < _0x5ad220['length']; ++_0x46d434) {
                                var _0xcc19f = _0x5ad220[_0x46d434],
                                    _0x336cef = !0x1,
                                    _0x106c49 = _0x523788(this[_0xc70fe4(0x55a)]),
                                    _0x1c1c56;
                                try {
                                    for (_0x106c49['s'](); !(_0x1c1c56 = _0x106c49['n']())[_0xc70fe4(0x288)];) {
                                        var _0xa36b7d = _0x1c1c56[_0xc70fe4(0x289)];
                                        if (_0x31f777[_0xc70fe4(0x55b)](_0xa36b7d, _0xcc19f)) {
                                            _0x336cef = !0x0;
                                            break;
                                        }
                                    }
                                } catch (_0x2db5ed) {
                                    _0x106c49['e'](_0x2db5ed);
                                } finally {
                                    _0x106c49['f']();
                                }
                                if (_0x336cef)
                                    continue;
                                var _0x20988d = _0x31f777['distanceSquared'](_0xcc19f, _0x5a56b5);
                                _0x20988d < _0x588677 && (_0x588677 = _0x20988d, _0x400fc3 = _0x46d434);
                            }
                            this[_0xc70fe4(0x558)] = _0x5ad220[_0x400fc3], this[_0xc70fe4(0x558)] ? fx['Utils'][_0xc70fe4(0x23f)](0.5) && (this[_0xc70fe4(0x558)] = _0x178e83['I'][_0xc70fe4(0x557)](this[_0xc70fe4(0x558)])) : (this['curTarPos'] = _0x178e83['I'][_0xc70fe4(0x55c)][_0xc70fe4(0x32e)](), this['curTarPos']['x'] += 0xa * Math['random']() - 0x5, this[_0xc70fe4(0x558)]['z'] += 0xa * Math[_0xc70fe4(0x55d)]() - 0x5);
                        }
                    },
                    {
                        'key': _0x3eddcc(0x3fb),
                        'value': function _0x255fe5() {
                            var _0x21b2b2 = _0x3eddcc;
                            this[_0x21b2b2(0x2a4)][_0x21b2b2(0x2b4)](0x0, 0x0), _0x58adf2(_0x5a6184(_0x4fd22a[_0x21b2b2(0x2e5)]), _0x21b2b2(0x3fb), this)['call'](this);
                        }
                    },
                    {
                        'key': _0x3eddcc(0x3ed),
                        'value': function _0x249301(_0x3ead8d) {
                            var _0x75b96a = _0x3eddcc;
                            _0x3ead8d[_0x75b96a(0x4ab)]['name'];
                        }
                    },
                    {
                        'key': _0x3eddcc(0x54c),
                        'value': function _0x655566() {
                            var _0x39dc66 = _0x3eddcc,
                                _0x55100b = _0x178e83['I'][_0x39dc66(0x55c)],
                                _0x4427d1 = this['transform'][_0x39dc66(0x32d)];
                            return Math[_0x39dc66(0x4b9)](_0x55100b['x'] - _0x4427d1['x']) < 0.2 && Math[_0x39dc66(0x4b9)](_0x55100b['z'] - _0x4427d1['z']) < 0.2;
                        }
                    },
                    {
                        'key': 'getWaitTime',
                        'value': function _0x181beb() {
                            var _0x4ece70 = _0x3eddcc;
                            if (fx['Utils'][_0x4ece70(0x23f)](0.1))
                                this[_0x4ece70(0x54e)] = 0xa * Math['random']() * 0x3e8;
                            else {
                                var _0x29eb43 = this[_0x4ece70(0x55a)][_0x4ece70(0x27c)],
                                    _0x1ecad0 = Math['random']() * _0x29eb43;
                                if (fx[_0x4ece70(0x1fb)][_0x4ece70(0x23f)](0.2)) {
                                    var _0x20b516 = 0xa * Math[_0x4ece70(0x55d)]() - 0x5;
                                    this['waitTime'] = 0x3e8 * (_0x1ecad0 + _0x20b516), this['waitTime'] = Math[_0x4ece70(0x28c)](this[_0x4ece70(0x54e)], 0x3e8);
                                } else
                                    this[_0x4ece70(0x54e)] = 0x3e8 * _0x1ecad0;
                            }
                            this[_0x4ece70(0x54e)] = Math[_0x4ece70(0x28c)](this['waitTime'], 0x3e8);
                        }
                    },
                    {
                        'key': _0x3eddcc(0x54a),
                        'value': function _0x4b253d(_0x10b27b) {
                            var _0x2a87c1 = _0x3eddcc;
                            _0x31f777[_0x2a87c1(0x55b)](_0x10b27b, this[_0x2a87c1(0x558)]) && (this['addTargetPosArr'](_0x10b27b), this[_0x2a87c1(0x547)](), this[_0x2a87c1(0x54e)] *= Math[_0x2a87c1(0x55d)]());
                        }
                    },
                    {
                        'key': 'addTargetPosArr',
                        'value': function _0x4be00c(_0x3dce45) {
                            var _0x3ad731 = _0x3eddcc,
                                _0x368d3c = !0x1;
                            return -0x1 == this[_0x3ad731(0x55a)][_0x3ad731(0x55e)](function(_0x5aa1d2) {
                                return _0x31f777['equals'](_0x5aa1d2, _0x3dce45);
                            }) && (_0x368d3c = !0x0, this['getTarPos'][_0x3ad731(0x290)](_0x3dce45)), _0x368d3c;
                        }
                    },
                    {
                        'key': _0x3eddcc(0x55f),
                        'value': function _0x30a38d(_0x250e86) {
                            var _0x458e5f = _0x3eddcc,
                                _0x1ac828 = !0x1;
                            return -0x1 == this[_0x458e5f(0x560)][_0x458e5f(0x55e)](function(_0x3b9182) {
                                return _0x3b9182 == _0x250e86;
                            }) && (_0x1ac828 = !0x0, this[_0x458e5f(0x560)][_0x458e5f(0x290)](_0x250e86)), _0x1ac828;
                        }
                    }
                ]), _0x4fd22a;
            }(_0x500c49),
            _0x178e83 = function() {
                var _0x80b9cc = _0x28eca3;

                function _0x364e1a() {
                    _0xaf4c50(this, _0x364e1a);
                }
                return _0x3f3356(_0x364e1a, [{
                        'key': 'ChoiceGroup',
                        'get': function _0x532f20() {
                            var _0x51d49f = _0x372d;
                            return this[_0x51d49f(0x561)];
                        },
                        'set': function _0x23766c(_0x48bbaa) {
                            var _0x5f3474 = _0x372d;
                            this[_0x5f3474(0x561)] = _0x48bbaa;
                        }
                    },
                    {
                        'key': _0x80b9cc(0x562),
                        'get': function _0x2778e8() {
                            var _0x79f82e = _0x80b9cc;
                            return this[_0x79f82e(0x286)];
                        },
                        'set': function _0x34a6dd(_0x55f6a8) {
                            var _0x422f9b = _0x80b9cc;
                            this[_0x422f9b(0x286)] = _0x55f6a8;
                        }
                    },
                    {
                        'key': 'Player',
                        'get': function _0x142cf9() {
                            var _0x547671 = _0x80b9cc;
                            return this[_0x547671(0x490)];
                        },
                        'set': function _0x2c395e(_0x2002ef) {
                            this['player'] = _0x2002ef;
                        }
                    },
                    {
                        'key': _0x80b9cc(0x563),
                        'get': function _0x3d3ede() {
                            var _0x15ee29 = _0x80b9cc;
                            return this[_0x15ee29(0x564)];
                        },
                        'set': function _0x22240d(_0x179c17) {
                            var _0x44344a = _0x80b9cc;
                            this[_0x44344a(0x564)] = _0x179c17;
                        }
                    },
                    {
                        'key': 'EndPos',
                        'get': function _0x1204ad() {
                            var _0x1055aa = _0x80b9cc;
                            return this[_0x1055aa(0x565)];
                        },
                        'set': function _0x1bc743(_0x130a72) {
                            var _0x27cce3 = _0x80b9cc;
                            this[_0x27cce3(0x565)] = _0x130a72;
                        }
                    },
                    {
                        'key': _0x80b9cc(0x559),
                        'get': function _0x594de8() {
                            return this['targetPos'];
                        }
                    },
                    {
                        'key': _0x80b9cc(0x270),
                        'value': function _0xa4331e() {
                            var _0x3a6a4e = _0x80b9cc;
                            this[_0x3a6a4e(0x566)] = [], this[_0x3a6a4e(0x563)] = [], this[_0x3a6a4e(0x4b8)] = [], this[_0x3a6a4e(0x562)] = _0x29989c['instance'][_0x3a6a4e(0x286)];
                        }
                    },
                    {
                        'key': _0x80b9cc(0x567),
                        'value': function _0x550673(_0x4b11f5) {
                            var _0x206035 = _0x80b9cc;
                            this[_0x206035(0x4b8)][_0x206035(0x290)](_0x4b11f5);
                        }
                    },
                    {
                        'key': _0x80b9cc(0x568),
                        'value': function _0x1d4c05(_0x3ef873) {
                            var _0x142ed4 = _0x80b9cc,
                                _0x774caf = this[_0x142ed4(0x4b8)]['findIndex'](function(_0x419c71) {
                                    var _0x18a587 = _0x142ed4;
                                    return _0x31f777[_0x18a587(0x55b)](_0x419c71, _0x3ef873);
                                }); -
                            0x1 != _0x774caf && this[_0x142ed4(0x4b8)][_0x142ed4(0x27f)](_0x774caf, 0x1);
                        }
                    },
                    {
                        'key': _0x80b9cc(0x557),
                        'value': function _0x5e45a6(_0x4c430f) {
                            var _0x4c4aa1 = _0x80b9cc,
                                _0x306dd7 = _0x4c430f['clone']();
                            for (var _0x2d75d2 = 0x0; _0x2d75d2 < this['ChoiceGroup'][_0x4c4aa1(0x27c)]; ++_0x2d75d2) {
                                var _0x1a130c = this[_0x4c4aa1(0x566)][_0x2d75d2],
                                    _0x4c9272 = !0x1;
                                for (var _0x234893 = 0x0; _0x234893 < _0x1a130c['numChildren']; ++_0x234893) {
                                    var _0xffbf70 = _0x1a130c[_0x4c4aa1(0x429)](_0x234893)['getChildByName']('whole')[_0x4c4aa1(0x209)](_0x4c4aa1(0x4b8));
                                    if (_0x31f777[_0x4c4aa1(0x55b)](_0x4c430f, _0xffbf70[_0x4c4aa1(0x32a)]['position'])) {
                                        _0x4c9272 = !0x0;
                                        break;
                                    }
                                }
                                if (_0x4c9272) {
                                    for (var _0x4cc257 = 0x0; _0x4cc257 < _0x1a130c[_0x4c4aa1(0x569)]; ++_0x4cc257) {
                                        var _0x5dc716 = _0x1a130c[_0x4c4aa1(0x429)](_0x4cc257)[_0x4c4aa1(0x209)](_0x4c4aa1(0x56a))[_0x4c4aa1(0x209)](_0x4c4aa1(0x4b8));
                                        if (!_0x31f777['equals'](_0x4c430f, _0x5dc716[_0x4c4aa1(0x32a)][_0x4c4aa1(0x32d)])) {
                                            _0x306dd7[_0x4c4aa1(0x329)](_0x5dc716[_0x4c4aa1(0x32a)]['position']);
                                            break;
                                        }
                                    }
                                    break;
                                }
                            }
                            return _0x306dd7;
                        }
                    },
                    {
                        'key': _0x80b9cc(0x56b),
                        'value': function _0x5041de() {
                            var _0x31ef7a = _0x80b9cc;
                            for (var _0x1184e4 = this[_0x31ef7a(0x564)][_0x31ef7a(0x27c)] - 0x1; _0x1184e4 >= 0x0; --_0x1184e4) {
                                var _0x25d4a9 = this['robots'][_0x1184e4];
                                _0x25d4a9 && !_0x25d4a9[_0x31ef7a(0x31b)] && _0x25d4a9[_0x31ef7a(0x2c4)](_0x6d85d8)['kill']();
                            }
                            this['player'][_0x31ef7a(0x2c4)](_0x53f643)['kill']();
                        }
                    }
                ], [{
                    'key': 'I',
                    'get': function _0x4dcf7b() {
                        var _0x5bf4cd = _0x80b9cc;
                        return this[_0x5bf4cd(0x233)] || (this[_0x5bf4cd(0x233)] = new _0x364e1a()), this[_0x5bf4cd(0x233)];
                    }
                }]), _0x364e1a;
            }(),
            _0x4a484e = function(_0x1feffe) {
                var _0x4d88ef = _0x28eca3;
                _0x10ff6e(_0x145569, _0x1feffe);
                var _0x286189 = _0x30529b(_0x145569);

                function _0x145569() {
                    var _0x3ba570 = _0x372d;
                    return _0xaf4c50(this, _0x145569), _0x286189[_0x3ba570(0x1f4)](this, arguments);
                }
                return _0x3f3356(_0x145569, [{
                        'key': 'onAwake',
                        'value': function _0x4a7229() {
                            var _0x3968be = _0x372d,
                                _0x2c7baf = this[_0x3968be(0x56c)] = this['owner'];
                            this[_0x3968be(0x56d)] = [];
                            for (var _0x57b416 = 0x0; _0x57b416 < _0x2c7baf[_0x3968be(0x569)]; ++_0x57b416) {
                                var _0x19bfc5 = _0x2c7baf['getChildAt'](_0x57b416);
                                _0x3968be(0x56e) == _0x19bfc5[_0x3968be(0x333)] && (this[_0x3968be(0x56d)][_0x3968be(0x290)](_0x19bfc5), this['initGlass'](_0x19bfc5));
                            }
                            this[_0x3968be(0x56f)] = fx[_0x3968be(0x1fb)][_0x3968be(0x279)](0x0, _0x2c7baf[_0x3968be(0x569)] - 0x1);
                        }
                    },
                    {
                        'key': _0x4d88ef(0x570),
                        'value': function _0x42a4e9(_0x26dd58) {
                            var _0x4330a2 = _0x4d88ef,
                                _0x2bd500 = _0x26dd58[_0x4330a2(0x209)](_0x4330a2(0x56a)),
                                _0x1a3dc0 = _0x2bd500[_0x4330a2(0x2c4)](Laya['PhysicsCollider']);
                            _0x2bd500['addComponent'](_0xdd3063)[_0x4330a2(0x270)]({
                                'static': !0x0,
                                'kinematic': !0x1,
                                'trigger': !0x1,
                                'event': !0x0,
                                'belongsTo': _0x134368[_0x4330a2(0x1ef)],
                                'collidesWith': _0x134368[_0x4330a2(0x1f0)],
                                'shape': _0x1a3dc0[_0x4330a2(0x36b)],
                                'debug': _0x4b339f[_0x4330a2(0x3a0)],
                                'neverSleep': !0x0
                            }), _0x2bd500['on'](fx['BaseEvent']['E_PHYSICS_COLLISION'], this, this[_0x4330a2(0x3ed)]);
                            var _0x5bc8cf = _0x2bd500[_0x4330a2(0x209)]('targetPos');
                            _0x178e83['I']['addTargetPos'](_0x5bc8cf[_0x4330a2(0x32a)][_0x4330a2(0x32d)][_0x4330a2(0x32e)]());
                        }
                    },
                    {
                        'key': _0x4d88ef(0x3ed),
                        'value': function _0x21aecb(_0x399675) {
                            var _0x569b9d = _0x4d88ef,
                                _0x160e36 = _0x399675['mine'],
                                _0xaeadf2 = this[_0x569b9d(0x56d)][this['fullIdx']];
                            if (_0x160e36[_0x569b9d(0x571)] == _0xaeadf2) {
                                var _0x4132c7 = _0xaeadf2[_0x569b9d(0x209)](_0x569b9d(0x56a));
                                _0x4132c7[_0x569b9d(0x240)] = !0x1;
                                var _0x380d53 = _0x4132c7[_0x569b9d(0x209)](_0x569b9d(0x4b8));
                                _0x178e83['I']['deleteTargetPos'](_0x380d53[_0x569b9d(0x32a)][_0x569b9d(0x32d)]);
                                var _0x3ee01e = _0xaeadf2[_0x569b9d(0x4cf)]['getChildByName'](_0x569b9d(0x572))['clone']();
                                _0x3ee01e['transform']['position'] = _0x4132c7[_0x569b9d(0x32a)][_0x569b9d(0x32d)][_0x569b9d(0x32e)](), _0xaeadf2[_0x569b9d(0x4cf)][_0x569b9d(0x3af)](_0x3ee01e), _0x3ee01e[_0x569b9d(0x240)] = !0x0, _0x3ee01e[_0x569b9d(0x387)][_0x569b9d(0x39d)](0xbb8, this, function() {
                                    var _0x568e0d = _0x569b9d;
                                    _0x3ee01e && !_0x3ee01e[_0x568e0d(0x31b)] && (_0x3ee01e[_0x568e0d(0x240)] = !0x1);
                                }), fx[_0x569b9d(0x1fb)][_0x569b9d(0x4c4)](_0x3ee01e, function(_0x16194d) {
                                    var _0x5754bd = _0x569b9d,
                                        _0x2e3840 = _0x16194d[_0x5754bd(0x2c4)](Laya[_0x5754bd(0x368)]);
                                    if (!_0x2e3840)
                                        return;
                                    var _0x561da4 = _0x16194d[_0x5754bd(0x367)](_0xdd3063);
                                    _0x561da4['init']({
                                        'static': !0x1,
                                        'kinematic': !0x1,
                                        'belongsTo': _0x134368['STATIC'],
                                        'collidesWith': _0x134368[_0x5754bd(0x1e9)],
                                        'shape': _0x2e3840[_0x5754bd(0x36b)],
                                        'debug': _0x4b339f[_0x5754bd(0x3a0)]
                                    });
                                    var _0x259952 = new _0x31f777();
                                    _0x259952['setValue'](0xa * Math['random'](), 0x0, 0xa * Math['random']()), _0x561da4[_0x5754bd(0x34d)](_0x259952);
                                }), fx[_0x569b9d(0x294)][_0x569b9d(0x203)][_0x569b9d(0x261)](_0x561c5d[_0x569b9d(0x549)], _0x380d53[_0x569b9d(0x32a)][_0x569b9d(0x32d)][_0x569b9d(0x32e)]()), fx['SoundManager']['instance'][_0x569b9d(0x573)](0xfa2);
                            } else {
                                var _0x342adc = _0x160e36[_0x569b9d(0x571)][_0x569b9d(0x209)]('whole')[_0x569b9d(0x209)]('targetPos'),
                                    _0x5417c4 = _0x178e83['I'][_0x569b9d(0x557)](_0x342adc[_0x569b9d(0x32a)][_0x569b9d(0x32d)]);
                                fx[_0x569b9d(0x294)][_0x569b9d(0x203)][_0x569b9d(0x261)](_0x561c5d[_0x569b9d(0x549)], _0x5417c4);
                            }
                        }
                    }
                ]), _0x145569;
            }(Laya[_0x28eca3(0x326)]),
            _0x2e0778 = function(_0x40dc00) {
                var _0x15d159 = _0x28eca3;
                _0x10ff6e(_0x41382d, _0x40dc00);
                var _0x16758e = _0x30529b(_0x41382d);

                function _0x41382d() {
                    var _0x3af79f = _0x372d;
                    return _0xaf4c50(this, _0x41382d), _0x16758e[_0x3af79f(0x1f4)](this, arguments);
                }
                return _0x3f3356(_0x41382d, [{
                        'key': _0x15d159(0x1fa),
                        'value': function _0x224dfe() {
                            var _0x1fc702 = _0x15d159,
                                _0x320f70 = this[_0x1fc702(0x56c)] = this[_0x1fc702(0x1fe)],
                                _0x5a73f2 = _0x320f70['getComponent'](Laya[_0x1fc702(0x368)]);
                            _0x320f70[_0x1fc702(0x367)](_0xdd3063)[_0x1fc702(0x270)]({
                                'static': !0x0,
                                'kinematic': !0x1,
                                'trigger': !0x0,
                                'event': !0x0,
                                'belongsTo': _0x134368[_0x1fc702(0x1f3)],
                                'collidesWith': _0x134368[_0x1fc702(0x1f0)],
                                'shape': _0x5a73f2[_0x1fc702(0x36b)],
                                'debug': _0x4b339f[_0x1fc702(0x3a0)],
                                'neverSleep': !0x0
                            }), _0x320f70['on'](fx[_0x1fc702(0x3eb)][_0x1fc702(0x3ec)], this, this[_0x1fc702(0x3ed)]);
                        }
                    },
                    {
                        'key': 'onDestroy',
                        'value': function _0x309b65() {
                            var _0x381f3b = _0x15d159;
                            this[_0x381f3b(0x56c)][_0x381f3b(0x376)](fx[_0x381f3b(0x3eb)]['E_PHYSICS_COLLISION'], this, this['onCollision']);
                        }
                    },
                    {
                        'key': _0x15d159(0x3ed),
                        'value': function _0x49eef5(_0x2b595a) {
                            var _0x1c6d83 = _0x15d159,
                                _0x551f77 = _0x2b595a[_0x1c6d83(0x4ab)];
                            if (!_0x551f77 || _0x551f77[_0x1c6d83(0x31b)])
                                return;
                            var _0x2082e9 = _0x551f77['getComponent'](_0x500c49);
                            _0x2082e9 && !_0x2082e9['destroyed'] && _0x2082e9[_0x1c6d83(0x3ff)]();
                        }
                    }
                ]), _0x41382d;
            }(Laya[_0x28eca3(0x326)]),
            _0x45ef71 = function(_0x5aef74) {
                var _0x3abe12 = _0x28eca3;
                _0x10ff6e(_0x4dc3ba, _0x5aef74);
                var _0x13d40d = _0x30529b(_0x4dc3ba);

                function _0x4dc3ba() {
                    var _0x45ba66 = _0x372d;
                    return _0xaf4c50(this, _0x4dc3ba), _0x13d40d[_0x45ba66(0x1f4)](this, arguments);
                }
                return _0x3f3356(_0x4dc3ba, [{
                        'key': _0x3abe12(0x1fa),
                        'value': function _0x393ccf() {
                            var _0x2c0640 = _0x3abe12,
                                _0x99cf7f = this[_0x2c0640(0x56c)] = this[_0x2c0640(0x1fe)],
                                _0x42833a = _0x99cf7f[_0x2c0640(0x2c4)](Laya['PhysicsCollider']);
                            _0x99cf7f[_0x2c0640(0x367)](_0xdd3063)[_0x2c0640(0x270)]({
                                'static': !0x0,
                                'kinematic': !0x1,
                                'trigger': !0x0,
                                'event': !0x0,
                                'belongsTo': _0x134368[_0x2c0640(0x1ef)],
                                'collidesWith': _0x134368[_0x2c0640(0x1f0)],
                                'shape': _0x42833a[_0x2c0640(0x36b)],
                                'debug': _0x4b339f['PHYSICS_DEBUG_SHOW'],
                                'neverSleep': !0x0
                            }), _0x99cf7f['on'](fx['BaseEvent'][_0x2c0640(0x3ec)], this, this[_0x2c0640(0x3ed)]);
                        }
                    },
                    {
                        'key': 'onDestroy',
                        'value': function _0x31ed24() {
                            var _0x4d8362 = _0x3abe12;
                            this[_0x4d8362(0x56c)][_0x4d8362(0x376)](fx['BaseEvent'][_0x4d8362(0x3ec)], this, this[_0x4d8362(0x3ed)]);
                        }
                    },
                    {
                        'key': _0x3abe12(0x3ed),
                        'value': function _0x5598fe(_0xf9bca6) {
                            var _0x36c759 = _0x3abe12,
                                _0x4fef3c = _0xf9bca6[_0x36c759(0x4ab)];
                            _0x4fef3c && !_0x4fef3c[_0x36c759(0x31b)] && _0x4fef3c[_0x36c759(0x2c4)](_0x500c49) instanceof _0x53f643 && _0x29989c['instance'][_0x36c759(0x277)](_0x4d7387[_0x36c759(0x1e6)]);
                        }
                    }
                ]), _0x4dc3ba;
            }(Laya[_0x28eca3(0x326)]),
            _0x2d1e39 = function(_0x46c8d5) {
                var _0x484838 = _0x28eca3;
                _0x10ff6e(_0x310b38, _0x46c8d5);
                var _0x36fa34 = _0x30529b(_0x310b38);

                function _0x310b38() {
                    return _0xaf4c50(this, _0x310b38), _0x36fa34['call'](this);
                }
                return _0x3f3356(_0x310b38, [{
                        'key': _0x484838(0x44e),
                        'value': function _0x25b30d() {
                            var _0xda49a3 = _0x484838,
                                _0x29252c = this;
                            _0x29989c['instance'][_0xda49a3(0x270)](), _0x178e83['I'][_0xda49a3(0x270)]();
                            var _0x550074 = Laya[_0xda49a3(0x319)][_0xda49a3(0x478)](_0x310b38[_0xda49a3(0x479)]);
                            this['scene3d'] = _0x550074, _0x550074['size'](this[_0xda49a3(0x2ba)], this[_0xda49a3(0x2a8)]), this[_0xda49a3(0x47c)](_0x550074, 0x0), _0x550074[_0xda49a3(0x367)](_0x39ee6f), (this[_0xda49a3(0x481)](), this[_0xda49a3(0x48f)](), this['initLevel'](), this[_0xda49a3(0x497)]()), !Laya[_0xda49a3(0x4c1)][_0xda49a3(0x489)](_0xda49a3(0x48b)) && Laya['Browser']['onPC'] ? (this[_0xda49a3(0x49b)][_0xda49a3(0x20b)] = this[_0xda49a3(0x488)]['visible'] = !![], Laya['LocalStorage']['setJSON'](_0xda49a3(0x48b), !![]), Laya[_0xda49a3(0x387)][_0xda49a3(0x39d)](0x1388, this, () => {
                                var _0x2ec0fe = _0xda49a3;
                                this[_0x2ec0fe(0x49b)]['visible'] = this[_0x2ec0fe(0x488)][_0x2ec0fe(0x20b)] = ![], this[_0x2ec0fe(0x482)][_0x2ec0fe(0x29b)](0x3, Laya['Handler'][_0x2ec0fe(0x325)](this, function() {
                                    var _0x123438 = _0x2ec0fe;
                                    Laya[_0x123438(0x387)][_0x123438(0x39d)](0x3e8, _0x29252c, _0x29252c['startGame']);
                                }));
                            })) : (this[_0xda49a3(0x49b)]['visible'] = this[_0xda49a3(0x488)]['visible'] = ![], this[_0xda49a3(0x482)][_0xda49a3(0x29b)](0x3, Laya['Handler'][_0xda49a3(0x325)](this, function() {
                                var _0x52d32b = _0xda49a3;
                                Laya[_0x52d32b(0x387)][_0x52d32b(0x39d)](0x3e8, _0x29252c, _0x29252c['startGame']);
                            }))), fx[_0xda49a3(0x202)]['instance'][_0xda49a3(0x574)](0xfa1), platform[_0xda49a3(0x451)]()['closeLoading']();
                        }
                    },
                    {
                        'key': _0x484838(0x20c),
                        'value': function _0xf15306() {
                            var _0x4ee1f9 = _0x484838;
                            fx[_0x4ee1f9(0x202)]['instance'][_0x4ee1f9(0x575)](0xfa1), fx['EventCenter'][_0x4ee1f9(0x203)][_0x4ee1f9(0x261)](_0x561c5d['E_CLOSE_ALL_PANEL']);
                        }
                    },
                    {
                        'key': _0x484838(0x481),
                        'value': function _0x266bd1() {
                            var _0x2c2955 = _0x484838,
                                _0x573f3d = this;
                            this[_0x2c2955(0x482)] = this['box_cd'][_0x2c2955(0x2c4)](_0xc00205), _0x20256e[_0x2c2955(0x3a2)](_0x2c2955(0x576), Laya[_0x2c2955(0x324)]['create'](this, function() {
                                var _0x523336 = _0x2c2955;
                                _0x20256e[_0x523336(0x3a2)]('One\x20piece\x20of\x20glass\x20in\x20each\x20row\x0a\x20\x20\x20\x20\x20\x20\x20will\x20break\x20under\x20force!\x0a\x20\x20\x20\x20\x20\x20Please\x20choose\x20carefully', Laya[_0x523336(0x324)][_0x523336(0x325)](_0x573f3d, function() {
                                    var _0x205f9a = _0x523336;
                                    _0x20256e['showTips'](_0x205f9a(0x577));
                                }), 0x2);
                            }), 0x2), this[_0x2c2955(0x485)] = this[_0x2c2955(0x486)][_0x2c2955(0x2c4)](_0x107110), this[_0x2c2955(0x485)]['setDuration'](_0x29989c[_0x2c2955(0x203)][_0x2c2955(0x283)]()), this[_0x2c2955(0x2a4)]['visible'] = !0x1, this[_0x2c2955(0x48d)]['on'](Laya[_0x2c2955(0x2ac)][_0x2c2955(0x450)], this, this[_0x2c2955(0x4fe)]), console[_0x2c2955(0x3bc)](0x5be8b167172ab000000000);
                        }
                    },
                    {
                        'key': 'goMain0',
                        'value': function _0x5605de() {
                            var _0x3f9f69 = _0x484838;
                            platform[_0x3f9f69(0x451)]()[_0x3f9f69(0x230)](() => {
                                var _0x4ec750 = _0x3f9f69;
                                fx[_0x4ec750(0x452)][_0x4ec750(0x40d)](this), platform[_0x4ec750(0x451)]()[_0x4ec750(0x458)](), _0x29989c[_0x4ec750(0x203)][_0x4ec750(0x265)]();
                            });
                        }
                    },
                    {
                        'key': _0x484838(0x48f),
                        'value': function _0x52233e() {
                            var _0x445e03 = _0x484838,
                                _0x564ce1 = this[_0x445e03(0x2a4)][_0x445e03(0x2c4)](_0x1a62ec),
                                _0x5a8298 = this[_0x445e03(0x47a)][_0x445e03(0x209)](_0x445e03(0x490)),
                                _0x288f8c = Laya[_0x445e03(0x319)]['getRes'](_0xf611c3['PREFAB_CHARACTER'])[_0x445e03(0x32e)]();
                            _0x5a8298[_0x445e03(0x3af)](_0x288f8c), this[_0x445e03(0x491)] = _0x5a8298[_0x445e03(0x32e)]();
                            var _0x37f8cb = _0x5a8298[_0x445e03(0x367)](_0x53f643);
                            _0x37f8cb[_0x445e03(0x270)](_0x564ce1), this['playerController'] = _0x37f8cb, this['characterPrefab']['getChildByName']('CameraPivot')['destroy'](), _0x178e83['I'][_0x445e03(0x490)] = _0x5a8298;
                        }
                    },
                    {
                        'key': 'initLevel',
                        'value': function _0x55e872() {
                            var _0xfabc28 = _0x484838,
                                _0x5b7f2c, _0x5cf6d0, _0x2894f7, _0x49fde3 = _0x178e83['I'][_0xfabc28(0x562)],
                                _0x2202c3 = fx[_0xfabc28(0x4c9)][_0xfabc28(0x203)][_0xfabc28(0x253)]('glassBridgeCfg');
                            for (var _0x16a80c in _0x2202c3) {
                                _0x5cf6d0 = _0x16a80c;
                                var _0x2d9258 = _0x2202c3[_0x16a80c];
                                if (_0x2d9258[_0xfabc28(0x578)] > _0x49fde3) {
                                    _0x5b7f2c = _0x2d9258['levName'];
                                    break;
                                }
                            }
                            _0x5b7f2c || (_0x5b7f2c = _0x2202c3[_0x5cf6d0][_0xfabc28(0x579)]);
                            var _0x5b2a8d = this[_0xfabc28(0x47a)][_0xfabc28(0x209)](_0xfabc28(0x57a));
                            for (var _0x1b56c8 = 0x0; _0x1b56c8 < _0x5b2a8d[_0xfabc28(0x569)]; ++_0x1b56c8) {
                                var _0x391de6 = _0x5b2a8d[_0xfabc28(0x429)](_0x1b56c8);
                                _0x391de6[_0xfabc28(0x333)] == _0x5b7f2c ? (_0x391de6[_0xfabc28(0x240)] = !0x0, _0x2894f7 = _0x391de6) : _0x391de6[_0xfabc28(0x240)] = !0x1;
                            }
                            var _0x598bb4 = _0x2894f7[_0xfabc28(0x209)](_0xfabc28(0x57b))['getChildByName'](_0xfabc28(0x57c)),
                                _0x24d201 = _0x2894f7[_0xfabc28(0x209)]('endPlat')[_0xfabc28(0x209)](_0xfabc28(0x57c));
                            fx[_0xfabc28(0x1fb)]['recurisNode'](_0x598bb4, function(_0x15becb) {
                                var _0x14173b = _0xfabc28;
                                _0x20256e[_0x14173b(0x4c5)](_0x15becb, _0x134368[_0x14173b(0x1ef)]);
                            }), fx[_0xfabc28(0x1fb)][_0xfabc28(0x4c4)](_0x24d201, function(_0x14dd5d) {
                                var _0x396fca = _0xfabc28;
                                _0x20256e[_0x396fca(0x4c5)](_0x14dd5d, _0x134368[_0x396fca(0x1ef)]);
                            });
                            var _0x337103 = [],
                                _0xd4b1a3 = _0x2894f7['getChildByName']('bridge')[_0xfabc28(0x209)](_0xfabc28(0x561));
                            for (var _0x46d8cc = 0x0; _0x46d8cc < _0xd4b1a3[_0xfabc28(0x569)]; ++_0x46d8cc) {
                                var _0x173edd = _0xd4b1a3[_0xfabc28(0x429)](_0x46d8cc);
                                _0x173edd[_0xfabc28(0x367)](_0x4a484e), _0x337103[_0xfabc28(0x290)](_0x173edd);
                            }
                            _0x178e83['I'][_0xfabc28(0x566)] = _0x337103, _0x2894f7['getChildByName']('finishTri')[_0xfabc28(0x367)](_0x45ef71), this[_0xfabc28(0x47a)][_0xfabc28(0x209)](_0xfabc28(0x57d))['addComponent'](_0x2e0778), _0x178e83['I']['EndPos'] = _0x2894f7['getChildByName'](_0xfabc28(0x565))[_0xfabc28(0x32a)][_0xfabc28(0x32d)], this[_0xfabc28(0x47a)][_0xfabc28(0x209)](_0xfabc28(0x572))[_0xfabc28(0x240)] = !0x1;
                        }
                    },
                    {
                        'key': _0x484838(0x497),
                        'value': function _0x5a04ec() {
                            var _0x1c32b2 = _0x484838,
                                _0x58e4db = this,
                                _0x243b47 = _0x178e83['I'][_0x1c32b2(0x562)],
                                _0xb8b62c = this[_0x1c32b2(0x492)][_0x1c32b2(0x3df)]['transform']['position'],
                                _0x519004 = [];
                            for (var _0x5692fc = 0x1; _0x5692fc < _0x243b47 + 0x1; ++_0x5692fc) {
                                this[_0x1c32b2(0x387)]['once'](0x3 * Math[_0x1c32b2(0x55d)]() * 0x3e8, this, function() {
                                    var _0x50aa07 = _0x1c32b2,
                                        _0x3a8a14 = _0x58e4db[_0x50aa07(0x491)]['clone']();
                                    _0x58e4db[_0x50aa07(0x47a)][_0x50aa07(0x3af)](_0x3a8a14), _0x3a8a14[_0x50aa07(0x32a)][_0x50aa07(0x32d)] = new _0x31f777(_0xb8b62c['x'] + (0xc * Math[_0x50aa07(0x55d)]() - 0x6), 0x0, _0xb8b62c['z'] + (0xc * Math[_0x50aa07(0x55d)]() - 0x6)), _0x3a8a14[_0x50aa07(0x367)](_0x6d85d8), _0x519004['push'](_0x3a8a14);
                                });
                            }
                            _0x178e83['I']['Robots'] = _0x519004;
                        }
                    },
                    {
                        'key': 'onEnter',
                        'value': function _0x2fcb6d() {
                            var _0x21b70a = _0x484838;
                            this['on'](_0x561c5d[_0x21b70a(0x262)], this, this[_0x21b70a(0x298)]);
                        }
                    },
                    {
                        'key': _0x484838(0x3c2),
                        'value': function _0x4e9578() {}
                    },
                    {
                        'key': 'startGame',
                        'value': function _0x239c9d() {
                            var _0x180142 = _0x484838;
                            _0x29989c['instance'][_0x180142(0x277)](_0x4d7387['E_GAME_START']), this[_0x180142(0x2a4)][_0x180142(0x20b)] = !0x0;
                            var _0x5e68 = _0x523788(_0x178e83['I'][_0x180142(0x563)]),
                                _0xc1bf4f;
                            try {
                                for (_0x5e68['s'](); !(_0xc1bf4f = _0x5e68['n']())[_0x180142(0x288)];) {
                                    var _0x10bfce = _0xc1bf4f['value'];
                                    _0x10bfce[_0x180142(0x2c4)](_0x6d85d8)[_0x180142(0x443)] = !0x0;
                                }
                            } catch (_0x31fad3) {
                                _0x5e68['e'](_0x31fad3);
                            } finally {
                                _0x5e68['f']();
                            }
                            this[_0x180142(0x485)][_0x180142(0x29b)](Laya['Handler'][_0x180142(0x325)](this, this[_0x180142(0x49d)]));
                        }
                    },
                    {
                        'key': _0x484838(0x49d),
                        'value': function _0x4fd045() {
                            var _0x59e77e = _0x484838;
                            _0x178e83['I'][_0x59e77e(0x56b)](), _0x29989c[_0x59e77e(0x203)][_0x59e77e(0x277)](_0x4d7387['E_GAME_FAILED']);
                        }
                    },
                    {
                        'key': 'goMain',
                        'value': function _0x4cac4f() {
                            var _0x2c2675 = _0x484838;
                            this['box_guide'][_0x2c2675(0x20b)] = this['spr_guide'][_0x2c2675(0x20b)] = ![];
                            var _0x73728 = Laya[_0x2c2675(0x266)]['getRegClass'](_0x2c2675(0x268));
                            Laya['SoundManager']['stopMusic'](), fx[_0x2c2675(0x452)][_0x2c2675(0x269)](_0x73728);
                        }
                    },
                    {
                        'key': _0x484838(0x298),
                        'value': function _0x152a49(_0x122455) {
                            var _0x2b5116 = _0x484838;
                            switch (_0x29989c[_0x2b5116(0x203)][_0x2b5116(0x264)]()) {
                                case _0x4d7387[_0x2b5116(0x1e6)]:
                                    this[_0x2b5116(0x49f)]();
                                    break;
                                case _0x4d7387[_0x2b5116(0x1e7)]:
                                    this[_0x2b5116(0x4a0)]();
                                    break;
                                case _0x4d7387[_0x2b5116(0x1e8)]:
                                    this[_0x2b5116(0x4a6)]();
                                    break;
                                case _0x4d7387[_0x2b5116(0x1e5)]:
                                    break;
                                case _0x4d7387[_0x2b5116(0x1e4)]:
                                    _0x122455 == _0x4d7387['E_GAME_FAILED'] ? this[_0x2b5116(0x276)]() : this[_0x2b5116(0x29b)]();
                            }
                        }
                    },
                    {
                        'key': _0x484838(0x4a1),
                        'value': function _0x310190(_0x51399f) {}
                    },
                    {
                        'key': 'onMouseMove',
                        'value': function _0x518940(_0x1a3de1) {}
                    },
                    {
                        'key': 'onMouseUp',
                        'value': function _0x21eacc(_0x4559fa) {}
                    },
                    {
                        'key': 'start',
                        'value': function _0x8c5545() {}
                    },
                    {
                        'key': _0x484838(0x49f),
                        'value': function _0x1dba58() {
                            var _0x4507d9 = _0x484838;
                            platform[_0x4507d9(0x451)]()[_0x4507d9(0x458)]();
                            var _0x29f5a4 = this;
                            this[_0x4507d9(0x47a)][_0x4507d9(0x209)](_0x4507d9(0x57d))[_0x4507d9(0x240)] = !0x1, Laya['SoundManager'][_0x4507d9(0x455)]();
                            var _0x103d19 = _0x29989c[_0x4507d9(0x203)]['getCharacterCnt']();
                            0x1 == _0x103d19 ? (_0x29989c[_0x4507d9(0x203)][_0x4507d9(0x278)](), fx[_0x4507d9(0x452)][_0x4507d9(0x4a4)](_0x3dffbb, {
                                'from': '',
                                'userArgs': [Laya[_0x4507d9(0x324)][_0x4507d9(0x325)](_this45, function() {
                                    var _0x55d6c2 = _0x4507d9;
                                    _0x29989c[_0x55d6c2(0x203)][_0x55d6c2(0x265)]();
                                })]
                            })) : (_0x29989c[_0x4507d9(0x203)][_0x4507d9(0x286)] = Math[_0x4507d9(0x28c)](_0x103d19 - 0x1, 0x1), _0x29989c[_0x4507d9(0x203)]['goNextStage'](), _0x29989c[_0x4507d9(0x203)][_0x4507d9(0x265)]()), fx[_0x4507d9(0x452)][_0x4507d9(0x40d)](this);
                        }
                    },
                    {
                        'key': _0x484838(0x4a0),
                        'value': function _0x2aca59() {
                            var _0xae481e = _0x484838;
                            platform[_0xae481e(0x451)]()[_0xae481e(0x458)]();
                            var _0x39618a = this;
                            Laya[_0xae481e(0x202)][_0xae481e(0x455)](), (_0x29989c[_0xae481e(0x203)][_0xae481e(0x278)](), fx[_0xae481e(0x452)]['openPanel'](_0x46859c, {
                                'from': '',
                                'userArgs': [Laya[_0xae481e(0x324)][_0xae481e(0x325)](_0x29989c['instance'], function() {
                                    var _0x39e05f = _0xae481e;
                                    _0x29989c[_0x39e05f(0x203)][_0x39e05f(0x265)]();
                                })]
                            })), fx[_0xae481e(0x452)]['destroy'](this);
                        }
                    },
                    {
                        'key': _0x484838(0x4a6),
                        'value': function _0x386286() {
                            Laya['SoundManager']['stopMusic']();
                        }
                    },
                    {
                        'key': _0x484838(0x276),
                        'value': function _0x4c514a() {}
                    },
                    {
                        'key': 'clear',
                        'value': function _0x56ec16() {}
                    }
                ], [{
                    'key': 'getRes',
                    'value': function _0x11cf0d() {
                        var _0x3be46e = _0x484838;
                        return this[_0x3be46e(0x479)] = _0x457d72['I'][_0x3be46e(0x249)]('res3d/ZglassRoad.ls'), [
                            this['scenePath'],
                            _0xf611c3[_0x3be46e(0x25a)]
                        ];
                    }
                }]), _0x310b38;
            }(_0x118985['scenes'][_0x28eca3(0x2e9)]);
        Laya[_0x28eca3(0x266)][_0x28eca3(0x2e3)](_0x28eca3(0x57e), _0xb653ba), Laya[_0x28eca3(0x266)][_0x28eca3(0x2e3)](_0x28eca3(0x57f), _0x254a93), Laya['ClassUtils'][_0x28eca3(0x2e3)]('GuessMarbleScene', _0x86f92), Laya[_0x28eca3(0x266)][_0x28eca3(0x2e3)](_0x28eca3(0x580), _0x2d1e39);
        var _0x1a2a5f = function(_0x336c66) {
            var _0x1e38de = _0x28eca3;
            _0x10ff6e(_0x477fbb, _0x336c66);
            var _0x18549b = _0x30529b(_0x477fbb);

            function _0x477fbb() {
                var _0x52859f = _0x372d,
                    _0x2bc467;
                return _0xaf4c50(this, _0x477fbb), (_0x2bc467 = _0x18549b['call'](this), _0x2bc467[_0x52859f(0x581)] = 0x0), _0x2bc467;
            }
            return _0x3f3356(_0x477fbb, [{
                    'key': 'onAdd',
                    'value': function _0x238f61() {
                        var _0x1d81ec = _0x372d;
                        _0x29989c[_0x1d81ec(0x203)][_0x1d81ec(0x270)]();
                        var _0xdc0a31 = Laya[_0x1d81ec(0x319)][_0x1d81ec(0x478)](_0x477fbb[_0x1d81ec(0x479)]);
                        this[_0x1d81ec(0x47a)] = _0xdc0a31, _0xdc0a31[_0x1d81ec(0x47b)](this['width'], this[_0x1d81ec(0x2a8)]), this[_0x1d81ec(0x47c)](_0xdc0a31, 0x0), _0xdc0a31['addComponent'](_0x39ee6f), this[_0x1d81ec(0x582)](_0xdc0a31), this['initUI'](), this[_0x1d81ec(0x49c)](), window[_0x1d81ec(0x583)]['visible'] = !![], platform['getInstance']()['closeLoading']();
                    }
                },
                {
                    'key': _0x1e38de(0x481),
                    'value': function _0x53895f() {
                        var _0x105875 = _0x1e38de;
                        this['b_countdown'][_0x105875(0x20b)] = !0x1, _0x5e5c9b[_0x105875(0x203)][_0x105875(0x232)](), this[_0x105875(0x584)][_0x105875(0x263)](), this['btn_music']['on'](Laya[_0x105875(0x2ac)][_0x105875(0x450)], this, this['changeMusic']), this['btn_help'][_0x105875(0x263)](), this['btn_help'][_0x105875(0x20b)] = Laya[_0x105875(0x2aa)][_0x105875(0x2ab)], this[_0x105875(0x585)]['on'](Laya[_0x105875(0x2ac)][_0x105875(0x450)], this, this[_0x105875(0x586)]), this[_0x105875(0x584)]['skin'] = window[_0x105875(0x587)][_0x105875(0x588)] ? _0x105875(0x589) : _0x105875(0x58a), this[_0x105875(0x58b)]['on'](Laya[_0x105875(0x2ac)][_0x105875(0x450)], this, this[_0x105875(0x58c)]), this[_0x105875(0x58b)]['visible'] = !![], this[_0x105875(0x49b)][_0x105875(0x20b)] = this[_0x105875(0x488)]['visible'] = ![], !Laya['LocalStorage']['getJSON'](_0x105875(0x48b)) && Laya[_0x105875(0x2aa)]['onPC'] && (this['box_guide']['visible'] = this[_0x105875(0x488)][_0x105875(0x20b)] = !![], Laya[_0x105875(0x4c1)]['setJSON']('_firstGame', !![]), Laya[_0x105875(0x387)][_0x105875(0x39d)](0x1388, this, () => {
                            var _0x376eb = _0x105875;
                            this[_0x376eb(0x49b)][_0x376eb(0x20b)] = this[_0x376eb(0x488)]['visible'] = ![];
                        }));
                    }
                },
                {
                    'key': _0x1e38de(0x586),
                    'value': function _0x58e462() {
                        var _0xf7569f = _0x1e38de;
                        this['box_guide']['visible'] = this['spr_guide'][_0xf7569f(0x20b)] = !![], this['box_guide'][_0xf7569f(0x39d)](Laya['Event'][_0xf7569f(0x450)], this, () => {
                            var _0x5f0c80 = _0xf7569f;
                            this[_0x5f0c80(0x49b)][_0x5f0c80(0x20b)] = this[_0x5f0c80(0x488)][_0x5f0c80(0x20b)] = ![];
                        });
                    }
                },
                {
                    'key': 'changeMusic',
                    'value': function _0x1fd213() {
                        var _0x46e82a = _0x1e38de;
                        window[_0x46e82a(0x587)][_0x46e82a(0x588)] = !window[_0x46e82a(0x587)][_0x46e82a(0x588)], Laya[_0x46e82a(0x4c1)][_0x46e82a(0x58d)](_0x46e82a(0x58e), window[_0x46e82a(0x587)][_0x46e82a(0x588)]), this[_0x46e82a(0x584)]['skin'] = window['WebAudioEngine']['pause'] ? 'game/btn_sound_off.png' : _0x46e82a(0x58a);
                    }
                },
                {
                    'key': _0x1e38de(0x58f),
                    'value': function _0x1d03f4() {
                        var _0x4a71bd = _0x1e38de,
                            _0x1dc826 = this;
                        if (this['maxHeadTipsCnt'] > 0x2)
                            return;
                        this[_0x4a71bd(0x581)]++;
                        var _0x49c421 = fx[_0x4a71bd(0x1fb)][_0x4a71bd(0x590)](_0xf611c3['PFB_RICKTEXT_TIPS']);
                        _0x49c421['y'] = 0x78, this[_0x4a71bd(0x591)][_0x4a71bd(0x3af)](_0x49c421);
                        var _0x5ef340 = new fx[(_0x4a71bd(0x592))](_0x4a71bd(0x593));
                        _0x5ef340['x'] = 0x5a, _0x5ef340['y'] = 0x19, _0x49c421['addChild'](_0x5ef340);
                        var _0x8fd942 = _0x49c421[_0x4a71bd(0x209)](_0x4a71bd(0x594)),
                            _0x59e7ea = new Laya[(_0x4a71bd(0x3ab))]();
                        _0x59e7ea[_0x4a71bd(0x2ba)] = _0x59e7ea[_0x4a71bd(0x2a8)] = 0x46, _0x59e7ea['x'] = _0x59e7ea['y'] = 0x5, _0x59e7ea[_0x4a71bd(0x333)] = _0x4a71bd(0x595), _0x8fd942[_0x4a71bd(0x3af)](_0x59e7ea);
                        var _0x1dbc53 = _0x29989c[_0x4a71bd(0x203)]['getRandomHeadCfg']();
                        _0x8fd942[_0x4a71bd(0x429)](0x0)[_0x4a71bd(0x596)] = _0x1dbc53[_0x4a71bd(0x201)], _0x5ef340[_0x4a71bd(0x597)] = 'color:#ffffff;font:30px\x20Arial', _0x5ef340[_0x4a71bd(0x598)](_0x4a71bd(0x599)['concat'](_0x1dbc53[_0x4a71bd(0x59a)], _0x4a71bd(0x59b))['concat'](_0x1dbc53[_0x4a71bd(0x333)], _0x4a71bd(0x59c))), _0x49c421[_0x4a71bd(0x2ba)] = _0x5ef340['width'] + 0x6e, new fx['Sequence']()[_0x4a71bd(0x59d)](0x1f4)[_0x4a71bd(0x59e)](0x2)[_0x4a71bd(0x59f)](0x12c)['up'](0x64, 0x12c)[_0x4a71bd(0x5a0)](Laya[_0x4a71bd(0x324)][_0x4a71bd(0x325)](this, function() {
                            var _0x15fd91 = _0x4a71bd;
                            _0x1dc826['maxHeadTipsCnt'] = Math['max'](_0x1dc826[_0x15fd91(0x581)] - 0x1, 0x0), _0x49c421[_0x15fd91(0x40d)]();
                        }))[_0x4a71bd(0x215)](_0x49c421);
                    }
                },
                {
                    'key': _0x1e38de(0x5a1),
                    'value': function _0xacc313() {
                        var _0x3bd9b7 = _0x1e38de,
                            _0x2c73bd = _0x29989c[_0x3bd9b7(0x203)][_0x3bd9b7(0x282)]();
                        if (this[_0x3bd9b7(0x5a2)] || _0x2c73bd > 0x1)
                            this[_0x3bd9b7(0x49c)]();
                        else {
                            if (!_0x5c9919['I'][_0x3bd9b7(0x51c)][_0x3bd9b7(0x519)](0x1))
                                return fx[_0x3bd9b7(0x1fb)]['showTips']('Low\x20Energy'), void fx[_0x3bd9b7(0x452)]['openPanel'](_0x56a64b, {
                                    'from': 'GameScene',
                                    'userArgs': [Laya[_0x3bd9b7(0x324)][_0x3bd9b7(0x325)](this, function(_0x39253e) {})]
                                });
                            this[_0x3bd9b7(0x5a2)] = !0x0, this['startGame']();
                        }
                    }
                },
                {
                    'key': _0x1e38de(0x49c),
                    'value': function _0x17eae2() {
                        var _0x5ac896 = _0x1e38de,
                            _0x133d3b = this;
                        this[_0x5ac896(0x5a3)](), this[_0x5ac896(0x214)](0x3e8, this, function() {
                            var _0x3a0790 = _0x5ac896,
                                _0xa41954 = _0x29989c[_0x3a0790(0x203)]['getTurnIndex']();
                            _0x20256e[_0x3a0790(0x3a2)](_0x3a0790(0x5a4)[_0x3a0790(0x296)](_0xa41954, ''), Laya[_0x3a0790(0x324)][_0x3a0790(0x325)](_0x133d3b, function() {}));
                        });
                    }
                },
                {
                    'key': _0x1e38de(0x58c),
                    'value': function _0x57febb() {
                        var _0x17a894 = _0x1e38de;
                        platform[_0x17a894(0x451)]()['showInterstitial'](() => {
                            var _0x576742 = _0x17a894,
                                _0x18e3ff = _0x29989c[_0x576742(0x203)][_0x576742(0x282)]();
                            this[_0x576742(0x5a5)][_0x576742(0x20b)] = !0x0;
                            var _0x29b971 = this[_0x576742(0x5a6)]['getComponent'](_0x5edaf4);
                            _0x29b971[_0x576742(0x284)] = 0x1 == _0x18e3ff ? 0xa : 0x5, _0x29b971[_0x576742(0x409)](), this[_0x576742(0x58b)][_0x576742(0x20b)] = ![];
                        });
                    }
                },
                {
                    'key': _0x1e38de(0x582),
                    'value': function _0x2345ec(_0x350a75) {
                        var _0xdc8617 = _0x1e38de,
                            _0x4f732a = _0x350a75[_0xdc8617(0x209)]('Player'),
                            _0x5ea91f = Laya[_0xdc8617(0x319)][_0xdc8617(0x31a)](_0xf611c3[_0xdc8617(0x25a)])[_0xdc8617(0x32e)]();
                        _0x4f732a['addChild'](_0x5ea91f), this[_0xdc8617(0x5a7)] = _0x4f732a['clone'](), this[_0xdc8617(0x5a7)][_0xdc8617(0x32a)][_0xdc8617(0x5a8)] = _0x31f777[_0xdc8617(0x35e)], this[_0xdc8617(0x5a7)][_0xdc8617(0x209)](_0xdc8617(0x406))['destroy']();
                        var _0x7b5013 = _0x4f732a['addComponent'](_0x5bf357),
                            _0x346a14 = this[_0xdc8617(0x2a4)][_0xdc8617(0x2c4)](_0x1a62ec);
                        _0x7b5013['init'](_0x346a14), _0x350a75[_0xdc8617(0x209)](_0xdc8617(0x4c3))[_0xdc8617(0x4c6)]()['forEach'](function(_0x3fb0f5) {
                            var _0x4bb3a8 = _0xdc8617;
                            (_0x3fb0f5[_0x4bb3a8(0x333)][_0x4bb3a8(0x334)](_0x4bb3a8(0x335)) || _0x3fb0f5[_0x4bb3a8(0x333)][_0x4bb3a8(0x334)](_0x4bb3a8(0x5a9))) && _0x20256e[_0x4bb3a8(0x4c5)](_0x3fb0f5, _0x134368[_0x4bb3a8(0x1ef)]);
                        }), this[_0xdc8617(0x47a)]['getChildByName'](_0xdc8617(0x5aa))[_0xdc8617(0x4c6)]()['forEach'](function(_0x211872) {
                            var _0x197a54 = _0xdc8617;
                            _0x211872[_0x197a54(0x240)] = !0x1;
                        });
                    }
                },
                {
                    'key': _0x1e38de(0x5a3),
                    'value': function _0x44e75d() {
                        var _0x1d31cc = _0x1e38de,
                            _0x669ee1 = this[_0x1d31cc(0x47a)][_0x1d31cc(0x209)](_0x1d31cc(0x5aa)),
                            _0x13625d = [];
                        _0x669ee1[_0x1d31cc(0x4c6)]()['forEach'](function(_0xe0251b) {
                            var _0x5efa61 = _0x1d31cc;
                            _0x13625d[_0x5efa61(0x290)](fx[_0x5efa61(0x1fb)][_0x5efa61(0x5ab)](_0xe0251b, !0x0)), _0xe0251b['destroy']();
                        });
                        var _0x363b56 = this[_0x1d31cc(0x47a)][_0x1d31cc(0x209)](_0x1d31cc(0x490)),
                            _0xb19251 = [fx[_0x1d31cc(0x1fb)][_0x1d31cc(0x5ac)](_0x363b56[_0x1d31cc(0x32a)]['position'], _0x669ee1)],
                            _0xefdcfc = _0x29989c[_0x1d31cc(0x203)][_0x1d31cc(0x286)];
                        this[_0x1d31cc(0x5ad)](_0x13625d, _0xb19251, _0x669ee1, _0xefdcfc);
                    }
                },
                {
                    'key': _0x1e38de(0x5ad),
                    'value': function _0x3ca6a8(_0x17ff7f, _0x604534, _0x4c4156, _0x5ec47a) {
                        var _0x3c830e = _0x1e38de,
                            _0x36e447 = this;
                        if (0x0 == _0x5ec47a || this['destroyed'])
                            return;
                        _0x5ec47a--;
                        var _0xe71040 = 0x3e8 * fx[_0x3c830e(0x1fb)][_0x3c830e(0x245)](0.2, 0.5);
                        this['timerOnce'](_0xe71040, this, function() {
                            var _0x36d0ba = _0x3c830e;
                            if (0x0 == _0x5ec47a || _0x36e447[_0x36d0ba(0x31b)])
                                return;
                            _0x36e447[_0x36d0ba(0x58f)]();
                            var _0x4371df = fx[_0x36d0ba(0x1fb)][_0x36d0ba(0x5ae)](_0x17ff7f, 0x1, _0x604534),
                                _0x5017a5 = _0x36e447[_0x36d0ba(0x5a7)][_0x36d0ba(0x32e)]();
                            _0x4c4156[_0x36d0ba(0x3af)](_0x5017a5), _0x5017a5[_0x36d0ba(0x32a)][_0x36d0ba(0x421)] = _0x4371df, _0x5017a5[_0x36d0ba(0x367)](_0x4cb5a1), _0x36e447[_0x36d0ba(0x5ad)](_0x17ff7f, _0x604534, _0x4c4156, _0x5ec47a);
                        });
                    }
                },
                {
                    'key': _0x1e38de(0x3cc),
                    'value': function _0xd6496b() {
                        var _0x664aee = _0x1e38de;
                        this['on'](_0x561c5d[_0x664aee(0x262)], this, this[_0x664aee(0x298)]);
                    }
                },
                {
                    'key': 'onGameStateChange',
                    'value': function _0x2eee65(_0x438236) {
                        var _0x3fe885 = _0x1e38de;
                        switch (_0x29989c[_0x3fe885(0x203)]['getGameState']()) {
                            case _0x4d7387[_0x3fe885(0x1e6)]:
                                this['finished']();
                                break;
                            case _0x4d7387[_0x3fe885(0x1e7)]:
                                this[_0x3fe885(0x4a0)]();
                                break;
                            case _0x4d7387['E_GAME_OVER']:
                                this[_0x3fe885(0x4a6)]();
                                break;
                            case _0x4d7387[_0x3fe885(0x1e5)]:
                                break;
                            case _0x4d7387[_0x3fe885(0x1e4)]:
                                _0x438236 == _0x4d7387[_0x3fe885(0x1e7)] ? this['revive']() : this[_0x3fe885(0x29b)]();
                        }
                    }
                },
                {
                    'key': 'start',
                    'value': function _0x1f2efc() {
                        var _0x58ebe3 = _0x1e38de;
                        platform[_0x58ebe3(0x451)]()[_0x58ebe3(0x458)]();
                        var _0x534553 = _0x29989c['instance']['getCurStage'](),
                            _0x3d34f8 = Laya['ClassUtils'][_0x58ebe3(0x267)](_0x534553[_0x58ebe3(0x5af)]);
                        fx['SceneManager'][_0x58ebe3(0x269)](_0x3d34f8), window[_0x58ebe3(0x583)][_0x58ebe3(0x20b)] = ![];
                    }
                },
                {
                    'key': _0x1e38de(0x49f),
                    'value': function _0x14ddd2() {}
                },
                {
                    'key': _0x1e38de(0x4a0),
                    'value': function _0x410896() {}
                },
                {
                    'key': _0x1e38de(0x4a6),
                    'value': function _0x3df9f4() {}
                },
                {
                    'key': _0x1e38de(0x276),
                    'value': function _0x37ddfb() {}
                },
                {
                    'key': _0x1e38de(0x278),
                    'value': function _0x342201() {}
                }
            ], [{
                'key': _0x1e38de(0x31a),
                'value': function _0x2dffbd() {
                    var _0xc8dddd = _0x1e38de;
                    return this[_0xc8dddd(0x479)] = _0x457d72['I']['formatScenePath'](_0xf611c3[_0xc8dddd(0x5b0)]), [
                        this[_0xc8dddd(0x479)],
                        _0xf611c3[_0xc8dddd(0x25a)],
                        _0xf611c3[_0xc8dddd(0x5b1)]
                    ];
                }
            }]), _0x477fbb;
        }(_0x118985[_0x28eca3(0x2f2)][_0x28eca3(0x5b2)]);
        Laya[_0x28eca3(0x266)][_0x28eca3(0x2e3)](_0x28eca3(0x268), _0x1a2a5f);
        var _0x58c76d = function(_0x20a785) {
                var _0x1d57a2 = _0x28eca3;
                _0x10ff6e(_0x1a9c55, _0x20a785);
                var _0x40a841 = _0x30529b(_0x1a9c55);

                function _0x1a9c55() {
                    var _0x3f69a7 = _0x372d,
                        _0x544ee8;
                    return _0xaf4c50(this, _0x1a9c55), (_0x544ee8 = _0x40a841[_0x3f69a7(0x1f7)](this), _0x544ee8['packages'] = [], _0x544ee8[_0x3f69a7(0x5b3)] = _0x544ee8[_0x3f69a7(0x5b4)][_0x3f69a7(0x27c)]), _0x544ee8;
                }
                return _0x3f3356(_0x1a9c55, [{
                        'key': _0x1d57a2(0x344),
                        'value': function _0x3e626a() {
                            var _0x3482c1 = _0x1d57a2,
                                _0x5a716e = this[_0x3482c1(0x1fe)][_0x3482c1(0x209)](_0x3482c1(0x5b5));
                            _0x5a716e[_0x3482c1(0x289)] = 0x0, this[_0x3482c1(0x5b5)] = _0x5a716e, this[_0x3482c1(0x5b6)](), this[_0x3482c1(0x5b5)][_0x3482c1(0x289)] = 0.3;
                        }
                    },
                    {
                        'key': 'onDisable',
                        'value': function _0x14bf69() {
                            var _0x3d5d22 = _0x1d57a2;
                            fx[_0x3d5d22(0x294)][_0x3d5d22(0x203)][_0x3d5d22(0x295)](this);
                        }
                    },
                    {
                        'key': _0x1d57a2(0x5b7),
                        'value': function _0x23ddaa() {
                            var _0x27d8db = _0x1d57a2,
                                _0x323b13 = this;
                            this[_0x27d8db(0x5b6)]();
                        }
                    },
                    {
                        'key': _0x1d57a2(0x5b8),
                        'value': function _0x23caa3(_0x49da08) {
                            var _0x503ea6 = _0x1d57a2;
                            console['log'](_0x49da08), this[_0x503ea6(0x5b7)]();
                        }
                    },
                    {
                        'key': _0x1d57a2(0x5b6),
                        'value': function _0x420b31() {
                            var _0x14a7ca = _0x1d57a2,
                                _0x42a78e = this;
                            platform[_0x14a7ca(0x451)]()[_0x14a7ca(0x5b9)](_0x14a7ca(0x5ba), () => {
                                var _0x14c5bb = _0x14a7ca;
                                window['yad'][_0x14c5bb(0x2bb)](0.8, 0.8), Laya[_0x14c5bb(0x2c6)][_0x14c5bb(0x3af)](window['scrollList']), Laya[_0x14c5bb(0x2c6)][_0x14c5bb(0x3af)](window[_0x14c5bb(0x583)]), window[_0x14c5bb(0x583)]['setSpaceX'](0xc8), window[_0x14c5bb(0x583)]['bottom'] = 0xc8, window['scrollList'][_0x14c5bb(0x5bb)] = 0x28, window[_0x14c5bb(0x457)]['visible'] = window[_0x14c5bb(0x583)]['visible'] = ![], window['WebAudioEngine'][_0x14c5bb(0x588)] = Laya['LocalStorage'][_0x14c5bb(0x237)](_0x14c5bb(0x58e)) ? JSON['parse'](Laya[_0x14c5bb(0x4c1)][_0x14c5bb(0x237)](_0x14c5bb(0x58e))) : ![], (fx[_0x14c5bb(0x294)][_0x14c5bb(0x203)][_0x14c5bb(0x39d)](fx[_0x14c5bb(0x466)][_0x14c5bb(0x5bc)], this, function(_0x21c30b) {
                                    var _0x537e68 = _0x14c5bb;
                                    console['log']('SDK\x20初始化完成！'), _0x42a78e[_0x537e68(0x5bd)](_0x21c30b);
                                }), Laya[_0x14c5bb(0x319)]['load']([
                                    _0x14c5bb(0x5be),
                                    _0x14c5bb(0x5bf),
                                    _0x14c5bb(0x5c0),
                                    _0x14c5bb(0x5c1),
                                    _0x14c5bb(0x5c2),
                                    _0x14c5bb(0x5c3),
                                    _0x14c5bb(0x5c4),
                                    _0x14c5bb(0x5c5)
                                ], Laya[_0x14c5bb(0x324)][_0x14c5bb(0x325)](this, () => {
                                    var _0x3a0dfc = _0x14c5bb;
                                    fx[_0x3a0dfc(0x231)][_0x3a0dfc(0x203)][_0x3a0dfc(0x270)]();
                                })));
                            });
                        }
                    },
                    {
                        'key': _0x1d57a2(0x5bd),
                        'value': function _0x150a09(_0xde913f) {
                            var _0x38e9ef = _0x1d57a2;
                            this[_0x38e9ef(0x5b5)][_0x38e9ef(0x289)] = 0x1, _0x5e5c9b[_0x38e9ef(0x203)][_0x38e9ef(0x270)](), _0x29989c[_0x38e9ef(0x203)][_0x38e9ef(0x270)](), _0x57eff4['I'][_0x38e9ef(0x270)](), Laya[_0x38e9ef(0x387)][_0x38e9ef(0x463)](this, function() {
                                var _0x5b3474 = _0x38e9ef;
                                console['log'](_0x5b3474(0x5c6)), fx[_0x5b3474(0x452)]['changeScene'](_0x1a2a5f, {
                                    'from': _0x5b3474(0x5c7)
                                }), platform[_0x5b3474(0x451)]()[_0x5b3474(0x5c8)](), platform[_0x5b3474(0x451)]()[_0x5b3474(0x5c9)](), Laya[_0x5b3474(0x2c6)][_0x5b3474(0x367)](_0x32e941);
                            });
                        }
                    }
                ]), _0x1a9c55;
            }(Laya[_0x28eca3(0x206)]),
            _0x35ce00 = function(_0x462bd3) {
                var _0x3802e5 = _0x28eca3;
                _0x10ff6e(_0x42b666, _0x462bd3);
                var _0x33529a = _0x30529b(_0x42b666);

                function _0x42b666() {
                    var _0x560345 = _0x372d;
                    return _0xaf4c50(this, _0x42b666), _0x33529a[_0x560345(0x1f4)](this, arguments);
                }
                return _0x3f3356(_0x42b666, [{
                        'key': _0x3802e5(0x1fa),
                        'value': function _0x11260f() {
                            var _0xc925f6 = _0x3802e5;
                            this[_0xc925f6(0x5ca)] = this['owner'][_0xc925f6(0x209)]('label_cnt'), this[_0xc925f6(0x5cb)] = this[_0xc925f6(0x1fe)]['getChildByName']('img_video'), this[_0xc925f6(0x1fe)]['on'](Laya[_0xc925f6(0x2ac)][_0xc925f6(0x450)], this, this[_0xc925f6(0x5cc)]), this['updateUI'](), fx[_0xc925f6(0x294)][_0xc925f6(0x203)]['on'](_0x561c5d[_0xc925f6(0x28d)], this, this[_0xc925f6(0x293)]);
                        }
                    },
                    {
                        'key': _0x3802e5(0x20c),
                        'value': function _0x359b80() {
                            var _0xc68837 = _0x3802e5;
                            fx[_0xc68837(0x294)]['instance'][_0xc68837(0x295)](this);
                        }
                    },
                    {
                        'key': _0x3802e5(0x293),
                        'value': function _0x1f210c() {
                            var _0x4f3266 = _0x3802e5,
                                _0x483b2c = _0x29989c[_0x4f3266(0x203)][_0x4f3266(0x28a)](this[_0x4f3266(0x5cd)]);
                            _0x483b2c <= 0x0 ? (this[_0x4f3266(0x5ca)][_0x4f3266(0x20b)] = !0x1, this['img_video']['visible'] = !0x0) : (this[_0x4f3266(0x5ca)][_0x4f3266(0x20b)] = !0x0, this[_0x4f3266(0x5ca)][_0x4f3266(0x210)] = '' [_0x4f3266(0x296)](_0x483b2c, '/3'), this['img_video']['visible'] = !0x1);
                        }
                    },
                    {
                        'key': _0x3802e5(0x5cc),
                        'value': function _0x324b8e() {
                            var _0x432f3f = _0x3802e5,
                                _0x246ff7 = this,
                                _0x365d41 = _0x29989c[_0x432f3f(0x203)];
                            _0x365d41['getGameState']() == _0x4d7387['E_GAME_READY'] && (_0x365d41['tryUseCnt'](this[_0x432f3f(0x5cd)], 0x1) ? (_0x365d41[_0x432f3f(0x278)](), _0x365d41[_0x432f3f(0x272)](this['gameId']), platform[_0x432f3f(0x451)]()[_0x432f3f(0x458)](), _0x365d41[_0x432f3f(0x277)](_0x4d7387['E_GAME_START'])) : _0x11e161[_0x432f3f(0x203)][_0x432f3f(0x52b)](_0x432f3f(0x5ce), this, function(_0x1c7c9a) {
                                var _0x1b3cd4 = _0x432f3f;
                                _0x1c7c9a && (_0x365d41[_0x1b3cd4(0x28e)](_0x246ff7[_0x1b3cd4(0x5cd)], 0x2), platform['getInstance']()['showLoading'](), _0x365d41[_0x1b3cd4(0x278)](), _0x365d41[_0x1b3cd4(0x272)](_0x246ff7['gameId']), _0x365d41[_0x1b3cd4(0x277)](_0x4d7387[_0x1b3cd4(0x1e4)]));
                            }));
                        }
                    }
                ]), _0x42b666;
            }(Laya[_0x28eca3(0x206)]),
            _0x4708ed, _0x14c1f9, _0x12cb7a;
        ! function(_0x5950a8) {
            var _0x1b59b6 = _0x28eca3;
            _0x5950a8[_0x1b59b6(0x5cf)] = _0x1b59b6(0x5d0), _0x5950a8['CHANGE_SCENE'] = 'changescene', _0x5950a8[_0x1b59b6(0x5d1)] = _0x1b59b6(0x5d2), _0x5950a8[_0x1b59b6(0x5d3)] = _0x1b59b6(0x5d4), _0x5950a8['CHANGE_PAGE'] = _0x1b59b6(0x5d5), _0x5950a8[_0x1b59b6(0x5d6)] = _0x1b59b6(0x5d7), _0x5950a8[_0x1b59b6(0x5d8)] = 'touch_event', _0x5950a8[_0x1b59b6(0x5d9)] = _0x1b59b6(0x5da);
        }(_0x4708ed || (_0x4708ed = {}));
        var _0x1de2da = function _0x1dfb4f() {
                _0xaf4c50(this, _0x1dfb4f);
            },
            _0x3bf6d9 = function(_0x58a89a) {
                var _0x21c056 = _0x28eca3;
                _0x10ff6e(_0x232706, _0x58a89a);
                var _0x2bac1f = _0x30529b(_0x232706);

                function _0x232706() {
                    var _0x29e4c7 = _0x372d;
                    return _0xaf4c50(this, _0x232706), _0x2bac1f[_0x29e4c7(0x1f7)](this);
                }
                return _0x3f3356(_0x232706, [{
                        'key': _0x21c056(0x344),
                        'value': function _0x5f1e88() {
                            var _0x45e6e5 = _0x21c056,
                                _0x55457f = this['owner'];
                            fx[_0x45e6e5(0x231)]['isOnWeiXin']() && fx[_0x45e6e5(0x1fb)][_0x45e6e5(0x5db)](fx[_0x45e6e5(0x231)][_0x45e6e5(0x203)][_0x45e6e5(0x5dc)]()[_0x45e6e5(0x5dd)], _0x45e6e5(0x5de)) < 0x0 ? _0x55457f['visible'] = !0x1 : (this[_0x45e6e5(0x5df)] = _0x55457f[_0x45e6e5(0x209)](_0x45e6e5(0x5df)), this[_0x45e6e5(0x5e0)] = _0x55457f[_0x45e6e5(0x209)]('changeBtn'), this['changeBtn']['on'](Laya[_0x45e6e5(0x2ac)][_0x45e6e5(0x450)], this, this[_0x45e6e5(0x5e1)]), _0x55457f['on'](Laya[_0x45e6e5(0x2ac)][_0x45e6e5(0x450)], this, function(_0x4b44a4) {
                                var _0x4d2936 = _0x45e6e5;
                                _0x4b44a4[_0x4d2936(0x2ae)]();
                            }), this[_0x45e6e5(0x5df)] && (this[_0x45e6e5(0x5df)]['renderHandler'] = new Laya[(_0x45e6e5(0x324))](this, this['cellUpdata']), this[_0x45e6e5(0x5df)][_0x45e6e5(0x5e2)] = [
                                0x0,
                                0x0,
                                0x0,
                                0x0,
                                0x0
                            ]), this[_0x45e6e5(0x5e3)]());
                        }
                    },
                    {
                        'key': _0x21c056(0x348),
                        'value': function _0x569b21() {}
                    },
                    {
                        'key': _0x21c056(0x5e1),
                        'value': function _0x2faa55() {
                            this['wx_open_data_viewerTouchEvent'](0x0, 0x0);
                        }
                    },
                    {
                        'key': _0x21c056(0x5e4),
                        'value': function _0x39aeee(_0x3c6369, _0x2a9379) {
                            var _0x50173f = _0x21c056;
                            _0x3c6369['offAll'](Laya[_0x50173f(0x2ac)]['CLICK']), _0x3c6369['on'](Laya[_0x50173f(0x2ac)][_0x50173f(0x450)], this, function(_0x5a8fb7) {
                                this['wx_open_data_viewerTouchEvent'](0x1, _0x5a8fb7);
                            }, [_0x2a9379]);
                        }
                    },
                    {
                        'key': _0x21c056(0x5e3),
                        'value': function _0x12a0ae() {
                            var _0x5e8238 = _0x21c056;
                            if (!fx['Sdk'][_0x5e8238(0x5e5)]())
                                return !0x1;
                            var _0x105039 = Laya[_0x5e8238(0x2aa)]['window']['wx'][_0x5e8238(0x275)](),
                                _0x40b7fd = new _0x1de2da(),
                                _0x37fe26 = _0x5e8238(0x5e6);
                            return Laya[_0x5e8238(0x5e7)]['sendAtlasToOpenDataContext'](_0x37fe26), _0x40b7fd[_0x5e8238(0x5e8)] = _0x4708ed[_0x5e8238(0x5d1)], _0x40b7fd[_0x5e8238(0x201)] = _0x37fe26, _0x40b7fd[_0x5e8238(0x4cf)] = _0x5e8238(0x5e9), _0x105039[_0x5e8238(0x274)](_0x40b7fd), !0x0;
                        }
                    },
                    {
                        'key': _0x21c056(0x5ea),
                        'value': function _0x170e62(_0x1f2862, _0x3f1723) {
                            var _0x494bac = _0x21c056;
                            if (!fx['Sdk'][_0x494bac(0x5e5)]())
                                return;
                            var _0x3a15e3 = Laya[_0x494bac(0x2aa)][_0x494bac(0x5eb)]['wx'][_0x494bac(0x275)](),
                                _0x5cd04a = new _0x1de2da();
                            _0x5cd04a[_0x494bac(0x5e8)] = _0x4708ed[_0x494bac(0x5d9)], _0x5cd04a[_0x494bac(0x4cf)] = _0x494bac(0x5e9), _0x5cd04a[_0x494bac(0x5ec)] = {
                                'touchType': _0x1f2862,
                                'listIndex': _0x3f1723
                            }, _0x3a15e3[_0x494bac(0x274)](_0x5cd04a);
                        }
                    }
                ]), _0x232706;
            }(Laya[_0x28eca3(0x206)]),
            _0x4f8269 = function(_0x57d00d) {
                var _0x19e82a = _0x28eca3;
                _0x10ff6e(_0x4b5758, _0x57d00d);
                var _0x36f31a = _0x30529b(_0x4b5758);

                function _0x4b5758() {
                    return _0xaf4c50(this, _0x4b5758), _0x36f31a['call'](this);
                }
                return _0x3f3356(_0x4b5758, [{
                        'key': _0x19e82a(0x344),
                        'value': function _0x1d4a8a() {
                            var _0x2095c3 = _0x19e82a,
                                _0x1b807c = this[_0x2095c3(0x1fe)],
                                _0x5a370a = new Laya[(_0x2095c3(0x5ed))](_0x1b807c['x'], _0x1b807c['y']),
                                _0x592417 = _0x1b807c[_0x2095c3(0x571)][_0x2095c3(0x5ee)](_0x5a370a),
                                _0x55e19c = 0x0,
                                _0x405060 = fx[_0x2095c3(0x231)]['instance'][_0x2095c3(0x5dc)](),
                                _0x47642c = Laya[_0x2095c3(0x266)][_0x2095c3(0x267)](_0x2095c3(0x231))[_0x2095c3(0x203)][_0x2095c3(0x5dc)]();
                            _0x405060 && _0x2095c3(0x5ef) == this['customId'] && (_0x55e19c = (_0x47642c[_0x2095c3(0x5f0)] - 0x168) / 0x2 / _0x47642c['screenWidth'] * Laya[_0x2095c3(0x2c6)][_0x2095c3(0x2ba)]);
                            var _0xc27637 = _0x592417['y'];
                            fx['Sdk'][_0x2095c3(0x203)]['showBlockAd'](this[_0x2095c3(0x5f1)], {
                                'left': _0x55e19c,
                                'top': _0xc27637
                            }, 0x0);
                        }
                    },
                    {
                        'key': _0x19e82a(0x20c),
                        'value': function _0x14a983() {
                            var _0x4bc5a9 = _0x19e82a;
                            fx[_0x4bc5a9(0x231)][_0x4bc5a9(0x203)][_0x4bc5a9(0x5f2)](this['customId']);
                        }
                    },
                    {
                        'key': _0x19e82a(0x348),
                        'value': function _0x4e88ab() {
                            var _0x3e303e = _0x19e82a;
                            fx[_0x3e303e(0x231)]['instance'][_0x3e303e(0x5f2)](this['customId']);
                        }
                    }
                ]), _0x4b5758;
            }(Laya[_0x28eca3(0x206)]),
            _0x3d6323 = function(_0x521886) {
                var _0x2a4543 = _0x28eca3;
                _0x10ff6e(_0x4bf01e, _0x521886);
                var _0x208b2d = _0x30529b(_0x4bf01e);

                function _0x4bf01e() {
                    var _0x5068eb = _0x372d;
                    return _0xaf4c50(this, _0x4bf01e), _0x208b2d[_0x5068eb(0x1f7)](this);
                }
                return _0x3f3356(_0x4bf01e, [{
                        'key': _0x2a4543(0x1fa),
                        'value': function _0x295f97() {
                            var _0xcebae6 = _0x2a4543,
                                _0x349173 = this[_0xcebae6(0x1fe)];
                            fx[_0xcebae6(0x1fb)][_0xcebae6(0x1fc)](_0x349173, 0.5, 0.5);
                            var _0x1e1b47 = _0x349173[_0xcebae6(0x1ff)];
                            new fx['Sequence']([{
                                    't': 'to',
                                    'target': _0x349173,
                                    'props': {
                                        'scaleX': _0x1e1b47 + 0.1,
                                        'scaleY': _0x1e1b47 + 0.1
                                    },
                                    'duration': 0x190,
                                    'ease': Laya[_0xcebae6(0x5f3)][_0xcebae6(0x5f4)],
                                    'complete': null,
                                    'completeArgs': null,
                                    'delay': 0x3e8
                                },
                                {
                                    't': 'to',
                                    'target': _0x349173,
                                    'props': {
                                        'scaleX': _0x1e1b47,
                                        'scaleY': _0x1e1b47
                                    },
                                    'duration': 0x190,
                                    'ease': Laya[_0xcebae6(0x5f3)][_0xcebae6(0x5f5)]
                                }
                            ], !0x0)['run']();
                        }
                    },
                    {
                        'key': _0x2a4543(0x348),
                        'value': function _0x470e20() {
                            var _0x3a0fd0 = _0x2a4543;
                            Laya[_0x3a0fd0(0x396)][_0x3a0fd0(0x4fa)](this['owner']);
                        }
                    }
                ]), _0x4bf01e;
            }(Laya[_0x28eca3(0x206)]),
            _0x47cac3 = function(_0x2df235) {
                var _0x860b36 = _0x28eca3;
                _0x10ff6e(_0x379a8b, _0x2df235);
                var _0x1df28b = _0x30529b(_0x379a8b);

                function _0x379a8b() {
                    var _0x6734d2 = _0x372d;
                    return _0xaf4c50(this, _0x379a8b), _0x1df28b[_0x6734d2(0x1f4)](this, arguments);
                }
                return _0x3f3356(_0x379a8b, [{
                        'key': _0x860b36(0x1fa),
                        'value': function _0x23df6f() {
                            var _0x5d717f = _0x860b36;
                            this[_0x5d717f(0x5f6)] = this[_0x5d717f(0x1fe)][_0x5d717f(0x209)](_0x5d717f(0x5f6)), this[_0x5d717f(0x5f7)] = this[_0x5d717f(0x1fe)][_0x5d717f(0x209)](_0x5d717f(0x5f7)), this[_0x5d717f(0x20a)] = this['owner']['getChildByName'](_0x5d717f(0x20a)), this[_0x5d717f(0x1fe)][_0x5d717f(0x209)]('box_click')['on'](Laya[_0x5d717f(0x2ac)][_0x5d717f(0x450)], this, this[_0x5d717f(0x5f8)]), this[_0x5d717f(0x293)](), fx[_0x5d717f(0x294)][_0x5d717f(0x203)]['on'](_0x1fba92['PowerChange'], this, this[_0x5d717f(0x293)]);
                        }
                    },
                    {
                        'key': _0x860b36(0x20c),
                        'value': function _0x22f4be() {
                            var _0x48d658 = _0x860b36;
                            fx[_0x48d658(0x294)][_0x48d658(0x203)][_0x48d658(0x295)](this);
                        }
                    },
                    {
                        'key': 'onClickAdd',
                        'value': function _0x2f75f7() {
                            var _0x4a338a = _0x860b36;
                            fx[_0x4a338a(0x452)][_0x4a338a(0x4a4)](_0x56a64b);
                        }
                    },
                    {
                        'key': 'updateUI',
                        'value': function _0x510418() {
                            var _0x2af2f9 = _0x860b36;
                            this[_0x2af2f9(0x5f6)]['visible'] = !0x1, this[_0x2af2f9(0x5f7)][_0x2af2f9(0x20b)] = !0x1, this[_0x2af2f9(0x20a)][_0x2af2f9(0x20b)] = !0x1;
                            var _0x141961 = _0x5c9919['I'][_0x2af2f9(0x51c)],
                                _0x5bac8f = _0x141961[_0x2af2f9(0x516)](),
                                _0x572882 = _0x5c9919['I'][_0x2af2f9(0x51c)][_0x2af2f9(0x50e)][_0x2af2f9(0x2f9)],
                                _0x18a55c = _0x5c9919['I'][_0x2af2f9(0x51c)][_0x2af2f9(0x517)];
                            if (_0x5bac8f)
                                this[_0x2af2f9(0x5f7)][_0x2af2f9(0x20b)] = !0x0, this[_0x2af2f9(0x1fe)]['clearTimer'](this, this[_0x2af2f9(0x4fc)]);
                            else {
                                if (_0x572882 > 0x0)
                                    this['label_value'][_0x2af2f9(0x289)] = '' [_0x2af2f9(0x296)](_0x572882, '/')['concat'](_0x18a55c), this[_0x2af2f9(0x5f6)][_0x2af2f9(0x20b)] = !0x0, this[_0x2af2f9(0x1fe)]['clearTimer'](this, this['updateCd']);
                                else {
                                    this[_0x2af2f9(0x20a)][_0x2af2f9(0x20b)] = !0x0;
                                    var _0x1f16b3 = Date[_0x2af2f9(0x50f)]() / 0x3e8;
                                    this['recoverCd'] = _0x141961[_0x2af2f9(0x50e)]['powerStartTime'] + _0x141961[_0x2af2f9(0x510)] - _0x1f16b3, this['recoverCd'] = Math[_0x2af2f9(0x28c)](this['recoverCd'], 0x0), this[_0x2af2f9(0x20a)]['text'] = fx['Utils']['timestampToMS'](0x3e8 * this[_0x2af2f9(0x5f9)], {
                                        'separator': [
                                            ':',
                                            ''
                                        ],
                                        'isAlign': !0x0
                                    }), this[_0x2af2f9(0x1fe)]['clearTimer'](this, this[_0x2af2f9(0x4fc)]), this['owner'][_0x2af2f9(0x40a)](0x3e8, this, this[_0x2af2f9(0x4fc)]);
                                }
                            }
                        }
                    },
                    {
                        'key': _0x860b36(0x4fc),
                        'value': function _0x4cba51() {
                            var _0x16b39f = _0x860b36;
                            this[_0x16b39f(0x5f9)]--, this[_0x16b39f(0x5f9)] = Math[_0x16b39f(0x28c)](this[_0x16b39f(0x5f9)], 0x0), this['label_cd'][_0x16b39f(0x210)] = fx[_0x16b39f(0x1fb)][_0x16b39f(0x29d)](0x3e8 * this[_0x16b39f(0x5f9)], {
                                'separator': [
                                    ':',
                                    ''
                                ],
                                'isAlign': !0x0
                            });
                        }
                    }
                ]), _0x379a8b;
            }(Laya['Script']),
            _0x14ca2e = function(_0x3f2745) {
                var _0x12ef4b = _0x28eca3;
                _0x10ff6e(_0x1dae53, _0x3f2745);
                var _0x218d21 = _0x30529b(_0x1dae53);

                function _0x1dae53() {
                    return _0xaf4c50(this, _0x1dae53), _0x218d21['call'](this);
                }
                return _0x3f3356(_0x1dae53, [{
                        'key': _0x12ef4b(0x1fa),
                        'value': function _0x4d974e() {
                            var _0x415228 = _0x12ef4b;
                            this[_0x415228(0x5fa)](_0x415228(0x217)), fx['EventCenter'][_0x415228(0x203)]['on'](fx['BaseEvent'][_0x415228(0x5fb)], this, this[_0x415228(0x5fa)]);
                        }
                    },
                    {
                        'key': _0x12ef4b(0x344),
                        'value': function _0x3980c1() {
                            var _0x3a9cd0 = _0x12ef4b,
                                _0x34ca60 = this[_0x3a9cd0(0x1fe)];
                            if (fx[_0x3a9cd0(0x452)][_0x3a9cd0(0x5fc)]()) {
                                var _0x5197a2 = (Laya[_0x3a9cd0(0x2c6)][_0x3a9cd0(0x2a8)] - Laya['stage'][_0x3a9cd0(0x5fd)]) / 0x2;
                                _0x5197a2 > 0x0 && (_0x34ca60[_0x3a9cd0(0x5fe)] = 0x32 - _0x5197a2);
                            }
                        }
                    },
                    {
                        'key': 'CoinsChange',
                        'value': function _0x9c1e54(_0x2c27c2) {
                            var _0x4a31fd = _0x12ef4b;
                            if (_0x4a31fd(0x217) === _0x2c27c2) {
                                var _0x3b7f18 = this['owner'] && this[_0x4a31fd(0x1fe)][_0x4a31fd(0x571)];
                                if (_0x3b7f18 && !_0x3b7f18[_0x4a31fd(0x31b)]) {
                                    var _0x444beb = this[_0x4a31fd(0x1fe)]['getChildByName']('coins_num');
                                    _0x444beb && (_0x444beb[_0x4a31fd(0x289)] = _0x5e5c9b[_0x4a31fd(0x203)][_0x4a31fd(0x22d)]()[_0x4a31fd(0x217)] + '');
                                }
                            }
                        }
                    },
                    {
                        'key': _0x12ef4b(0x348),
                        'value': function _0x820858() {
                            var _0x20a295 = _0x12ef4b;
                            fx[_0x20a295(0x294)][_0x20a295(0x203)][_0x20a295(0x376)](fx[_0x20a295(0x3eb)][_0x20a295(0x5fb)], this, this[_0x20a295(0x5fa)]);
                        }
                    }
                ]), _0x1dae53;
            }(Laya[_0x28eca3(0x206)]),
            _0x32e941 = function(_0x294153) {
                var _0x5860c4 = _0x28eca3;
                _0x10ff6e(_0x1a83a7, _0x294153);
                var _0x223473 = _0x30529b(_0x1a83a7);

                function _0x1a83a7() {
                    var _0x3cf445 = _0x372d,
                        _0x450dee;
                    return _0xaf4c50(this, _0x1a83a7), (_0x450dee = _0x223473[_0x3cf445(0x1f4)](this, arguments), _0x450dee[_0x3cf445(0x2a4)] = new _0xdb1a4f()), _0x450dee;
                }
                return _0x3f3356(_0x1a83a7, [{
                        'key': _0x5860c4(0x1fa),
                        'value': function _0x3dff86() {
                            var _0x27a2fb = _0x5860c4;
                            Laya[_0x27a2fb(0x2c6)]['on'](Laya['Event'][_0x27a2fb(0x5ff)], this, this[_0x27a2fb(0x600)]), Laya[_0x27a2fb(0x2c6)]['on'](Laya[_0x27a2fb(0x2ac)]['KEY_DOWN'], this, this[_0x27a2fb(0x601)]);
                        }
                    },
                    {
                        'key': _0x5860c4(0x602),
                        'value': function _0x12a39c() {}
                    },
                    {
                        'key': _0x5860c4(0x603),
                        'value': function _0x50571f(_0x4f1c08, _0x298817) {}
                    },
                    {
                        'key': 'onClickSure',
                        'value': function _0x3b66e0() {}
                    },
                    {
                        'key': _0x5860c4(0x3bc),
                        'value': function _0x354989(_0x5dc496) {}
                    },
                    {
                        'key': _0x5860c4(0x601),
                        'value': function _0x3b027(_0x380f5b) {
                            var _0x27b71b = _0x5860c4;
                            switch (_0x380f5b[_0x27b71b(0x604)]) {
                                case 0x20:
                                    this[_0x27b71b(0x3d4)]();
                                    break;
                            }
                        }
                    },
                    {
                        'key': _0x5860c4(0x600),
                        'value': function _0x171777(_0x57863a) {
                            var _0x2631c1 = _0x5860c4;
                            switch (_0x57863a[_0x2631c1(0x604)]) {
                                case 0x77:
                                    break;
                                case 0x20:
                                    break;
                                case 0x51:
                                    break;
                                default:
                                    this[_0x2631c1(0x3fb)]();
                            }
                        }
                    },
                    {
                        'key': _0x5860c4(0x29c),
                        'value': function _0x3111af() {
                            var _0x3fe52e = _0x5860c4;
                            Laya[_0x3fe52e(0x605)][_0x3fe52e(0x606)](0x57) && this[_0x3fe52e(0x607)](-0x1), Laya[_0x3fe52e(0x605)][_0x3fe52e(0x606)](0x53) && this[_0x3fe52e(0x607)](0x1), Laya[_0x3fe52e(0x605)][_0x3fe52e(0x606)](0x41) && this[_0x3fe52e(0x608)](-0x1), Laya['KeyBoardManager'][_0x3fe52e(0x606)](0x44) && this[_0x3fe52e(0x608)](0x1), Laya[_0x3fe52e(0x605)][_0x3fe52e(0x606)](0x26) && this[_0x3fe52e(0x609)](-0x1), Laya[_0x3fe52e(0x605)][_0x3fe52e(0x606)](0x28) && this[_0x3fe52e(0x609)](0x1), Laya['KeyBoardManager']['hasKeyDown'](0x25) && this['lookRight'](-0x1), Laya[_0x3fe52e(0x605)][_0x3fe52e(0x606)](0x27) && this['lookRight'](0x1);
                        }
                    },
                    {
                        'key': 'moveForward',
                        'value': function _0x5047fa(_0x355855) {
                            var _0x5f3dfc = _0x5860c4;
                            if (!fx['Utils'][_0x5f3dfc(0x60a)]() || !fx['Utils'][_0x5f3dfc(0x60a)]()['getChildByName'](_0x5f3dfc(0x490)) || !fx['Utils'][_0x5f3dfc(0x60a)]()[_0x5f3dfc(0x209)]('Player')[_0x5f3dfc(0x2c4)](_0x500c49))
                                return;
                            this[_0x5f3dfc(0x2a4)]['y'] = _0x355855, fx[_0x5f3dfc(0x1fb)][_0x5f3dfc(0x60a)]()[_0x5f3dfc(0x209)](_0x5f3dfc(0x490))[_0x5f3dfc(0x2c4)](_0x500c49)['input'][_0x5f3dfc(0x2c3)][_0x5f3dfc(0x2a4)][_0x5f3dfc(0x2b4)](this[_0x5f3dfc(0x2a4)]['x'], this[_0x5f3dfc(0x2a4)]['y']);
                        }
                    },
                    {
                        'key': _0x5860c4(0x608),
                        'value': function _0x1b3c77(_0x5e9656) {
                            var _0x216684 = _0x5860c4;
                            if (!fx[_0x216684(0x1fb)][_0x216684(0x60a)]() || !fx[_0x216684(0x1fb)][_0x216684(0x60a)]()[_0x216684(0x209)]('Player') || !fx[_0x216684(0x1fb)][_0x216684(0x60a)]()[_0x216684(0x209)](_0x216684(0x490))[_0x216684(0x2c4)](_0x500c49))
                                return;
                            this[_0x216684(0x2a4)]['x'] = _0x5e9656, fx[_0x216684(0x1fb)][_0x216684(0x60a)]()['getChildByName'](_0x216684(0x490))[_0x216684(0x2c4)](_0x500c49)['input'][_0x216684(0x2c3)][_0x216684(0x2a4)][_0x216684(0x2b4)](this[_0x216684(0x2a4)]['x'], this[_0x216684(0x2a4)]['y']);
                        }
                    },
                    {
                        'key': 'stopMove',
                        'value': function _0x1dea01() {
                            var _0x363429 = _0x5860c4;
                            if (!fx[_0x363429(0x1fb)]['getDefault3dScene']() || !fx[_0x363429(0x1fb)][_0x363429(0x60a)]()['getChildByName'](_0x363429(0x490)) || !fx[_0x363429(0x1fb)]['getDefault3dScene']()[_0x363429(0x209)](_0x363429(0x490))[_0x363429(0x2c4)](_0x500c49))
                                return;
                            this[_0x363429(0x2a4)]['setValue'](0x0, 0x0);
                            var _0x324dbd = fx[_0x363429(0x1fb)][_0x363429(0x60a)]()[_0x363429(0x209)](_0x363429(0x490))[_0x363429(0x2c4)](_0x500c49);
                            _0x324dbd['input'][_0x363429(0x2c3)][_0x363429(0x2a4)]['x'] = 0x0, _0x324dbd[_0x363429(0x2a4)][_0x363429(0x2c3)]['input']['y'] = 0x0;
                        }
                    },
                    {
                        'key': _0x5860c4(0x609),
                        'value': function _0x98ad40(_0x2f4e62) {
                            var _0x5df109 = _0x5860c4;
                            if (!fx['Utils'][_0x5df109(0x60a)]() || !fx['Utils'][_0x5df109(0x60a)]()[_0x5df109(0x209)](_0x5df109(0x490)) || !fx['Utils'][_0x5df109(0x60a)]()['getChildByName']('Player')[_0x5df109(0x2c4)](_0x500c49))
                                return;
                            fx[_0x5df109(0x1fb)][_0x5df109(0x60a)]()[_0x5df109(0x209)]('Player')[_0x5df109(0x2c4)](_0x500c49)[_0x5df109(0x2a4)][_0x5df109(0x2c5)]['moveX'] = 0xa * _0x2f4e62;
                        }
                    },
                    {
                        'key': _0x5860c4(0x60b),
                        'value': function _0x51b311(_0x3ee976) {
                            var _0x424df0 = _0x5860c4;
                            if (!fx[_0x424df0(0x1fb)][_0x424df0(0x60a)]() || !fx[_0x424df0(0x1fb)][_0x424df0(0x60a)]()[_0x424df0(0x209)](_0x424df0(0x490)) || !fx[_0x424df0(0x1fb)][_0x424df0(0x60a)]()[_0x424df0(0x209)](_0x424df0(0x490))['getComponent'](_0x500c49))
                                return;
                            fx['Utils'][_0x424df0(0x60a)]()[_0x424df0(0x209)]('Player')[_0x424df0(0x2c4)](_0x500c49)[_0x424df0(0x2a4)][_0x424df0(0x2c5)][_0x424df0(0x2b7)] = 0xa * _0x3ee976;
                        }
                    },
                    {
                        'key': _0x5860c4(0x3d4),
                        'value': function _0xe66aeb() {
                            var _0x5a64c5 = _0x5860c4;
                            if (!fx[_0x5a64c5(0x1fb)][_0x5a64c5(0x60a)]() || !fx[_0x5a64c5(0x1fb)][_0x5a64c5(0x60a)]()[_0x5a64c5(0x209)](_0x5a64c5(0x490)) || !fx[_0x5a64c5(0x1fb)][_0x5a64c5(0x60a)]()[_0x5a64c5(0x209)](_0x5a64c5(0x490))['getComponent'](_0x500c49))
                                return;
                            fx['Utils'][_0x5a64c5(0x60a)]()[_0x5a64c5(0x209)](_0x5a64c5(0x490))['getComponent'](_0x500c49)[_0x5a64c5(0x2a4)][_0x5a64c5(0x2c3)]['jump'] = !0x0;
                        }
                    }
                ]), _0x1a83a7;
            }(Laya[_0x28eca3(0x206)]),
            _0x15c900 = function(_0x301420) {
                var _0x24664b = _0x28eca3;
                _0x10ff6e(_0x26cba8, _0x301420);
                var _0x429190 = _0x30529b(_0x26cba8);

                function _0x26cba8() {
                    var _0x2d4c41 = _0x372d,
                        _0x5e2a31;
                    return _0xaf4c50(this, _0x26cba8), (_0x5e2a31 = _0x429190[_0x2d4c41(0x1f7)](this), _0x5e2a31[_0x2d4c41(0x60c)] = 0x0, _0x5e2a31[_0x2d4c41(0x60d)] = 0x78, fx['EventCenter']['instance']['on'](fx[_0x2d4c41(0x466)][_0x2d4c41(0x522)], _0x142038(_0x5e2a31), _0x5e2a31['giveRewardEvent'])), _0x5e2a31;
                }
                return _0x3f3356(_0x26cba8, [{
                        'key': _0x24664b(0x60e),
                        'get': function _0x124c78() {
                            var _0x43d4f8 = _0x24664b;
                            return this[_0x43d4f8(0x60c)];
                        },
                        'set': function _0x25a490(_0x29ac36) {
                            var _0x150ce1 = _0x24664b;
                            this[_0x150ce1(0x60c)] = _0x29ac36;
                        }
                    },
                    {
                        'key': _0x24664b(0x60d),
                        'get': function _0x446006() {
                            var _0x55c399 = _0x24664b;
                            return this[_0x55c399(0x60f)];
                        },
                        'set': function _0x27ff2c(_0x5bd213) {
                            var _0x152487 = _0x24664b;
                            this[_0x152487(0x60f)] = _0x5bd213;
                        }
                    },
                    {
                        'key': _0x24664b(0x610),
                        'value': function _0x33f428(_0x5cbac2) {
                            var _0x1e6720 = _0x24664b;
                            _0x5cbac2['code'] == fx[_0x1e6720(0x468)]['SHARE_SUCCESS'] ? Laya[_0x1e6720(0x387)]['once'](0x7d0, this, function() {
                                var _0x5d6c10 = _0x1e6720;
                                _0x5e5c9b[_0x5d6c10(0x203)][_0x5d6c10(0x22d)]()[_0x5d6c10(0x226)](0x12c), fx[_0x5d6c10(0x1fb)]['showTips'](_0x5d6c10(0x611));
                            }) : (_0x5cbac2['code'], fx[_0x1e6720(0x468)][_0x1e6720(0x612)]);
                        }
                    }
                ], [{
                    'key': _0x24664b(0x203),
                    'get': function _0x17c47f() {
                        var _0x16eb46 = _0x24664b;
                        return this[_0x16eb46(0x233)] || (this[_0x16eb46(0x233)] = new _0x26cba8()), this[_0x16eb46(0x233)];
                    }
                }]), _0x26cba8;
            }(fx['BaseEventDispatcher']);
        ! function(_0x5e4140) {
            var _0x1a7b53 = _0x28eca3;
            _0x5e4140[_0x5e4140[_0x1a7b53(0x613)] = 0x1] = _0x1a7b53(0x613), _0x5e4140[_0x5e4140[_0x1a7b53(0x614)] = 0x2] = _0x1a7b53(0x614), _0x5e4140[_0x5e4140[_0x1a7b53(0x615)] = 0x3] = _0x1a7b53(0x615);
        }(_0x14c1f9 || (_0x14c1f9 = {})),
        function(_0x4149f7) {
            var _0x5241dd = _0x28eca3;
            _0x4149f7[_0x5241dd(0x613)] = 'res/record_2.png', _0x4149f7['START_RECORD'] = _0x5241dd(0x616), _0x4149f7[_0x5241dd(0x615)] = _0x5241dd(0x617);
        }(_0x12cb7a || (_0x12cb7a = {}));
        var _0x5bb6ba = {
                'E_GAME_RECORD': _0x28eca3(0x618)
            },
            _0x305d7d;
        ! function(_0x1b4b31) {
            var _0xb8e891 = _0x28eca3;
            _0x1b4b31[_0x1b4b31[_0xb8e891(0x619)] = 0x0] = 'E_RECORD_READY', _0x1b4b31[_0x1b4b31[_0xb8e891(0x61a)] = 0x1] = _0xb8e891(0x61a), _0x1b4b31[_0x1b4b31[_0xb8e891(0x61b)] = 0x2] = _0xb8e891(0x61b), _0x1b4b31[_0x1b4b31[_0xb8e891(0x61c)] = 0x3] = _0xb8e891(0x61c), _0x1b4b31[_0x1b4b31[_0xb8e891(0x61d)] = 0x4] = _0xb8e891(0x61d);
        }(_0x305d7d || (_0x305d7d = {}));
        var _0x1d60b6 = function(_0xd11113) {
                var _0x349c7e = _0x28eca3;
                _0x10ff6e(_0x1947f4, _0xd11113);
                var _0x1f1602 = _0x30529b(_0x1947f4);

                function _0x1947f4() {
                    var _0x24d25f = _0x372d,
                        _0x1b11a3;
                    return _0xaf4c50(this, _0x1947f4), (_0x1b11a3 = _0x1f1602[_0x24d25f(0x1f7)](this), _0x1b11a3[_0x24d25f(0x3ef)] = [
                        fx[_0x24d25f(0x466)]['E_RECORD_VIDEO_START'],
                        fx['SdkEvent'][_0x24d25f(0x61e)],
                        fx[_0x24d25f(0x466)][_0x24d25f(0x61f)],
                        fx['SdkEvent'][_0x24d25f(0x620)],
                        fx['SdkEvent'][_0x24d25f(0x522)],
                        _0x5bb6ba[_0x24d25f(0x621)]
                    ], _0x1b11a3['funcName'] = [
                        'start_video',
                        _0x24d25f(0x622),
                        _0x24d25f(0x623),
                        _0x24d25f(0x624),
                        _0x24d25f(0x625),
                        _0x24d25f(0x626)
                    ], _0x1b11a3[_0x24d25f(0x413)] = !0x1), _0x1b11a3;
                }
                return _0x3f3356(_0x1947f4, [{
                        'key': _0x349c7e(0x1fa),
                        'value': function _0x8c4762() {
                            var _0x367d4d = _0x349c7e;
                            this['_owner'] = this['owner'], this[_0x367d4d(0x627)] = this[_0x367d4d(0x628)][_0x367d4d(0x209)]('shareImg'), this[_0x367d4d(0x629)] = this['_owner']['getChildByName'](_0x367d4d(0x629)), this['shareTime'][_0x367d4d(0x20b)] = !0x1, this[_0x367d4d(0x62a)] = _0x14c1f9[_0x367d4d(0x613)];
                        }
                    },
                    {
                        'key': _0x349c7e(0x344),
                        'value': function _0x262607() {
                            var _0x5417ae = _0x349c7e,
                                _0x1f0a10 = this;
                            this['_owner']['on'](Laya[_0x5417ae(0x2ac)]['CLICK'], this, function(_0x26fa8f) {
                                var _0x203855 = _0x5417ae;
                                if (_0x26fa8f[_0x203855(0x2ae)](), fx[_0x203855(0x1fb)][_0x203855(0x533)]()) {
                                    if (_0x1f0a10[_0x203855(0x62a)] == _0x14c1f9[_0x203855(0x613)])
                                        _0x1f0a10[_0x203855(0x62b)](0x78);
                                    else {
                                        if (_0x1f0a10[_0x203855(0x62a)] == _0x14c1f9[_0x203855(0x614)]) {
                                            if (_0x15c900[_0x203855(0x203)][_0x203855(0x60e)] >= _0x15c900[_0x203855(0x203)][_0x203855(0x60d)] - 0x3)
                                                return void fx[_0x203855(0x1fb)]['showTips'](_0x203855(0x62c));
                                            _0x1f0a10[_0x203855(0x622)](!0x1);
                                        } else
                                            _0x1f0a10[_0x203855(0x62a)] == _0x14c1f9[_0x203855(0x615)] && fx[_0x203855(0x294)][_0x203855(0x203)][_0x203855(0x261)](fx[_0x203855(0x466)]['E_SHARE_RESULT'], {
                                                'code': fx[_0x203855(0x468)]['SHARE_SUCCESS']
                                            });
                                    }
                                } else {
                                    if (_0x1f0a10['playStage'] == _0x14c1f9[_0x203855(0x613)])
                                        fx[_0x203855(0x231)][_0x203855(0x203)]['startRecord'](_0x15c900[_0x203855(0x203)][_0x203855(0x60d)]);
                                    else {
                                        if (_0x1f0a10['playStage'] == _0x14c1f9[_0x203855(0x614)]) {
                                            if (_0x15c900[_0x203855(0x203)]['record_time'] >= _0x15c900[_0x203855(0x203)][_0x203855(0x60d)] - 0x3)
                                                return void fx[_0x203855(0x1fb)][_0x203855(0x3a2)](_0x203855(0x62c));
                                            fx[_0x203855(0x231)][_0x203855(0x203)][_0x203855(0x62d)]();
                                        } else
                                            _0x1f0a10['playStage'] == _0x14c1f9['SUCCESS_RECORD'] && fx[_0x203855(0x231)]['instance'][_0x203855(0x46c)]();
                                    }
                                }
                            });
                            for (var _0x8878cd = 0x0; _0x8878cd < this[_0x5417ae(0x3ef)][_0x5417ae(0x27c)]; _0x8878cd++) {
                                var _0x26d315 = this[_0x5417ae(0x3ef)][_0x8878cd],
                                    _0x311264 = this['funcName'][_0x8878cd];
                                fx[_0x5417ae(0x294)][_0x5417ae(0x203)]['on'](_0x26d315, this, this[_0x311264]);
                            }
                        }
                    },
                    {
                        'key': _0x349c7e(0x20c),
                        'value': function _0x48d656() {
                            var _0x594a6f = _0x349c7e;
                            for (var _0x4cf3f9 = 0x0; _0x4cf3f9 < this['eventName']['length']; _0x4cf3f9++) {
                                var _0x1fb4e9 = this[_0x594a6f(0x3ef)][_0x4cf3f9],
                                    _0x199ee0 = this[_0x594a6f(0x62e)][_0x4cf3f9];
                                fx[_0x594a6f(0x294)][_0x594a6f(0x203)][_0x594a6f(0x376)](_0x1fb4e9, this, this[_0x199ee0]);
                            }
                            this[_0x594a6f(0x413)] || this[_0x594a6f(0x62f)]();
                        }
                    },
                    {
                        'key': _0x349c7e(0x512),
                        'value': function _0x2bfb05() {
                            var _0x5cbdc2 = _0x349c7e;
                            _0x15c900[_0x5cbdc2(0x203)][_0x5cbdc2(0x60e)] -= 0x1, this[_0x5cbdc2(0x629)]['text'] = _0x15c900[_0x5cbdc2(0x203)][_0x5cbdc2(0x60e)]['toString']() + 's', _0x15c900['instance'][_0x5cbdc2(0x60e)] <= 0x0 && (this['shareTime'][_0x5cbdc2(0x20b)] = !0x1, fx[_0x5cbdc2(0x231)]['instance'][_0x5cbdc2(0x62d)](!0x0));
                        }
                    },
                    {
                        'key': _0x349c7e(0x62b),
                        'value': function _0x52240f(_0xe35ec1) {
                            var _0x3d0e9d = _0x349c7e;
                            _0x15c900[_0x3d0e9d(0x203)][_0x3d0e9d(0x60e)] = _0x15c900[_0x3d0e9d(0x203)][_0x3d0e9d(0x60d)] = _0xe35ec1, this['shareImg'][_0x3d0e9d(0x630)] = Laya[_0x3d0e9d(0x319)]['getRes'](_0x12cb7a[_0x3d0e9d(0x614)]), this[_0x3d0e9d(0x62a)] = _0x14c1f9['START_RECORD'], this['shareTime']['text'] = _0x15c900[_0x3d0e9d(0x203)][_0x3d0e9d(0x60e)][_0x3d0e9d(0x631)]() + 's', Laya[_0x3d0e9d(0x387)][_0x3d0e9d(0x512)](0x3e8, this, this[_0x3d0e9d(0x512)]), this[_0x3d0e9d(0x629)][_0x3d0e9d(0x20b)] = !0x0;
                        }
                    },
                    {
                        'key': _0x349c7e(0x622),
                        'value': function _0x25fafb(_0x24e5f5) {
                            var _0x4c5c24 = _0x349c7e;
                            _0x15c900[_0x4c5c24(0x203)][_0x4c5c24(0x60e)] >= _0x15c900['instance'][_0x4c5c24(0x60d)] - 0x3 ? (this[_0x4c5c24(0x627)][_0x4c5c24(0x630)] = Laya[_0x4c5c24(0x319)][_0x4c5c24(0x31a)](_0x12cb7a[_0x4c5c24(0x613)]), this[_0x4c5c24(0x62a)] = _0x14c1f9[_0x4c5c24(0x613)]) : (this[_0x4c5c24(0x627)][_0x4c5c24(0x630)] = Laya[_0x4c5c24(0x319)][_0x4c5c24(0x31a)](_0x12cb7a['SUCCESS_RECORD']), this[_0x4c5c24(0x62a)] = _0x14c1f9[_0x4c5c24(0x615)]), Laya['timer']['clear'](this, this[_0x4c5c24(0x512)]), this[_0x4c5c24(0x629)]['visible'] = !0x1, _0x15c900[_0x4c5c24(0x203)][_0x4c5c24(0x60e)] = _0x15c900['instance']['maxRecordTime'], this[_0x4c5c24(0x629)]['text'] = _0x15c900['instance'][_0x4c5c24(0x60e)][_0x4c5c24(0x631)]() + 's';
                        }
                    },
                    {
                        'key': _0x349c7e(0x623),
                        'value': function _0x7b48d9() {
                            var _0x27350d = _0x349c7e;
                            Laya[_0x27350d(0x387)][_0x27350d(0x278)](this, this['loop']);
                        }
                    },
                    {
                        'key': _0x349c7e(0x624),
                        'value': function _0x3974bc() {
                            var _0xffd8cc = _0x349c7e;
                            this[_0xffd8cc(0x627)][_0xffd8cc(0x630)] = Laya['loader'][_0xffd8cc(0x31a)](_0x12cb7a[_0xffd8cc(0x614)]), this[_0xffd8cc(0x62a)] = _0x14c1f9[_0xffd8cc(0x614)], this['shareTime'][_0xffd8cc(0x210)] = _0x15c900[_0xffd8cc(0x203)][_0xffd8cc(0x60e)]['toString']() + 's', Laya[_0xffd8cc(0x387)][_0xffd8cc(0x512)](0x3e8, this, this[_0xffd8cc(0x512)]), this['shareTime'][_0xffd8cc(0x20b)] = !0x0;
                        }
                    },
                    {
                        'key': _0x349c7e(0x625),
                        'value': function _0x131cd1(_0x576c67) {
                            var _0x116802 = _0x349c7e;
                            _0x576c67[_0x116802(0x467)] == fx[_0x116802(0x468)][_0x116802(0x534)] ? (this[_0x116802(0x627)][_0x116802(0x630)] = Laya['loader'][_0x116802(0x31a)](_0x12cb7a[_0x116802(0x613)]), this[_0x116802(0x62a)] = _0x14c1f9[_0x116802(0x613)]) : (_0x576c67[_0x116802(0x467)], fx[_0x116802(0x468)][_0x116802(0x612)]);
                        }
                    },
                    {
                        'key': _0x349c7e(0x632),
                        'value': function _0x50e802() {
                            var _0x3a0c9c = _0x349c7e;
                            this[_0x3a0c9c(0x627)][_0x3a0c9c(0x630)] = Laya[_0x3a0c9c(0x319)][_0x3a0c9c(0x31a)](_0x12cb7a['NOT_RECORD']), this[_0x3a0c9c(0x62a)] = _0x14c1f9[_0x3a0c9c(0x613)], fx[_0x3a0c9c(0x231)][_0x3a0c9c(0x203)][_0x3a0c9c(0x62d)](!0x0);
                        }
                    },
                    {
                        'key': 'onGameRecordEvent',
                        'value': function _0x2c2bf3(_0x53e4d7) {
                            var _0x33b3bc = _0x349c7e,
                                _0x20fb59 = fx[_0x33b3bc(0x231)]['instance']['getSystemInfo']();
                            if (_0x53e4d7 == _0x305d7d['E_RECORD_START'] && _0x20fb59 && _0x33b3bc(0x633) == _0x20fb59[_0x33b3bc(0x634)])
                                this[_0x33b3bc(0x628)]['visible'] = !0x0;
                            else {
                                if (fx['Utils']['isOnPC']() || _0x33b3bc(0x635) !== _0x20fb59['appName'])
                                    switch (_0x53e4d7) {
                                        case _0x305d7d['E_RECORD_READY']:
                                            this[_0x33b3bc(0x632)](), console[_0x33b3bc(0x3bc)](_0x33b3bc(0x636));
                                            break;
                                        case _0x305d7d[_0x33b3bc(0x61a)]:
                                            this[_0x33b3bc(0x637)](), console[_0x33b3bc(0x3bc)](_0x33b3bc(0x638));
                                            break;
                                        case _0x305d7d[_0x33b3bc(0x61b)]:
                                            this[_0x33b3bc(0x639)](), console[_0x33b3bc(0x3bc)](_0x33b3bc(0x63a));
                                            break;
                                        case _0x305d7d[_0x33b3bc(0x61c)]:
                                            this[_0x33b3bc(0x63b)](), console[_0x33b3bc(0x3bc)](_0x33b3bc(0x63c));
                                            break;
                                        case _0x305d7d[_0x33b3bc(0x61d)]:
                                            this['isFinish'] = !0x0, this[_0x33b3bc(0x62f)](), console[_0x33b3bc(0x3bc)](_0x33b3bc(0x63d));
                                    }
                            }
                        }
                    },
                    {
                        'key': _0x349c7e(0x637),
                        'value': function _0x4be0ad() {
                            var _0x5cac59 = _0x349c7e;
                            console[_0x5cac59(0x3bc)]('playStage:', this['playStage']), this['playStage'] != _0x14c1f9['START_RECORD'] && (this[_0x5cac59(0x628)]['visible'] = !0x0, fx['Utils'][_0x5cac59(0x533)]() ? this['start_video'](0x78) : fx[_0x5cac59(0x231)][_0x5cac59(0x203)][_0x5cac59(0x63e)]());
                        }
                    },
                    {
                        'key': 'end_record',
                        'value': function _0x1772dd() {
                            var _0x39d6fc = _0x349c7e;
                            this[_0x39d6fc(0x628)]['visible'] = !0x1, this[_0x39d6fc(0x62a)] == _0x14c1f9['START_RECORD'] && (fx['Utils'][_0x39d6fc(0x533)]() ? this[_0x39d6fc(0x622)](!0x1) : fx[_0x39d6fc(0x231)][_0x39d6fc(0x203)][_0x39d6fc(0x62d)](!0x0));
                        }
                    },
                    {
                        'key': 'pause_record',
                        'value': function _0x564d55() {
                            var _0x23c73a = _0x349c7e;
                            fx[_0x23c73a(0x1fb)][_0x23c73a(0x533)]() ? this[_0x23c73a(0x623)]() : fx[_0x23c73a(0x231)]['instance'][_0x23c73a(0x63f)]();
                        }
                    },
                    {
                        'key': _0x349c7e(0x63b),
                        'value': function _0x5d4d43() {
                            var _0x53fff3 = _0x349c7e;
                            fx[_0x53fff3(0x1fb)][_0x53fff3(0x533)]() ? this[_0x53fff3(0x624)]() : fx[_0x53fff3(0x231)]['instance'][_0x53fff3(0x640)]();
                        }
                    }
                ]), _0x1947f4;
            }(Laya[_0x28eca3(0x206)]),
            _0x3a2efe = function(_0x3b9398) {
                var _0x38d3fa = _0x28eca3;
                _0x10ff6e(_0x1249e5, _0x3b9398);
                var _0x164333 = _0x30529b(_0x1249e5);

                function _0x1249e5() {
                    var _0x4708b0 = _0x372d,
                        _0xd1b0ca;
                    return _0xaf4c50(this, _0x1249e5), (_0xd1b0ca = _0x164333[_0x4708b0(0x1f7)](this), _0xd1b0ca['settingBoxSwitch'] = !0x1, _0xd1b0ca[_0x4708b0(0x641)] = !0x1, _0xd1b0ca[_0x4708b0(0x642)] = _0xd1b0ca[_0x4708b0(0x643)] = 0x1), _0xd1b0ca;
                }
                return _0x3f3356(_0x1249e5, [{
                        'key': 'onAwake',
                        'value': function _0x43d6fe() {
                            var _0x32b951 = _0x372d;
                            this[_0x32b951(0x644)] = this[_0x32b951(0x1fe)], this[_0x32b951(0x645)] = this[_0x32b951(0x644)][_0x32b951(0x209)](_0x32b951(0x646)), this[_0x32b951(0x645)][_0x32b951(0x20b)] = !0x1, this[_0x32b951(0x647)] = this['settingBox'][_0x32b951(0x209)](_0x32b951(0x648)), this['soundBtn'] = this[_0x32b951(0x644)][_0x32b951(0x209)](_0x32b951(0x649)), this[_0x32b951(0x64a)] = this[_0x32b951(0x644)][_0x32b951(0x209)](_0x32b951(0x64b)), this[_0x32b951(0x645)] && this[_0x32b951(0x647)] && this[_0x32b951(0x64c)] && this[_0x32b951(0x64a)] ? (this[_0x32b951(0x64c)][_0x32b951(0x2bb)](0x0, 0x0), this['shakeBtn'][_0x32b951(0x2bb)](0x0, 0x0), this['settingBox']['on'](Laya[_0x32b951(0x2ac)][_0x32b951(0x450)], this, this[_0x32b951(0x64d)]), this[_0x32b951(0x64c)]['on'](Laya[_0x32b951(0x2ac)]['CLICK'], this, this[_0x32b951(0x64e)]), this[_0x32b951(0x64a)]['on'](Laya[_0x32b951(0x2ac)]['CLICK'], this, this['shake_btn_listener']), this[_0x32b951(0x64f)]()) : console['warn'](_0x32b951(0x650));
                        }
                    },
                    {
                        'key': 'onDisable',
                        'value': function _0x5845e5() {
                            var _0x265247 = _0x372d;
                            this[_0x265247(0x644)][_0x265247(0x376)](Laya[_0x265247(0x2ac)][_0x265247(0x450)], this, this[_0x265247(0x64d)]), this['soundBtn']['off'](Laya['Event'][_0x265247(0x450)], this, this['sound_btn_listener']), this[_0x265247(0x64a)][_0x265247(0x376)](Laya['Event'][_0x265247(0x450)], this, this[_0x265247(0x651)]);
                        }
                    },
                    {
                        'key': _0x38d3fa(0x652),
                        'value': function _0x5bd74e(_0x57c424) {
                            var _0x33ac44 = _0x38d3fa;
                            this[_0x33ac44(0x653)] = this[_0x33ac44(0x653)] || new Laya['Timer'](), this[_0x33ac44(0x653)][_0x33ac44(0x278)](this, this['setAtionLock']), this[_0x33ac44(0x654)](!0x0), this[_0x33ac44(0x653)]['once'](_0x57c424, this, this[_0x33ac44(0x654)], [!0x1]);
                        }
                    },
                    {
                        'key': _0x38d3fa(0x654),
                        'value': function _0x3fe43(_0xb31802) {
                            var _0x34edae = _0x38d3fa;
                            this[_0x34edae(0x641)] = _0xb31802;
                        }
                    },
                    {
                        'key': 'setting_box_listener',
                        'value': function _0x1986d5(_0x447bd0) {
                            var _0x18db66 = _0x38d3fa;
                            _0x447bd0[_0x18db66(0x2ae)](), this[_0x18db66(0x655)]();
                        }
                    },
                    {
                        'key': 'trigger',
                        'value': function _0x1197cf() {
                            var _0x579f36 = _0x38d3fa,
                                _0x300957 = this;
                            this['actionLock'] || (this[_0x579f36(0x656)] ? (Laya[_0x579f36(0x396)]['to'](this['settingBoxBg'], {
                                'scaleY': this[_0x579f36(0x642)]
                            }, 0x190, Laya[_0x579f36(0x5f3)][_0x579f36(0x5f5)], Laya[_0x579f36(0x324)][_0x579f36(0x325)](this, function() {
                                var _0x1f123b = _0x579f36;
                                _0x300957[_0x1f123b(0x645)][_0x1f123b(0x20b)] = !0x1;
                            })), Laya[_0x579f36(0x396)]['to'](this[_0x579f36(0x647)], {
                                'rotation': 0x0
                            }, 0x12c), Laya[_0x579f36(0x396)]['to'](this[_0x579f36(0x64c)], {
                                'scaleX': 0x0,
                                'scaleY': 0x0
                            }, 0x12c, Laya['Ease'][_0x579f36(0x5f5)], null, 0x64), Laya[_0x579f36(0x396)]['to'](this[_0x579f36(0x64a)], {
                                'scaleX': 0x0,
                                'scaleY': 0x0
                            }, 0x12c, Laya[_0x579f36(0x5f3)][_0x579f36(0x5f5)]), this[_0x579f36(0x652)](0x190), this[_0x579f36(0x656)] = !0x1) : (this['settingBoxBg'][_0x579f36(0x20b)] = !0x0, this[_0x579f36(0x645)][_0x579f36(0x1f9)] = this[_0x579f36(0x642)], Laya[_0x579f36(0x396)]['to'](this[_0x579f36(0x645)], {
                                'scaleY': this[_0x579f36(0x643)]
                            }, 0x190, Laya[_0x579f36(0x5f3)][_0x579f36(0x5f4)]), Laya[_0x579f36(0x396)]['to'](this['settingBtnIcon'], {
                                'rotation': 0x5a
                            }, 0x12c), Laya[_0x579f36(0x396)]['to'](this['soundBtn'], {
                                'scaleX': 0x1,
                                'scaleY': 0x1
                            }, 0x12c, Laya[_0x579f36(0x5f3)][_0x579f36(0x5f4)]), Laya['Tween']['to'](this[_0x579f36(0x64a)], {
                                'scaleX': 0x1,
                                'scaleY': 0x1
                            }, 0x12c, Laya['Ease'][_0x579f36(0x5f4)], null, 0x64), this[_0x579f36(0x652)](0x190), this[_0x579f36(0x656)] = !0x0), this[_0x579f36(0x64f)]());
                        }
                    },
                    {
                        'key': 'sound_btn_listener',
                        'value': function _0x21b743(_0x4b5d0f) {
                            var _0x2eff13 = _0x38d3fa;
                            if (_0x4b5d0f[_0x2eff13(0x2ae)](), this[_0x2eff13(0x641)])
                                return;
                            var _0x5b23fd = fx[_0x2eff13(0x202)]['instance'][_0x2eff13(0x657)]();
                            this[_0x2eff13(0x64f)](), console[_0x2eff13(0x3bc)](_0x2eff13(0x658) + _0x5b23fd);
                        }
                    },
                    {
                        'key': 'shake_btn_listener',
                        'value': function _0x4cfb44(_0x385461) {
                            var _0x5a105d = _0x38d3fa;
                            if (_0x385461['stopPropagation'](), this[_0x5a105d(0x641)])
                                return;
                            var _0x13c930 = _0x5e5c9b[_0x5a105d(0x203)]['getPlayerInfo']()[_0x5a105d(0x216)] = !_0x5e5c9b[_0x5a105d(0x203)][_0x5a105d(0x22d)]()[_0x5a105d(0x216)];
                            this['refreshSelf'](), console[_0x5a105d(0x3bc)](_0x5a105d(0x659) + _0x13c930);
                        }
                    },
                    {
                        'key': _0x38d3fa(0x64f),
                        'value': function _0x21527c() {
                            var _0x4f4161 = _0x38d3fa,
                                _0x5fc886 = fx[_0x4f4161(0x202)]['instance']['getToggleSoundFxStatus'](),
                                _0x245e50 = _0x5e5c9b[_0x4f4161(0x203)]['getPlayerInfo']()[_0x4f4161(0x216)];
                            this[_0x4f4161(0x64a)][_0x4f4161(0x596)] = _0x245e50 ? _0xf611c3[_0x4f4161(0x65a)] : _0xf611c3[_0x4f4161(0x65b)], this['soundBtn'][_0x4f4161(0x596)] = _0x5fc886 ? _0xf611c3['UI_SOUND_ON_IMG'] : _0xf611c3[_0x4f4161(0x65c)];
                        }
                    }
                ]), _0x1249e5;
            }(Laya[_0x28eca3(0x206)]),
            _0x155b84 = function() {
                function _0x59db33() {
                    _0xaf4c50(this, _0x59db33);
                }
                return _0x3f3356(_0x59db33, null, [{
                    'key': 'init',
                    'value': function _0xead22e() {
                        var _0x359e45 = _0x372d,
                            _0x56d1d8 = Laya[_0x359e45(0x266)][_0x359e45(0x2e3)];
                        _0x56d1d8(_0x359e45(0x65d), _0x136e40), _0x56d1d8('script/StartCDScript.ts', _0xc00205), _0x56d1d8(_0x359e45(0x65e), _0x408f9d), _0x56d1d8(_0x359e45(0x65f), _0x107110), _0x56d1d8('script/InputScript.ts', _0x1a62ec), _0x56d1d8(_0x359e45(0x660), _0x303818), _0x56d1d8('script/Banner.ts', _0x337c61), _0x56d1d8(_0x359e45(0x661), _0x58c76d), _0x56d1d8(_0x359e45(0x662), _0x5edaf4), _0x56d1d8(_0x359e45(0x663), _0x35ce00), _0x56d1d8(_0x359e45(0x664), _0x3bf6d9), _0x56d1d8(_0x359e45(0x665), _0x4f8269), _0x56d1d8(_0x359e45(0x666), _0x1894a2), _0x56d1d8(_0x359e45(0x667), _0x3d6323), _0x56d1d8(_0x359e45(0x668), _0x47cac3), _0x56d1d8(_0x359e45(0x669), _0x14ca2e), _0x56d1d8('common/GMScript.ts', _0x32e941), _0x56d1d8('script/RecordScript.ts', _0x1d60b6), _0x56d1d8(_0x359e45(0x66a), _0x3a2efe);
                    }
                }]), _0x59db33;
            }();
        _0x155b84[_0x28eca3(0x2ba)] = 0x2ee, _0x155b84[_0x28eca3(0x2a8)] = 0x536, _0x155b84['scaleMode'] = _0x28eca3(0x66b), _0x155b84['screenMode'] = _0x28eca3(0x66c), _0x155b84[_0x28eca3(0x66d)] = 'middle', _0x155b84[_0x28eca3(0x66e)] = _0x28eca3(0x66f), _0x155b84[_0x28eca3(0x670)] = _0x28eca3(0x671), _0x155b84['sceneRoot'] = '', _0x155b84[_0x28eca3(0x672)] = !0x1, _0x155b84[_0x28eca3(0x2db)] = !0x1, _0x155b84['physicsDebug'] = !0x1, _0x155b84[_0x28eca3(0x673)] = !0x0, _0x155b84[_0x28eca3(0x270)]();
        var _0x3149c0 = null,
            _0x293aac = function() {
                var _0x5c9135 = _0x28eca3;

                function _0x5365a7() {
                    _0xaf4c50(this, _0x5365a7);
                }
                return _0x3f3356(_0x5365a7, null, [{
                        'key': _0x5c9135(0x674),
                        'value': function _0x1f0aab() {
                            var _0x8d89f1 = _0x5c9135,
                                _0x1bd7a8 = [],
                                _0x54085a = console[_0x8d89f1(0x3bc)],
                                _0x54fc08 = function _0x96b463(_0x1bbea3) {
                                    var _0x5a8026 = _0x8d89f1;
                                    for (var _0x583c4b = arguments['length'], _0x1046f1 = new Array(_0x583c4b > 0x1 ? _0x583c4b - 0x1 : 0x0), _0x4bcce1 = 0x1; _0x4bcce1 < _0x583c4b; _0x4bcce1++) {
                                        _0x1046f1[_0x4bcce1 - 0x1] = arguments[_0x4bcce1];
                                    }
                                    if (_0x3149c0) {
                                        var _0x4931cd = _0x3149c0[_0x5a8026(0x2c4)](_0x32e941);
                                        if (_0x1bd7a8[_0x5a8026(0x27c)] > 0x0) {
                                            for (var _0x6ab07b = 0x0; _0x6ab07b < _0x1bd7a8['length']; _0x6ab07b += 0x2) {
                                                var _0x43a390 = _0x1bd7a8[_0x6ab07b],
                                                    _0x16befe = _0x1bd7a8[_0x6ab07b + 0x1];
                                                _0x4931cd[_0x5a8026(0x3bc)](_0x43a390, _0x16befe);
                                            }
                                            _0x1bd7a8[_0x5a8026(0x278)]();
                                        }
                                        _0x4931cd['log'][_0x5a8026(0x1f4)](_0x4931cd, [_0x1bbea3][_0x5a8026(0x296)](_0x1046f1));
                                    } else {
                                        var _0x3b8081 = _0x523788(_0x1046f1),
                                            _0x183df9;
                                        try {
                                            for (_0x3b8081['s'](); !(_0x183df9 = _0x3b8081['n']())[_0x5a8026(0x288)];) {
                                                var _0x5b7a45 = _0x183df9[_0x5a8026(0x289)];
                                                _0x1bd7a8[_0x5a8026(0x290)](_0x1bbea3, _0x5b7a45);
                                            }
                                        } catch (_0x3d77f4) {
                                            _0x3b8081['e'](_0x3d77f4);
                                        } finally {
                                            _0x3b8081['f']();
                                        }
                                    }
                                    _0x54085a[_0x5a8026(0x1f4)](void 0x0, _0x1046f1);
                                };
                            fx[_0x8d89f1(0x1fb)]['isOnPC']() || (console['log'] = _0x54fc08[_0x8d89f1(0x304)](this, _0x8d89f1(0x675)), console[_0x8d89f1(0x676)] = _0x54fc08['bind'](this, '#FFFBE5'), console[_0x8d89f1(0x677)] = _0x54fc08[_0x8d89f1(0x304)](this, '#FF0000'));
                        }
                    },
                    {
                        'key': _0x5c9135(0x270),
                        'value': function _0xd673e() {}
                    },
                    {
                        'key': _0x5c9135(0x678),
                        'value': function _0x3b0263() {
                            var _0x13d233 = _0x5c9135;
                            Laya[_0x13d233(0x679)][_0x13d233(0x67a)]();
                        }
                    },
                    {
                        'key': _0x5c9135(0x67b),
                        'value': function _0x151334() {
                            var _0x120fa7 = _0x5c9135;
                            Laya[_0x120fa7(0x679)]['hide']();
                        }
                    },
                    {
                        'key': _0x5c9135(0x67c),
                        'value': function _0x1fdc78() {
                            var _0x221311 = _0x5c9135;
                            _0x5365a7[_0x221311(0x67d)] = !0x0;
                        }
                    },
                    {
                        'key': 'openScene',
                        'value': function _0x43da41(_0x1404e1) {
                            var _0x37abb0 = _0x5c9135,
                                _0x5a20e2 = _0x29989c[_0x37abb0(0x203)][_0x37abb0(0x26a)]()[_0x37abb0(0x253)](_0x1404e1),
                                _0xf07356 = Laya[_0x37abb0(0x266)][_0x37abb0(0x267)](_0x5a20e2['sceneName']);
                            fx['SceneManager'][_0x37abb0(0x269)](_0xf07356);
                        }
                    },
                    {
                        'key': _0x5c9135(0x67e),
                        'value': function _0x2a3556() {
                            var _0x56f8a0 = _0x5c9135,
                                _0x3866e6 = _0x29989c[_0x56f8a0(0x203)][_0x56f8a0(0x281)]();
                            for (var _0x1deb37 = _0x3866e6[_0x56f8a0(0x27c)] - 0x1; _0x1deb37 >= 0x0; --_0x1deb37) {
                                var _0x195eeb = _0x3866e6[_0x1deb37];
                                _0x195eeb[_0x56f8a0(0x209)](_0x56f8a0(0x406)) || _0x195eeb[_0x56f8a0(0x2c4)](_0x500c49)['kill']();
                            }
                        }
                    },
                    {
                        'key': 'openGuess',
                        'value': function _0x2ad2ae() {
                            var _0x5cf7f8 = _0x5c9135;
                            fx[_0x5cf7f8(0x452)]['changeScene'](_0x86f92);
                        }
                    },
                    {
                        'key': _0x5c9135(0x67f),
                        'value': function _0x3bf0bf() {
                            var _0x59c8da = _0x5c9135;
                            _0x29989c[_0x59c8da(0x203)][_0x59c8da(0x277)](_0x4d7387['E_GAME_FINISH']);
                        }
                    },
                    {
                        'key': _0x5c9135(0x680),
                        'value': function _0x4fc573() {
                            var _0x4e2ad8 = _0x5c9135;
                            fx['Utils']['getDefault3dScene']()[_0x4e2ad8(0x209)](_0x4e2ad8(0x490))[_0x4e2ad8(0x2c4)](_0x500c49)[_0x4e2ad8(0x3ea)][_0x4e2ad8(0x543)](new _0x31f777(0x0, 0x0, 0x0));
                        }
                    },
                    {
                        'key': 'fall',
                        'value': function _0x4d061b() {
                            var _0x3380e6 = _0x5c9135;
                            fx[_0x3380e6(0x1fb)]['getDefault3dScene']()[_0x3380e6(0x209)]('Player')[_0x3380e6(0x2c4)](_0x500c49)[_0x3380e6(0x3ea)][_0x3380e6(0x543)](new _0x31f777(0x0, -9.8, 0x0));
                        }
                    },
                    {
                        'key': _0x5c9135(0x681),
                        'value': function _0x138be8(_0x3ca7be) {
                            var _0x1a3be3 = _0x5c9135;
                            fx[_0x1a3be3(0x1fb)][_0x1a3be3(0x60a)]()['getChildByName']('Player')[_0x1a3be3(0x2c4)](_0x500c49)[_0x1a3be3(0x3e4)] = _0x3ca7be ? Number(_0x3ca7be) : 0xf;
                        }
                    },
                    {
                        'key': _0x5c9135(0x682),
                        'value': function _0x44ca9d() {
                            var _0x250851 = _0x5c9135;
                            fx[_0x250851(0x452)][_0x250851(0x269)](_0x2d1e39);
                        }
                    }
                ]), _0x5365a7;
            }();
        _0x293aac[_0x28eca3(0x67d)] = !0x1, new(function(_0x465608) {
            var _0x14e56e = _0x28eca3;
            _0x10ff6e(_0x3965c, _0x465608);
            var _0x36f3c7 = _0x30529b(_0x3965c);

            function _0x3965c() {
                var _0x2466e0 = _0x372d,
                    _0x3a8a7b;
                _0xaf4c50(this, _0x3965c);
                var _0x4b9d57 = _0x155b84;
                if (!_0x4b9d57[_0x2466e0(0x2db)] && fx['Utils'][_0x2466e0(0x533)]() && (_0x4b9d57[_0x2466e0(0x2db)] = !0x0), _0x4b9d57['stat'] && _0x293aac[_0x2466e0(0x674)](), fx[_0x2466e0(0x231)][_0x2466e0(0x683)](_0x13db4b), _0x3a8a7b = _0x36f3c7['call'](this, _0x4b9d57, _0x13db4b[_0x2466e0(0x2d1)]), _0x4b9d57['stat'] && _0x293aac[_0x2466e0(0x270)](), fx[_0x2466e0(0x1fb)][_0x2466e0(0x684)]() && !fx[_0x2466e0(0x1fb)]['isOnPC']() && _0x13db4b[_0x2466e0(0x2d7)]) {
                    Laya[_0x2466e0(0x685)][_0x2466e0(0x686)] = _0x13db4b[_0x2466e0(0x2d7)];
                    var _0x3d96f7 = fx[_0x2466e0(0x231)]['instance']['getMiniAdapter']();
                    _0x3d96f7 && (_0x3d96f7[_0x2466e0(0x687)] = !0x0, _0x3d96f7[_0x2466e0(0x688)] = []);
                }
                return Laya[_0x2466e0(0x689)]['multiTouchEnabled'] = !0x0, _0x141ce5(_0x3a8a7b);
            }
            return _0x3f3356(_0x3965c, [{
                    'key': _0x14e56e(0x68a),
                    'value': function _0x5cd75b() {
                        var _0x15094e = _0x14e56e,
                            _0x1c6f4e = this;
                        fx[_0x15094e(0x4c9)][_0x15094e(0x203)][_0x15094e(0x68b)](_0xf611c3['JSON_GAME_CFG'], Laya[_0x15094e(0x324)][_0x15094e(0x325)](this, function() {
                            var _0x99ce6d = _0x15094e;
                            if (console[_0x99ce6d(0x3bc)](_0x99ce6d(0x68c)), _0x1c6f4e[_0x99ce6d(0x68d)](), _0x13db4b['showBQ']) {}
                        }));
                    }
                },
                {
                    'key': _0x14e56e(0x68e),
                    'value': function _0x577126(_0x1b202a) {
                        var _0x1e3cc0 = _0x14e56e;
                        _0x58adf2(_0x5a6184(_0x3965c[_0x1e3cc0(0x2e5)]), 'initGraphicsSetting', this)['call'](this, _0x1b202a);
                    }
                }
            ]), _0x3965c;
        }(fx[_0x28eca3(0x68f)]))();
    }();
}());